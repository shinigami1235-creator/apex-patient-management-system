// Talking to the branch PC, and the records held in memory on this device.
// Every list in S mirrors a store on the server and stays current through the
// live update stream.

const STORE_NAMES = ['users', 'patients', 'visits', 'charts', 'heads', 'photos', 'services', 'products', 'lots', 'conflicts', 'tags', 'fields', 'incidents', 'presets', 'analyses', 'previews', 'transcripts', 'bookings', 'messages'];

const S = {
  me: null, user: null, clinic: null, templates: null, backup: null, voice: null, translator: null,
  lan: [], port: 4810, version: '', serverOffset: 0, online: true, stale: false,
  pending: 0, pendingOthers: [], failed: [],
};
for (const k of STORE_NAMES) S[k] = [];
const IDX = {}; // store -> Map(id -> doc)

class ApiError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const OFFLINE_MSG = 'The branch PC cannot be reached. Check the wifi and that the Apex Patient Management System is running on the PC.';

async function api(path, body, { method, headers = {}, raw = false } = {}) {
  let res;
  try {
    res = await fetch(path, {
      method: method || (body !== undefined ? 'POST' : 'GET'),
      credentials: 'same-origin',
      headers: { ...(raw ? {} : body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(typeof deviceName === 'function' && deviceName() ? { 'x-device-name': encodeURIComponent(deviceName()) } : {}), ...headers },
      body: raw ? body : body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    setOnline(false);
    throw new ApiError(0, OFFLINE_MSG);
  }
  setOnline(true);
  let data = null;
  const text = await res.text();
  try { data = text ? JSON.parse(text) : null; } catch (e) { data = { error: text }; }
  if (res.status === 401 && !['/api/login', '/api/master-reset', '/api/authorize', '/api/clock', '/api/me/pin', '/api/backup/restore'].includes(path)) { signedOut(); throw new ApiError(401, (data && data.error) || 'Sign in again.'); }
  if (!res.ok) throw new ApiError(res.status, (data && data.error) || 'Request failed.');
  return data;
}

// ---------- connection ----------
// While the branch PC is away, saves wait in a queue on this device (see below). A
// timer keeps trying the PC, and the queue goes over as soon as it answers.
let pollTimer = null;
function setOnline(v) {
  if (S.online === v) return;
  S.online = v;
  paintConnection();
  if (!v) { if (!pollTimer) pollTimer = setInterval(pollServer, 4000); }
  else { clearInterval(pollTimer); pollTimer = null; onReconnect(); }
}
async function pollServer() {
  try { const r = await fetch('/api/hello', { cache: 'no-store' }); if (r.ok) setOnline(true); } catch (e) { /* still away */ }
}
function paintConnection() {
  const b = document.getElementById('offline');
  if (b) { b.hidden = S.online && !S.pending; b.innerHTML = `${I.wifi}${S.online ? '' : 'Not connected'}${S.pending ? `${S.online ? '' : ' · '}${S.pending} waiting to sync` : ''}`; }
  const ban = document.getElementById('offline-banner');
  if (ban) ban.hidden = S.online;
  const cf = document.getElementById('conflicts-btn');
  if (cf) { const n = (S.conflicts || []).length + (S.failed || []).length; cf.hidden = !n; cf.textContent = `${n} to settle`; }
}
let reconnecting = false;
async function onReconnect() {
  if (reconnecting || !S.me) return;
  reconnecting = true;
  try {
    const sent = await syncQueue();
    if (!S.pending || sent) { await loadAll(); if (typeof startEvents === 'function') startEvents(); }
    if (sent) toast(`Connected again. ${plural(sent, 'save')} sent to the branch PC.`);
    if (typeof remoteChanged === 'function') remoteChanged('sync', true);
  } catch (e) { /* still away, the timer tries again */ }
  finally { reconnecting = false; }
}

// ---------- the offline queue ----------
// Saves made while the PC is away are kept in IndexedDB on this device, in order, with
// the record as it looked before the change. They are sent in order when the PC is back.
const QDB = 'apex-pms-offline';
let qdb = null;
function openQueue() {
  if (qdb) return qdb;
  qdb = new Promise((resolve, reject) => {
    if (!window.indexedDB) return resolve(null);
    const req = indexedDB.open(QDB, 2);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains('queue')) d.createObjectStore('queue', { keyPath: 'seq', autoIncrement: true });
      if (!d.objectStoreNames.contains('failed')) d.createObjectStore('failed', { keyPath: 'seq' });
      // Photos and signatures taken while away, kept until the branch PC has them.
      if (!d.objectStoreNames.contains('files')) d.createObjectStore('files', { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(null);
  });
  return qdb;
}
async function qAll(name) { const d = await openQueue(); if (!d) return []; return new Promise(r => { const rq = d.transaction(name).objectStore(name).getAll(); rq.onsuccess = () => r(rq.result || []); rq.onerror = () => r([]); }); }
async function qPut(name, v) { const d = await openQueue(); if (!d) return null; return new Promise(r => { const rq = d.transaction(name, 'readwrite').objectStore(name).put(v); rq.onsuccess = () => r(rq.result); rq.onerror = () => r(null); }); }
async function qDel(name, key) { const d = await openQueue(); if (!d) return; return new Promise(r => { const rq = d.transaction(name, 'readwrite').objectStore(name).delete(key); rq.onsuccess = rq.onerror = () => r(); }); }
async function refreshPending() {
  const q = await qAll('queue');
  S.pending = q.length;
  S.pendingOthers = [...new Set(q.filter(o => S.me && o.by !== S.me.id).map(o => o.byName || 'someone else'))];
  S.failed = await qAll('failed');
  paintConnection();
}

// What cannot wait in the queue, since the branch PC has to check it first.
const OFFLINE_BLOCK = { users: 'Changes to doctors and assistants', heads: '3D heads', conflicts: 'Conflict decisions' };
function offlineRefusal(store, patch) {
  if (OFFLINE_BLOCK[store]) return `Not connected. ${OFFLINE_BLOCK[store]} wait until the branch PC is back.`;
  return '';
}
// Puts a change in the queue and applies it on this device.
async function queueSave(store, id, { patch = {}, push, pull, action }) {
  const refusal = offlineRefusal(store, patch);
  if (refusal) throw new ApiError(0, refusal);
  const before = byId(store, id);
  const base = before ? Object.fromEntries(Object.entries(before).filter(([k]) => !k.startsWith('_'))) : null;
  await qPut('queue', { at: Date.now(), by: S.me.id, byName: S.me.name, store, id, patch, push, pull, action, base });
  let doc = { ...(before || {}), ...patch, id };
  for (const k of Object.keys(doc)) if (doc[k] === null) delete doc[k];
  doc = applyArrayOpsLocal(doc, push, pull);
  if (!before) { doc.created = doc.created || Date.now(); doc.createdBy = doc.createdBy || S.me.id; }
  doc._pending = true;
  putLocal(store, doc);
  await refreshPending();
  return doc;
}
function applyArrayOpsLocal(cur, push, pull) {
  const next = { ...cur };
  for (const [f, items] of Object.entries(push || {})) {
    const arr = Array.isArray(next[f]) ? [...next[f]] : [];
    for (const it of items) { const i = it && it.id ? arr.findIndex(x => x && x.id === it.id) : -1; if (i >= 0) arr[i] = it; else arr.push(it); }
    next[f] = arr;
  }
  for (const [f, ids] of Object.entries(pull || {})) next[f] = (Array.isArray(next[f]) ? next[f] : []).filter(x => !ids.includes(x && x.id));
  return next;
}
// Sends the queue in order. Entries made by someone else signed in on this device wait
// for that person. Returns how many went over.
let syncing = null;
function syncQueue() {
  if (syncing) return syncing;
  syncing = (async () => {
    let sent = 0;
    if (!(await sendWaitingFiles())) return 0;
    const q = await qAll('queue');
    for (const op of q) {
      if (!S.me || op.by !== S.me.id) continue;
      try {
        await api('/api/save', { store: op.store, id: op.id, patch: op.patch, push: op.push, pull: op.pull, action: op.action, base: op.base, offlineAt: op.at });
        await qDel('queue', op.seq);
        sent++;
      } catch (e) {
        if (e.status === 0) break;
        await qPut('failed', { ...op, error: e.message, failedAt: Date.now() });
        await qDel('queue', op.seq);
      }
    }
    await refreshPending();
    return sent;
  })();
  return syncing.finally(() => { syncing = null; });
}
async function discardFailed(seq) { await qDel('failed', seq); await refreshPending(); }
const isPending = doc => !!(doc && doc._pending);
// Warn before a reload that would lose the page while the PC is away.
if (window.addEventListener) window.addEventListener('beforeunload', e => { if (!S.online || S.pending) { e.preventDefault(); e.returnValue = ''; } });

function indexStore(store) { IDX[store] = new Map(S[store].map(d => [d.id, d])); }
function byId(store, id) { return (IDX[store] && IDX[store].get(id)) || null; }

async function loadAll() {
  const r = await api('/api/all');
  S.me = r.me; S.user = r.me;
  for (const k of STORE_NAMES) { S[k] = r.data[k] || []; indexStore(k); }
  applyMeta(r.meta || {});
  S.lan = r.lan || []; S.port = r.port; S.securePort = r.securePort || 0; S.version = r.version;
  S.serverOffset = r.serverTime - Date.now();
  await refreshPending();
  await loadLocalFiles();
}
// The camera and the microphone work only over https or on the branch PC itself. This is the
// same screen on the secure address, or '' when there is none.
function secureURL(hash = location.hash.slice(1)) {
  if (!S.securePort) return '';
  const host = location.hostname === 'localhost' || location.hostname === '127.0.0.1' ? ((S.lan && S.lan[0]) || location.hostname) : location.hostname;
  return `https://${host}:${S.securePort}/#${hash}`;
}
// Why the camera or microphone cannot be used on this device, with a way to the secure address.
function secureNote(what) {
  if (window.isSecureContext) return '';
  const u = secureURL();
  const setup = `http://${location.hostname === 'localhost' || location.hostname === '127.0.0.1' ? ((S.lan && S.lan[0]) || location.hostname) : location.hostname}:${S.port || 4810}/tablet.html`;
  return `<div class="banner">${esc(what)} needs the secure address on this device.${u ? ` <a class="btn secondary small" href="${esc(u)}">Open the secure address</a>` : ''} <a class="btn quiet small" href="${esc(setup)}">Set up this tablet</a></div>`;
}
// The clinic address tablets and phones use, with a screen in the app after it.
// Built the same way as the Devices QR under Settings.
function clinicURL(hash) {
  const ip = (S.lan && S.lan[0]) || (typeof hello !== 'undefined' && hello && hello.lan && hello.lan[0]);
  const port = S.port || (typeof hello !== 'undefined' && hello && hello.port) || 4810;
  const base = ip ? `http://${ip}:${port}` : location.origin;
  return base + '/#' + hash;
}

function applyMeta(meta) {
  for (const [k, v] of Object.entries(meta)) S[k] = v;
  S.clinic = S.clinic || {};
  S.templates = S.templates || { consent: JSON.parse(JSON.stringify(CONSENT_DEFAULTS)), aftercare: { ...AFTERCARE_DEFAULTS } };
  for (const k of ['privacy', 'photos']) if (!S.templates.consent[k]) S.templates.consent[k] = CONSENT_DEFAULTS[k];
  if (!S.templates.sheets) S.templates.sheets = JSON.parse(JSON.stringify(SHEET_DEFAULTS));
  S.voice = S.voice || {};
  S.translator = S.translator || {};
}

function putLocal(store, doc) {
  const list = S[store];
  const i = list.findIndex(d => d.id === doc.id);
  if (i >= 0) list[i] = doc; else list.push(doc);
  (IDX[store] || (IDX[store] = new Map())).set(doc.id, doc);
  if (S.me && store === 'users' && doc.id === S.me.id) { S.me = doc; S.user = doc; }
}
function dropLocal(store, id) {
  const list = S[store];
  const i = list.findIndex(d => d.id === id);
  if (i >= 0) list.splice(i, 1);
  if (IDX[store]) IDX[store].delete(id);
}

// Fields that changed between what this device last saw and the new version.
function patchOf(before, after) {
  if (!before) return after;
  const p = {};
  for (const k of new Set([...Object.keys(before), ...Object.keys(after)])) {
    if (['updated', 'updatedBy', 'created', 'createdBy'].includes(k) || k.startsWith('_')) continue;
    const a = before[k], b = after[k];
    if (JSON.stringify(a ?? null) !== JSON.stringify(b ?? null)) p[k] = b === undefined ? null : b;
  }
  return p;
}

// Saves a record. Only the changed fields go to the server, so two people editing
// different parts of the same record do not overwrite each other.
// opts: action (history label), push/pull (add or remove items in a list field), grant, pin
async function save(store, doc, opts = {}) {
  if (!doc.id) doc = { ...doc, id: uid() };
  const before = byId(store, doc.id);
  const patch = patchOf(before, doc);
  if (before && !Object.keys(patch).length && !opts.push && !opts.pull && !opts.pin) return before;
  const body = { store, id: doc.id, patch, action: opts.action, push: opts.push, pull: opts.pull, grant: opts.grant, pin: opts.pin };
  if ((!S.online || hasWaitingRef(body)) && !opts.grant && !opts.pin) { const d = await queueSave(store, doc.id, body); if (S.online) onReconnect(); return d; }
  let r;
  try { r = await api('/api/save', body); }
  catch (e) { if (e.status === 0 && !opts.grant && !opts.pin) return queueSave(store, doc.id, body); throw e; }
  if (r.doc) putLocal(store, r.doc);
  return r.doc;
}
// Adds or replaces items in a list field on the server side, so two devices adding
// payments or consents at the same moment both keep theirs.
async function pushTo(store, id, field, items, action) {
  const cur = byId(store, id);
  const body = { store, id, patch: {}, push: { [field]: items }, action };
  if (!S.online || hasWaitingRef(body)) { const d = await queueSave(store, id, body); if (S.online) onReconnect(); return d; }
  let r;
  try { r = await api('/api/save', body); }
  catch (e) { if (e.status === 0) return queueSave(store, id, body); throw e; }
  if (r.doc) putLocal(store, r.doc);
  return r.doc || cur;
}
async function pullFrom(store, id, field, ids, action) {
  const body = { store, id, patch: {}, pull: { [field]: ids }, action };
  if (!S.online) return queueSave(store, id, body);
  let r;
  try { r = await api('/api/save', body); }
  catch (e) { if (e.status === 0) return queueSave(store, id, body); throw e; }
  if (r.doc) putLocal(store, r.doc);
  return r.doc;
}
async function remove(store, id) {
  if (!S.online) throw new ApiError(0, 'Not connected. Deleting waits until the branch PC is back.');
  await api('/api/delete', { store, id });
  dropLocal(store, id);
}
async function setMeta(key, value) {
  if (!S.online) throw new ApiError(0, 'Not connected. Settings wait until the branch PC is back.');
  await api('/api/meta', { key, value });
  S[key] = value;
}
async function historyFor(patientId) { return api('/api/history?patientId=' + encodeURIComponent(patientId)); }
async function historyOf(recId) { return api('/api/history?recId=' + encodeURIComponent(recId)); }

// canWait: a photo or signature taken while the PC is away is kept on this device under a
// waiting id, shown from there, and sent before the queued saves that use it.
async function uploadFile(blob, { canWait = false } = {}) {
  if (!S.online) { if (canWait) return keepFile(blob); throw new ApiError(0, 'Not connected. This file waits until the branch PC is back.'); }
  try {
    const r = await api('/api/upload', blob, { raw: true, headers: { 'Content-Type': blob.type || 'image/jpeg' } });
    return r.fileId;
  } catch (e) { if (e.status === 0 && canWait) return keepFile(blob); throw e; }
}
const localFiles = new Map();
async function keepFile(blob) {
  const id = 'pend-' + uid() + (/png/.test(blob.type) ? '.png' : /pdf/.test(blob.type) ? '.pdf' : '.jpg');
  if (!(await qPut('files', { id, blob, type: blob.type || 'image/jpeg', at: Date.now(), by: S.me ? S.me.id : '' }))) throw new ApiError(0, 'This device cannot keep photos while away. Wait for the branch PC.');
  localFiles.set(id, URL.createObjectURL(blob));
  return id;
}
// Shows waiting photos again after the page opens.
async function loadLocalFiles() { for (const f of await qAll('files')) if (!localFiles.has(f.id)) localFiles.set(f.id, URL.createObjectURL(f.blob)); }
const hasWaitingRef = body => localFiles.size > 0 && JSON.stringify(body).includes('"pend-');
// Sends the waiting files, then swaps their waiting ids for the real ones in the queue.
async function sendWaitingFiles() {
  const files = await qAll('files');
  if (!files.length) return true;
  const swap = {};
  for (const f of files) {
    try {
      const r = await api('/api/upload', f.blob, { raw: true, headers: { 'Content-Type': f.type } });
      swap[f.id] = r.fileId;
    } catch (e) { if (e.status === 0) return false; swap[f.id] = ''; }
  }
  for (const op of await qAll('queue')) {
    let txt = JSON.stringify(op);
    if (!txt.includes('"pend-')) continue;
    for (const [a, b] of Object.entries(swap)) txt = txt.split(JSON.stringify(a)).join(JSON.stringify(b));
    await qPut('queue', JSON.parse(txt));
  }
  for (const f of files) await qDel('files', f.id);
  return true;
}
// Tells the branch PC who opened a patient's record, for the owner's access log. The PC
// keeps one entry per person and record every 10 minutes; a print is always kept.
const seenAt = new Map();
function markSeen(patientId, what = 'record') {
  if (!patientId || !S.me || !S.online) return;
  const now = Date.now();
  if (what !== 'print' && seenAt.get(patientId) && now - seenAt.get(patientId) < 10 * 60000) return;
  seenAt.set(patientId, now);
  api('/api/seen', { patientId, what }).catch(() => seenAt.delete(patientId));
}
const fileURL = id => (!id ? '' : String(id).startsWith('pend-') ? localFiles.get(id) || '' : '/files/' + encodeURIComponent(id));

// ---------- live updates ----------
let events = null;
function startEvents() {
  if (events) events.close();
  events = new EventSource('/api/events');
  events.onmessage = e => {
    let m;
    try { m = JSON.parse(e.data); } catch (err) { return; }
    if (m.reload) { location.reload(); return; }
    if (m.goto) { if (typeof onRemoteGoto === 'function') onRemoteGoto(m); return; }
    if (m.signedOut) { stopEvents(); signedOut(); return; }
    if (m.closing) { if (typeof onClosing === 'function') onClosing(m); return; }
    if (m.meta) { applyMeta({ [m.meta]: m.value }); remoteChanged(m.meta, false); return; }
    if (m.deleted) dropLocal(m.store, m.id);
    else putLocal(m.store, m.doc);
    if (!m.self) remoteChanged(m.store, true);
  };
  events.onerror = () => { setOnline(navigator.onLine && events.readyState !== 2 ? S.online : false); };
  events.onopen = () => setOnline(true);
}
function stopEvents() { if (events) { events.close(); events = null; } }

// ---------- lookups ----------
const patient = id => byId('patients', id);
const visit = id => byId('visits', id);
const product = id => byId('products', id);
const lot = id => byId('lots', id);
const service = id => byId('services', id);
const fieldDef = id => byId('fields', id);
const tagDef = id => byId('tags', id);
// Custom fields for one form, in order. Retired fields are kept out of forms and kept in
// views where the record holds a value.
function fieldsFor(target, { retired = false, role = null } = {}) {
  return S.fields.filter(f => f.target === target && (retired || !f.retired) && (!role || fieldVisible(f, role))).sort((a, b) => num(a.order) - num(b.order) || (a.label || '').localeCompare(b.label || ''));
}
// Tags in use: the central list, plus any name an older record still carries.
function tagList({ retired = false } = {}) { return S.tags.filter(t => retired || !t.retired).sort((a, b) => a.name.localeCompare(b.name)); }
function tagColor(name) { const t = S.tags.find(x => x.name === name); return t ? t.color || '' : ''; }
const userName = id => (byId('users', id) || {}).name || '';
const activeUsers = () => S.users.filter(u => !u.archived);
const doctors = () => activeUsers().filter(u => u.role === 'doctor' || (u.role === 'owner' && u.clinicalRole === 'doctor')).sort((a, b) => a.name.localeCompare(b.name));
// The doctor a new visit starts with: the signed-in doctor, else the first doctor by name.
function defaultDoctorId() {
  const docs = doctors();
  if (docs.some(d => d.id === S.me.id)) return S.me.id;
  return (docs[0] || {}).id || '';
}
const visitsOf = pid => S.visits.filter(v => v.patientId === pid).sort((a, b) => (b.date + (b.time || '')).localeCompare(a.date + (a.time || '')));
const photosOf = pid => S.photos.filter(p => p.patientId === pid).sort((a, b) => (b.date || '').localeCompare(a.date || '') || b.created - a.created);
const chartsOfVisit = vid => S.charts.filter(c => c.visitId === vid);
// What this person's role may do with a record type, with the admin's choices under Settings, People.
const accessOf = store => (S.me ? accessRule(store, S.me.role, S.access || {}) : '');
// Edit follows whether the role may change visits, since that decides whether the clinical screens open view only.
const can = what => !!(S.me && ROLES[S.me.role] && (what === 'edit' ? S.me.role === 'owner' || accessOf('visits').includes('w') : ROLES[S.me.role][what]));
const isOwner = () => !!(S.me && S.me.role === 'owner');
const productLabel = p => p ? p.name : '';
const lotLabel = l => { if (!l) return ''; const p = product(l.productId); return `${p ? p.name : ''}${l.lot ? ' · lot ' + l.lot : ''}`; };

// ---------- lots ----------
// The lot numbers of each product, kept so a chart mark records what was injected and a
// recall finds every patient who had a lot. Stock is counted in Apex's own system.
function lotUsable(l) { return !!l && !l.archived; }
function lotLeft(lotId) { return lotUsable(lot(lotId)) ? 1 : 0; }
function lotsOf(productId, { all = false } = {}) {
  return S.lots.filter(l => l.productId === productId && (all || !l.archived)).sort((a, b) => (a.expiry || '9999').localeCompare(b.expiry || '9999'));
}
// First lot to use: earliest expiry that has not expired.
function pickLot(productId) {
  const today = todayISO();
  const ok = lotsOf(productId).filter(l => !l.expiry || l.expiry >= today);
  return ok[0] || lotsOf(productId)[0] || null;
}
function stockChanged() {}
function usesOfLot(lotId) {
  const out = [];
  for (const v of S.visits) for (const t of v.treatments || []) if (t.lotId === lotId) out.push({ type: t.source === 'med' ? 'Medicine given' : 'Treatment', date: v.date, patientId: v.patientId, qty: num(t.amount), unit: t.unit, visitId: v.id, area: t.area });
  return out.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
}

// ---------- treatment lines from chart marks ----------
function linesFromMarks(marks) {
  const groups = new Map();
  for (const m of marks) {
    // A copy shows where another chart's points go; its dose is counted on that chart.
    if (!CHART_KINDS.includes(m.t) || m.copy) continue;
    const l = m.lotId ? lot(m.lotId) : null;
    const p = l ? product(l.productId) : (m.productId ? product(m.productId) : null);
    const unit = (p && p.unit) || m.unit || KINDS[m.t].unit;
    const key = [m.t, m.lotId || '', (m.product || '').toLowerCase(), unit].join('|');
    if (!groups.has(key)) groups.set(key, { kind: m.t, lotId: m.lotId || '', productId: p ? p.id : '', product: (p && p.name) || m.product || '', lot: (l && l.lot) || '', unit, amount: 0, areas: new Set(), points: 0, notes: new Set() });
    const g = groups.get(key);
    g.amount += num(m.amount); g.points++;
    if (m.area) g.areas.add(m.area);
    if (m.depth) g.notes.add(m.depth);
    if (m.technique === 'arrow') g.notes.add('Linear threading');
    if (m.technique === 'fan') g.notes.add('Fanning');
    if (m.settings) g.notes.add(m.settings);
  }
  return [...groups.entries()].map(([key, g]) => ({ id: 'c-' + key, source: 'chart', kind: g.kind, lotId: g.lotId, productId: g.productId, product: g.product, lot: g.lot, unit: g.unit,
    amount: +g.amount.toFixed(3), area: [...g.areas].join(', '), notes: [...g.notes].join('; '), points: g.points }));
}
function chartLines(visitId) { return linesFromMarks(chartsOfVisit(visitId).flatMap(c => c.marks || [])); }
async function syncChartLines(visitId) {
  const v = visit(visitId);
  if (!v) return;
  const manual = (v.treatments || []).filter(t => t.source !== 'chart');
  const prev = new Map((v.treatments || []).filter(t => t.source === 'chart').map(t => [t.id, t]));
  const lines = chartLines(visitId).map(l => (prev.get(l.id) && prev.get(l.id).price !== undefined ? { ...l, price: prev.get(l.id).price } : l));
  await save('visits', { ...v, treatments: [...lines, ...manual] }, { action: 'Treatment record updated from chart' });
  stockChanged();
}

function nextPatientNo() { return ''; }
