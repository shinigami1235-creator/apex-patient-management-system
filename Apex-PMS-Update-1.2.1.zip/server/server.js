// Apex Patient Management System hub. Runs on the branch PC, keeps the database and the photo
// files, and serves the app to every device on the clinic wifi.
'use strict';

// Test mode, on only when CLINIC_TEST_MODE is set in the environment: the clock can be
// moved with POST /api/test/clock so a test can run through several days, and a request
// may say which device it comes from with an x-test-ip header. Both are ignored otherwise.
const TEST_MODE = !!process.env.CLINIC_TEST_MODE;
if (TEST_MODE) {
  const RealDate = Date;
  let clockOffset = 0;
  global.Date = class extends RealDate {
    constructor(...a) { if (a.length) super(...a); else super(RealDate.now() + clockOffset); }
    static now() { return RealDate.now() + clockOffset; }
  };
  global.__setTestClock = ms => { clockOffset = ms - RealDate.now(); };
}

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { DatabaseSync } = require('node:sqlite');
const { ROLES, ACCESS, ACCESS_AREAS, ACCESS_LEVELS, accessRule, LIMITED_FIELDS, LIMITED_NEW, fieldVisible } = require('../app/js/roles.js');
const { APEX_PRODUCTS, APEX_SURGERY } = require('../app/js/apex-products.js');
const { INCIDENT_TYPES, INCIDENT_SEVERITY, INCIDENT_OUTCOMES, STARTER_TAGS, STARTER_FIELDS, FIELD_SECTIONS, CLINICAL_SECTIONS, FIELD_TYPES, ALL_ROLES } = require('../app/js/data.js');
const backup = require('./backup.js');
const hotspot = require('./hotspot.js');

const VERSION = JSON.parse(fs.readFileSync(path.join(__dirname, 'version.json'), 'utf8')).version;
const ROOT = path.resolve(__dirname, '..');
const APP = path.join(ROOT, 'app');
const DATA = process.env.CLINIC_DATA || path.join(ROOT, 'data');
const FILES = path.join(DATA, 'files');
const PORT = +process.env.CLINIC_PORT || 4810;
// The secure address for tablets: the next port, over https. CLINIC_HTTPS_PORT=0 turns it off.
const HTTPS_PORT = process.env.CLINIC_HTTPS_PORT !== undefined ? +process.env.CLINIC_HTTPS_PORT : PORT + 1;
const SESSION_DAYS = 14;

fs.mkdirSync(FILES, { recursive: true });

// ---------- database ----------
let db;
function openDb() {
  db = new DatabaseSync(path.join(DATA, 'clinic.db'));
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    CREATE TABLE IF NOT EXISTS docs (store TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL, updated INTEGER NOT NULL, PRIMARY KEY (store, id));
    CREATE INDEX IF NOT EXISTS docs_updated ON docs (updated);
    CREATE TABLE IF NOT EXISTS audit (id TEXT PRIMARY KEY, at INTEGER, by TEXT, byName TEXT, action TEXT, store TEXT, recId TEXT, patientId TEXT, changes TEXT);
    CREATE INDEX IF NOT EXISTS audit_patient ON audit (patientId);
    CREATE INDEX IF NOT EXISTS audit_rec ON audit (recId);
    CREATE INDEX IF NOT EXISTS audit_at ON audit (at);
    CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, userId TEXT, created INTEGER, seen INTEGER, device TEXT);
    CREATE TABLE IF NOT EXISTS access (id TEXT PRIMARY KEY, at INTEGER, by TEXT, byName TEXT, role TEXT, patientId TEXT, what TEXT, device TEXT);
    CREATE INDEX IF NOT EXISTS access_patient ON access (patientId, at);
  `);
  // Added in r12: where each signed-in device last called from, and the name it goes by.
  for (const col of ['ip TEXT', 'name TEXT']) { try { db.exec(`ALTER TABLE sessions ADD COLUMN ${col}`); } catch (e) { /* already there */ } }
}
openDb();

const q = {
  get: () => db.prepare('SELECT data FROM docs WHERE store = ? AND id = ?'),
  all: () => db.prepare('SELECT data FROM docs WHERE store = ?'),
  put: () => db.prepare('INSERT INTO docs (store, id, data, updated) VALUES (?, ?, ?, ?) ON CONFLICT (store, id) DO UPDATE SET data = excluded.data, updated = excluded.updated'),
  del: () => db.prepare('DELETE FROM docs WHERE store = ? AND id = ?'),
};
function getDoc(store, id) { const r = q.get().get(store, id); return r ? JSON.parse(r.data) : null; }
function allDocs(store) { return q.all().all(store).map(r => JSON.parse(r.data)); }
let dataVer = 0;
function putDoc(store, doc) { q.put().run(store, doc.id, JSON.stringify(doc), doc.updated || Date.now()); dataVer++; }
function getMeta(key, def = null) { const r = db.prepare('SELECT value FROM meta WHERE key = ?').get(key); return r ? JSON.parse(r.value) : def; }
function setMeta(key, value) { db.prepare('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value').run(key, JSON.stringify(value)); }
function tx(fn) { db.exec('BEGIN'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } }

const uid = () => crypto.randomUUID();
const STORES = Object.keys(ACCESS);

// ---------- PINs ----------
function hashPin(pin, salt) { return crypto.pbkdf2Sync(String(pin), Buffer.from(salt, 'base64'), 120000, 32, 'sha256').toString('base64'); }
function checkPin(user, pin) {
  if (!user || !user.pinHash) return false;
  const a = Buffer.from(hashPin(pin, user.salt), 'base64'), b = Buffer.from(user.pinHash, 'base64');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
// Wrong PINs are counted per person per device, so someone guessing from a phone
// cannot lock the owner out of the front desk PC. Each lockout doubles, up to a day.
// A device that gets many PINs wrong across different people is locked as well.
const fails = new Map(); // key -> {n, rounds, until}
const ipOf = req => (TEST_MODE && req && req.headers && req.headers['x-test-ip']) || String((req && req.socket && req.socket.remoteAddress) || '').replace(/^::ffff:/, '');
function pinWait(key) { const f = fails.get(key); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 60000) : 0; }
function pinBlocked(userId, req) { return Math.max(pinWait(userId + '@' + ipOf(req)), pinWait('ip@' + ipOf(req))); }
function bump(key, limit) {
  const f = fails.get(key) || { n: 0, rounds: 0, until: 0 };
  f.n++;
  if (f.n >= limit) { f.until = Date.now() + Math.min(5 * 60000 * 2 ** f.rounds, 86400000); f.rounds++; f.n = 0; }
  fails.set(key, f);
}
function pinFailed(userId, req) { bump(userId + '@' + ipOf(req), 5); bump('ip@' + ipOf(req), 12); }
function pinOk(userId, req) { fails.delete(userId + '@' + ipOf(req)); }
function tooMany(wait) { return new HttpError(429, `Too many wrong PINs. Try again in ${wait} minute${wait > 1 ? 's' : ''}.`); }

// ---------- sessions ----------
function newSession(userId, device, req) {
  const token = crypto.randomBytes(32).toString('base64url');
  let name = '';
  try { name = decodeURIComponent(String((req && req.headers['x-device-name']) || '')).slice(0, 40).trim(); } catch (e) { /* a bad header is no name */ }
  db.prepare('INSERT INTO sessions (token, userId, created, seen, device, ip, name) VALUES (?, ?, ?, ?, ?, ?, ?)').run(token, userId, Date.now(), Date.now(), device || '', req ? ipOf(req) : '', name);
  return token;
}
function sessionOf(req) {
  const m = /(?:^|;\s*)cc_session=([^;]+)/.exec(req.headers.cookie || '');
  if (!m) return null;
  const s = db.prepare('SELECT * FROM sessions WHERE token = ?').get(m[1]);
  if (!s || Date.now() - s.seen > SESSION_DAYS * 86400000) return null;
  const user = getDoc('users', s.userId);
  if (!user || user.archived) return null;
  if (Date.now() - s.seen > 60000 || (s.ip || '') !== ipOf(req)) db.prepare('UPDATE sessions SET seen = ?, ip = ? WHERE token = ?').run(Date.now(), ipOf(req), s.token);
  return { token: s.token, user };
}
function cookie(token, maxAge) {
  return `cc_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}

// ---------- access ----------
function rule(store, role) { return accessRule(store, role, getMeta('access', {})); }
function canRead(store, user) { return !!rule(store, user.role); }
function canWrite(store, user) { const r = rule(store, user.role); return r.includes('w') || r.includes('l'); }
const publicUser = u => {
  const { pinHash, salt, ...rest } = u;
  return rest;
};
// Trims a document to what this user may see. Returns null to hide it entirely.
function view(store, doc, user, ctx) {
  const role = user.role, r = rule(store, role);
  if (!r) return null;
  if (role === 'owner') return store === 'users' ? publicUser(doc) : doc;
  if (['services', 'products', 'users'].includes(store) && doc.custom) doc = { ...doc, custom: customFor(doc, role) };
  if (store === 'users') return publicUser(doc);
  if (r.startsWith('o')) return doc.userId === user.id ? doc : null;
  return doc;
}

// The custom field values of a record that this role may see.
function customFor(doc, role) {
  const out = {};
  for (const [k, v] of Object.entries(doc.custom || {})) { const f = getDoc('fields', k); if (f && fieldVisible(f, role)) out[k] = v; }
  return out;
}

// ---------- audit ----------
const SKIP_DIFF = new Set(['updated', 'updatedBy']);
function short(v) {
  if (v === undefined || v === null || v === '') return '';
  const s = typeof v === 'string' ? v : JSON.stringify(v);
  return s.length > 400 ? s.slice(0, 400) + '…' : s;
}
function diff(a, b) {
  const out = [];
  for (const k of new Set([...Object.keys(a || {}), ...Object.keys(b || {})])) {
    if (SKIP_DIFF.has(k)) continue;
    const x = a ? a[k] : undefined, y = b ? b[k] : undefined;
    // Custom fields go in one entry each, so the history can be trimmed to what a role sees.
    if (k === 'custom') { for (const sk of new Set([...Object.keys(x || {}), ...Object.keys(y || {})])) { const xv = (x || {})[sk], yv = (y || {})[sk]; if (JSON.stringify(xv ?? '') !== JSON.stringify(yv ?? '')) out.push({ f: 'custom.' + sk, from: short(xv), to: short(yv) }); } continue; }
    if (JSON.stringify(x ?? '') !== JSON.stringify(y ?? '')) out.push({ f: k, from: short(x), to: short(y) });
  }
  return out;
}
function patientOf(store, doc) { return store === 'patients' ? doc.id : (doc.patientId || ''); }
function audit(user, action, store, doc, changes) {
  db.prepare('INSERT INTO audit (id, at, by, byName, action, store, recId, patientId, changes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(uid(), Date.now(), user ? user.id : '', user ? user.name : 'System', action, store, doc.id, patientOf(store, doc), JSON.stringify(changes));
}

// ---------- live updates ----------
const clients = new Set(); // {res, user, token}
// A stream opened before someone's role changed, or before they were archived,
// keeps going until the page reloads, so each message checks the person again.
function liveUser(c) {
  const u = getDoc('users', c.user.id);
  if (!u || u.archived || !db.prepare('SELECT token FROM sessions WHERE token = ?').get(c.token)) { clients.delete(c); c.res.end(); return null; }
  c.user = u;
  return u;
}
function broadcast(store, doc, deleted, byToken) {
  const ctx = {};
  for (const c of clients) {
    if (!liveUser(c)) continue;
    let payload;
    if (deleted) payload = canRead(store, c.user) ? { store, id: doc.id, deleted: true } : null;
    else { const v = view(store, doc, c.user, ctx); payload = v ? { store, doc: v } : (canRead(store, c.user) ? { store, id: doc.id, deleted: true } : null); }
    if (!payload) continue;
    payload.self = c.token === byToken;
    c.res.write(`data: ${JSON.stringify(payload)}\n\n`);
  }
}
function broadcastMeta(key, value) {
  for (const c of clients) if (liveUser(c) && metaVisible(key, c.user)) c.res.write(`data: ${JSON.stringify({ meta: key, value })}\n\n`);
}
setInterval(() => { for (const c of clients) c.res.write(': ping\n\n'); }, 25000);

// ---------- counters ----------
function nextNumber(series, prefix, width) {
  const counters = getMeta('counters', {});
  counters[series] = (counters[series] || 0) + 1;
  setMeta('counters', counters);
  return prefix + String(counters[series]).padStart(width, '0');
}
// The highest number already used, so a counter never hands out a duplicate.
function seedCounter(series, store, field, prefix) {
  const counters = getMeta('counters', {});
  if (counters[series] !== undefined) return;
  let max = 0;
  for (const d of allDocs(store)) { const n = parseInt(String(d[field] || '').replace(prefix, '')); if (n > max) max = n; }
  counters[series] = max;
  setMeta('counters', counters);
}

// ---------- saving ----------
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }

const grants = new Map(); // one-time supervisor approvals
function useGrant(token, action) {
  const g = grants.get(token);
  if (!g || g.action !== action || g.until < Date.now()) return null;
  grants.delete(token);
  return g;
}

const badKey = k => typeof k !== 'string' || k.startsWith('__') || k === 'constructor' || k === 'prototype';
function applyArrayOps(cur, push, pull) {
  const next = { ...cur };
  for (const f of [...Object.keys(push || {}), ...Object.keys(pull || {})]) if (badKey(f)) throw new HttpError(400, 'Bad request.');
  for (const [f, items] of Object.entries(push || {})) {
    const arr = Array.isArray(next[f]) ? [...next[f]] : [];
    for (const it of items) { const i = it && it.id ? arr.findIndex(x => x && x.id === it.id) : -1; if (i >= 0) arr[i] = it; else arr.push(it); }
    next[f] = arr;
  }
  for (const [f, ids] of Object.entries(pull || {})) next[f] = (Array.isArray(next[f]) ? next[f] : []).filter(x => !ids.includes(x && x.id));
  return next;
}

// Writes a record the server changed on its own during someone else's save, such as
// a deposit forfeited by a no-show. It is audited and handed back for broadcast.
function sideSave(ctx, user, store, doc, action, cur) {
  doc.updated = Date.now(); doc.updatedBy = user.id;
  putDoc(store, doc);
  audit(user, action, store, doc, cur ? diff(cur, doc) : []);
  ctx.extra.push({ store, doc });
}
function sideRemove(ctx, user, store, id, action) {
  const cur = getDoc(store, id);
  if (!cur) return;
  q.del().run(store, id); dataVer++;
  audit(user, action, store, cur, []);
  ctx.extra.push({ store, doc: cur, deleted: true });
}
const todayLocal = () => localISO(new Date());

// Custom field values are checked against their definitions. Someone who may not see a
// field cannot change it, so their save keeps whatever that field held.
function checkCustom(doc, cur, user, target) {
  if (doc.custom === undefined) return;
  if (doc.custom === null || typeof doc.custom !== 'object' || Array.isArray(doc.custom)) throw new HttpError(400, 'Bad request.');
  const out = { ...((cur && cur.custom) || {}) };
  for (const [k, v] of Object.entries(doc.custom)) {
    if (badKey(k)) throw new HttpError(400, 'Bad request.');
    const f = getDoc('fields', k);
    if (!f || f.target !== target) { out[k] = v; continue; }
    if (!fieldVisible(f, user.role)) continue;
    if (v === undefined || v === null || v === '') { delete out[k]; continue; }
    if (f.type === 'number' && !(typeof v === 'number' && isFinite(v))) throw new HttpError(400, `${f.label} needs a number.`);
    if (f.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(String(v))) throw new HttpError(400, `${f.label} needs a date.`);
    if (f.type === 'yesno' && typeof v !== 'boolean') throw new HttpError(400, `${f.label} is yes or no.`);
    if (f.type === 'choice' && !(f.options || []).includes(v)) throw new HttpError(400, `${f.label}: pick one of ${(f.options || []).join(', ')}.`);
    if (f.type === 'multi' && !(Array.isArray(v) && v.every(x => (f.options || []).includes(x)))) throw new HttpError(400, `${f.label}: pick from ${(f.options || []).join(', ')}.`);
    if (['text', 'long'].includes(f.type) && typeof v !== 'string') throw new HttpError(400, `${f.label} needs text.`);
    out[k] = v;
  }
  for (const k of Object.keys(out)) { const f = getDoc('fields', k); if (f && !fieldVisible(f, user.role)) { if (cur && cur.custom && k in cur.custom) out[k] = cur.custom[k]; else delete out[k]; } }
  doc.custom = out;
}

// Every record carries the branch it was made at, and numbers carry the branch code, so two
// branches never hand out the same number when their records are joined later.
function branch() { const c = getMeta('clinic', {}) || {}; return { code: String(c.branchCode || 'AP').toUpperCase(), name: c.branchName || c.name || '' }; }
const ARRAYS_CHECKED = ['treatments', 'consents'];

// Hooks run inside the save transaction. They may change the doc before it is written.
const HOOKS = {
  patients(doc, cur, user) {
    if (!doc.no) { const b = branch(); seedCounter('patient-' + b.code, 'patients', 'no', b.code + '-'); doc.no = nextNumber('patient-' + b.code, b.code + '-', 5); }
    checkCustom(doc, cur, user, 'patients');
    if (Array.isArray(doc.tags)) doc.tags = [...new Set(doc.tags.map(t => String(t).trim()).filter(Boolean))];
    // The Apex HN is the patient's number in Apex's own EMR. Two patients never share one.
    if (doc.hn !== undefined) {
      doc.hn = String(doc.hn || '').trim().toUpperCase();
      if (doc.hn && allDocs('patients').some(p => p.id !== doc.id && String(p.hn || '').toUpperCase() === doc.hn)) throw new HttpError(409, `Another patient already has the HN ${doc.hn}.`);
    }
  },
  visits(doc, cur, user) {
    if (!doc.no) { const b = branch(); seedCounter('visit-' + b.code, 'visits', 'no', b.code + '-V'); doc.no = nextNumber('visit-' + b.code, b.code + '-V', 6); }
    checkCustom(doc, cur, user, 'visits');
    // A line sent twice keeps one copy.
    for (const f of ARRAYS_CHECKED) if (Array.isArray(doc[f])) { const seen = new Set(); doc[f] = doc[f].filter(t => { const k = t && t.id; if (!k || seen.has(k)) return false; seen.add(k); return true; }); }
    // Assistants work on a visit while it is open. A signed visit is changed by a doctor who reopens it.
    if (cur && cur.signedAt && doc.signedAt && !ROLES[user.role].sign) {
      const free = new Set(['consents', 'updated', 'updatedBy', 'followUp', 'followReason']);
      for (const k of new Set([...Object.keys(cur), ...Object.keys(doc)])) if (!free.has(k) && JSON.stringify(cur[k] ?? null) !== JSON.stringify(doc[k] ?? null)) throw new HttpError(409, 'This visit is signed. A doctor reopens it to change it.');
    }
    if (doc.signedAt && (!cur || !cur.signedAt) && !ROLES[user.role].sign) throw new HttpError(403, 'Only a doctor signs a visit.');
  },
  services(doc, cur, user) { checkCustom(doc, cur, user, 'services'); },
  products(doc, cur, user) { checkCustom(doc, cur, user, 'products'); },
  // A complication needs a patient, a type, a severity and an outcome from the lists.
  incidents(doc) {
    if (!doc.patientId || !getDoc('patients', doc.patientId)) throw new HttpError(400, 'A complication needs a patient.');
    if (!INCIDENT_TYPES.includes(doc.type)) throw new HttpError(400, 'Pick what happened.');
    if (!INCIDENT_SEVERITY.includes(doc.severity)) throw new HttpError(400, 'Pick how severe it is.');
    if (!INCIDENT_OUTCOMES.includes(doc.outcome)) throw new HttpError(400, 'Pick where it stands.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(doc.date || ''))) throw new HttpError(400, 'A complication needs a date.');
    if (doc.outcome === 'Resolved' && !doc.resolvedOn) doc.resolvedOn = doc.date > todayLocal() ? doc.date : todayLocal();
    if (doc.outcome !== 'Resolved') doc.resolvedOn = '';
  },
  // A patient's heads are numbered from 1 in build order. The number is given here so
  // two devices building at the same time cannot hand out the same one.
  heads(doc, cur) {
    if (cur) { doc.version = cur.version; return; }
    let max = 0;
    for (const h of allDocs('heads')) if (h.patientId === doc.patientId && +h.version > max) max = +h.version;
    doc.version = max + 1;
  },
  analyses(doc) { if (!doc.patientId || !getDoc('patients', doc.patientId)) throw new HttpError(400, 'A skin analysis belongs to a patient.'); },
  previews(doc) { if (!doc.patientId || !getDoc('patients', doc.patientId)) throw new HttpError(400, 'A preview belongs to a patient.'); },
  transcripts(doc) { if (!doc.patientId || !getDoc('patients', doc.patientId)) throw new HttpError(400, 'A transcript belongs to a patient.'); },
  bookings(doc, cur) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(doc.date || '') || !/^\d{2}:\d{2}$/.test(doc.time || '')) throw new HttpError(400, 'A booking needs a date and a time.');
    if (doc.patientId && !getDoc('patients', doc.patientId)) throw new HttpError(400, 'That patient is not on record.');
    if (!doc.patientId && !String(doc.name || '').trim()) throw new HttpError(400, 'A booking needs a patient or a name.');
    if (!['booked', 'confirmed', 'arrived', 'done', 'noshow', 'cancelled'].includes(doc.status || 'booked')) throw new HttpError(400, 'Unknown booking status.');
    doc.status = doc.status || 'booked';
    doc.mins = Math.max(5, Math.min(480, +doc.mins || 30));
    if (!cur) doc.created = doc.created || Date.now();
  },
  // Renaming a tag renames it on every patient. Merging moves every patient of this tag
  // onto the target and retires this one.
  tags(doc, cur, user, opts, ctx) {
    doc.name = String(doc.name || '').trim();
    if (!doc.name) throw new HttpError(400, 'A tag needs a name.');
    if (allDocs('tags').some(t => t.id !== doc.id && !t.retired && t.name.toLowerCase() === doc.name.toLowerCase() && !doc.retired)) throw new HttpError(409, `There is already a tag called ${doc.name}.`);
    const renameOn = (from, to) => {
      for (const p of allDocs('patients')) {
        const tags = Array.isArray(p.tags) ? p.tags : [];
        if (!tags.includes(from)) continue;
        const next = [...new Set(tags.map(t => (t === from ? to : t)).filter(Boolean))];
        sideSave(ctx, user, 'patients', { ...p, tags: next }, to ? `Tag renamed: ${from} to ${to}` : `Tag removed: ${from}`, p);
      }
    };
    if (doc.mergeInto) {
      const target = getDoc('tags', doc.mergeInto);
      if (!target || target.id === doc.id) throw new HttpError(400, 'Pick the tag to merge into.');
      renameOn(cur ? cur.name : doc.name, target.name);
      doc.retired = true; doc.mergedInto = target.name; delete doc.mergeInto;
      return;
    }
    if (cur && cur.name !== doc.name) renameOn(cur.name, doc.name);
  },
  fields(doc, cur, user) {
    doc.label = String(doc.label || '').trim();
    if (!doc.label) throw new HttpError(400, 'A field needs a label.');
    if (!FIELD_SECTIONS[doc.target]) throw new HttpError(400, 'Pick where the field goes.');
    if (!FIELD_TYPES.some(t => t[0] === doc.type)) throw new HttpError(400, 'Pick the field type.');
    doc.section = String(doc.section || '').trim() || FIELD_SECTIONS[doc.target][0][0];
    if (CLINICAL_SECTIONS.includes(doc.section)) doc.clinical = true;
    doc.roles = (Array.isArray(doc.roles) ? doc.roles : []).filter(r => ALL_ROLES.includes(r));
    if (!doc.roles.includes('owner')) doc.roles.unshift('owner');
    if (['choice', 'multi'].includes(doc.type)) { doc.options = (Array.isArray(doc.options) ? doc.options : String(doc.options || '').split('\n')).map(o => String(o).trim()).filter(Boolean); if (!doc.options.length) throw new HttpError(400, 'A choice field needs its choices, one per line.'); }
    if (allDocs('fields').some(f => f.id !== doc.id && f.target === doc.target && !f.retired && !doc.retired && f.label.toLowerCase() === doc.label.toLowerCase())) throw new HttpError(409, `There is already a field called ${doc.label}.`);
  },
  users(doc, cur, user) {
    checkCustom(doc, cur, user, 'users');
    if (!ROLES[doc.role]) throw new HttpError(400, 'Pick the role.');
    if (cur && cur.role === 'owner' && !cur.archived && (doc.role !== 'owner' || doc.archived) && allDocs('users').filter(u => u.role === 'owner' && !u.archived).length < 2) throw new HttpError(409, 'The branch needs at least one admin.');
  },
};

function save(user, store, body, sessionToken) {
  if (!STORES.includes(store)) throw new HttpError(404, 'Unknown record type.');
  if (!canWrite(store, user)) throw new HttpError(403, 'Your role cannot change this.');
  const r = rule(store, user.role);
  return tx(() => {
    const id = body.id || (body.doc && body.doc.id) || uid();
    const cur = getDoc(store, id);
    let patch = body.patch || body.doc || {};
    if (Object.keys(patch).some(badKey)) throw new HttpError(400, 'Bad request.');
    if (r.includes('l') && !r.includes('w')) {
      const allowed = LIMITED_FIELDS[store] || [];
      const fresh = ['id', 'patientId', 'date', 'time', 'type', ...(LIMITED_NEW[store] || [])];
      patch = Object.fromEntries(Object.entries(patch).filter(([k]) => allowed.includes(k) || (!cur && fresh.includes(k))));
      for (const ops of [body.push, body.pull]) for (const f of Object.keys(ops || {})) if (!allowed.includes(f)) throw new HttpError(403, 'Your role cannot change this.');
    }
    if (store !== 'users') delete patch.no; // numbers come from the server
    if (r.startsWith('o') && cur && cur.userId !== user.id) throw new HttpError(403, 'That record belongs to someone else.');
    for (const k of Object.keys(patch)) if (k.startsWith('_')) delete patch[k]; // device-only markers
    // A save made while a device was away carries the record as that device last had it.
    // Fields the server changed since then, and this device changed differently, are
    // kept aside as conflicts for a person to decide, and the rest go in.
    const conflicts = [];
    if (body.base && typeof body.base === 'object' && cur && cur.updated !== body.base.updated) {
      const base = body.base, merged = {};
      for (const [k, v] of Object.entries(patch)) {
        const curV = JSON.stringify(cur[k] ?? null), baseV = JSON.stringify(base[k] ?? null), mineV = JSON.stringify(v ?? null);
        if (curV === baseV || curV === mineV || k === 'id') merged[k] = v;
        else conflicts.push({ id: uid(), store, recId: id, field: k, mine: v ?? null, theirs: cur[k] ?? null, theirsBy: cur.updatedBy || '', theirsAt: cur.updated || 0, userId: user.id, byName: user.name, at: Date.now(), patientId: patientOf(store, cur), label: String(cur.name || cur.no || cur.date || '') });
      }
      patch = merged;
    }
    let doc = { ...(cur || {}), ...patch, id };
    for (const k of Object.keys(doc)) if (doc[k] === null && patch[k] === null) delete doc[k];
    doc = applyArrayOps(doc, body.push, body.pull);
    if (store === 'users') {
      if (body.pin) {
        if (!/^\d{4,8}$/.test(body.pin)) throw new HttpError(400, 'The PIN needs 4 to 8 digits.');
        doc.salt = crypto.randomBytes(16).toString('base64'); doc.pinHash = hashPin(body.pin, doc.salt); doc.pinLen = body.pin.length;
      }
      if (cur) { if (!body.pin) { doc.salt = cur.salt; doc.pinHash = cur.pinHash; } }
      else if (!body.pin) throw new HttpError(400, 'A new team member needs a PIN.');
    }
    const ctx = { extra: [] };
    if (HOOKS[store]) HOOKS[store](doc, cur, user, body, ctx);
    for (const c of conflicts) { putDoc('conflicts', c); audit(user, `Sync conflict on ${c.field}`, 'conflicts', c, []); ctx.extra.push({ store: 'conflicts', doc: c }); }
    const now = Date.now();
    doc.updated = now; doc.updatedBy = user.id;
    if (!cur) { doc.created = doc.created || now; doc.createdBy = doc.createdBy || user.id; }
    const changes = diff(cur && store === 'users' ? publicUser(cur) : cur, store === 'users' ? publicUser(doc) : doc);
    if (cur && !changes.length) return { doc: cur, unchanged: true, extra: ctx.extra, conflicts };
    putDoc(store, doc);
    audit(user, body.action || (cur ? 'Edited' : 'Added'), store, doc, cur ? changes : []);
    return { doc, extra: ctx.extra, conflicts };
  });
}

function remove(user, store, id) {
  if (!STORES.includes(store)) throw new HttpError(404, 'Unknown record type.');
  if (!canWrite(store, user) || rule(store, user.role).includes('l') && !rule(store, user.role).includes('w')) throw new HttpError(403, 'Your role cannot delete this.');
  return tx(() => {
    const cur = getDoc(store, id);
    if (!cur) return null;
    if (rule(store, user.role).startsWith('o') && cur.userId !== user.id) throw new HttpError(403, 'That record belongs to someone else.');
    if (store === 'users') throw new HttpError(409, 'Doctors and assistants are archived rather than deleted.');
    if (store === 'visits' && cur.signedAt) throw new HttpError(409, 'A signed visit is kept. Reopen it to change it.');
    if (store === 'patients' && allDocs('visits').some(v => v.patientId === id)) throw new HttpError(409, 'A patient with visits is kept.');
    if (store === 'heads' && allDocs('charts').some(c => c.base && c.base.headId === id)) throw new HttpError(409, 'A chart is drawn on this head.');
    if (store === 'tags' && allDocs('patients').some(p => (p.tags || []).includes(cur.name))) throw new HttpError(409, `${cur.name} is on a patient. Retire it or merge it instead.`);
    if (store === 'fields' && allDocs(cur.target || 'patients').some(d => d.custom && d.custom[cur.id] !== undefined && d.custom[cur.id] !== '')) throw new HttpError(409, `${cur.label} holds values on a record. Retire it instead.`);
    q.del().run(store, id); dataVer++;
    audit(user, 'Deleted', store, cur, diff(cur, null));
    if (store === 'photos') for (const f of [cur.fileId, cur.thumbId]) if (f) fs.rm(path.join(FILES, f), () => {});
    if (store === 'heads') for (const f of headFiles(cur)) fs.rm(path.join(FILES, f), () => {});
    return cur;
  });
}

// ---------- meta (settings) ----------
const META_PUBLIC = ['clinic', 'templates', 'voice', 'translator', 'spots', 'phrases', 'access'];
function metaVisible(key, user) { return user.role === 'owner' || META_PUBLIC.includes(key); }
const META_KEYS = ['clinic', 'templates', 'backup', 'voice', 'translator', 'hotspot', 'spots', 'phrases', 'line', 'access'];
// Settings the doctors keep themselves: the template spots and the note phrases.
const DOCTOR_META = ['spots', 'phrases'];

// ---------- HTTP helpers ----------
function send(res, code, body, headers = {}) {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': typeof body === 'object' && !Buffer.isBuffer(body) ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(data);
}
function readBody(req, limit = 4 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { reject(new HttpError(413, 'Too large.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function json(req) {
  const b = await readBody(req);
  if (!b.length) return {};
  try { return JSON.parse(b.toString('utf8')); } catch (e) { throw new HttpError(400, 'Bad request.'); }
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.task': 'application/octet-stream', '.bin': 'application/octet-stream' };
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(APP, rel));
  if (!file.startsWith(APP)) return send(res, 403, 'Forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found');
    const ext = path.extname(file);
    // The 3D libraries under vendor are large and change only with the app, so they are kept for a week.
    const cache = rel.startsWith('/vendor/') ? 'max-age=604800' : ['.html', '.js', '.mjs', '.css'].includes(ext) ? 'no-cache' : 'max-age=86400';
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache });
    fs.createReadStream(file).pipe(res);
  });
}

// The laptop's own hotspot address comes first: it never changes, so its QR keeps working.
function lanAddresses() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push({ name, address: a.address });
  return out.sort((a, b) => (b.address === hotspot.HOTSPOT_IP) - (a.address === hotspot.HOTSPOT_IP));
}

// ---------- routes ----------
const routes = {};
const route = (method, p, fn, { auth = true } = {}) => { routes[method + ' ' + p] = { fn, auth }; };

route('GET', '/api/hello', (req, res) => {
  const clinic = getMeta('clinic');
  const users = allDocs('users').filter(u => !u.archived).map(u => ({ id: u.id, name: u.name, role: u.role, title: u.title || '', pinLen: u.pinLen || 0, photo: u.photo || '', lang: u.lang || '' }));
  send(res, 200, { version: VERSION, ready: !!clinic, clinic: clinic ? { name: clinic.name, branchName: clinic.branchName || '', logo: clinic.logo || '' } : null, users, lan: lanAddresses().map(a => a.address), port: PORT, securePort: secureUp ? HTTPS_PORT : 0, signedIn: !!(clinic && sessionOf(req)) });
}, { auth: false });

route('POST', '/api/setup', async (req, res) => {
  if (getMeta('clinic')) throw new HttpError(409, 'The clinic is already set up.');
  const b = await json(req);
  if (!b.clinic || !b.clinic.name || !b.owner || !/^\d{4,8}$/.test(b.pin || '')) throw new HttpError(400, 'Fill in the clinic name, your name and a 4 to 8 digit PIN.');
  const salt = crypto.randomBytes(16).toString('base64');
  const user = { id: uid(), name: b.owner.name, nameTh: b.owner.nameTh || '', role: 'owner', licence: b.owner.licence || '', title: b.owner.title || '', clinicalRole: b.owner.clinicalRole === 'none' ? 'none' : 'doctor', salt, pinHash: hashPin(b.pin, salt), pinLen: b.pin.length, created: Date.now(), updated: Date.now() };
  tx(() => {
    setMeta('clinic', { currency: '฿', lockMinutes: 10, dateEra: 'be', ...b.clinic, branchCode: String((b.clinic && b.clinic.branchCode) || 'AP').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'AP' });
    if (b.templates) setMeta('templates', b.templates);
    putDoc('users', user);
    audit(user, 'Clinic set up', 'users', user, []);
  });
  seedStarters(user);
  const token = newSession(user.id, req.headers['user-agent'], req);
  send(res, 200, { ok: true }, { 'Set-Cookie': cookie(token, SESSION_DAYS * 86400) });
}, { auth: false });

route('POST', '/api/login', async (req, res) => {
  const b = await json(req);
  const user = getDoc('users', b.userId);
  if (!user || user.archived) throw new HttpError(404, 'Unknown team member.');
  const wait = pinBlocked(user.id, req);
  if (wait) throw tooMany(wait);
  if (!checkPin(user, b.pin)) { pinFailed(user.id, req); throw new HttpError(401, 'Wrong PIN.'); }
  pinOk(user.id, req);
  const old = sessionOf(req);
  if (old) db.prepare('DELETE FROM sessions WHERE token = ?').run(old.token);
  const token = newSession(user.id, req.headers['user-agent'], req);
  send(res, 200, { ok: true }, { 'Set-Cookie': cookie(token, SESSION_DAYS * 86400) });
}, { auth: false });

route('POST', '/api/logout', (req, res, s) => {
  db.prepare('DELETE FROM sessions WHERE token = ?').run(s.token);
  send(res, 200, { ok: true }, { 'Set-Cookie': cookie('', 0) });
});


// The signed-in person's own screen language.
route('POST', '/api/me/lang', async (req, res, s) => {
  const b = await json(req);
  if (!['th', 'en'].includes(b.lang)) throw new HttpError(400, 'Pick Thai or English.');
  const user = getDoc('users', s.user.id);
  const doc = { ...user, lang: b.lang, updated: Date.now(), updatedBy: user.id };
  tx(() => { putDoc('users', doc); audit(user, 'Screen language changed', 'users', doc, diff(publicUser(user), publicUser(doc))); });
  broadcast('users', doc, false, s.token);
  send(res, 200, { ok: true });
});

// Changes the signed-in person's own PIN.
route('POST', '/api/me/pin', async (req, res, s) => {
  const b = await json(req);
  const user = getDoc('users', s.user.id);
  const wait = pinBlocked(user.id, req);
  if (wait) throw tooMany(wait);
  if (!checkPin(user, b.old)) { pinFailed(user.id, req); throw new HttpError(401, 'The current PIN is wrong.'); }
  pinOk(user.id, req);
  if (!/^\d{4,8}$/.test(b.pin || '')) throw new HttpError(400, 'The PIN needs 4 to 8 digits.');
  const salt = crypto.randomBytes(16).toString('base64');
  const doc = { ...user, salt, pinHash: hashPin(b.pin, salt), pinLen: b.pin.length, updated: Date.now(), updatedBy: user.id };
  tx(() => { putDoc('users', doc); audit(user, 'PIN changed', 'users', doc, []); });
  broadcast('users', doc, false, s.token);
  send(res, 200, { ok: true });
});

// The master key sets a new PIN for anyone, the admin included, when a PIN is forgotten.
// It works only on the branch PC, behind five taps on the sign-in logo or on the photo above the PIN pad.
// The update files are public, so only a check value of the key is kept here.
const MASTER_KEY = { salt: 'dUDHwBWSSSQDo/+qoxsRZg==', hash: '+90VLTFEjQjlGW0rbi4ROpf5XRQxRNnNVH5SzW4y2yY=' };
route('POST', '/api/master-reset', async (req, res) => {
  if (!onThisPC(req)) throw new HttpError(403, 'The master key works only on the branch PC.');
  const b = await json(req);
  const key = 'master@' + ipOf(req), wait = pinWait(key);
  if (wait) throw new HttpError(429, `Too many wrong master keys. Try again in ${wait} minute${wait > 1 ? 's' : ''}.`);
  const a = Buffer.from(hashPin(String(b.key || '').slice(0, 200), MASTER_KEY.salt), 'base64'), h = Buffer.from(MASTER_KEY.hash, 'base64');
  if (!(a.length === h.length && crypto.timingSafeEqual(a, h))) { bump(key, 5); throw new HttpError(401, 'Wrong master key.'); }
  fails.delete(key);
  const user = getDoc('users', b.userId);
  if (!user || user.archived) throw new HttpError(404, 'Unknown team member.');
  if (!/^\d{4,8}$/.test(b.pin || '')) throw new HttpError(400, 'The PIN needs 4 to 8 digits.');
  const salt = crypto.randomBytes(16).toString('base64');
  const doc = { ...user, salt, pinHash: hashPin(b.pin, salt), pinLen: b.pin.length, updated: Date.now(), updatedBy: user.id };
  for (const k of [...fails.keys()]) if (k.startsWith(user.id + '@') || k.startsWith('ip@')) fails.delete(k);
  tx(() => { putDoc('users', doc); audit(null, `PIN reset with the master key for ${user.name}`, 'users', doc, []); });
  broadcast('users', doc, false);
  send(res, 200, { ok: true });
}, { auth: false });

// What kind of device a request came from, for the access log.
const onThisPC = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(TEST_MODE && req.headers['x-test-ip'] ? req.headers['x-test-ip'] : String((req.socket && req.socket.remoteAddress) || ''));
function deviceOf(req) {
  const ua = String(req.headers['user-agent'] || '');
  if (/iPhone/.test(ua)) return 'iPhone';
  if (/iPad|Macintosh.*Mobile/.test(ua)) return 'iPad';
  if (/Android/.test(ua)) return /Mobile/.test(ua) ? 'Android phone' : 'Android tablet';
  if (onThisPC(req)) return 'Clinic PC';
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Macintosh/.test(ua)) return 'Mac';
  if (/Linux/.test(ua)) return 'Linux PC';
  return 'Other device';
}


route('GET', '/api/all', (req, res, s) => {
  const out = {}, ctx = {};
  for (const store of STORES) {
    if (!canRead(store, s.user)) continue;
    out[store] = allDocs(store).map(d => view(store, d, s.user, ctx)).filter(Boolean);
  }
  const meta = {};
  for (const k of META_KEYS) if (metaVisible(k, s.user)) meta[k] = getMeta(k);
  meta.lineInfo = lineInfo();
  if (seesUpdates(s.user)) meta.update = updateState();
  send(res, 200, { me: publicUser(s.user), data: out, meta, version: VERSION, lan: lanAddresses().map(a => a.address), port: PORT, securePort: secureUp ? HTTPS_PORT : 0, serverTime: Date.now() });
});

route('POST', '/api/save', async (req, res, s) => {
  const b = await json(req);
  const r = save(s.user, b.store, b, s.token);
  if (!r.unchanged) broadcast(b.store, r.doc, false, s.token);
  for (const x of r.extra || []) broadcast(x.store, x.doc, !!x.deleted, '');
  send(res, 200, { doc: view(b.store, r.doc, s.user, {}), conflicts: r.conflicts || [] });
});

route('POST', '/api/delete', async (req, res, s) => {
  const b = await json(req);
  const cur = remove(s.user, b.store, b.id);
  if (cur) broadcast(b.store, cur, true, s.token);
  send(res, 200, { ok: true });
});

// Sample data for trying every screen: sample doctors, patients, visits, charts, photos and
// results, all marked as sample and removed together. Only the admin loads or removes it.
const sample = require('./sample.js');
route('GET', '/api/sample', (req, res, s) => { if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin sees the sample.'); send(res, 200, getMeta('sample', null) || { loaded: false }); });
route('POST', '/api/sample', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin loads or removes the sample.');
  const b = await json(req);
  if (b.action === 'load') {
    if ((getMeta('sample', {}) || {}).loaded) throw new HttpError(409, 'The sample is already loaded.');
    const r = tx(() => {
      const out = sample.load({ getDoc, allDocs, putDoc, hashPin, FILES, branchCode: branch().code, me: s.user });
      setMeta('sample', { loaded: true, at: Date.now(), by: s.user.name, pins: out.pins });
      audit(s.user, 'Sample data loaded', 'settings', { id: 'sample' }, []);
      return out;
    });
    for (const x of r.docs) broadcast(x.store, x.doc, false, s.token);
    broadcastMeta('sample', getMeta('sample'));
    return send(res, 200, { ok: true, added: r.docs.length, pins: r.pins });
  }
  if (b.action === 'remove') {
    const gone = tx(() => {
      const out = sample.remove({ allDocs, delDoc: (store, id) => { q.del().run(store, id); dataVer++; }, FILES, STORES });
      setMeta('sample', { loaded: false });
      audit(s.user, 'Sample data removed', 'settings', { id: 'sample' }, []);
      return out;
    });
    for (const x of gone) broadcast(x.store, x.doc, true, s.token);
    broadcastMeta('sample', getMeta('sample'));
    return send(res, 200, { ok: true, removed: gone.length });
  }
  throw new HttpError(400, 'Load or remove.');
});

// Apex's own product list (app/js/apex-products.js). Adds the ones the branch doesn't have
// yet, matched by name, and leaves the rest as they are.
// Apex's surgical treatments, added to the treatment list the same way.
route('POST', '/api/services/apex', (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin adds the treatment list.');
  const added = tx(() => {
    const have = new Set(allDocs('services').map(x => String(x.name || '').trim().toLowerCase()));
    const out = [];
    for (const [category, name, duration, nameTh] of APEX_SURGERY) {
      if (have.has(name.toLowerCase())) continue;
      const now = Date.now();
      const doc = { id: uid(), name, nameTh: nameTh || '', category, duration, kind: '', consents: [], apex: true, active: true, custom: {}, created: now, updated: now, createdBy: s.user.id, updatedBy: s.user.id };
      putDoc('services', doc); out.push(doc); have.add(name.toLowerCase());
    }
    if (out.length) audit(s.user, `Apex surgical treatments added (${out.length})`, 'settings', { id: 'services' }, []);
    return out;
  });
  for (const d of added) broadcast('services', d, false, s.token);
  send(res, 200, { ok: true, added: added.length });
});

route('POST', '/api/products/apex', (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin adds the product list.');
  const added = tx(() => {
    const have = new Set(allDocs('products').map(p => String(p.name || '').trim().toLowerCase()));
    const out = [];
    for (const [group, name, kind, unit] of APEX_PRODUCTS) {
      if (have.has(name.toLowerCase())) continue;
      const now = Date.now();
      const doc = { id: uid(), name, kind, unit, group, apex: true, active: true, custom: {}, created: now, updated: now, createdBy: s.user.id, updatedBy: s.user.id };
      putDoc('products', doc); out.push(doc); have.add(name.toLowerCase());
    }
    if (out.length) audit(s.user, `Apex product list added (${out.length})`, 'settings', { id: 'products' }, []);
    return out;
  });
  for (const d of added) broadcast('products', d, false, s.token);
  send(res, 200, { ok: true, added: added.length });
});

route('POST', '/api/meta', async (req, res, s) => {
  const b = await json(req);
  if (!META_KEYS.includes(b.key)) throw new HttpError(404, 'Unknown setting.');
  if (s.user.role !== 'owner' && !(DOCTOR_META.includes(b.key) && s.user.role === 'doctor')) throw new HttpError(403, 'Only the admin changes settings.');
  if (b.key === 'access') b.value = cleanAccess(b.value);
  const before = getMeta(b.key);
  tx(() => { setMeta(b.key, b.value); audit(s.user, 'Settings changed', 'settings', { id: b.key }, diff(before || {}, b.value || {})); });
  broadcastMeta(b.key, b.value);
  // What each role may open has changed, so everyone else's screens load again with the new rules.
  if (b.key === 'access') for (const c of clients) if (c.user && c.user.role !== 'owner') c.res.write(`data: ${JSON.stringify({ reload: true })}\n\n`);
  if (b.key === 'backup') backup.reschedule();
  send(res, 200, { ok: true });
});

// The admin's choice of what each role may open, kept to known roles, areas and levels.
function cleanAccess(v) {
  const out = {};
  for (const role of Object.keys(ROLES)) {
    if (role === 'owner' || !v || typeof v[role] !== 'object') continue;
    for (const [area] of ACCESS_AREAS) {
      const l = v[role][area];
      if (typeof l === 'string' && ACCESS_LEVELS.some(x => x[0] === l) && (l !== 'rl' || area === 'patients')) (out[role] = out[role] || {})[area] = l;
    }
  }
  return out;
}

// Who opened a patient's record: the device says so when a record, visit or chart opens.
// The same person on the same record within 10 minutes is one entry.
route('POST', '/api/seen', async (req, res, s) => {
  const b = await json(req);
  const p = typeof b.patientId === 'string' && getDoc('patients', b.patientId);
  if (!p || !view('patients', p, s.user, {})) throw new HttpError(404, 'No such record.');
  const what = ['record', 'visit', 'chart', 'photos', 'print'].includes(b.what) ? b.what : 'record';
  const last = db.prepare('SELECT at FROM access WHERE patientId = ? AND by = ? ORDER BY at DESC LIMIT 1').get(p.id, s.user.id);
  if (!last || Date.now() - last.at > 10 * 60000 || what === 'print') db.prepare('INSERT INTO access (id, at, by, byName, role, patientId, what, device) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').run(uid(), Date.now(), s.user.id, s.user.name, s.user.role, p.id, what, deviceOf(req));
  send(res, 200, { ok: true });
});
route('GET', '/api/access', (req, res, s, url) => {
  // Anyone who treats patients sees who opened a patient's record, since doctors cover for each
  // other. The whole branch's log is the admin's.
  const pid = url.searchParams.get('patientId');
  if (s.user.role !== 'owner' && !(pid && ROLES[s.user.role] && ROLES[s.user.role].clinical)) throw new HttpError(403, 'Only the admin sees the whole access log.');
  const rows = pid ? db.prepare('SELECT * FROM access WHERE patientId = ? ORDER BY at DESC LIMIT 500').all(pid) : db.prepare('SELECT * FROM access ORDER BY at DESC LIMIT 1000').all();
  send(res, 200, rows);
});

route('GET', '/api/history', (req, res, s, url) => {
  const pid = url.searchParams.get('patientId'), rid = url.searchParams.get('recId'), store = url.searchParams.get('store');
  let rows;
  if (pid) { if (!ROLES[s.user.role].clinical) throw new HttpError(403, 'Your role cannot see clinical history.'); rows = db.prepare('SELECT * FROM audit WHERE patientId = ? ORDER BY at DESC LIMIT 2000').all(pid); }
  else if (rid) rows = db.prepare('SELECT * FROM audit WHERE recId = ? ORDER BY at DESC LIMIT 500').all(rid);
  else if (store && s.user.role === 'owner') rows = db.prepare('SELECT * FROM audit WHERE store = ? ORDER BY at DESC LIMIT 500').all(store);
  else if (s.user.role === 'owner') rows = db.prepare('SELECT * FROM audit ORDER BY at DESC LIMIT 500').all();
  else throw new HttpError(403, 'Only the owner sees the full change log.');
  let keep = null;
  if (rid && !pid && s.user.role !== 'owner' && rows.length) {
    // Others see the history of a record only as far as they can see the record itself.
    const st = rows[0].store;
    if (!STORES.includes(st) || st === 'users') throw new HttpError(403, 'Your role cannot see this.');
    const cur = getDoc(st, rid), v = cur && view(st, cur, s.user, {});
    if (!v) throw new HttpError(403, 'Your role cannot see this.');
    keep = new Set(Object.keys(v));
  }
  // A role without clinical access sees that a record changed, never what was given or found.
  const plain = !ROLES[s.user.role].clinical && s.user.role !== 'owner';
  // Custom field values only for the roles that see that field. Older entries held every
  // custom value in one, so only the owner sees those.
  const seeChange = c => s.user.role === 'owner' || (c.f !== 'custom' && (!String(c.f).startsWith('custom.') || fieldVisible(getDoc('fields', c.f.slice(7)), s.user.role)));
  send(res, 200, rows.map(r => { const ch = JSON.parse(r.changes || '[]').filter(seeChange); return { ...r, action: plain && ['visits', 'patients'].includes(r.store) && !/^(Added|Edited|Deleted|Visit started|Patient added|Record edited|Bill started|Follow-up set|Visit signed|Visit reopened|Patient arrived)/.test(r.action) ? 'Edited' : r.action, changes: keep ? ch.filter(c => keep.has(String(c.f).split('.')[0])) : ch }; }));
});

// Raw image upload. The body is the file; returns the stored file id.
route('POST', '/api/upload', async (req, res, s) => {
  if (!canWrite('photos', s.user) && !canWrite('visits', s.user) && !canWrite('patients', s.user) && s.user.role !== 'owner') throw new HttpError(403, 'Your role cannot add files.');
  const type = String(req.headers['content-type'] || '');
  const ext = /png/.test(type) ? '.png' : /jpe?g/.test(type) ? '.jpg' : /webp/.test(type) ? '.webp' : /pdf/.test(type) ? '.pdf' : /octet-stream/.test(type) ? '.bin' : null;
  if (!ext) throw new HttpError(415, 'Only JPEG, PNG, WebP, PDF and head mesh files are stored.');
  const body = await readBody(req, 40 * 1024 * 1024);
  const id = uid() + ext;
  fs.writeFileSync(path.join(FILES, id), body);
  uploads.set(id, s.user.id);
  send(res, 200, { fileId: id, size: body.length });
});

route('GET', '/api/network', (req, res) => send(res, 200, { lan: lanAddresses(), port: PORT }));

// ---------- the laptop's hotspot ----------
// Read on the branch PC, or by the owner anywhere. Switched on and off at the branch PC
// itself, since a tablet that turns the hotspot off cuts itself off.
const onPCOnly = req => { if (!onThisPC(req)) throw new HttpError(403, 'Do this on the branch PC itself.'); };
async function hotspotReply(r) {
  const cfg = getMeta('hotspot', {});
  return { ...r, error: hotspot.explain(r), raw: r.ok ? '' : r.error || '', auto: !!cfg.auto, ip: hotspot.HOTSPOT_IP, wifi: r.ok && r.ssid ? hotspot.wifiQR(r.ssid, r.passphrase) : '', port: PORT, securePort: secureUp ? HTTPS_PORT : 0, onPC: true };
}
route('GET', '/api/hotspot', async (req, res, s) => {
  if (!onThisPC(req) && s.user.role !== 'owner') throw new HttpError(403, 'The hotspot shows on the branch PC.');
  send(res, 200, await hotspotReply(await hotspot.status(+(new URL(req.url, 'http://x').searchParams.get('fresh') ? 0 : 3000))));
});
route('POST', '/api/hotspot', async (req, res, s) => {
  onPCOnly(req);
  const b = await json(req);
  if (typeof b.auto === 'boolean') { setMeta('hotspot', { ...getMeta('hotspot', {}), auto: b.auto }); audit(s.user, b.auto ? 'Hotspot set to start with the clinic' : 'Hotspot no longer starts with the clinic', 'settings', { id: 'hotspot' }, []); }
  let r = await hotspot.status(0);
  if (typeof b.on === 'boolean' && r.ok && (r.state === 'On') !== b.on) {
    r = await hotspot.turn(b.on);
    if (r.ok) audit(s.user, b.on ? 'Hotspot turned on' : 'Hotspot turned off', 'settings', { id: 'hotspot' }, []);
    refreshCertificate();
  }
  send(res, 200, await hotspotReply(r));
});
route('POST', '/api/hotspot/settings', async (req, res) => { onPCOnly(req); await hotspot.openSettings(); send(res, 200, { ok: true }); });
route('POST', '/api/hotspot/firewall', async (req, res, s) => {
  onPCOnly(req);
  const r = await hotspot.allowFirewall([PORT, HTTPS_PORT]);
  if (!r.ok) throw new HttpError(400, r.error);
  audit(s.user, `Firewall opened for ports ${PORT} and ${HTTPS_PORT}`, 'settings', { id: 'hotspot' }, []);
  send(res, 200, { ok: true });
});

// ---------- signed-in devices ----------
// A device is one sign-in: the browser, the person, where it last called from. The owner
// sees and signs out any of them; everyone sees the devices connected now, to send a
// screen to one of them.
const deviceId = token => crypto.createHash('sha256').update(token).digest('hex').slice(0, 16);
function deviceLabel(ua, ip) {
  ua = String(ua || '');
  if (/iPhone/.test(ua)) return 'iPhone';
  if (/iPad|Macintosh.*Mobile/.test(ua)) return 'iPad';
  if (/Android/.test(ua)) return /Mobile/.test(ua) ? 'Android phone' : 'Android tablet';
  if (['127.0.0.1', '::1'].includes(ip)) return 'Clinic PC';
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Macintosh/.test(ua)) return 'Mac';
  return 'Browser';
}
const liveTokens = () => new Set([...clients].map(c => c.token));
route('GET', '/api/devices', (req, res, s) => {
  const live = liveTokens(), owner = s.user.role === 'owner';
  const rows = db.prepare('SELECT * FROM sessions ORDER BY seen DESC').all().filter(r => Date.now() - r.seen < SESSION_DAYS * 86400000);
  const out = [];
  for (const r of rows) {
    const u = getDoc('users', r.userId);
    if (!u || u.archived) continue;
    const self = r.token === s.token, on = live.has(r.token);
    if (!owner && !self && !on) continue;
    out.push({ id: deviceId(r.token), self, live: on, user: u.name, userId: u.id, kind: deviceLabel(r.device, r.ip), name: r.name || '', ...(owner || self ? { ip: r.ip || '', seen: r.seen, since: r.created } : {}) });
  }
  send(res, 200, out);
});
route('POST', '/api/devices/name', async (req, res, s) => {
  const b = await json(req);
  const name = String(b.name || '').slice(0, 40).trim();
  db.prepare('UPDATE sessions SET name = ? WHERE token = ?').run(name, s.token);
  send(res, 200, { ok: true, name });
});
route('POST', '/api/devices/signout', async (req, res, s) => {
  const b = await json(req);
  const row = db.prepare('SELECT * FROM sessions').all().find(r => deviceId(r.token) === b.id);
  if (!row) throw new HttpError(404, 'That device is already signed out.');
  if (s.user.role !== 'owner' && row.userId !== s.user.id) throw new HttpError(403, 'Only the owner signs out someone else\'s device.');
  db.prepare('DELETE FROM sessions WHERE token = ?').run(row.token);
  for (const c of [...clients]) if (c.token === row.token) { try { c.res.write(`data: ${JSON.stringify({ signedOut: true })}\n\n`); c.res.end(); } catch (e) { /* gone */ } clients.delete(c); }
  const u = getDoc('users', row.userId);
  audit(s.user, `Signed out ${u ? u.name + '\'s ' : 'a '}${row.name || deviceLabel(row.device, row.ip)}`, 'settings', { id: 'devices' }, []);
  send(res, 200, { ok: true });
});
// Opens a screen on another device that is connected now: a patient, a visit, a chart.
route('POST', '/api/devices/send', async (req, res, s) => {
  const b = await json(req);
  if (!/^#\/[\w\-/?=&%.]*$/.test(String(b.hash || ''))) throw new HttpError(400, 'Nothing to send.');
  let n = 0;
  for (const c of clients) if (deviceId(c.token) === b.id && liveUser(c)) { c.res.write(`data: ${JSON.stringify({ goto: b.hash, from: s.user.name, what: String(b.what || '').slice(0, 80) })}\n\n`); n++; }
  if (!n) throw new HttpError(404, 'That device is not connected right now.');
  send(res, 200, { ok: true });
});

// Test mode only: moves the branch PC's clock. {at: milliseconds since 1970}.
if (TEST_MODE) {
  route('POST', '/api/test/clock', async (req, res) => {
    const b = await json(req);
    if (b.at) global.__setTestClock(+b.at);
    backup.reschedule();
    send(res, 200, { now: Date.now(), today: todayLocal() });
  }, { auth: false });
  route('GET', '/api/test/clock', (req, res) => send(res, 200, { now: Date.now(), today: todayLocal() }), { auth: false });
}

route('GET', '/api/backup', (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the owner manages backups.');
  send(res, 200, backup.status());
});
route('POST', '/api/backup/now', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the owner manages backups.');
  const r = await backup.run('Manual');
  send(res, 200, r);
});
route('POST', '/api/backup/key', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the owner manages backups.');
  const b = await json(req);
  if (!b.passphrase || b.passphrase.length < 8) throw new HttpError(400, 'Use at least 8 characters.');
  backup.setPassphrase(b.passphrase);
  audit(s.user, 'Backup passphrase set', 'settings', { id: 'backup' }, []);
  send(res, 200, backup.status());
});
route('POST', '/api/backup/restore', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the owner restores backups.');
  const pass = decodeURIComponent(String(req.headers['x-passphrase'] || ''));
  const tmp = path.join(DATA, 'restore-upload.ccbak');
  await new Promise((resolve, reject) => { const w = fs.createWriteStream(tmp); req.pipe(w); w.on('finish', resolve); w.on('error', reject); });
  try {
    await backup.restore(tmp, pass, { close: () => db.close(), reopen: openDb });
  } finally { fs.rmSync(tmp, { force: true }); }
  for (const c of clients) c.res.write(`data: ${JSON.stringify({ reload: true })}\n\n`);
  send(res, 200, { ok: true }, { 'Set-Cookie': cookie('', 0) });
});


// ---------- updates ----------
// The program looks for a newer version when it starts and every six hours, and downloads it in
// the background (update.js). The admin and the staff see that it's ready. It goes in when the
// program is closed for the day from the PC, or straight away from Settings, Updates.
const updates = require('./update.js');
const UPD = { checked: 0, latest: '', ready: null, error: '', checking: false };
const seesUpdates = u => u && (u.role === 'owner' || u.role === 'staff');
function updateState() {
  const r = UPD.ready;
  return { version: VERSION, latest: UPD.latest, ready: r ? { version: r.version, notes: r.notes || {}, date: r.date || '' } : null, checked: UPD.checked, error: UPD.error, checking: UPD.checking, launcher: process.env.APEX_LAUNCHER === '1' };
}
function sendUpdateState() {
  const st = updateState();
  for (const c of clients) if (liveUser(c) && seesUpdates(c.user)) c.res.write(`data: ${JSON.stringify({ meta: 'update', value: st })}\n\n`);
}
async function checkUpdates() {
  if (UPD.checking) return;
  UPD.checking = true; sendUpdateState();
  try {
    const m = await updates.fetchFeed();
    UPD.latest = m.version; UPD.error = '';
    if (updates.newer(m.version, VERSION)) {
      const had = UPD.ready && UPD.ready.version;
      UPD.ready = await updates.fetchUpdate(s => console.log(' ' + s));
      if (UPD.ready && had !== UPD.ready.version) console.log(` Version ${UPD.ready.version} installs when the program is closed for the day.`);
    }
  } catch (e) { UPD.error = e.message; }
  UPD.checked = Date.now(); UPD.checking = false;
  sendUpdateState();
}
UPD.ready = updates.ready();
if (!process.env.CLINIC_NO_UPDATES) { setTimeout(checkUpdates, +process.env.CLINIC_UPDATE_DELAY || 15000).unref(); setInterval(checkUpdates, 6 * 3600 * 1000).unref(); }
route('GET', '/api/update', (req, res, s) => { if (!seesUpdates(s.user)) throw new HttpError(403, 'Only the admin and the staff see updates.'); send(res, 200, updateState()); });
route('POST', '/api/update/check', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin checks for updates.');
  await checkUpdates();
  send(res, 200, updateState());
});
// Closes the program, from the PC itself. With update, the launcher installs the waiting
// version first; with restart, it starts again straight after, for the admin's Update now.
const isLoopback = req => /^(127\.|::1$|localhost$)/.test(ipOf(req));
route('POST', '/api/close', async (req, res, s) => {
  const b = await json(req);
  const restart = !!b.restart;
  if (restart ? s.user.role !== 'owner' : !(seesUpdates(s.user) && isLoopback(req))) throw new HttpError(403, restart ? 'Only the admin updates the program.' : 'The program is closed from the branch PC, by the admin or the staff.');
  const install = (b.update || restart) && !!updates.ready() && process.env.APEX_LAUNCHER === '1';
  if (restart && !install) throw new HttpError(409, 'There is no update ready to install.');
  audit(s.user, restart ? 'Update installed' : install ? 'Closed for the day, update installed' : 'Closed for the day', 'settings', { id: 'program' }, []);
  send(res, 200, { ok: true, install });
  for (const c of clients) c.res.write(`data: ${JSON.stringify({ closing: true, restart })}\n\n`);
  setTimeout(() => { try { db.close(); } catch (e) { /* already closed */ } process.exit(restart ? 43 : install ? 42 : 40); }, 600);
});

// ---------- voice ----------
// whisper.cpp on this PC turns a recording into text. One recording at a time, since each
// one uses every core.
const voice = require('./voice.js');
voice.init(DATA);
let voiceQueue = Promise.resolve();
// Real Time Translator runs on a computer with an NVIDIA card somewhere on the branch wifi.
// This PC reads its transcript, since a tablet on the secure address cannot read a plain
// http page. Only addresses on the branch network are allowed.
function translatorBase() {
  let u = String((getMeta('translator') || {}).url || '').trim();
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
  let x;
  try { x = new URL(u); } catch (e) { return ''; }
  const h = x.hostname.replace(/^\[|\]$/g, '');
  const local = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|::1$|f[cd][0-9a-f]{2}:)/i.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h) || /\.local$/i.test(h) || !h.includes('.');
  return local ? x.origin : '';
}
async function translatorText() {
  const base = translatorBase();
  if (!base) throw new HttpError(400, (getMeta('translator') || {}).url ? 'The translator address must be on the branch wifi, such as http://192.168.1.20:8000.' : 'Set the translator address under Settings, Translator.');
  let r;
  try { r = await fetch(base + '/export/txt', { signal: AbortSignal.timeout(8000) }); } catch (e) { throw new HttpError(502, 'The translator did not answer. Check that it is running and that its computer is on the branch wifi.'); }
  if (r.status === 403) throw new HttpError(502, 'The translator has downloads turned off. Tick "Let viewers download the transcript" on its host panel.');
  if (!r.ok) throw new HttpError(502, `The translator answered with an error (${r.status}).`);
  const text = (await r.text()).slice(0, 2000000);
  return { base, text };
}
route('GET', '/api/translator/status', async (req, res) => {
  const base = translatorBase();
  if (!base) return send(res, 200, { set: !!(getMeta('translator') || {}).url, ok: false });
  try { const t = await translatorText(); send(res, 200, { set: true, ok: true, base, lines: t.text.split('\n').filter(l => /^\[/.test(l)).length }); }
  catch (e) { send(res, 200, { set: true, ok: false, base, error: e.message }); }
});
route('POST', '/api/translator/pull', async (req, res, s) => {
  if (!canWrite('transcripts', s.user)) throw new HttpError(403, 'Your role cannot save transcripts.');
  const t = await translatorText();
  send(res, 200, { text: t.text });
});

// ---------- LINE: confirmations and reminders ----------
const line = require('./line.js');
// What every device may know about LINE: whether it is on, the clinic's LINE ID for the link
// QR, and when LINE last reached this PC. The token and secret stay with the admin.
function lineInfo() {
  const set = line.settings(getMeta);
  return { on: !!(set.enabled && set.token), basicId: set.basicId || '', seen: getMeta('lineSeen') || 0 };
}
function putMessage(doc) {
  const cur = getDoc('messages', doc.id);
  const out = { ...(cur || {}), ...doc, updated: Date.now() };
  putDoc('messages', out);
  broadcast('messages', out, false, '');
  return out;
}
function clinicWords() {
  const c = getMeta('clinic') || {};
  return { clinic: [c.name, c.branchName].filter(Boolean).join(' ') || 'the clinic', phone: c.phone || '' };
}
function doctorName(id, lang) { const u = id ? getDoc('users', id) : null; return u ? (lang === 'th' && u.nameTh ? u.nameTh : u.name) : (lang === 'th' ? 'แพทย์' : lang === 'zh' ? '医生' : 'the doctor'); }
const firstName = p => String(p.goesBy || p.nameTh || p.name || '').split(' ')[0];
// One message: on LINE when the patient is linked and LINE is on, else onto the by-hand list.
async function sendMessage(id, kind, p, words, refs) {
  if (getDoc('messages', id)) return null;
  const set = line.settings(getMeta), lang = ['th', 'en', 'zh'].includes(p.plang) ? p.plang : 'th';
  const text = line.fill(line.textFor(set, kind, lang), { name: firstName(p), ...clinicWords(), ...words });
  const base = { id, kind, patientId: p.id, lang, text, created: Date.now(), ...refs, ...(p.sample ? { sample: true } : {}) };
  if (!(set.enabled && set.token && p.lineUserId)) return kind === 'confirm' || kind === 'soon' ? null : putMessage({ ...base, channel: 'hand', status: 'todo' });
  try { await line.push(set.token, p.lineUserId, text); return putMessage({ ...base, channel: 'line', status: 'sent', sentAt: Date.now() }); }
  catch (e) { return putMessage({ ...base, channel: 'line', status: 'failed', error: e.message }); }
}
const isoDay = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
// Every minute: what is due now goes out once. Each message has a fixed id, so nothing goes twice.
let remindersRunning = false;
async function runReminders(now = new Date()) {
  if (remindersRunning || !getMeta('clinic')) return 0;
  remindersRunning = true;
  let n = 0;
  try {
    const set = line.settings(getMeta), R = set.rules, today = isoDay(now);
    const tomorrow = isoDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));
    const since = set.enabledAt || 0;
    for (const b of allDocs('bookings')) {
      if (!b.patientId || !['booked', 'confirmed'].includes(b.status || 'booked') || b.date < today) continue;
      const p = getDoc('patients', b.patientId);
      if (!p || p.archived) continue;
      const start = new Date(`${b.date}T${b.time}:00`);
      if (start <= now) continue;
      const words = lang => ({ date: line.dateWords(b.date, lang), time: b.time, doctor: doctorName(b.doctorId, lang) });
      const lang = ['th', 'en', 'zh'].includes(p.plang) ? p.plang : 'th';
      if (R.confirm && b.remind !== false && (b.created || 0) > since && b.source !== 'line') { if (await sendMessage('confirm:' + b.id, 'confirm', p, words(lang), { bookingId: b.id })) n++; }
      if (R.dayBefore && b.remind !== false && b.date === tomorrow && now.getHours() >= +R.dayBeforeHour) { if (await sendMessage(`remind:${b.id}:${b.date}`, 'remind', p, words(lang), { bookingId: b.id })) n++; }
      if (R.soon && b.remind !== false && b.date === today && start - now <= R.soonHours * 3600000) { if (await sendMessage(`soon:${b.id}:${b.date}`, 'soon', p, words(lang), { bookingId: b.id })) n++; }
    }
    // A follow-up date a few days off, with nothing booked for that patient from today on.
    if (R.followUp) {
      const booked = new Set(allDocs('bookings').filter(b => b.date >= today && !['cancelled', 'noshow'].includes(b.status)).map(b => b.patientId));
      const soon = isoDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() + (+R.followUpDays || 0)));
      for (const v of allDocs('visits')) {
        if (!v.followUp || v.followUp < today || v.followUp > soon || booked.has(v.patientId) || now.getHours() < 9) continue;
        const p = getDoc('patients', v.patientId);
        if (!p || p.archived) continue;
        const lang = ['th', 'en', 'zh'].includes(p.plang) ? p.plang : 'th';
        if (await sendMessage(`followup:${v.id}:${v.followUp}`, 'followup', p, { date: line.dateWords(v.followUp, lang), reason: v.followReason || (lang === 'th' ? 'ติดตามผลการรักษา' : lang === 'zh' ? '复诊' : 'review'), doctor: doctorName(v.doctorId, lang) }, { visitId: v.id })) n++;
      }
    }
  } finally { remindersRunning = false; }
  return n;
}
setInterval(() => { runReminders().catch(e => console.error('reminders', e)); }, 60000).unref();

// LINE calls this when a patient sends the clinic a message. A message with a link code ties
// the patient's LINE to their record, and they get a reply in their language.
route('POST', '/line/webhook', async (req, res) => {
  const raw = await readBody(req, 1024 * 1024);
  const set = line.settings(getMeta);
  if (!line.signed(set.secret, raw, req.headers['x-line-signature'])) return send(res, 401, { error: 'Bad signature.' });
  setMeta('lineSeen', Date.now());
  let body;
  try { body = JSON.parse(raw.toString('utf8')); } catch (e) { return send(res, 400, { error: 'Bad request.' }); }
  for (const ev of body.events || []) {
    const text = ev.type === 'message' && ev.message && ev.message.type === 'text' ? ev.message.text : '';
    const m = text.match(line.CODE_RE), userId = ev.source && ev.source.userId;
    if (!m || !userId) continue;
    const p = allDocs('patients').find(x => x.lineCode && x.lineCode.toUpperCase() === m[1].toUpperCase());
    if (!p) continue;
    const doc = { ...p, lineUserId: userId, lineLinkedAt: Date.now(), updated: Date.now() };
    putDoc('patients', doc);
    broadcast('patients', doc, false, '');
    audit({ id: 'line', name: 'LINE' }, 'LINE linked', 'patients', doc, []);
    const lang = ['th', 'en', 'zh'].includes(p.plang) ? p.plang : 'th';
    if (ev.replyToken && set.token) await line.reply(set.token, ev.replyToken, line.fill(line.textFor(set, 'linked', lang), { name: firstName(p), ...clinicWords() })).catch(e => console.error('LINE reply', e.message));
  }
  send(res, 200, { ok: true });
}, { auth: false });
route('POST', '/api/line/run', async (req, res, s) => {
  if (!canWrite('bookings', s.user)) throw new HttpError(403, 'Your role cannot send reminders.');
  send(res, 200, { sent: await runReminders() });
});
route('POST', '/api/line/test', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin sets up LINE.');
  const b = await json(req), set = line.settings(getMeta), p = getDoc('patients', b.patientId);
  if (!set.token) throw new HttpError(400, 'Enter the channel access token first.');
  if (!p || !p.lineUserId) throw new HttpError(400, 'That patient has not linked LINE yet.');
  try { await line.push(set.token, p.lineUserId, String(b.text || 'Test from ' + clinicWords().clinic)); } catch (e) { throw new HttpError(502, e.message); }
  send(res, 200, { ok: true });
});
route('GET', '/api/line/defaults', (req, res) => send(res, 200, { texts: line.DEFAULT_TEXTS, rules: line.DEFAULT_RULES }));

// ---------- all the records, raw ----------
// One .zip for the admin: every record as a spreadsheet and as JSON, readable sheets of the
// visits, the materials used, the patients and the bookings, and the photos and signed forms
// when asked for. Nothing in it is a price, since the program keeps none.
const { zipWriter, csvOf } = require('./zip.js');
route('GET', '/api/export/all', async (req, res, s, url) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the admin downloads all the records.');
  const withFiles = url.searchParams.get('files') === '1';
  const pts = new Map(allDocs('patients').map(p => [p.id, p])), users = new Map(allDocs('users').map(u => [u.id, u]));
  const who = id => (users.get(id) || {}).name || '';
  const pt = id => pts.get(id) || {};
  const svcs = new Map(allDocs('services').map(x => [x.id, x]));
  const visits = allDocs('visits').sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
  const used = v => (v.treatments || []).filter(t => t.source !== 'supply' && t.product).map(t => `${t.product} ${t.amount ?? ''} ${t.unit || ''}`.trim()).join(' · ');
  const sheets = {
    'Patients.csv': [...pts.values()].map(p => ({ 'Patient number': p.no, 'Apex HN': p.hn, Name: p.name, 'Name in Thai': p.nameTh, 'Goes by': p.goesBy, 'Date of birth': p.dob, Sex: p.sex, Nationality: p.nationality, Mobile: p.phone, 'LINE ID': p.line, 'LINE linked': p.lineUserId ? 'yes' : '', Email: p.email, Allergies: (p.allergies || []).map(a => [a.what, a.reaction].filter(Boolean).join(': ')).join('; '), 'On record since': p.created ? new Date(p.created).toISOString().slice(0, 10) : '' })),
    'Visits.csv': visits.map(v => ({ 'Visit number': v.no, Date: v.date, Time: v.time, Type: v.type, 'Patient number': pt(v.patientId).no, 'Apex HN': pt(v.patientId).hn, Patient: pt(v.patientId).name, Doctor: who(v.doctorId), 'Treatments done': (v.services || []).map(x => (svcs.get(x.serviceId) || x).name).join(', '), 'Materials used': used(v), Complaint: v.complaint, Findings: v.findings, Assessment: v.assessment, Plan: v.plan, 'Follow-up': v.followUp, 'Follow-up reason': v.followReason, 'Signed by': who(v.signedBy), Signed: v.signedAt ? new Date(v.signedAt).toISOString() : '' })),
    'Materials used.csv': visits.flatMap(v => (v.treatments || []).filter(t => t.product).map(t => ({ 'Visit number': v.no, Date: v.date, 'Patient number': pt(v.patientId).no, 'Apex HN': pt(v.patientId).hn, Patient: pt(v.patientId).name, Doctor: who(v.doctorId), Type: t.kind, Product: t.product, Lot: t.lot, Amount: t.amount, Unit: t.unit, Area: t.area, Notes: t.notes, From: t.source }))),
    'Bookings.csv': allDocs('bookings').sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)).map(b => ({ Date: b.date, Time: b.time, Minutes: b.mins, Patient: b.patientId ? pt(b.patientId).name : b.name, 'Patient number': pt(b.patientId).no, Mobile: pt(b.patientId).phone, Doctor: who(b.doctorId), Treatment: (svcs.get(b.serviceId) || {}).name || '', Note: b.what, Status: b.status })),
  };
  const day = new Date().toISOString().slice(0, 10);
  res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Disposition': `attachment; filename="apex-records-${day}${withFiles ? '-with-photos' : ''}.zip"`, 'Cache-Control': 'no-store' });
  const z = zipWriter(res);
  try {
    await z.addBuffer('README.txt', Buffer.from([`All the records of ${(getMeta('clinic') || {}).name || 'the clinic'}, ${new Date().toString()}.`, '',
      'Patients, Visits, Materials used and Bookings open in Excel and are the easy ones to read.',
      'records.json has every record exactly as the program keeps it. The raw folder has the same as one spreadsheet per kind of record.',
      withFiles ? 'The files folder has the photos, signatures and signed forms. Each record names its files by the id in this folder.' : 'Photos and signed forms are not in this download. Download again with photos to have them.'].join('\r\n'), 'utf8'));
    for (const [name, rows] of Object.entries(sheets)) await z.addBuffer(name, Buffer.from(csvOf(rows), 'utf8'));
    const all = {};
    for (const store of STORES) { const docs = allDocs(store).map(d => (store === 'users' ? publicUser(d) : d)); all[store] = docs; await z.addBuffer(`raw/${store}.csv`, Buffer.from(csvOf(docs), 'utf8')); }
    await z.addBuffer('records.json', Buffer.from(JSON.stringify({ exported: new Date().toISOString(), clinic: getMeta('clinic'), records: all }, null, 1), 'utf8'));
    if (withFiles && fs.existsSync(FILES)) for (const f of fs.readdirSync(FILES)) if (FILE_RE.test(f)) await z.addFile('files/' + f, path.join(FILES, f));
    await z.end();
    audit(s.user, withFiles ? 'All records downloaded with photos' : 'All records downloaded', 'settings', { id: 'export' }, []);
  } catch (e) { console.error('export', e.message); res.destroy(); }
});

route('GET', '/api/voice/status', (req, res) => send(res, 200, voice.status(getMeta('voice') || {})));
route('POST', '/api/voice/download', async (req, res, s) => {
  if (s.user.role !== 'owner') throw new HttpError(403, 'Only the owner sets up voice.');
  const b = await json(req);
  try { send(res, 200, voice.download(b.what)); } catch (e) { throw new HttpError(400, e.message); }
});
route('POST', '/api/voice', async (req, res) => {
  const raw = await readBody(req, 8 * 1024 * 1024);
  let b;
  try { b = JSON.parse(raw.toString('utf8')); } catch (e) { throw new HttpError(400, 'Bad request.'); }
  const set = getMeta('voice') || {};
  const wav = Buffer.from(String(b.wav || ''), 'base64');
  const run = voiceQueue.then(() => voice.transcribe(wav, { model: set.model || 'base', lang: 'en', prompt: String(b.prompt || '') }));
  voiceQueue = run.catch(() => {});
  let text;
  try { text = await run; } catch (e) { throw new HttpError(503, e.message); }
  send(res, 200, { text });
});

function ollama(method, p, body, timeout = 4000) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const [oh, op] = (process.env.CLINIC_OLLAMA || '127.0.0.1:11434').split(':');
    const r = http.request({ host: oh, port: +op || 11434, path: p, method, timeout, headers: data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {} }, resp => {
      const chunks = []; resp.on('data', c => chunks.push(c));
      resp.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString())); } catch (e) { reject(e); } });
    });
    r.on('timeout', () => r.destroy(new Error('timeout')));
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

function localISO(d) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }

// ---------- server ----------
const handler = async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/api/events') {
      const s = sessionOf(req);
      if (!s) return send(res, 401, { error: 'Sign in again.' });
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      res.write(`retry: 3000\n\n`);
      const c = { res, user: s.user, token: s.token };
      clients.add(c);
      req.on('close', () => clients.delete(c));
      return;
    }
    // The tablet set-up page and the certificate a tablet installs once. Open to anyone on
    // the branch wifi, since a tablet needs them before anyone can sign in on it.
    if (url.pathname === '/ca.crt' || url.pathname === '/ca.pem' || url.pathname === '/ca.mobileconfig') {
      const tls = require('./tls.js');
      const ca = tls.authorityFor(DATA, caCode());
      if (url.pathname === '/ca.crt') return send(res, 200, ca.der, { 'Content-Type': 'application/x-x509-ca-cert', 'Content-Disposition': 'attachment; filename="apex-pms.crt"' });
      if (url.pathname === '/ca.pem') return send(res, 200, ca.cert, { 'Content-Type': 'application/x-pem-file', 'Content-Disposition': 'attachment; filename="apex-pms.pem"' });
      return send(res, 200, tls.mobileconfig(ca, (getMeta('clinic', {}) || {}).branchName || ''), { 'Content-Type': 'application/x-apple-aspen-config', 'Content-Disposition': 'attachment; filename="apex-pms.mobileconfig"' });
    }
    if (url.pathname === '/api/tablet') {
      const ca = require('./tls.js').authorityFor(DATA, caCode());
      const c = getMeta('clinic', {}) || {};
      return send(res, 200, { name: c.name || '', branchName: c.branchName || '', label: ca.label, fingerprint: ca.fingerprint, lan: lanAddresses().map(a => a.address), pcName: PC_NAME, port: PORT, securePort: secureUp ? HTTPS_PORT : 0 });
    }
    if (url.pathname.startsWith('/files/')) {
      const s = sessionOf(req);
      const id = path.basename(url.pathname);
      if (!FILE_RE.test(id)) return send(res, 404, 'Not found');
      const file = path.join(FILES, id);
      if (!fs.existsSync(file)) return send(res, 404, 'Not found');
      if (!(s ? fileAllowed(id, s.user) : filePublic(id))) return send(res, s ? 403 : 401, s ? 'Forbidden' : 'Sign in again.');
      res.writeHead(200, { 'Content-Type': MIME[path.extname(id)] || (id.endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream'), 'Cache-Control': 'private, max-age=31536000, immutable' });
      return fs.createReadStream(file).pipe(res);
    }
    const r = routes[req.method + ' ' + url.pathname];
    if (r) {
      let s = null;
      if (r.auth) { s = sessionOf(req); if (!s) return send(res, 401, { error: 'Sign in again.' }); }
      return await r.fn(req, res, s, url);
    }
    if (url.pathname.startsWith('/api/')) return send(res, 404, { error: 'Not found.' });
    if (req.method !== 'GET') return send(res, 405, 'Method not allowed');
    serveStatic(req, res, url.pathname);
  } catch (e) {
    const known = e instanceof HttpError || e.expose;
    if (!known) console.error(new Date().toISOString(), req.method, url.pathname, e);
    if (!res.headersSent) send(res, known ? e.code : 500, { error: known ? e.message : 'Something went wrong on the branch PC. ' + e.message });
  }
};
const server = http.createServer(handler);

// A file goes to whoever can see a record that points at it. Staff photos and the
// clinic logo show on the sign-in screen, so they are open. A file nobody points at
// yet goes back only to the person who sent it.
const uploads = new Map();
// Every stored file a head record points at: the mesh, the texture and the view pictures.
function headFiles(h) { return [...Object.values(h.files || {}), ...Object.values(h.thumbs || {})].filter(f => typeof f === 'string' && FILE_RE.test(f)); }
const FILE_RE = /^[0-9a-f-]{36}\.(jpg|png|webp|pdf|bin)$/;
let fileIdx = null, fileIdxVer = -1;
function fileRefs() {
  if (fileIdx && fileIdxVer === dataVer) return fileIdx;
  const idx = new Map();
  const add = (id, ref) => { if (!idx.has(id)) idx.set(id, []); idx.get(id).push(ref); };
  const scan = (v, ref) => { if (typeof v === 'string') { if (FILE_RE.test(v)) add(v, ref); } else if (v && typeof v === 'object') for (const x of Object.values(v)) scan(x, ref); };
  for (const store of STORES) for (const d of allDocs(store)) scan(d, { store, doc: d });
  fileIdx = idx; fileIdxVer = dataVer;
  return idx;
}
function filePublic(id) {
  const c = getMeta('clinic', {}) || {};
  if (c.logo === id) return true;
  return (fileRefs().get(id) || []).some(r => r.store === 'users' && r.doc.photo === id && !r.doc.archived);
}
function fileAllowed(id, user) {
  if (user.role === 'owner' || filePublic(id)) return true;
  const refs = fileRefs().get(id);
  if (!refs) return uploads.get(id) === user.id;
  return refs.some(r => { const v = view(r.store, r.doc, user, {}); return !!v && JSON.stringify(v).includes(id); });
}

// The starter tags and fields are added once, for a clinic set up before they existed as
// well as a new one. The owner edits or retires them under Settings.
function seedStarters(user) {
  if (!getMeta('clinic')) return;
  const flags = getMeta('seeded', {}) || {};
  tx(() => {
    if (!flags.tags && !allDocs('tags').length) { for (const [name, color] of STARTER_TAGS) { const d = { id: uid(), name, color, created: Date.now(), updated: Date.now() }; putDoc('tags', d); audit(user, 'Tag added', 'tags', d, []); } flags.tags = true; }
    if (!flags.fields && !allDocs('fields').length) { for (const f of STARTER_FIELDS) { const d = { ...f, starter: true, created: Date.now(), updated: Date.now() }; putDoc('fields', d); audit(user, 'Field added', 'fields', d, []); } flags.fields = true; }
    setMeta('seeded', flags);
  });
}
seedStarters(null);

backup.init({ dataDir: DATA, filesDir: FILES, rootDir: ROOT, getMeta, setMeta, db: () => db, audit: (action) => audit(null, action, 'settings', { id: 'backup' }, []) });

server.listen(PORT, '0.0.0.0', () => {
  const lan = lanAddresses();
  const line = '-'.repeat(60);
  console.log(line);
  console.log(` Apex Patient Management System ${VERSION} is running.`);
  console.log(` On this PC:      http://localhost:${PORT}`);
  for (const a of lan) console.log(` Tablets, phones: http://${a.address}:${PORT}`);
  console.log(' Keep this window open while the clinic is working.');
  console.log(line);
  if (process.platform === 'win32' && !process.env.CLINIC_NO_BROWSER) require('child_process').exec(`start "" "http://localhost:${PORT}"`);
  if ((getMeta('hotspot', {}) || {}).auto) hotspot.turn(true).then(r => console.log(r.ok ? ` Hotspot on: join "${r.ssid}" on tablets and phones.` : ' Hotspot did not start: ' + hotspot.explain(r)));
});
// The secure address. A tablet accepts the certificate warning once.
let secureUp = false, secure = null;
// The certificate names every address tablets use. The hotspot address is on it from the
// start on Windows, so switching the hotspot on does not bring the warning back.
// The branch code goes in the certificate's name once the branch is set up.
// The PC's own name on the network, such as desktop-k2m81.local. Windows answers it by itself,
// so a tablet that reaches the PC by name keeps working when the PC's address changes.
const PC_NAME = (process.env.CLINIC_PC_NAME || require('os').hostname()).toLowerCase().replace(/\.local$/, '').replace(/[^a-z0-9-]/g, '') + '.local';
function caCode() { return String((getMeta('clinic', {}) || {}).branchCode || ''); }
const certIPs = () => [...new Set([...lanAddresses().map(a => a.address), ...(process.platform === 'win32' || process.env.CLINIC_HOTSPOT_STUB ? [hotspot.HOTSPOT_IP] : [])])];
function refreshCertificate() {
  if (!secure) return;
  try { const tc = require('./tls.js').certificateFor(DATA, certIPs(), caCode(), [PC_NAME]); if (tc.made) secure.setSecureContext({ key: tc.key, cert: tc.cert }); } catch (e) { console.log('The secure address could not renew its certificate: ' + e.message); }
}
setInterval(refreshCertificate, 60000);
if (HTTPS_PORT) {
  try {
    const tc = require('./tls.js').certificateFor(DATA, certIPs(), caCode(), [PC_NAME]);
    secure = require('https').createServer({ key: tc.key, cert: tc.cert }, handler);
    secure.on('error', e => console.log(`The secure address could not start on port ${HTTPS_PORT}: ${e.message}`));
    secure.listen(HTTPS_PORT, '0.0.0.0', () => { secureUp = true; for (const a of lanAddresses()) console.log(` Tablets, after the one-time set-up: https://${a.address}:${HTTPS_PORT}`); console.log(` Tablet set-up page: http://${(lanAddresses()[0] || {}).address || 'localhost'}:${PORT}/tablet.html`); });
  } catch (e) { console.log('The secure address could not start: ' + e.message); }
}
server.on('error', e => {
  if (e.code === 'EADDRINUSE') { console.log(`The Apex Patient Management System is already running. Open http://localhost:${PORT}`); if (process.platform === 'win32') require('child_process').exec(`start "" "http://localhost:${PORT}"`); setTimeout(() => process.exit(0), 4000); }
  else { console.error(e); process.exit(1); }
});

module.exports = { server };
