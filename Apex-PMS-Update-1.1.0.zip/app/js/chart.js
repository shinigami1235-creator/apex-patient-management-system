// Treatment chart: marks drawn over a photo or the standard face drawing.
// Mark positions are stored as fractions of the base width and height.

const PEN_COLORS = ['#1B222C', '#A31B1B', '#1F5E99', '#0E6B4F', '#C27A0E'];

// ---------- drawing marks (editor, cards and print all use this) ----------
function markSize(w, h) { return Math.max(w, h) * 0.011; }

// Filler techniques. A point is a bolus, or an area when dragged round. An arrow is one
// needle or cannula path, entry to tip. A fan is several arrows from one entry point: its pts
// are the entry point, then each arrow's tip, and its amount is for the whole fan.
const FILLER_TECHS = [
  { key: 'point', label: 'Point', how: 'Tap for a bolus, draw a line for an arrow, or circle an area to shade it.' },
  { key: 'arrow', label: 'Arrow', how: 'Drag from the entry point to where the needle or cannula ends.' },
  { key: 'fan', label: 'Fan', how: 'Drag from the entry point for the first arrow. Start each next arrow on the same entry point to fan out from it. The amount is for the whole fan.' },
];
const TECH_NOTE = { arrow: 'Linear threading', fan: 'Fanning' };
function fillerTech(s) { return (s && FILLER_TECHS.some(t => t.key === s.technique) && s.technique) || 'point'; }
function techIcon(k) {
  const a = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
  if (k === 'point') return `<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 6l6 6-6 6-6-6z" fill="currentColor"/></svg>`;
  if (k === 'arrow') return `<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M4 18L19 6M12 6h7v7" ${a}/></svg>`;
  return `<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M5 19L10 5M5 19L17 8M5 19L20 15" ${a}/><circle cx="5" cy="19" r="2.2" fill="currentColor"/></svg>`;
}
// Whether a drawn path ends well away from where it started, rather than closing a loop.
function openStroke(P, R) {
  let len = 0;
  const d = (a, b) => Math.hypot(...a.map((v, k) => v - b[k]));
  for (let i = 1; i < P.length; i++) len += d(P[i], P[i - 1]);
  const chord = d(P[P.length - 1], P[0]);
  return chord > R * 3 && chord > len * 0.45;
}
// The fan whose entry point is under p, newest first. marks are in 2D, as drawn.
function fanAt(marks, p, w, h) {
  const R = markSize(w, h);
  for (let i = marks.length - 1; i >= 0; i--) {
    const m = marks[i];
    if (m.t !== 'filler' || m.technique !== 'fan' || !m.pts || !m.pts.length) continue;
    if (Math.hypot((m.pts[0][0] - p[0]) * w, (m.pts[0][1] - p[1]) * h) <= R * 2.6) return i;
  }
  return -1;
}
// An arrowhead at the end of a path, in picture pixels.
function arrowHead(path, w, h, R, color) {
  const P = path.map(q => [q[0] * w, q[1] * h]);
  const e = P[P.length - 1];
  let b = P[0];
  for (let i = P.length - 2; i >= 0; i--) { if (Math.hypot(e[0] - P[i][0], e[1] - P[i][1]) >= R * 1.6) { b = P[i]; break; } }
  const len = Math.hypot(e[0] - b[0], e[1] - b[1]) || 1, dx = (e[0] - b[0]) / len, dy = (e[1] - b[1]) / len;
  const L = R * 1.7, hw = R * 0.95, bx = e[0] - dx * L, by = e[1] - dy * L;
  const pt = (x, y) => `${x.toFixed(1)},${y.toFixed(1)}`;
  return `<polygon points="${pt(e[0] + dx * R * 0.2, e[1] + dy * R * 0.2)} ${pt(bx - dy * hw, by + dx * hw)} ${pt(bx + dy * hw, by - dx * hw)}" fill="${color}" stroke="#fff" stroke-width="${(R * 0.18).toFixed(1)}" stroke-linejoin="round"/>`;
}
function ptsAttr(pts, w, h) { return pts.map(p => `${(p[0] * w).toFixed(1)},${(p[1] * h).toFixed(1)}`).join(' '); }
function centroid(pts) {
  let x = 0, y = 0;
  for (const p of pts) { x += p[0]; y += p[1]; }
  return [x / pts.length, y / pts.length];
}
function markLabel(m) {
  const amt = m.amount !== undefined && m.amount !== '' ? trimNum(m.amount) : '';
  if (m.t === 'toxin') return amt;
  if (m.t === 'filler' || m.t === 'booster') return amt ? `${amt} ml` : '';
  if (m.t === 'device') return [m.settings, amt ? `${amt} ${m.unit || 'shots'}` : ''].filter(Boolean).join(', ');
  if (m.t === 'thread') return m.product || 'Thread';
  return '';
}

function marksSVG(marks, w, h, { selected = -1 } = {}) {
  const R = markSize(w, h), fs = R * 1.7;
  const halo = `stroke="#fff" stroke-width="${(R * 0.45).toFixed(1)}" paint-order="stroke" stroke-linejoin="round"`;
  const text = (x, y, s, color, anchor = 'start') => s ? `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" font-size="${fs.toFixed(1)}" font-family="IBM Plex Sans, Segoe UI, sans-serif" font-weight="600" fill="${color}" text-anchor="${anchor}" ${halo}>${esc(s)}</text>` : '';
  let out = '';
  marks.forEach((m, i) => {
    const color = m.color || (KINDS[m.t] ? KINDS[m.t].color : '#1B222C');
    const sel = i === selected;
    let g = '';
    if (m.pts && m.pts.length > 1 && (m.technique === 'arrow' || m.technique === 'fan')) {
      const paths = m.technique === 'fan' ? m.pts.slice(1).map(q => [m.pts[0], q]) : [m.pts];
      const a = m.pts[0];
      for (const path of paths) {
        const P = ptsAttr(path, w, h);
        if (sel) g += `<polyline points="${P}" fill="none" stroke="#1F5E99" stroke-opacity=".35" stroke-width="${(R * 1.3).toFixed(1)}" stroke-linecap="round" stroke-linejoin="round"/>`;
        g += `<polyline points="${P}" fill="none" stroke="transparent" stroke-width="${(R * 1.8).toFixed(1)}"/>`;
        g += `<polyline points="${P}" fill="none" stroke="${color}" stroke-width="${(R * 0.38).toFixed(1)}" stroke-linecap="round" stroke-linejoin="round"/>`;
        g += arrowHead(path, w, h, R, color);
      }
      g += `<circle cx="${(a[0] * w).toFixed(1)}" cy="${(a[1] * h).toFixed(1)}" r="${(R * 0.6).toFixed(1)}" fill="${color}" stroke="#fff" stroke-width="${(R * 0.2).toFixed(1)}"/>`;
      // A fan is labelled just below its entry point.
      // An arrow is labelled behind its entry point, away from where it points.
      if (m.technique === 'arrow') { const b = m.pts[m.pts.length - 1], right = b[0] >= a[0]; g += text(a[0] * w + (right ? -R : R), a[1] * h + fs * 0.35, markLabel(m), color, right ? 'end' : 'start'); }
      else g += text(a[0] * w, a[1] * h + R * 1.2 + fs, markLabel(m), color, 'middle');
    } else if (m.pts && m.pts.length > 1) {
      const P = ptsAttr(m.pts, w, h);
      if (m.t === 'pen') {
        g += `<polyline points="${P}" fill="none" stroke="transparent" stroke-width="${(R * 1.6).toFixed(1)}"/>`;
        g += `<polyline points="${P}" fill="none" stroke="${color}" stroke-width="${(R * 0.32).toFixed(1)}" stroke-linecap="round" stroke-linejoin="round"/>`;
      } else if (m.t === 'thread') {
        const a = m.pts[0], b = m.pts[m.pts.length - 1];
        g += `<polyline points="${P}" fill="none" stroke="transparent" stroke-width="${(R * 1.6).toFixed(1)}"/>`;
        g += `<polyline points="${P}" fill="none" stroke="${color}" stroke-width="${(R * 0.42).toFixed(1)}" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="${(R * 1.2).toFixed(1)} ${(R * 0.6).toFixed(1)}"/>`;
        g += `<circle cx="${(a[0] * w).toFixed(1)}" cy="${(a[1] * h).toFixed(1)}" r="${(R * 0.7).toFixed(1)}" fill="${color}" stroke="#fff" stroke-width="${(R * 0.2).toFixed(1)}"/>`;
        g += text(b[0] * w + R, b[1] * h - R * 0.6, markLabel(m), color);
      } else {
        const dash = m.t === 'device' ? ` stroke-dasharray="${(R * 0.9).toFixed(1)} ${(R * 0.5).toFixed(1)}"` : '';
        const op = m.t === 'device' ? 0.16 : 0.24;
        g += `<polygon points="${P}" fill="${color}" fill-opacity="${op}" stroke="${color}" stroke-width="${(R * 0.22).toFixed(1)}" stroke-linejoin="round"${dash}/>`;
        const c = centroid(m.pts);
        g += text(c[0] * w, c[1] * h + fs * 0.35, markLabel(m), color, 'middle');
      }
      if (sel) g += `<polyline points="${P}${m.t === 'pen' || m.t === 'thread' ? '' : ' ' + ptsAttr([m.pts[0]], w, h)}" fill="none" stroke="#1F5E99" stroke-width="${(R * 0.25).toFixed(1)}" stroke-dasharray="${(R * 0.6).toFixed(1)} ${(R * 0.4).toFixed(1)}"/>`;
    } else if (m.t === 'text') {
      g += `<text x="${(m.x * w).toFixed(1)}" y="${(m.y * h).toFixed(1)}" font-size="${(fs * 1.15).toFixed(1)}" font-family="IBM Plex Sans, Segoe UI, sans-serif" font-weight="600" fill="${color}" ${halo}>${esc(m.text)}</text>`;
      if (sel) g += `<circle cx="${(m.x * w).toFixed(1)}" cy="${(m.y * h).toFixed(1)}" r="${(R * 0.6).toFixed(1)}" fill="#1F5E99"/>`;
    } else if (m.x !== undefined) {
      const x = m.x * w, y = m.y * h;
      if (m.t === 'toxin') {
        g += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${R.toFixed(1)}" fill="${color}" stroke="#fff" stroke-width="${(R * 0.25).toFixed(1)}"/>`;
      } else {
        const d = R * 1.2;
        g += `<polygon points="${x},${(y - d).toFixed(1)} ${(x + d).toFixed(1)},${y} ${x},${(y + d).toFixed(1)} ${(x - d).toFixed(1)},${y}" fill="${color}" stroke="#fff" stroke-width="${(R * 0.25).toFixed(1)}"/>`;
      }
      g += text(x + R * 1.4, y - R * 0.6, markLabel(m), color);
      if (sel) g += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(R * 2).toFixed(1)}" fill="none" stroke="#1F5E99" stroke-width="${(R * 0.25).toFixed(1)}" stroke-dasharray="${(R * 0.6).toFixed(1)} ${(R * 0.4).toFixed(1)}"/>`;
    }
    out += `<g data-i="${i}"${m.copy ? ' opacity=".6"' : ''}>${g}</g>`;
  });
  return out;
}

// Full chart picture as an SVG string. imgUrl is needed for a photo base and for a head
// base, where it is the head's picture from the chart's standard view.
// crop, as fractions [x, y, width, height] of the picture, shows that part only.
function chartSVG(chart, imgUrl, attrs = '', crop = null) {
  const w = chart.w || FACE_W, h = chart.h || FACE_H;
  const box = crop ? `${(crop[0] * w).toFixed(1)} ${(crop[1] * h).toFixed(1)} ${(crop[2] * w).toFixed(1)} ${(crop[3] * h).toFixed(1)}` : `0 0 ${w} ${h}`;
  const isHead = chart.base && chart.base.type === 'head';
  const base = (chart.base && chart.base.type === 'photo' || isHead) && imgUrl
    ? `<image href="${imgUrl}" x="0" y="0" width="${w}" height="${h}" preserveAspectRatio="none"/>`
    : (chart.base && (chart.base.type === 'photo' || isHead) ? `<rect width="${w}" height="${h}" fill="#E4E8ED"/>` : `<rect width="${w}" height="${h}" fill="#fff"/>${faceArt(chart.view)}`);
  const marks = isHead ? marksForView(chart.marks || [], chart.shot || 'front') : (chart.marks || []);
  return `<svg viewBox="${box}" xmlns="http://www.w3.org/2000/svg" ${attrs}>${base}${marksSVG(marks, w, h)}</svg>`;
}

// ---------- photo URLs ----------
function photoMeta(id) { return byId('photos', id); }
function thumbURL(photoId) { const p = photoMeta(photoId); return p ? fileURL(p.thumbId || p.fileId) : ''; }
function fullURL(photoId) { const p = photoMeta(photoId); return p ? fileURL(p.fileId) : ''; }
function chartThumbURL(chart) {
  if (chart.base && chart.base.type === 'head') return headThumbURL(byId('heads', chart.base.headId), chart.shot || 'front');
  return chart.base && chart.base.type === 'photo' ? thumbURL(chart.base.photoId) : '';
}

// Picks the photo a new chart should open on: this visit's photo of that view, Before first.
function defaultChartPhoto(v, viewKey) {
  const want = CHART_VIEWS.find(x => x.key === viewKey).photo;
  const mine = S.photos.filter(p => p.visitId === v.id && p.view === want);
  return mine.find(p => p.stage === 'Before' || p.stage === 'Baseline') || mine[0] || null;
}

// The same view on the patient's previous visit that has a chart.
function previousChart(v, viewKey) {
  const earlier = visitsOf(v.patientId).filter(x => x.id !== v.id && (x.date + x.time) < (v.date + v.time));
  for (const x of earlier) {
    const c = S.charts.find(c => c.visitId === x.id && c.view === viewKey && (c.marks || []).length);
    if (c) return { chart: c, visit: x };
  }
  return null;
}

// ---------- editor ----------
const TOOL_ICONS = {
  select: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M5 3l14 8-6 2-3 6z"/></svg>',
  hand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 13V5a1.5 1.5 0 0 1 3 0v6M11 11V4a1.5 1.5 0 0 1 3 0v7M14 11V6a1.5 1.5 0 0 1 3 0v8c0 4-2.5 7-6 7s-5-2-7-6l-1.5-3a1.5 1.5 0 0 1 2.6-1.5L8 13"/></svg>',
  pen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20l4-1 11-11-3-3L5 16z"/></svg>',
  text: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M5 6V4h14v2M12 4v16M9 20h6"/></svg>',
  erase: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 20h12M5 15l9-9 5 5-8 8H8z"/></svg>',
  undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/></svg>',
  redo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/></svg>',
};
// The treatment tools for the toolbar. Filler carries its three shapes right under it, so
// they are a tap away even when the side panel is closed.
function drawToolsHTML(toolBtn) {
  return DRAW_TOOLS.map(([k, label]) => toolBtn(k, label, `<span class="dot" style="background:${KINDS[k].color}"></span>`) + (k === 'filler' ? fillerTechToolsHTML() : '')).join('');
}
function fillerTechToolsHTML() {
  const cur = fillerTech(E.tools.filler);
  return `<div class="tool-sub" role="group" aria-label="Filler shape">${FILLER_TECHS.map(x => `<button class="tool small" data-tech="${x.key}" aria-pressed="${E.tool === 'filler' && cur === x.key}" title="${x.how}">${techIcon(x.key)}<span>${x.label}</span></button>`).join('')}</div>`;
}
function setFillerTech(k) {
  E.tool = 'filler'; E.sel = -1; E.tools.filler.technique = k;
  S.editorSettings = { tools: E.tools };
  (E.render || edRender)();
}
const DRAW_TOOLS = [
  ['toxin', 'Botox'], ['filler', 'Filler'], ['booster', 'Booster'], ['device', 'Device'], ['thread', 'Thread'],
];

let E = null;

// Lots of every product of this kind, earliest expiry first.
function lotsForKind(kind) {
  const prods = new Set(S.products.filter(p => p.kind === kind && p.active !== false).map(p => p.id));
  return S.lots.filter(l => prods.has(l.productId) && !l.archived).sort((a, b) => (product(a.productId).name || '').localeCompare(product(b.productId).name || '') || (a.expiry || '9').localeCompare(b.expiry || '9'));
}
function lotOptionLabel(l) {
  const p = product(l.productId);
  return `${p.name}${l.lot ? ' · lot ' + l.lot : ''}${l.expiry ? ' · exp ' + fmtMonthYear(l.expiry) : ''}${l.expiry && l.expiry < todayISO() ? ' · expired' : ''}`;
}
function defaultToolSettings() {
  const out = {};
  for (const k of ['toxin', 'filler', 'booster', 'device', 'thread']) {
    const first = lotsForKind(k).find(l => lotLeft(l.id) > 0 && (!l.expiry || l.expiry >= todayISO())) || null;
    out[k] = { lotId: first ? first.id : '', product: first ? product(first.productId).name : '', area: '', depth: '', settings: '',
      amount: { toxin: 4, filler: 0.1, booster: 0.05, device: 100, thread: 1 }[k] };
  }
  out.pen = { color: PEN_COLORS[0] };
  out.text = { color: PEN_COLORS[0] };
  return out;
}

// A view with no face drawing opens only on a photo or a chart already made. Every view has one now.
function chartViewBlocked(visitId, viewKey) {
  const cv = CHART_VIEWS.find(x => x.key === viewKey);
  if (!cv || cv.drawing || S.charts.some(c => c.visitId === visitId && c.view === viewKey)) return '';
  const v = visit(visitId), p = patient(v.patientId);
  if (p.photoConsent !== 'no' && defaultChartPhoto(v, viewKey)) return '';
  return p.photoConsent === 'no' ? 'The patient declined photos.' : `Add a ${cv.label} photo to this visit first.`;
}

// opts.dock: an element to show the chart in, inside a page. The Full chart page has one
// (#chartdock) and every chart opened while it is on screen goes there. opts.max opens it
// full screen.
async function openChart(visitId, viewKey, opts = {}) {
  if (viewKey === HEAD_CHART.key) return openHeadChart(visitId);
  const dock = opts.dock !== undefined ? opts.dock : document.getElementById('chartdock');
  const v = visit(visitId), p = patient(v.patientId);
  markSeen(v.patientId, 'chart');
  const existing = S.charts.find(c => c.visitId === visitId && c.view === viewKey);
  let chart;
  if (existing) chart = JSON.parse(JSON.stringify(existing));
  else {
    const ph = p.photoConsent === 'no' ? null : defaultChartPhoto(v, viewKey);
    const blocked = chartViewBlocked(visitId, viewKey);
    if (blocked) { toast(blocked); return; }
    chart = { id: uid(), patientId: p.id, visitId, view: viewKey, base: ph ? { type: 'photo', photoId: ph.id } : { type: 'drawing' }, marks: [], dilution: { units: 100, ml: 2.5 } };
  }
  const saved = (S.editorSettings && S.editorSettings.tools) || null;
  E = {
    v, p, chart, isNew: !existing, tool: 'toxin', sel: -1, undo: [], redo: [], dirty: false, zoom: 1, penSeen: false,
    tools: saved || defaultToolSettings(), showPrev: true, prev: previousChart(v, viewKey), img: null, prevImg: null,
    readOnly: !!v.signedAt || !can('edit'), docked: !!dock, max: !!opts.max,
  };
  if (!E.chart.dilution) E.chart.dilution = { units: 100, ml: 2.5 };
  await loadBase();
  if (E.prev && E.prev.chart.base.type === 'photo') E.prevImg = fullURL(E.prev.chart.base.photoId);
  if (dock) {
    dock.innerHTML = `<div class="editor docked${E.max ? ' max' : ''}" id="editor" role="region" aria-label="Treatment chart"></div>`;
    document.body.classList.toggle('chart-max', E.max);
    // A docked chart saves itself a moment after each change.
    E.timer = setInterval(dockTick, 1200);
  } else document.body.insertAdjacentHTML('beforeend', `<div class="editor" id="editor" role="dialog" aria-label="Treatment chart"></div>`);
  document.addEventListener('keydown', edKeys);
  edRender();
}

// Saves once a whole tick has gone by with no change, so a run of taps saves as one.
function dockTick() {
  const e = E;
  if (!e || !e.docked || !e.dirty || e.readOnly || e.saving || e.down) return;
  if (e.seenAt !== e.changedAt) { e.seenAt = e.changedAt; return; }
  dockSave(e);
}
async function dockSave(e) {
  e.saving = true; edStatus();
  try { await edSave(e); }
  catch (err) { fail(err); }
  finally { e.saving = false; edStatus(); }
  if (typeof fcAfterChartSave === 'function') fcAfterChartSave(e.v.id);
}
// Leaving the page with a docked chart: saves what is not saved yet, without waiting.
function dockFlush() {
  const e = E;
  if (!e || !e.docked || !e.dirty || e.readOnly || e.saving) return;
  edSave(e).catch(fail);
}
function edStatus() {
  const el = document.getElementById('edstatus');
  if (!el || !E) return;
  const empty = E.isNew && !(E.chart.marks || []).length;
  el.textContent = E.readOnly ? 'View only' : empty ? 'Nothing charted' : E.saving || E.dirty ? 'Saving' : 'Saved';
  el.dataset.state = !empty && (E.saving || E.dirty) ? 'busy' : 'ok';
}
const ICON_MAX = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>';
const ICON_MIN = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>';
function edSetMax(on) {
  if (!E || !E.docked) return;
  E.max = on;
  const root = document.getElementById('editor');
  if (root) root.classList.toggle('max', on);
  document.body.classList.toggle('chart-max', on);
  edRender();
}

// The running count under the picture: points and amount for each product.
function edFootText() {
  const marks = E.chart.marks || [];
  const lines = linesFromMarks(marks);
  if (!lines.length) return E.readOnly ? 'No treatment marks.' : 'Pick a tool and tap the picture.';
  const points = marks.filter(m => m.t === 'toxin').length;
  return `${points ? plural(points, 'point') + ' · ' : ''}${lines.map(l => `${l.product || KINDS[l.kind].label} ${trimNum(l.amount)} ${l.unit}`).join(' · ')}`;
}

async function loadBase() {
  const c = E.chart;
  if (c.base.type === 'photo') {
    const url = fullURL(c.base.photoId);
    const meta = photoMeta(c.base.photoId);
    if (url && meta) { E.img = url; c.w = meta.w; c.h = meta.h; return; }
    c.base = { type: 'drawing' };
  }
  E.img = null; c.w = FACE_W; c.h = FACE_H;
}

function edClose() {
  document.removeEventListener('keydown', edKeys);
  if (typeof besideDispose === 'function') besideDispose();
  if (E && E.timer) clearInterval(E.timer);
  if (E && E.docked) document.body.classList.remove('chart-max');
  if (E && E.dispose) E.dispose();
  const el = document.getElementById('editor');
  if (el) el.remove();
  E = null;
}

function edKeys(e) {
  if (!E || document.querySelector('.scrim')) return;
  if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? edRedo() : edUndo(); }
  else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); edRedo(); }
  else if ((e.key === 'Delete' || e.key === 'Backspace') && E.sel >= 0) { e.preventDefault(); edDelete(E.sel); }
  else if (e.key === 'Escape' && E.sel >= 0) { E.sel = -1; edRender(); }
  else if (e.key === 'Escape' && E.docked && E.max) edSetMax(false);
}

function edPush() {
  E.changedAt = (E.changedAt || 0) + 1;
  E.undo.push(JSON.stringify(E.chart.marks));
  if (E.undo.length > 100) E.undo.shift();
  E.redo = [];
  E.dirty = true;
}
function edUndo() { if (!E.undo.length) return; E.redo.push(JSON.stringify(E.chart.marks)); E.chart.marks = JSON.parse(E.undo.pop()); E.sel = -1; E.dirty = true; edRender(); }
function edRedo() { if (!E.redo.length) return; E.undo.push(JSON.stringify(E.chart.marks)); E.chart.marks = JSON.parse(E.redo.pop()); E.sel = -1; E.dirty = true; edRender(); }
function edDelete(i) { edPush(); E.chart.marks.splice(i, 1); E.sel = -1; edRender(); }

function prevShown() {
  const stage = document.querySelector('#editor .ed-stage');
  return !!(E.showPrev && E.prev && stage && stage.clientWidth > 600);
}
function fitScale() {
  const stage = document.querySelector('#editor .ed-stage');
  const c = E.chart;
  if (!stage) return 1;
  const sw = stage.clientWidth - 24, sh = stage.clientHeight - 48;
  const extra = prevShown() ? (E.prev.chart.w / E.prev.chart.h) * c.h : 0;
  const k = Math.min(sh / c.h, (sw - (extra ? 12 : 0)) / (c.w + extra));
  return Math.max(0.05, k);
}

function edRender() {
  if (E && E.render) return E.render();
  const root = document.getElementById('editor');
  if (!root) return;
  const { v, p, chart } = E;
  const viewLabel = CHART_VIEWS.find(x => x.key === chart.view).label;
  const ro = E.readOnly;
  const toolBtn = (k, label, icon) => `<button class="tool" data-tool="${k}" aria-pressed="${E.tool === k}" title="${label}">${icon}<span>${label}</span></button>`;
  const seg = `<div class="seg" role="group" aria-label="Chart view">${CHART_VIEWS.map(x => `<button data-ed="view" data-view="${x.key}" aria-pressed="${x.key === chart.view}">${x.label}</button>`).join('')}<button data-ed="view" data-view="${HEAD_CHART.key}" aria-pressed="false">${HEAD_CHART.label}</button></div>`;
  root.innerHTML = `
    ${E.docked ? `<div class="ed-top">
      ${E.max ? `<div class="ttl">${esc(viewLabel)} chart · ${esc(p.name)}<small>${fmtDate(v.date)}${ro ? ' · signed, view only' : ''}</small></div>` : ''}
      ${seg}
      <span class="spacer"></span>
      <span class="ed-status" id="edstatus" role="status"></span>
      <button class="btn secondary small ed-side-toggle" data-ed="side">Settings</button>
      <button class="btn secondary small ed-max" data-ed="max" aria-pressed="${E.max}" title="${E.max ? 'Back to the split screen (Esc)' : 'Full screen'}" aria-label="${E.max ? 'Exit full screen' : 'Full screen'}">${E.max ? ICON_MIN + '<span>Exit full screen</span>' : ICON_MAX}</button>
    </div>` : `<div class="ed-top">
      <button class="btn secondary small" data-ed="close">Back</button>
      <div class="ttl">${esc(viewLabel)} chart · ${esc(p.name)}<small>${fmtDate(v.date)}${ro ? ' · signed, view only' : ''}</small></div>
      <span class="spacer"></span>
      ${seg}
      <button class="btn secondary small ed-side-toggle" data-ed="side">Settings</button>
      ${ro ? '' : `<button class="btn primary small" data-ed="save">Save</button>`}
    </div>`}
    <div class="ed-body">
      <div class="ed-tools" role="toolbar" aria-label="Tools">
        ${toolBtn('select', 'Select', TOOL_ICONS.select)}
        ${toolBtn('hand', 'Move', TOOL_ICONS.hand)}
        ${ro ? edReopenTool() : `<hr>
        ${drawToolsHTML(toolBtn)}
        <hr>
        ${toolBtn('pen', 'Pen', TOOL_ICONS.pen)}
        ${toolBtn('text', 'Text', TOOL_ICONS.text)}
        ${toolBtn('erase', 'Erase', TOOL_ICONS.erase)}
        <hr>
        <button class="tool" data-ed="undo" ${E.undo.length ? '' : 'disabled'}>${TOOL_ICONS.undo}<span>Undo</span></button>
        <button class="tool" data-ed="redo" ${E.redo.length ? '' : 'disabled'}>${TOOL_ICONS.redo}<span>Redo</span></button>`}
      </div>
      <div class="ed-stage"><div class="wrap">
        <div class="cur"><span class="meta" id="curlabel">This visit · ${fmtDate(v.date)}</span>
        <svg class="board" id="board" viewBox="0 0 ${chart.w} ${chart.h}" xmlns="http://www.w3.org/2000/svg">
          ${chart.base.type === 'photo' ? `<image href="${E.img}" x="0" y="0" width="${chart.w}" height="${chart.h}" preserveAspectRatio="none"/>` : `<rect width="${chart.w}" height="${chart.h}" fill="#fff"/>${faceArt(chart.view)}`}
          <g id="marks">${marksSVG(chart.marks, chart.w, chart.h, { selected: E.sel })}</g>
          <polyline id="live" fill="none" stroke="#1F5E99" stroke-width="${(markSize(chart.w, chart.h) * 0.3).toFixed(1)}" stroke-dasharray="6 4" points=""/>
        </svg></div>
        ${E.showPrev && E.prev ? `<div class="prev" id="prevbox"><span class="meta">Last visit · ${fmtDate(E.prev.visit.date)}</span>${chartSVG(E.prev.chart, E.prevImg, 'id="prevsvg"')}</div>` : ''}
      </div>
      <div class="ed-zoom"><button data-ed="zoom-out" aria-label="Zoom out">−</button><button data-ed="fit" aria-label="Fit to screen">⤢</button><button data-ed="zoom-in" aria-label="Zoom in">+</button></div>
      ${E.docked ? `<div class="ed-foot" id="edfoot">${esc(edFootText())}</div>` : ''}
      </div>
      <aside class="ed-side" id="edside">${E.docked ? '<button class="btn secondary small ed-side-close" data-ed="side">Close</button>' : ''}${edSide()}</aside>
    </div>`;
  edSize();
  edWire(root);
  besideRefresh();
  edStatus();
  if (E.docked && typeof fcStripMark === 'function') fcStripMark();
}

function edSize() {
  const k = fitScale() * E.zoom;
  const board = document.getElementById('board');
  if (!board) return;
  board.style.width = Math.round(E.chart.w * k) + 'px';
  board.style.height = Math.round(E.chart.h * k) + 'px';
  const box = document.getElementById('prevbox');
  if (box) box.style.display = prevShown() ? '' : 'none';
  // Today's chart carries a label too while last visit's sits beside it, so both pictures start on one line.
  const cur = document.getElementById('curlabel');
  if (cur) cur.style.display = box && prevShown() ? '' : 'none';
  const prev = document.getElementById('prevsvg');
  if (prev) {
    const pk = (E.chart.h * k) / E.prev.chart.h;
    prev.style.height = Math.round(E.chart.h * k) + 'px';
    prev.style.width = Math.round(E.prev.chart.w * pk) + 'px';
  }
}

function itemSelect(kind, current) {
  const opts = lotsForKind(kind);
  return `<select data-set="lotId">
    ${opts.map(l => `<option value="${l.id}" ${l.id === current.lotId ? 'selected' : ''}>${esc(lotOptionLabel(l))}</option>`).join('')}
    <option value="" ${!current.lotId ? 'selected' : ''}>Not in the product list</option>
  </select>`;
}

function markFields(kind, m, scope) {
  // scope 'tool' edits the settings for the next mark, 'mark' edits the selected mark
  const unit = m.lotId && lot(m.lotId) ? product(lot(m.lotId).productId).unit : KINDS[kind].unit;
  const amtLabel = kind === 'toxin' ? 'Units per point' : kind === 'device' ? `Amount (${unit})` : kind === 'thread' ? 'Threads' : `Amount (${unit})`;
  const areaList = AREAS[kind] || [];
  let h = `<label class="field"><span class="label">Product and lot</span>${itemSelect(kind, m)}</label>`;
  if (!m.lotId) h += `<label class="field"><span class="label">Product</span><input type="text" data-set="product" value="${esc(m.product || '')}" list="dl-${kind}" placeholder="${esc((PRODUCT_HINTS[kind] || [''])[0])}"><datalist id="dl-${kind}">${(PRODUCT_HINTS[kind] || []).map(x => `<option value="${esc(x)}">`).join('')}</datalist></label>`;
  h += `<label class="field"><span class="label">${amtLabel}</span><input type="number" step="any" min="0" inputmode="decimal" data-set="amount" value="${esc(m.amount ?? '')}"></label>`;
  if (kind === 'device') h += `<label class="field"><span class="label">Settings</span><input type="text" data-set="settings" value="${esc(m.settings || '')}" placeholder="3.0 mm, 0.8 J"></label>`;
  if (kind === 'filler' || kind === 'booster') h += `<label class="field"><span class="label">Depth</span><select data-set="depth"><option value=""></option>${DEPTHS.map(d => `<option ${m.depth === d ? 'selected' : ''}>${d}</option>`).join('')}</select></label>`;
  h += `<label class="field"><span class="label">Area</span><input type="text" data-set="area" value="${esc(m.area || '')}" list="area-${kind}" placeholder="${esc(areaList[0] || '')}"><datalist id="area-${kind}">${areaList.map(x => `<option value="${esc(x)}">`).join('')}</datalist></label>`;
  return h;
}

// The selected mark's fields, or the settings for the next mark of the current tool.
// A signed chart opens view only. A doctor can reopen the visit from the chart itself.
function edReopenTool() { return E.v.signedAt && can('sign') ? `<hr><button class="tool" data-ed="reopen">${I.edit}<span>Reopen</span></button>` : ''; }
async function edReopen() {
  if (E.docked) return reopenVisitFlow(E.v.id);
  const r = await ask({ title: 'Reopen this visit?', body: 'The visit history keeps the signed version and every change after it.', buttons: [{ label: 'Cancel', value: null }, { label: 'Reopen', value: true, kind: 'primary' }] });
  if (!r) return;
  try { await save('visits', { ...visit(E.v.id), signedAt: null, signedBy: null }, { action: 'Visit reopened' }); } catch (e) { return fail(e); }
  E.v = visit(E.v.id); E.readOnly = !can('edit'); E.tool = E.readOnly ? 'select' : 'toxin'; E.sel = -1;
  (E.render || edRender)();
}
function edToolPanel() {
  const c = E.chart, ro = E.readOnly;
  let h = ro && E.v.signedAt ? `<p class="banner info"><span>This visit is signed, so the chart is view only.</span> <span>${can('sign') ? 'Press Reopen to change it.' : 'A doctor can reopen it.'}</span></p>` : '';
  if (E.sel >= 0 && c.marks[E.sel]) {
    const m = c.marks[E.sel];
    h += `<h3>Selected ${m.t === 'pen' ? 'line' : m.t === 'text' ? 'text' : KINDS[m.t].short.toLowerCase()}</h3><div data-scope="mark">`;
    if (m.copy) h += `<p class="banner info">A copy of a template placed on the other picture. Its dose is counted there, not here.</p>`;
    if (m.technique === 'arrow') h += `<p class="meta">Linear threading, one arrow.</p>`;
    else if (m.technique === 'fan') h += `<p class="meta">${m.pts ? `Fanning, ${m.pts.length - 1} arrows from one entry point.` : 'Fanning.'} The amount is for the whole fan.</p>`;
    if (KINDS[m.t] && m.t !== 'other') h += markFields(m.t, m, 'mark');
    if (m.t === 'text') h += `<label class="field"><span class="label">Text</span><input type="text" data-set="text" value="${esc(m.text)}"></label>`;
    if (m.t === 'pen' || m.t === 'text') h += `<div class="field"><span class="label">Colour</span><div class="colors">${PEN_COLORS.map(col => `<button data-color="${col}" aria-pressed="${m.color === col}" style="background:${col}" aria-label="Colour ${col}"></button>`).join('')}</div></div>`;
    h += `</div>${ro ? '' : `<div class="row"><button class="btn danger small" data-ed="del">Delete</button><button class="btn secondary small" data-ed="desel">Done</button></div>`}`;
  } else if (!ro && KINDS[E.tool]) {
    const t = E.tools[E.tool];
    const how = E.tool === 'toxin' ? 'Tap each injection point.'
      : E.tool === 'device' ? 'Drag around the area to shade it.'
      : E.tool === 'thread' ? 'Drag along the thread path from the entry point.'
      : E.tool === 'filler' ? FILLER_TECHS.find(x => x.key === fillerTech(t)).how
      : 'Tap for a bolus or drag around an area.';
    const techs = E.tool === 'filler' ? `<div class="seg tech" role="radiogroup" aria-label="Technique">${FILLER_TECHS.map(x => `<label class="${fillerTech(t) === x.key ? 'on' : ''}"><input type="radio" name="tech" data-set="technique" value="${x.key}" ${fillerTech(t) === x.key ? 'checked' : ''}>${techIcon(x.key)}<span>${x.label}</span></label>`).join('')}</div>` : '';
    h += `<h3>${KINDS[E.tool].label}</h3><div data-scope="tool">${techs}<p class="meta">${how}</p>${markFields(E.tool, t, 'tool')}</div>`;
    if (E.tool === 'toxin') {
      const d = c.dilution;
      h += `<div class="field"><span class="label">Dilution</span><div class="grid2"><input type="number" data-dil="units" value="${esc(d.units)}" aria-label="Units in the vial"><input type="number" step="any" data-dil="ml" value="${esc(d.ml)}" aria-label="Saline in ml"></div>
        <span class="hint" id="dilhint">${dilHint()}</span></div>`;
    }
  } else if (!ro && (E.tool === 'pen' || E.tool === 'text')) {
    const t = E.tools[E.tool];
    h += `<h3>${E.tool === 'pen' ? 'Pen' : 'Text'}</h3><p class="meta">${E.tool === 'pen' ? 'Draw freehand.' : 'Tap where the text goes.'}</p>
      <div class="field" data-scope="tool"><span class="label">Colour</span><div class="colors">${PEN_COLORS.map(col => `<button data-color="${col}" aria-pressed="${t.color === col}" style="background:${col}" aria-label="Colour ${col}"></button>`).join('')}</div></div>`;
  } else if (E.tool === 'erase') {
    h += `<h3>Erase</h3><p class="meta">Tap a mark to remove it.</p>`;
  } else if (E.tool === 'hand') {
    h += E.kind === 'head' ? `<h3>Turn</h3><p class="meta">Drag to turn the head.</p>` : `<h3>Move</h3><p class="meta">Tap to zoom in on a spot and tap again to see it all. Pinch to zoom, drag to move around.</p>`;
  } else {
    h += `<h3>Select</h3><p class="meta">${ro ? 'Tap a mark to see what was given.' : E.kind === 'head' ? 'Tap a mark to change it. Drag a point to a new spot.' : 'Tap a mark to change it or drag it to a new spot.'}</p>`;
  }
  return h + `<div id="edtot">${edTotals()}</div>`;
}

function edSide() {
  const c = E.chart, ro = E.readOnly;
  let h = edToolPanel() + templatesPanelHTML() + besideFieldHTML();

  // base
  h += `<h3 style="margin-top:16px">Base</h3>`;
  const photos = photosOf(E.p.id);
  const want = CHART_VIEWS.find(x => x.key === c.view).photo;
  const ordered = [...photos.filter(x => x.visitId === E.v.id && x.view === want), ...photos.filter(x => !(x.visitId === E.v.id && x.view === want))];
  if (!ro) {
    const drawable = CHART_VIEWS.find(x => x.key === c.view).drawing;
    h += `<div class="row" style="margin-bottom:8px">${drawable ? `<button class="btn ${c.base.type === 'drawing' ? 'primary' : 'secondary'} small" data-ed="drawing">Face drawing</button>` : ''}<button class="btn secondary small" data-ed="view" data-view="${HEAD_CHART.key}">3D head</button></div>`;
    if (E.p.photoConsent === 'no') h += `<p class="meta">The patient declined photos.</p>`;
    else if (!ordered.length) h += `<p class="meta">No photos yet. Add them under Photos on the visit page.</p>`;
    else h += `<div class="photo-grid" style="grid-template-columns:repeat(3,1fr);gap:6px">${ordered.slice(0, 12).map(ph => `<button class="ph" data-ed="photo" data-id="${ph.id}" style="padding:0;cursor:pointer;${c.base.photoId === ph.id ? 'outline:3px solid var(--p600)' : ''}" title="${esc(ph.view)} · ${esc(ph.stage || '')} · ${fmtDate(ph.date)}"><img src="${thumbURL(ph.id)}" alt="${esc(ph.view)}"></button>`).join('')}</div>`;
  }

  if (E.prev) {
    h += `<h3 style="margin-top:16px">Last visit</h3><p class="meta">${fmtDate(E.prev.visit.date)} · ${linesFromMarks(E.prev.chart.marks).map(l => `${esc(l.product || KINDS[l.kind].label)} ${trimNum(l.amount)} ${esc(l.unit)}`).join(', ')}</p>
      <div class="row"><button class="btn secondary small" data-ed="toggle-prev">${E.showPrev ? 'Hide' : 'Show'}</button>${ro ? '' : `<button class="btn secondary small" data-ed="copy-prev">Copy its marks</button>`}</div>`;
  }
  return h;
}

function edTotals() {
  const c = E.chart;
  const lines = linesFromMarks(c.marks);
  let h = `<h3 style="margin-top:16px">On this chart</h3>`;
  if (!lines.length) return h + `<p class="meta">No treatment marks yet.</p>`;
  const perU = num(c.dilution.ml) / Math.max(1, num(c.dilution.units));
  h += `<div class="tot">${lines.map(l => `<div><span>${esc(l.product || KINDS[l.kind].label)}${l.lot ? ` <span class="meta">lot ${esc(l.lot)}</span>` : ''}</span><b>${trimNum(l.amount)} ${esc(l.unit)}${l.kind === 'toxin' ? ` <span class="meta">${trimNum(l.amount * perU, 2)} ml</span>` : ''}</b></div>`).join('')}</div>`;
  const others = chartsOfVisit(E.v.id).filter(x => x.view !== c.view);
  if (others.length) {
    const all = linesFromMarks([...c.marks, ...others.flatMap(x => x.marks || [])]);
    h += `<p class="meta" style="margin-top:8px">Whole visit: ${all.map(l => `${esc(l.product || KINDS[l.kind].label)} ${trimNum(l.amount)} ${esc(l.unit)}`).join(', ')}</p>`;
  }
  return h;
}
function dilHint() {
  const d = E.chart.dilution, t = E.tools.toxin, perU = num(d.ml) / Math.max(1, num(d.units));
  return `Units in the vial and ml of saline. ${trimNum(t.amount)} U is ${trimNum(num(t.amount) * perU, 3)} ml at this dilution.`;
}

function edWire(root) {
  root.querySelectorAll('[data-tool]').forEach(b => b.onclick = () => { E.tool = b.dataset.tool; E.sel = -1; edRender(); });
  root.querySelectorAll('[data-tech]').forEach(b => b.onclick = () => setFillerTech(b.dataset.tech));
  root.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => edAction(b.dataset.ed, b));
  const side = root.querySelector('#edside');
  side.addEventListener('change', edSideChange);
  side.addEventListener('input', e => { if (e.target.matches('input[data-set], [data-dil]')) edSideChange(e); });
  side.addEventListener('focusin', e => { if (e.target.closest('[data-scope="mark"]') && e.target.matches('[data-set]')) edPush(); });
  side.querySelectorAll('[data-color]').forEach(b => b.onclick = () => {
    const scope = b.closest('[data-scope]').dataset.scope;
    if (scope === 'mark') { edPush(); E.chart.marks[E.sel].color = b.dataset.color; } else E.tools[E.tool].color = b.dataset.color;
    edRender();
  });
  const stage = root.querySelector('.ed-stage');
  stage.addEventListener('wheel', e => { if (!e.ctrlKey) return; e.preventDefault(); E.zoom = Math.min(6, Math.max(0.5, E.zoom * (e.deltaY < 0 ? 1.12 : 0.89))); edSize(); }, { passive: false });
  const board = root.querySelector('#board');
  board.addEventListener('pointerdown', edDown);
  window.onresize = () => E && edSize();
}

function edSideHTML() {
  const side = document.getElementById('edside');
  const open = side.classList.contains('open');
  side.innerHTML = (E.docked ? '<button class="btn secondary small ed-side-close" data-ed="side">Close</button>' : '') + edSide();
  side.classList.toggle('open', open);
}
function edSideChange(e) {
  const el = e.target;
  if (el.matches('[data-beside]')) { if (e.type === 'change') setBeside(el.value); return; }
  const refresh = () => {
    if (E.redraw) E.redraw(); else document.getElementById('marks').innerHTML = marksSVG(E.chart.marks, E.chart.w, E.chart.h, { selected: E.sel });
    document.getElementById('edtot').innerHTML = edTotals();
    const foot = document.getElementById('edfoot');
    if (foot) foot.textContent = edFootText();
    if (E.dirty) E.changedAt = (E.changedAt || 0) + 1;
    edStatus();
    const dh = document.getElementById('dilhint');
    if (dh) dh.textContent = dilHint();
  };
  if (el.dataset.dil) { E.chart.dilution[el.dataset.dil] = num(el.value); E.dirty = true; refresh(); return; }
  const key = el.dataset.set;
  if (!key) return;
  const scope = el.closest('[data-scope]').dataset.scope;
  let v = el.value;
  if (key === 'amount') v = v === '' ? '' : num(v);
  const target = scope === 'mark' ? E.chart.marks[E.sel] : E.tools[E.tool];
  if (!target) return;
  if (scope === 'mark') E.dirty = true;
  target[key] = v;
  if (key === 'lotId') {
    const l = lot(v), p = l ? product(l.productId) : null;
    if (p) { target.product = p.name; target.unit = p.unit; target.productId = p.id; } else { target.unit = undefined; target.productId = ''; }
  }
  if (scope === 'tool') S.editorSettings = { tools: E.tools };
  if (key === 'lotId' || key === 'technique') { if (E.sideRefresh) E.sideRefresh(); else { edSideHTML(); edWireSide(); } }
  refresh();
}

async function edAction(a, b) {
  const c = E.chart;
  if (a === 'close') {
    if (E.dirty && !E.readOnly) {
      const r = await ask({ title: 'Save the chart?', body: 'The changes on this chart are not saved yet.', buttons: [{ label: 'Discard', value: 'discard', kind: 'danger' }, { label: 'Cancel', value: null }, { label: 'Save', value: 'save', kind: 'primary' }] });
      if (!r) return;
      if (r === 'save') await edSave();
    }
    edClose(); render();
  } else if (a === 'save') { await edSave(); toast('Chart saved.'); edRender(); }
  else if (a === 'view') {
    const view = b.dataset.view;
    if (view === c.view) return;
    const blocked = chartViewBlocked(E.v.id, view);
    if (blocked) { toast(blocked); return; }
    if (E.dirty && !E.readOnly) await edSave();
    const vid = E.v.id, max = E.docked && E.max, was = c.view;
    edClose(); await openChart(vid, view, { max });
    // the 3D head may not open (none built, or the build was cancelled): the chart that was open comes back
    if (!E && document.getElementById('chartdock')) await openChart(vid, was, { max });
  }
  else if (a === 'max') edSetMax(!E.max);
  else if (a === 'undo') edUndo();
  else if (a === 'redo') edRedo();
  else if (a === 'del') edDelete(E.sel);
  else if (a === 'desel') { E.sel = -1; edRender(); }
  else if (a === 'reopen') await edReopen();
  else if (a === 'tpl') await applyTemplate(b.dataset.id);
  else if (a === 'tpl-save') await saveTemplateSpots();
  else if (a === 'tpl-reset') await resetTemplateSpots();
  else if (a === 'zoom-in') { E.zoom = Math.min(6, E.zoom * 1.25); edSize(); }
  else if (a === 'zoom-out') { E.zoom = Math.max(0.5, E.zoom / 1.25); edSize(); }
  else if (a === 'fit') { E.zoom = 1; edSize(); }
  else if (a === 'side') document.getElementById('edside').classList.toggle('open');
  else if (a === 'toggle-prev') { E.showPrev = !E.showPrev; E.beside = E.showPrev ? 'prev' : ''; edRender(); }
  else if (a === 'copy-prev') {
    if (c.marks.length) {
      const r = await ask({ title: "Copy last visit's marks?", body: 'They are added to the marks already on this chart.', buttons: [{ label: 'Cancel', value: null }, { label: 'Copy', value: true, kind: 'primary' }] });
      if (!r) return;
    }
    edPush();
    for (const m of E.prev.chart.marks) {
      const copy = JSON.parse(JSON.stringify(m));
      // the lot used last time may be finished: move to the current lot of the same product
      const old = copy.lotId ? lot(copy.lotId) : null;
      if (copy.lotId && (!old || old.archived || lotLeft(old.id) <= 0)) {
        const next = old ? pickLot(old.productId) : null;
        copy.lotId = next ? next.id : '';
      }
      c.marks.push(copy);
    }
    edRender();
  }
  else if (a === 'drawing') { if (c.base.type !== 'drawing') { c.base = { type: 'drawing' }; await loadBase(); E.dirty = true; E.zoom = 1; edRender(); } }
  else if (a === 'photo') { c.base = { type: 'photo', photoId: b.dataset.id }; await loadBase(); E.dirty = true; E.zoom = 1; edRender(); }
}

// e is the editor state the save started from, so a save still running when the chart
// changes view finishes on the right chart. Changes made while it runs stay unsaved.
async function edSave(e = E) {
  const c = e.chart;
  if (e.isNew && !c.marks.length) { e.dirty = false; return; }
  const snap = JSON.stringify([c.marks, c.dilution, c.base]);
  const wasNew = e.isNew;
  e.isNew = false;
  try { await save('charts', JSON.parse(JSON.stringify(c)), { action: wasNew ? 'Chart started' : 'Chart edited' }); }
  catch (err) { e.isNew = wasNew; throw err; }
  e.dirty = JSON.stringify([c.marks, c.dilution, c.base]) !== snap;
  await syncChartLines(e.v.id);
  e.v = visit(e.v.id);
}

// ---------- pointer input ----------
function toNorm(e) {
  const board = document.getElementById('board');
  const r = board.getBoundingClientRect();
  return [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))];
}

function simplify(pts, tol) {
  if (pts.length < 3) return pts;
  const out = [pts[0]];
  for (let i = 1; i < pts.length - 1; i++) {
    const a = out[out.length - 1], p = pts[i];
    if (Math.hypot(p[0] - a[0], p[1] - a[1]) >= tol) out.push(p);
  }
  out.push(pts[pts.length - 1]);
  return out.map(p => [+p[0].toFixed(4), +p[1].toFixed(4)]);
}

// Move: one finger drags a zoomed chart, two fingers pinch to zoom, and a tap on the whole chart
// zooms in on that spot. Another tap shows the whole chart again.
function edZoomAt(z, cx, cy, stage) {
  const r = stage.getBoundingClientRect(), k0 = fitScale() * E.zoom;
  const px = (stage.scrollLeft + cx - r.left) / k0, py = (stage.scrollTop + cy - r.top) / k0;
  E.zoom = Math.min(6, Math.max(1, z));
  edSize();
  const k1 = fitScale() * E.zoom;
  stage.scrollLeft = px * k1 - (cx - r.left); stage.scrollTop = py * k1 - (cy - r.top);
}
function edHand(e, board, stage) {
  e.preventDefault();
  board.setPointerCapture(e.pointerId);
  const T = E.touches || (E.touches = new Map());
  const id = e.pointerId;
  T.set(id, { x: e.clientX, y: e.clientY });
  const sx = e.clientX, sy = e.clientY, sl = stage.scrollLeft, st = stage.scrollTop;
  let moved = false;
  const two = () => { const [a, b] = [...T.values()]; return { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; };
  // Two fingers pinch. Once a second finger has been down, nothing pans or taps until all are up.
  if (T.size === 2) { const p = two(); E.pinching = { d0: p.d, z0: E.zoom }; }
  if (T.size > 1) E.multiTouch = true;
  // Each finger's handlers only answer to that finger, since the board captures every finger
  // and a handler that took another finger's lift would leave this one stuck in the set.
  const move = ev => {
    if (ev.pointerId !== id || !T.has(id)) return;
    T.set(id, { x: ev.clientX, y: ev.clientY });
    if (Math.hypot(ev.clientX - sx, ev.clientY - sy) > 6) moved = true;
    if (T.size >= 2 && E.pinching) { const p = two(); edZoomAt(E.pinching.z0 * p.d / E.pinching.d0, p.x, p.y, stage); return; }
    if (T.size === 1 && !E.multiTouch) { stage.scrollLeft = sl - (ev.clientX - sx); stage.scrollTop = st - (ev.clientY - sy); }
  };
  const up = ev => {
    if (ev.pointerId !== id) return;
    T.delete(id);
    board.removeEventListener('pointermove', move); board.removeEventListener('pointerup', up); board.removeEventListener('pointercancel', up);
    if (!T.size) {
      if (!moved && !E.multiTouch && ev.type === 'pointerup' && E.tool === 'hand') edZoomAt(E.zoom <= 1.01 ? 2.5 : 1, ev.clientX, ev.clientY, stage);
      E.pinching = null; E.multiTouch = false;
    }
  };
  board.addEventListener('pointermove', move); board.addEventListener('pointerup', up); board.addEventListener('pointercancel', up);
}

function edDown(e) {
  if (!E) return;
  const board = e.currentTarget;
  if (e.pointerType === 'pen') E.penSeen = true;
  const stage = board.closest('.ed-stage');
  const hit = e.target.closest('[data-i]');
  const hitI = hit ? +hit.dataset.i : -1;
  if (E.kind !== 'head' && (E.tool === 'hand' || (e.pointerType === 'touch' && E.touches && E.touches.size))) return edHand(e, board, stage);
  const pan = (E.penSeen && e.pointerType === 'touch') || e.button === 1;
  e.preventDefault();
  board.setPointerCapture(e.pointerId);
  E.down = true;
  const start = toNorm(e);
  const sx = e.clientX, sy = e.clientY, sl = stage.scrollLeft, st = stage.scrollTop;
  const pts = [start];
  let moved = false;
  const live = document.getElementById('live');
  const W = E.chart.w, H = E.chart.h;
  const sel0 = E.sel;
  let dragOrig = null;

  if (!pan && E.tool === 'select' && hitI >= 0) {
    E.sel = hitI;
    dragOrig = JSON.parse(JSON.stringify(E.chart.marks[hitI]));
    if (sel0 !== hitI) { document.getElementById('marks').innerHTML = marksSVG(E.chart.marks, W, H, { selected: E.sel }); edSideHTML(); edWireSide(); }
  }

  const move = ev => {
    if (Math.hypot(ev.clientX - sx, ev.clientY - sy) > 4) moved = true;
    if (pan) { stage.scrollLeft = sl - (ev.clientX - sx); stage.scrollTop = st - (ev.clientY - sy); return; }
    const p = toNorm(ev);
    if (E.tool === 'select' && dragOrig && !E.readOnly) {
      const dx = p[0] - start[0], dy = p[1] - start[1];
      const m = E.chart.marks[E.sel];
      if (dragOrig.pts) m.pts = dragOrig.pts.map(q => [+(q[0] + dx).toFixed(4), +(q[1] + dy).toFixed(4)]);
      else { m.x = +(dragOrig.x + dx).toFixed(4); m.y = +(dragOrig.y + dy).toFixed(4); }
      document.getElementById('marks').innerHTML = marksSVG(E.chart.marks, W, H, { selected: E.sel });
      return;
    }
    if (['filler', 'booster', 'device', 'thread', 'pen'].includes(E.tool)) {
      const ce = ev.getCoalescedEvents ? ev.getCoalescedEvents() : [ev];
      for (const c of ce) pts.push(toNorm(c));
      const fan = E.tool === 'filler' && fillerTech(E.tools.filler) === 'fan';
      live.setAttribute('points', ptsAttr(fan ? [start, pts[pts.length - 1]] : pts, W, H));
    }
  };
  const up = ev => {
    board.removeEventListener('pointermove', move);
    board.removeEventListener('pointerup', up);
    board.removeEventListener('pointercancel', up);
    E.down = false;
    live.setAttribute('points', '');
    if (pan || E.readOnly && E.tool !== 'select') return;
    const tol = 0.004;
    const s = E.tools[E.tool];
    const base = () => { const l = s.lotId ? lot(s.lotId) : null, p = l ? product(l.productId) : null; return { t: E.tool, lotId: s.lotId || '', productId: p ? p.id : '', product: p ? p.name : (s.product || ''), unit: p ? p.unit : KINDS[E.tool].unit, amount: s.amount, area: s.area || '' }; };
    if (E.tool === 'select') {
      if (dragOrig && moved && !E.readOnly) {
        const after = JSON.stringify(E.chart.marks);
        E.chart.marks[E.sel] = dragOrig; edPush(); E.chart.marks = JSON.parse(after);
      }
      if (hitI < 0) E.sel = -1;
      edRender();
      return;
    }
    if (E.tool === 'erase') { if (hitI >= 0) edDelete(hitI); return; }
    if (E.tool === 'toxin') {
      if (moved && pts.length > 3) return;
      edPush(); E.chart.marks.push({ ...base(), x: +start[0].toFixed(4), y: +start[1].toFixed(4) }); edRender(); return;
    }
    const tech = E.tool === 'filler' ? fillerTech(s) : 'point';
    if (tech === 'arrow' || tech === 'fan') {
      const end = pts[pts.length - 1], r4 = q => [+q[0].toFixed(4), +q[1].toFixed(4)];
      if (!moved || Math.hypot((end[0] - start[0]) * W, (end[1] - start[1]) * H) < markSize(W, H) * 2) { toast('Drag from the entry point to where the needle ends.'); return; }
      const j = tech === 'fan' ? fanAt(E.chart.marks, start, W, H) : -1;
      edPush();
      if (j >= 0) E.chart.marks[j].pts.push(r4(end));
      else if (tech === 'fan') E.chart.marks.push({ ...base(), depth: s.depth || '', technique: 'fan', pts: [r4(start), r4(end)] });
      else E.chart.marks.push({ ...base(), depth: s.depth || '', technique: 'arrow', pts: simplify(pts, 0.012) });
      edRender(); return;
    }
    // On Point, a stroke that doesn't come back round on itself is a needle line, so it
    // becomes an arrow. Only a loop shades an area.
    if (E.tool === 'filler' && moved && pts.length >= 4 && openStroke(pts.map(q => [q[0] * W, q[1] * H]), markSize(W, H))) {
      edPush(); E.chart.marks.push({ ...base(), depth: s.depth || '', technique: 'arrow', pts: simplify(pts, 0.012) }); edRender(); return;
    }
    if (E.tool === 'filler' || E.tool === 'booster') {
      edPush();
      if (!moved || pts.length < 4) E.chart.marks.push({ ...base(), depth: s.depth || '', x: +start[0].toFixed(4), y: +start[1].toFixed(4) });
      else E.chart.marks.push({ ...base(), depth: s.depth || '', pts: simplify(pts, tol) });
      edRender(); return;
    }
    if (E.tool === 'device' || E.tool === 'thread') {
      if (!moved || pts.length < 4) { toast(E.tool === 'device' ? 'Drag around the area to shade it.' : 'Drag along the thread path.'); return; }
      edPush(); E.chart.marks.push({ ...base(), settings: E.tool === 'device' ? s.settings || '' : undefined, pts: simplify(pts, tol) }); edRender(); return;
    }
    if (E.tool === 'pen') {
      if (pts.length < 2) pts.push([start[0] + 0.001, start[1] + 0.001]);
      edPush(); E.chart.marks.push({ t: 'pen', color: s.color, pts: simplify(pts, 0.002) }); edRender(); return;
    }
    if (E.tool === 'text') {
      textPrompt('').then(txt => { if (!txt) return; edPush(); E.chart.marks.push({ t: 'text', color: s.color, text: txt, x: +start[0].toFixed(4), y: +start[1].toFixed(4) }); edRender(); });
    }
  };
  board.addEventListener('pointermove', move);
  board.addEventListener('pointerup', up);
  board.addEventListener('pointercancel', up);
}

function edWireSide() {
  const side = document.getElementById('edside');
  side.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => edAction(b.dataset.ed, b));
  side.querySelectorAll('[data-color]').forEach(b => b.onclick = () => {
    const scope = b.closest('[data-scope]').dataset.scope;
    if (scope === 'mark') { edPush(); E.chart.marks[E.sel].color = b.dataset.color; } else E.tools[E.tool].color = b.dataset.color;
    edRender();
  });
}

function textPrompt(value) {
  return new Promise(resolve => {
    const scrim = document.createElement('div');
    scrim.className = 'scrim';
    scrim.innerHTML = `<form class="sheet" role="dialog" aria-modal="true"><h2>Add text</h2>
      <label class="field"><span class="label">Text</span><input type="text" name="t" value="${esc(value)}" placeholder="Avoid, previous bruise"></label>
      <div class="actions"><button type="button" class="btn secondary" data-x>Cancel</button><button class="btn primary">Add</button></div></form>`;
    const close = v => { scrim.remove(); resolve(v); };
    scrim.querySelector('[data-x]').onclick = () => close('');
    scrim.querySelector('form').onsubmit = e => { e.preventDefault(); close(scrim.querySelector('input').value.trim()); };
    scrim.addEventListener('click', e => { if (e.target === scrim) close(''); });
    document.body.appendChild(scrim);
    scrim.querySelector('input').focus();
  });
}
