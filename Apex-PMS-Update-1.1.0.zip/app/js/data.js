// Fixed lists and starting templates. Stored values stay in English and show in the
// person's language through i18n.js.

// Every product has a kind. The charted kinds draw on the treatment chart.
const KINDS = {
  toxin: { label: 'Botulinum toxin', short: 'Botox', unit: 'U', color: '#6A388C', chart: true },
  filler: { label: 'Filler', short: 'Filler', unit: 'ml', color: '#CC3366', chart: true },
  booster: { label: 'Skin booster', short: 'Skin booster', unit: 'ml', color: '#2E7DB5', chart: true },
  device: { label: 'Device cartridge', short: 'Device', unit: 'shots', color: '#C27A0E', chart: true },
  thread: { label: 'Thread', short: 'Thread', unit: 'pcs', color: '#0E6B4F', chart: true },
  medicine: { label: 'Medicine', short: 'Medicine', unit: 'amp', color: '#A33A2B' },
  other: { label: 'Other', short: 'Other', unit: 'pcs', color: '#5A4A66' },
};
const KIND_KEYS = Object.keys(KINDS);
const CHART_KINDS = KIND_KEYS.filter(k => KINDS[k].chart);

// The complication log.
const INCIDENT_TYPES = ['Bruising', 'Swelling', 'Lump or nodule', 'Suspected vascular occlusion', 'Allergic reaction', 'Infection', 'Drooping eyelid or brow', 'Uneven result', 'Burn or blister', 'Pigment change', 'Fainting', 'Other'];
const INCIDENT_SEVERITY = ['Mild', 'Moderate', 'Severe'];
const INCIDENT_OUTCOMES = ['Ongoing', 'Improving', 'Resolved', 'Referred'];
const SERVICE_CATS = ['Consultation', 'Botulinum toxin', 'Filler', 'Skin booster', 'Energy device', 'Thread lift', 'Facial', 'Peel', 'Laser', 'Body', 'Other'];
// The photo charts of a visit. Each has a face drawing for when there is no photo.
const CHART_VIEWS = [
  { key: 'front', label: 'Front', photo: 'Front', drawing: true },
  { key: 'right45', label: 'Right 45°', photo: 'Right 45°', drawing: true },
  { key: 'left45', label: 'Left 45°', photo: 'Left 45°', drawing: true },
  { key: 'right', label: 'Right side', photo: 'Right side', drawing: true },
  { key: 'left', label: 'Left side', photo: 'Left side', drawing: true },
];
const PHOTO_VIEWS = ['Front', 'Left side', 'Right side', 'Left 45°', 'Right 45°', 'Close-up', 'Other'];
// The 3D head chart: one per visit, drawn on the patient's built head.
const HEAD_CHART = { key: 'head', label: '3D head' };
// Its standard views, with the photo view each one is built from.
const HEAD_VIEWS = [
  { key: 'front', label: 'Front', photo: 'Front' },
  { key: 'right45', label: 'Right 45°', photo: 'Right 45°' },
  { key: 'left45', label: 'Left 45°', photo: 'Left 45°' },
  { key: 'right', label: 'Right side', photo: 'Right side' },
  { key: 'left', label: 'Left side', photo: 'Left side' },
];
const PHOTO_STAGES = ['Baseline', 'Before', 'After', 'Follow-up'];

const AREAS = {
  toxin: ['Forehead', 'Glabella', "Crow's feet", 'Brow lift', 'Bunny lines', 'Gummy smile', 'Lip flip', 'DAO', 'Chin', 'Masseter', 'Platysma', 'Neck', 'Underarm'],
  filler: ['Temple', 'Forehead', 'Tear trough', 'Cheek', 'Nasolabial fold', 'Nose', 'Lips', 'Marionette', 'Pre-jowl', 'Chin', 'Jawline', 'Neck'],
  booster: ['Full face', 'Under eye', 'Cheek', 'Neck', 'Hands'],
  device: ['Full face', 'Forehead', 'Periorbital', 'Cheek', 'Submental', 'Jawline', 'Neck'],
  thread: ['Brow', 'Midface', 'Jawline', 'Neck', 'Nose'],
};
const PRODUCT_HINTS = {
  toxin: ['Botox 100 U', 'Dysport 300 U', 'Xeomin 100 U', 'Nabota 100 U', 'Botulax 100 U'],
  filler: ['Juvederm Voluma', 'Juvederm Volift', 'Juvederm Volbella', 'Restylane Lyft', 'Restylane Kysse', 'Belotero Balance'],
  booster: ['Profhilo', 'Rejuran', 'Juvederm Volite'],
  device: ['HIFU cartridge 4.5 mm', 'HIFU cartridge 3.0 mm', 'Thermage tip', 'RF microneedling tip'],
  thread: ['PDO mono', 'PDO cog', 'PCL cog'],
  medicine: ['Lidocaine 2% 5 ml vial', 'Tranexamic acid 500 mg ampoule', 'Hyaluronidase 1500 IU vial', 'Glutathione 600 mg vial', 'Ascorbic acid 500 mg ampoule', 'Diphenhydramine 50 mg ampoule', 'Epinephrine 1 mg/ml ampoule'],
};
const UNITS = ['U', 'ml', 'cc', 'shots', 'shot', 'tip', 'lines', 'pcs', 'pair', 'thread', 'syringe', 'vial', 'amp', 'tab', 'tube', 'dose', 'bottle', 'box', 'pack', 'set', 'cycle', 'min', 'session'];
const DEPTHS = ['Supraperiosteal', 'Subcutaneous', 'Deep dermis', 'Superficial dermis', 'Submucosal', 'Intramuscular'];
const WEEKDAYS = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];
const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

// Pre-treatment screening shown on every patient record.
const SCREEN = [
  { k: 'pregnant', label: 'Pregnant or breastfeeding' },
  { k: 'thinner', label: 'Takes blood thinners, aspirin, fish oil or vitamin E' },
  { k: 'bleeding', label: 'Bleeding or clotting disorder' },
  { k: 'keloid', label: 'Keloid or raised scars' },
  { k: 'herpes', label: 'Cold sores' },
  { k: 'autoimmune', label: 'Autoimmune disease' },
  { k: 'neuromuscular', label: 'Myasthenia gravis or other nerve and muscle disease' },
  { k: 'isotretinoin', label: 'Isotretinoin in the last 6 months' },
  { k: 'implant', label: 'Permanent filler or implant in the face' },
  { k: 'pacemaker', label: 'Pacemaker or metal implant' },
  { k: 'infection', label: 'Skin infection or open wound at the site' },
];

// Starter treatments. The admin adds Apex's own list under Settings, Treatments.
const STARTER_SERVICES = [
  { name: 'Consultation', category: 'Consultation', duration: 30, kind: '' },
  { name: 'Botox, frown lines', category: 'Botulinum toxin', duration: 30, kind: 'toxin', consents: ['toxin'], aftercare: 'toxin' },
  { name: 'Botox, forehead and frown lines', category: 'Botulinum toxin', duration: 30, kind: 'toxin', consents: ['toxin'], aftercare: 'toxin' },
  { name: 'Botox, jaw slimming', category: 'Botulinum toxin', duration: 30, kind: 'toxin', consents: ['toxin'], aftercare: 'toxin' },
  { name: 'Lip filler', category: 'Filler', duration: 45, kind: 'filler', consents: ['filler'], aftercare: 'filler' },
  { name: 'Cheek filler', category: 'Filler', duration: 60, kind: 'filler', consents: ['filler'], aftercare: 'filler' },
  { name: 'Chin and jawline filler', category: 'Filler', duration: 60, kind: 'filler', consents: ['filler'], aftercare: 'filler' },
  { name: 'Under-eye filler', category: 'Filler', duration: 45, kind: 'filler', consents: ['filler'], aftercare: 'filler' },
  { name: 'Skin booster', category: 'Skin booster', duration: 45, kind: 'booster', consents: ['booster'], aftercare: 'booster' },
  { name: 'HIFU full face', category: 'Energy device', duration: 90, kind: 'device', consents: ['device'], aftercare: 'device', sheetId: 'hifu' },
  { name: 'Thread lift', category: 'Thread lift', duration: 90, kind: 'thread', consents: ['thread'], aftercare: 'thread' },
  { name: 'Review', category: 'Consultation', duration: 15, kind: '' },
];


// Medicines given in the clinic, as opposed to the take-home prescription.
const MED_ROUTES = ['IV', 'IM', 'SC', 'Intradermal', 'Intralesional', 'Oral', 'Topical', 'Sublingual', 'Inhaled'];
const MED_UNITS = ['mg', 'mcg', 'g', 'ml', 'IU', 'U', 'tab', 'cap', 'drop', 'puff', 'application'];
const MED_HINTS = ['Lidocaine 2%', 'Lidocaine 2% with epinephrine', 'Tranexamic acid', 'Hyaluronidase', 'Glutathione', 'Ascorbic acid', 'Diphenhydramine', 'Epinephrine 1 mg/ml', 'Hydrocortisone', 'Cetirizine', 'Paracetamol', 'Mefenamic acid', 'Triamcinolone acetonide', 'Ondansetron', 'Valacyclovir'];

// Settings sheets: what gets written down for each laser, device or peel so the next
// session can start from it. Every field is editable in Settings, Treatment settings.
const SHEET_GROUPS = ['Laser', 'Light', 'Energy device', 'Peel', 'Needling', 'Other'];
const RESPONSES = ['Good result', 'Some result', 'No change yet', 'Side effects'];
const NEXT_STEPS = ['Go up', 'Keep the same', 'Go down'];
const SHEET_DEFAULTS = [
  { id: 'lhr', name: 'Laser hair removal', group: 'Laser', fields: [
    { label: 'Laser', unit: '', type: 'text', ph: 'Diode 810 nm' }, { label: 'Fluence', unit: 'J/cm²', type: 'number' }, { label: 'Pulse width', unit: 'ms', type: 'number' },
    { label: 'Spot size', unit: 'mm', type: 'number' }, { label: 'Rate', unit: 'Hz', type: 'number' }, { label: 'Cooling', unit: '', type: 'text', ph: 'Contact, 5°C' },
    { label: 'Passes', unit: '', type: 'number' }, { label: 'Total pulses', unit: '', type: 'number' }] },
  { id: 'pigment', name: 'Pico or Q-switched laser', group: 'Laser', fields: [
    { label: 'Wavelength', unit: 'nm', type: 'number' }, { label: 'Handpiece', unit: '', type: 'text', ph: 'Zoom, flat top' }, { label: 'Fluence', unit: 'J/cm²', type: 'number' },
    { label: 'Spot size', unit: 'mm', type: 'number' }, { label: 'Rate', unit: 'Hz', type: 'number' }, { label: 'Passes', unit: '', type: 'number' }, { label: 'Total pulses', unit: '', type: 'number' }] },
  { id: 'co2', name: 'Fractional CO2 laser', group: 'Laser', fields: [
    { label: 'Mode', unit: '', type: 'text', ph: 'Deep, scan' }, { label: 'Power', unit: 'W', type: 'number' }, { label: 'Pulse energy', unit: 'mJ', type: 'number' },
    { label: 'Density', unit: '%', type: 'number' }, { label: 'Stack', unit: '', type: 'number' }, { label: 'Passes', unit: '', type: 'number' }, { label: 'Topical anaesthetic', unit: 'min', type: 'number' }] },
  { id: 'ipl', name: 'IPL', group: 'Light', fields: [
    { label: 'Filter', unit: 'nm', type: 'number' }, { label: 'Fluence', unit: 'J/cm²', type: 'number' }, { label: 'Pulse width', unit: 'ms', type: 'number' },
    { label: 'Pulses per shot', unit: '', type: 'number' }, { label: 'Delay', unit: 'ms', type: 'number' }, { label: 'Passes', unit: '', type: 'number' }, { label: 'Total shots', unit: '', type: 'number' }] },
  { id: 'hifu', name: 'HIFU', group: 'Energy device', fields: [
    { label: 'Cartridge', unit: 'mm', type: 'number' }, { label: 'Energy', unit: 'J', type: 'number' }, { label: 'Spacing', unit: 'mm', type: 'number' },
    { label: 'Lines', unit: '', type: 'number' }, { label: 'Passes', unit: '', type: 'number' }] },
  { id: 'rfmn', name: 'RF microneedling', group: 'Energy device', fields: [
    { label: 'Tip', unit: '', type: 'text', ph: '25 pin insulated' }, { label: 'Depth', unit: 'mm', type: 'number' }, { label: 'Power level', unit: '', type: 'number' },
    { label: 'Pulse time', unit: 'ms', type: 'number' }, { label: 'Passes', unit: '', type: 'number' }] },
  { id: 'peel', name: 'Chemical peel', group: 'Peel', fields: [
    { label: 'Agent', unit: '', type: 'text', ph: 'Glycolic acid' }, { label: 'Strength', unit: '%', type: 'number' }, { label: 'Layers', unit: '', type: 'number' },
    { label: 'Contact time', unit: 'min', type: 'number' }, { label: 'End point', unit: '', type: 'text', ph: 'Even redness, no frost' }, { label: 'Neutralised with', unit: '', type: 'text' }] },
  { id: 'mn', name: 'Microneedling', group: 'Needling', fields: [
    { label: 'Depth', unit: 'mm', type: 'number' }, { label: 'Passes', unit: '', type: 'number' }, { label: 'Serum', unit: '', type: 'text', ph: 'Hyaluronic acid' }] },
];

// Starter patient tags. The admin renames, merges or retires them under Settings, Tags.
const STARTER_TAGS = [['VIP', '#C49A45'], ['New', '#6A388C'], ['Regular', '#0E6B4F'], ['Foreign patient', '#2E7DB5'], ['Doctor referral', '#A886CD'], ['Staff', '#5A4A66'], ['Sensitive skin', '#C27A0E'], ['Needle-anxious', '#CC3366']];

// Sections of the patient record a custom field can sit in. The clinical ones are never
// shown only to the roles ticked on the field.
const FIELD_SECTIONS = { patients: [['details', 'Details'], ['medical', 'Medical history'], ['lifestyle', 'Lifestyle'], ['aesthetic', 'Aesthetic profile']], visits: [['notes', 'Notes']], services: [['service', 'Service']], products: [['product', 'Product']], users: [['staff', 'Doctor or assistant']] };
const CLINICAL_SECTIONS = ['medical', 'lifestyle', 'aesthetic', 'notes'];
const FIELD_TYPES = [['text', 'Short text'], ['long', 'Long text'], ['number', 'Number with unit'], ['date', 'Date'], ['yesno', 'Yes or no'], ['choice', 'One choice'], ['multi', 'Several choices']];
const FIELD_TARGETS = [['patients', 'Patient record'], ['visits', 'Visit notes'], ['services', 'Treatment'], ['products', 'Product'], ['users', 'Doctor or assistant']];
const ALL_ROLES = ['owner', 'doctor', 'nurse', 'staff'];
// Starter aesthetic fields. Skin type, pregnancy, blood thinners, isotretinoin, keloids,
// cold sores, autoimmune disease, permanent fillers, smoking, alcohol, sun and past
// treatments are already fixed parts of the record, so they are not repeated here.
const STARTER_FIELDS = [
  { id: 'f-glogau', target: 'patients', section: 'aesthetic', label: 'Glogau photoaging type', hint: 'I no wrinkles, II wrinkles in motion, III wrinkles at rest, IV only wrinkles.', type: 'choice', options: ['I', 'II', 'III', 'IV'], roles: ['owner', 'doctor', 'nurse'], order: 10 },
  { id: 'f-concerns', target: 'patients', section: 'aesthetic', label: 'Main concerns', hint: 'In the patient\'s own words. Example: frown lines and a tired look under the eyes.', type: 'long', roles: ['owner', 'doctor', 'nurse'], order: 20 },
  { id: 'f-goals', target: 'patients', section: 'aesthetic', label: 'Treatment goals', hint: 'Example: softer frown lines before a wedding on 20 Nov, with no frozen look.', type: 'long', roles: ['owner', 'doctor', 'nurse'], order: 30 },
  { id: 'f-dental', target: 'patients', section: 'medical', label: 'Dental work in the last 2 weeks', hint: 'Cleaning, extraction or a root canal raises the infection risk with filler.', type: 'yesno', roles: ['owner', 'doctor', 'nurse'], order: 40 },
  { id: 'f-skincare', target: 'patients', section: 'lifestyle', label: 'Skincare routine', hint: 'Example: cleanser, retinol at night, SPF 50 every morning.', type: 'long', roles: ['owner', 'doctor', 'nurse'], order: 50 },
  { id: 'f-contact', target: 'patients', section: 'details', label: 'Preferred way to reach them', hint: '', type: 'choice', options: ['LINE', 'WhatsApp', 'WeChat', 'Phone call', 'Email'], roles: ['owner', 'doctor', 'nurse'], order: 60 },
];

if (typeof module !== 'undefined') module.exports = { INCIDENT_TYPES, INCIDENT_SEVERITY, INCIDENT_OUTCOMES, KINDS, STARTER_TAGS, STARTER_FIELDS, FIELD_SECTIONS, CLINICAL_SECTIONS, FIELD_TYPES, ALL_ROLES };
