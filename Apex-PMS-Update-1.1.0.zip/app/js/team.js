// People: the doctors and assistants who sign in, and each person's own page with their
// language and PIN.

function renderTeam(b) {
  const owner = isOwner();
  const tabs = owner ? [['people', 'People'], ['me', 'Me']] : [['me', 'Me']];
  if (!b || !tabs.some(t => t[0] === b)) b = tabs[0][0];
  const body = { people: teamPeople, me: teamMe }[b]();
  $app.innerHTML = shell('team', `<div class="page-head"><div><h1>${owner ? 'Doctors and assistants' : 'Me'}</h1></div></div>${tabs.length > 1 ? tabsNav(tabs, b, '#/team/') : ''}<div id="team">${body}</div>`);
  wireShell();
  ({ people: wirePeople, me: wireMe }[b])();
}

// ---------- people ----------
function teamPeople() {
  const list = [...S.users].sort((a, b) => (a.archived ? 1 : 0) - (b.archived ? 1 : 0) || a.name.localeCompare(b.name));
  return `<div class="row end gap-b"><button class="btn secondary" data-act="staff-print">${I.print}Print the list</button><button class="btn primary" data-act="add">${I.plus}Add a doctor or assistant</button></div>
    <div class="list">${list.map(u => `<button class="li ${u.archived ? 'dim' : ''}" data-user="${u.id}">${avatar(u)}<div class="grow"><div class="t">${esc(u.name)}${u.nameTh ? ` <span class="meta" lang="th">${esc(u.nameTh)}</span>` : ''}${u.id === S.me.id ? ' <span class="meta">(you)</span>' : ''}</div><div class="m">${esc(u.title || ROLES[u.role].label)}${u.licence ? ` · ${esc(u.licence)}` : ''}</div></div>${u.archived ? chip('Left') : chip(ROLES[u.role].label)}</button>`).join('')}</div>
    <p class="meta" style="margin-top:10px">${Object.values(ROLES).map(r => `<b>${r.label}.</b> ${esc(r.desc)}`).join(' ')}</p>`;
}
function wirePeople() {
  document.querySelector('[data-act="add"]').onclick = () => personSheet(null);
  document.querySelector('[data-act="staff-print"]').onclick = () => printStaff([...S.users].filter(u => !u.archived).sort((a, b) => a.name.localeCompare(b.name)));
  document.querySelectorAll('[data-user]').forEach(b => b.onclick = () => personSheet(byId('users', b.dataset.user)));
}

async function personSheet(u) {
  let photo = u ? u.photo : '';
  const f = await sheet({
    title: u ? u.name : 'Add a doctor or assistant', wide: true,
    extra: `${u && u.id !== S.me.id ? `<button type="button" class="btn ${u.archived ? 'secondary' : 'danger'}" data-arch>${u.archived ? 'Bring back' : 'Mark as left'}</button>` : ''}`,
    body: `<div class="grid2">${field('Name in English', 'name', u ? u.name : '', { ph: 'Dr. Nantapat Srisuk' })}${field('Name in Thai', 'nameTh', u ? u.nameTh : '', { ph: 'นพ. นันทพัทธ์ ศรีสุข' })}</div>
      <div class="grid3">${field('Role', 'role', u ? u.role : 'doctor', { type: 'select', options: Object.entries(ROLES).map(([k, r]) => [k, r.label]), blank: false })}${field('Position', 'title', u ? u.title : '', { ph: 'Plastic surgeon' })}${field('Medical licence number', 'licence', u ? u.licence : '', { ph: 'ว. 12345', hint: 'Printed on prescriptions and signed visits.' })}</div>
      <div class="grid3">${field('Treats patients', 'clinicalRole', u ? u.clinicalRole || '' : 'doctor', { type: 'select', options: [['doctor', 'As a doctor']], blank: 'No', hint: 'For an admin who also sees patients.' })}${field('Mobile', 'phone', u ? u.phone : '', { type: 'tel', ph: '081 234 5678' })}${field('Email', 'email', u ? u.email : '', { type: 'email' })}</div>
      <div class="grid3">${field('Screen language', 'lang', u ? u.lang || 'th' : 'th', { type: 'select', options: [['th', 'ไทย'], ['en', 'English']], blank: false })}${field(u ? 'New PIN' : 'PIN', 'pin', '', { type: 'password', hint: u ? 'Blank keeps the current PIN.' : '4 to 8 digits.', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}${field('PIN again', 'pin2', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}</div>
      <div class="row"><span class="avatar lg" data-ph>${photo ? `<img src="${fileURL(photo)}" alt="">` : esc(initials(u ? u.name : '?'))}</span><label class="btn secondary small">Photo<input type="file" class="file-hidden" accept="image/*" data-photo></label></div>
      ${fieldsFor('users', { retired: true }).length ? `${customFieldsHTML('users', u ? u.custom : {}, 'staff')}${customSections('users', u ? u.custom : {}).map(sec => `<h3 class="sub-head">${esc(sec)}</h3>${customFieldsHTML('users', u ? u.custom : {}, sec)}`).join('')}` : ''}`,
    onOpen: form => {
      form.querySelector('[data-photo]').onchange = async e => { const file = e.target.files[0]; if (!file) return; try { const r = await resizeImage(file, 400, 0.85); photo = await uploadFile(r.blob); form.querySelector('[data-ph]').innerHTML = `<img src="${fileURL(photo)}" alt="">`; } catch (ex) { form.err(ex.message); } };
      const ar = form.querySelector('[data-arch]');
      if (ar) ar.onclick = async () => { form.close(null); try { await save('users', { ...u, archived: !u.archived }, { action: u.archived ? 'Brought back' : 'Marked as left' }); render(); } catch (e) { fail(e); } };
    },
    validate: form => {
      const pin = val(form, 'pin');
      if (!val(form, 'name')) return 'Enter the name in English.';
      if ((!u || pin) && !/^\d{4,8}$/.test(pin)) return 'The PIN needs 4 to 8 digits.';
      if (pin && pin !== val(form, 'pin2')) return 'The two PINs are different.';
      return customMissing(form, 'users');
    },
  });
  if (!f) return;
  const rec = { ...(u || { id: uid() }), photo };
  for (const k of ['name', 'nameTh', 'title', 'role', 'licence', 'clinicalRole', 'phone', 'email', 'lang']) rec[k] = val(f, k);
  rec.custom = readCustomFields(f, 'users', u ? u.custom : {});
  try {
    await save('users', rec, { action: u ? 'Person edited' : 'Person added', pin: val(f, 'pin') || undefined });
    hello = await api('/api/hello').catch(() => hello);
    if (u && u.id === S.me.id) setLang(rec.lang);
    render();
  } catch (e) { fail(e); }
}

function printStaff(list) {
  doPrint(`${printHead()}<h1>Doctors and assistants</h1><table><tr><th>Name</th><th>Role</th><th>Position</th><th>Licence</th><th>Mobile</th></tr>
    ${list.map(u => `<tr><td>${esc(u.name)}${u.nameTh ? `<br>${esc(u.nameTh)}` : ''}</td><td>${esc((ROLES[u.role] || {}).label)}</td><td>${esc(u.title || '')}</td><td>${esc(u.licence || '')}</td><td>${esc(u.phone || '')}</td></tr>`).join('')}</table>${printFoot()}`, 'Doctors and assistants');
}

// ---------- me ----------
function teamMe() {
  const u = S.me;
  return `<div class="cols">
    <div class="card"><div class="phead">${avatar(u, 'lg')}<div class="grow"><h2>${esc(u.name)}</h2>${u.nameTh ? `<div lang="th">${esc(u.nameTh)}</div>` : ''}<div class="meta">${esc(u.title || ROLES[u.role].label)}${u.licence ? ` · ${esc(u.licence)}` : ''}</div></div></div>
      ${['staff', ...customSections('users', u.custom)].map(sec => { const pairs = customPairs('users', u.custom, sec); return pairs.length ? `<h3 class="sub-head">${esc(SECTION_LABEL('users', sec))}</h3>${customKV(pairs)}` : ''; }).join('')}
      <h3 class="sub-head">Screen language</h3>
      <div class="seg" role="group" aria-label="Screen language">${[['th', 'ไทย'], ['en', 'English']].map(([k, l]) => `<button type="button" data-pick-lang="${k}" class="${curLang() === k ? 'on' : ''}" translate="no">${l}</button>`).join('')}</div></div>
    <form class="card" id="mypin"><h2 class="card-title">Change my PIN</h2>
      <div class="grid3">${field('Current PIN', 'old', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="current-password"' })}${field('New PIN', 'pin', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}${field('New PIN again', 'pin2', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}</div>
      <p class="form-err" data-err></p><div class="row end"><button class="btn primary">Change PIN</button></div></form>
  </div>`;
}
function wireMe() {
  document.querySelectorAll('[data-pick-lang]').forEach(b => b.onclick = async () => {
    const lang = b.dataset.pickLang;
    setLang(lang);
    try { await api('/api/me/lang', { lang }); S.me.lang = lang; } catch (e) { /* the device keeps the choice */ }
    render();
  });
  const f = document.getElementById('mypin');
  f.onsubmit = async e => {
    e.preventDefault();
    const err = m => { f.querySelector('[data-err]').textContent = tr(m); };
    const pin = val(f, 'pin');
    if (!/^\d{4,8}$/.test(pin)) return err('The PIN needs 4 to 8 digits.');
    if (pin !== val(f, 'pin2')) return err('The two PINs are different.');
    try { await api('/api/me/pin', { old: val(f, 'old'), pin }); S.me.pinLen = pin.length; delete f.dataset.dirty; hello = await api('/api/hello').catch(() => hello); toast('PIN changed.'); render(); }
    catch (ex) { err(ex.message); }
  };
}
