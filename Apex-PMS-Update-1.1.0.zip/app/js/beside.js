// What sits beside the chart, for comparing. A picture chart can have last visit's chart
// beside it (inside the stage, as before) or the 3D head with this visit's head marks. The
// 3D head can have this visit's picture charts beside it, or the photo when nothing is
// charted on that view. Either pane flips between the five standard views, and the head's
// pane follows the head when one of its standard views is pressed.

let BESIDE_PREF = '';

function besideHead() {
  const hc = S.charts.find(c => c.visitId === E.v.id && c.view === HEAD_CHART.key);
  const h = hc ? byId('heads', hc.base.headId) : latestHead(E.p.id);
  return h ? { head: h, chart: hc } : null;
}
function besideOptions() {
  if (E.docked && !E.max) return [];
  const o = [['', 'Nothing']];
  if (E.kind === 'head') o.push(['photo', 'Photos and charts']);
  else { if (E.prev) o.push(['prev', 'Last visit']); if (besideHead()) o.push(['head', '3D head']); }
  return o.length > 1 ? o : [];
}
function besideNow() {
  if (E.beside === undefined) {
    // Choosing the other picture in one editor carries over to the other one: the photos
    // beside the head, the head beside a photo.
    const want = BESIDE_PREF === 'head' || BESIDE_PREF === 'photo' ? (E.kind === 'head' ? 'photo' : 'head') : '';
    const ok = want && besideOptions().some(([k]) => k === want);
    E.beside = ok ? want : E.kind !== 'head' && E.showPrev && E.prev ? 'prev' : '';
    if (E.beside === 'head') E.showPrev = false;
  }
  return E.beside;
}
function besideFieldHTML() {
  const o = besideOptions();
  if (!o.length) return '';
  const now = besideNow();
  return `<label class="field" style="margin-top:16px"><span class="label">Beside the chart</span><select data-beside>${o.map(([k, l]) => `<option value="${k}" ${now === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
}
function setBeside(v) {
  E.beside = v; BESIDE_PREF = v;
  if (E.kind === 'head') { besideRefresh(); hdSideRefresh(); return; }
  E.showPrev = v === 'prev';
  edRender();
}

function besidePaneHTML() {
  const chips = (views, cur) => `<div class="seg beside-views" role="group" aria-label="View">${views.map(x => `<button type="button" data-beside-view="${x.key}" aria-pressed="${x.key === cur}">${x.label}</button>`).join('')}</div>`;
  if (E.beside === 'head') {
    const hb = besideHead();
    if (!hb) return '<p class="meta">No 3D head for this patient.</p>';
    const view = E.besideView || (HEAD_VIEWS.some(x => x.key === E.chart.view) ? E.chart.view : 'front');
    const n = hb.chart ? (hb.chart.marks || []).length : 0;
    // The head turns by dragging, like the head chart itself. Until it has loaded, its standard picture stands in.
    const url = headThumbURL(hb.head, view);
    return `${chips(HEAD_VIEWS, view)}<div class="beside-3d" title="Drag to turn the head"><img class="beside-still" src="${url}" alt=""><canvas></canvas><svg xmlns="http://www.w3.org/2000/svg"></svg></div>
      <p class="meta">${esc(headLabel(hb.head))} · ${n ? plural(n, 'mark') + ' on this visit' : 'nothing charted on the head this visit'}</p>${besideWindowHTML(HEAD_CHART.key)}`;
  }
  const view = E.besideView || (E.viewer && hdViewKey(E.viewer.V.az, E.viewer.V.el)) || 'front';
  const c = S.charts.find(x => x.visitId === E.v.id && x.view === view);
  if (c) {
    const img = c.base.type === 'photo' ? fullURL(c.base.photoId) : '';
    return `${chips(CHART_VIEWS, view)}<div class="beside-pic">${chartSVG(c, img)}</div><p class="meta">${esc(CHART_VIEWS.find(x => x.key === view).label)} chart · ${plural((c.marks || []).length, 'mark')}</p>${besideWindowHTML(view)}`;
  }
  const want = CHART_VIEWS.find(x => x.key === view).photo;
  const ph = S.photos.filter(x => x.patientId === E.p.id && x.view === want && x.fileId).sort((a, b) => (a.visitId === E.v.id ? 0 : 1) - (b.visitId === E.v.id ? 0 : 1) || (b.created || 0) - (a.created || 0))[0];
  if (ph) return `${chips(CHART_VIEWS, view)}<div class="beside-pic"><img src="${fullURL(ph.id)}" alt="${esc(want)}"></div><p class="meta">${esc(want)} photo, ${fmtDate(ph.date)}. Nothing charted on it this visit.</p>`;
  return `${chips(CHART_VIEWS, view)}<p class="meta">No chart or photo of this view.</p>`;
}

// The pane is a column of its own between the stage and the side panel.
function besideRefresh() {
  const body = document.querySelector('#editor .ed-body');
  if (!body || !E) return;
  const now = besideNow(), show = now === 'head' || now === 'photo';
  const was = body.classList.contains('with-beside');
  body.classList.toggle('with-beside', show);
  let pane = body.querySelector('.ed-beside');
  if (!show) { besideDispose(); if (pane) pane.remove(); }
  else {
    if (!pane) { pane = document.createElement('div'); pane.className = 'ed-beside'; body.querySelector('.ed-stage').after(pane); }
    // A head already turning in the pane only changes its angle.
    if (now === 'head' && BESIDE.vw && pane.querySelector('.beside-3d canvas.on')) {
      if (E.besideView) { BESIDE.vw.setView(E.besideView); BESIDE.draw(); }
      pane.querySelectorAll('[data-beside-view]').forEach(b => b.setAttribute('aria-pressed', b.dataset.besideView === E.besideView));
    } else {
      besideDispose();
      pane.innerHTML = besidePaneHTML();
      if (now === 'head') besideHeadMount(pane).catch(e => console.error(e));
    }
    pane.querySelectorAll('[data-beside-view]').forEach(b => b.onclick = () => { E.besideView = b.dataset.besideView; besideRefresh(); });
  }
  if (was !== show && E.kind !== 'head') edSize();
}

// ---------- the head in the pane ----------
const BESIDE = { vw: null, mesh: null, headId: '', ro: null, draw: () => {} };
async function besideHeadMount(pane) {
  const hb = besideHead(), box = pane.querySelector('.beside-3d');
  if (!hb || !box) return;
  const HV = await headView();
  if (BESIDE.headId !== hb.head.id || !BESIDE.mesh) {
    const loaded = await HV.loadHeadFiles({ meshUrl: fileURL(hb.head.files.mesh), atlasUrl: fileURL(hb.head.files.atlas), alphaUrl: fileURL(hb.head.files.alpha), maxAtlas: headAtlasMax() });
    BESIDE.mesh = HV.headMesh(loaded); BESIDE.headId = hb.head.id;
  }
  if (!document.contains(box)) return;
  const cv = box.querySelector('canvas'), svg = box.querySelector('svg');
  const vw = BESIDE.vw = HV.makeViewer(cv, BESIDE.mesh, { bg: 0xffffff });
  vw.setView(E.besideView || (HEAD_VIEWS.some(x => x.key === E.chart.view) ? E.chart.view : 'front'));
  BESIDE.draw = () => {
    if (!BESIDE.vw) return;
    vw.render();
    const { w, h } = vw.V, c = S.charts.find(x => x.visitId === E.v.id && x.view === HEAD_CHART.key);
    svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
    svg.innerHTML = marksSVG(c ? hdMarks2D(c.marks || [], vw) : [], w, h);
  };
  const fit = () => { if (box.clientWidth && box.clientHeight) { vw.size(box.clientWidth, box.clientHeight); BESIDE.draw(); } };
  BESIDE.ro = new ResizeObserver(fit); BESIDE.ro.observe(box);
  cv.classList.add('on');
  fit();
  box.onpointerdown = e => {
    e.preventDefault(); box.setPointerCapture(e.pointerId);
    const sx = e.clientX, sy = e.clientY, az0 = vw.V.az, el0 = vw.V.el;
    const move = ev => { vw.setAngles(az0 - (ev.clientX - sx) * 0.4, Math.max(-60, Math.min(60, el0 + (ev.clientY - sy) * 0.3))); BESIDE.draw(); };
    const up = () => { box.removeEventListener('pointermove', move); box.removeEventListener('pointerup', up); box.removeEventListener('pointercancel', up); };
    box.addEventListener('pointermove', move); box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
  };
}
function besideDispose() {
  if (BESIDE.ro) BESIDE.ro.disconnect();
  if (BESIDE.vw) BESIDE.vw.dispose();
  BESIDE.vw = null; BESIDE.ro = null; BESIDE.draw = () => {};
}

// The other chart in a window of its own, for a second screen or a side-by-side window.
function besideWindowHTML(view) {
  return `<a class="btn quiet small" href="#/chart/${esc(E.v.id)}/${esc(view)}" target="_blank" rel="opener">Open in its own window</a>`;
}
