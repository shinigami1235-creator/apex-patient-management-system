// Treatment presets: a standard treatment saved once and put on a visit in one tap. A
// preset keeps the services, the chart marks of each view with their products and amounts,
// and a line for the plan. Using it adds the services (with their set consumables, consent
// forms and aftercare), draws the marks on this visit's charts at the same spots, takes the
// lots in use now, and writes the plan line. Drag any mark that needs moving.

const presetsList = () => [...S.presets].sort((a, b) => a.name.localeCompare(b.name));
const canPresets = () => ACCESS.presets[S.me.role].includes('w');
function presetSummary(pr) {
  const svc = (pr.serviceIds || []).map(id => (service(id) || {}).name).filter(Boolean);
  const lines = linesFromMarks((pr.charts || []).flatMap(c => c.marks || []));
  return [...svc, ...lines.map(l => `${l.product || KINDS[l.kind].short} ${trimNum(l.amount)} ${l.unit}`)].join(', ');
}

// Saves the visit's services, charts and plan as a preset.
async function savePresetSheet(v) {
  const charts = chartsOfVisit(v.id).filter(c => (c.marks || []).length);
  if (!charts.length && !(v.services || []).length) return toast('Add services or chart marks first.');
  const f = await sheet({
    title: 'Save as a preset', submit: 'Save preset',
    body: `${field('Name', 'name', '', { ph: 'Glabella 20 U, 5 points' })}
      <p class="muted">${esc([...(v.services || []).map(s => (service(s.serviceId) || {}).name || s.name), ...charts.map(c => `${(CHART_VIEWS.find(x => x.key === c.view) || {}).label} chart, ${plural(c.marks.length, 'mark')}`)].filter(Boolean).join(' · '))}</p>
      ${field('Plan line', 'plan', v.plan || '', { ph: 'Review in 2 weeks for a top-up.' })}`,
    validate: x => (!val(x, 'name') ? 'Name the preset.' : S.presets.some(p => p.name.toLowerCase() === val(x, 'name').toLowerCase()) ? 'A preset has that name already.' : ''),
  });
  if (!f) return null;
  const rec = { id: uid(), name: val(f, 'name'), serviceIds: (v.services || []).map(s => s.serviceId).filter(Boolean), plan: val(f, 'plan'),
    charts: charts.map(c => ({ view: c.view, base: c.base.type === 'photo' ? 'photo' : 'drawing', dilution: c.dilution, marks: JSON.parse(JSON.stringify(c.marks)) })) };
  try { await save('presets', rec, { action: 'Preset saved' }); toast(`Preset ${rec.name} saved.`); return rec; } catch (e) { fail(e); return null; }
}

async function usePresetSheet(v) {
  const list = presetsList();
  if (!list.length) return toast(canPresets() ? 'No presets yet. Chart a treatment, then press Save as preset.' : 'No presets yet.');
  const pick = await ask({ title: 'Use a preset', body: '', buttons: [...list.map(pr => ({ label: pr.name, value: pr.id })), { label: 'Cancel', value: null }] });
  if (!pick) return;
  await applyPreset(visit(v.id), byId('presets', pick));
}

async function applyPreset(v, pr) {
  if (!v || !pr || v.signedAt) return;
  const p = patient(v.patientId);
  try {
    // treatments
    const have = new Set((v.services || []).map(s => s.serviceId));
    const lines = (pr.serviceIds || []).filter(id => service(id) && !have.has(id)).map(id => ({ id: uid(), serviceId: id, name: service(id).name }));
    if (lines.length) await pushTo('visits', v.id, 'services', lines, `Treatments from the preset ${pr.name}`);
    // chart marks, on the lots in use now
    for (const pc of pr.charts || []) {
      const marks = (pc.marks || []).map(m => {
        const copy = { ...JSON.parse(JSON.stringify(m)) };
        const old = copy.lotId ? lot(copy.lotId) : null;
        if (copy.lotId && (!old || old.archived || lotLeft(old.id) <= 0)) { const next = old ? pickLot(old.productId) : null; copy.lotId = next ? next.id : ''; }
        return copy;
      });
      const cur = S.charts.find(c => c.visitId === v.id && c.view === pc.view);
      if (cur) await save('charts', { ...cur, marks: [...(cur.marks || []), ...marks] }, { action: `Chart marks from the preset ${pr.name}` });
      else {
        const ph = pc.base === 'photo' && p.photoConsent !== 'no' ? defaultChartPhoto(v, pc.view) : null;
        const meta = ph && photoMeta(ph.id);
        await save('charts', { id: uid(), patientId: v.patientId, visitId: v.id, view: pc.view, base: ph ? { type: 'photo', photoId: ph.id } : { type: 'drawing' }, w: meta ? meta.w : FACE_W, h: meta ? meta.h : FACE_H, marks, dilution: pc.dilution || { units: 100, ml: 2.5 } }, { action: `Chart from the preset ${pr.name}` });
      }
    }
    if ((pr.charts || []).length) await syncChartLines(v.id);
    if (pr.plan && !(visit(v.id).plan || '').includes(pr.plan)) { const cur = visit(v.id); await save('visits', { ...cur, plan: (cur.plan ? cur.plan.trim() + ' ' : '') + pr.plan }, { action: `Plan from the preset ${pr.name}` }); }
    toast(`${pr.name} is on the visit. Check the marks on the chart.`, 5000);
    renderVisit(v.id);
  } catch (e) { fail(e); }
}

// Settings, Presets: rename and delete.
function presetsTab() {
  const list = presetsList();
  return `<div class="card"><h2 class="card-title">Treatment presets</h2>
    <p class="muted">A preset is made on a visit: chart the treatment, add the services, then press Save as preset under Services. Use a preset on any visit puts it all on in one tap.</p>
    ${list.length ? `<div class="list flat">${list.map(pr => `<div class="li"><div class="grow"><div class="t medium">${esc(pr.name)}</div><div class="m">${esc(presetSummary(pr))}${pr.plan ? ' · Plan: ' + esc(pr.plan) : ''}</div></div><button class="btn quiet small" data-pren="${pr.id}">Rename</button><button class="btn quiet small" data-pdel="${pr.id}">Delete</button></div>`).join('')}</div>` : '<p class="muted">No presets yet.</p>'}</div>`;
}
function wirePresetsTab() {
  document.querySelectorAll('[data-pren]').forEach(b => b.onclick = async () => {
    const pr = byId('presets', b.dataset.pren);
    const f = await sheet({ title: 'Rename the preset', body: `${field('Name', 'name', pr.name)}${field('Plan line', 'plan', pr.plan || '')}`, validate: x => (!val(x, 'name') ? 'Name the preset.' : '') });
    if (!f) return;
    try { await save('presets', { ...pr, name: val(f, 'name'), plan: val(f, 'plan') }, { action: 'Preset renamed' }); render(); } catch (e) { fail(e); }
  });
  document.querySelectorAll('[data-pdel]').forEach(b => b.onclick = async () => {
    const pr = byId('presets', b.dataset.pdel);
    if (!(await confirmDanger(`Delete ${pr.name}?`, 'Visits it was used on keep their marks.'))) return;
    try { await remove('presets', pr.id); render(); } catch (e) { fail(e); }
  });
}
