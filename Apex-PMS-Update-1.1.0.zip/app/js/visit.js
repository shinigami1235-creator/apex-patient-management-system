// Visit page: treatments done, notes, photos, treatment chart, settings used, medicines
// given, treatment record, consent, prescription, aftercare, follow-up and the summary the
// staff re-encode into Apex's EMR.

const VISIT_TYPES = ['Consultation', 'Treatment', 'Review', 'Post-op check'];
const isPrescriber = () => !!(S.me && (S.me.role === 'doctor' || (S.me.role === 'owner' && S.me.clinicalRole === 'doctor')));

async function newVisit(patientId) {
  const f = await sheet({
    title: 'New visit', submit: 'Start visit',
    body: `<div class="grid3">${field('Date', 'date', todayISO(), { type: 'date' })}${field('Time', 'time', nowTime(), { type: 'time' })}${field('Type', 'type', 'Consultation', { type: 'select', options: VISIT_TYPES, blank: false })}</div>
      ${field('Reason for the visit', 'complaint', '', { ph: 'Frown lines and tired-looking eyes' })}
      ${doctorSelect()}`,
  });
  if (!f) return;
  const v = { id: uid(), patientId, date: val(f, 'date') || todayISO(), time: val(f, 'time'), type: val(f, 'type'), complaint: val(f, 'complaint'), doctorId: val(f, 'doctorId'),
    services: [], findings: '', assessment: '', plan: '', treatments: [], consents: [], rx: [], aftercare: null, followUp: '', followReason: '' };
  try {
    const saved = await save('visits', v, { action: 'Visit started' });
    go('#/visit/' + saved.id);
  } catch (e) { fail(e); }
}

function doctorSelect(current) {
  const docs = doctors();
  const def = current || defaultDoctorId();
  return field('Doctor', 'doctorId', def, { type: 'select', options: docs.map(d => [d.id, d.name]), blank: false });
}

function kindsOf(v) { return [...new Set([...(v.treatments || []).map(t => t.kind), ...(v.services || []).map(s => (service(s.serviceId) || {}).kind)].filter(Boolean))]; }
// The aftercare for what was done on the visit, in the patient's language.
function defaultAftercare(v) {
  const keys = new Set(kindsOf(v));
  for (const s of v.services || []) { const sv = service(s.serviceId); if (sv && sv.aftercare) keys.add(sv.aftercare); }
  const lang = (patient(v.patientId) || {}).plang || 'th';
  return [...keys].map(k => aftercareText(k, lang)).filter(Boolean).join('\n\n');
}
function consentsWanted(v, p) {
  const want = new Set(kindsOf(v).filter(k => S.templates.consent[k]));
  for (const s of v.services || []) for (const k of (service(s.serviceId) || {}).consents || []) want.add(k);
  if (p.photoConsent !== 'yes' && p.photoConsent !== 'no') want.add('photos');
  if (!p.privacyConsentAt && S.templates.consent.privacy) want.add('privacy');
  return want;
}

function renderVisit(id) {
  const v = visit(id);
  if (!v) return go('#/patients');
  const p = patient(v.patientId) || { name: 'Unknown patient', id: v.patientId };
  const clin = can('clinical');
  const locked = !!v.signedAt || !can('edit');
  const doc = byId('users', v.doctorId);
  const missing = clin && !locked ? [...consentsWanted(v, p)].filter(k => S.templates.consent[k] && !(v.consents || []).some(c => c.key === k)) : [];
  const head = `
    <a class="crumb" href="#/patient/${p.id}/visits">${I.back}${esc(p.name)}</a>
    <div class="page-head"><div><h1>${esc(v.type || 'Visit')} · ${fmtDate(v.date)}</h1>
      <div class="meta sub">${esc(v.no || '')}${v.time ? ' · ' + fmtTime(v.time) : ''}${doc ? ' · ' + esc(doc.name) : ''}${v.signedAt ? ` · signed by ${esc(userName(v.signedBy))} · ${fmtStamp(v.signedAt)}` : ''}</div></div>
      <div class="row wrap-end">${clin ? `<a class="btn secondary" href="#/chart/${v.id}">Full chart</a>` + showPatientButtonHTML(p.id, v.id) + sendButtonHTML('#/visit/' + v.id, p.name + '\'s visit') : ''}${clin && !locked ? '<button class="btn secondary" data-act="checkin">Hand to patient</button>' : ''}${clin ? `<button class="btn secondary" data-act="print-visit">${I.print}Print summary</button>` : ''}
        ${can('sign') ? (locked ? `<button class="btn secondary" data-act="reopen">Reopen</button>` : `<button class="btn primary" data-act="sign">Sign visit</button>`) : ''}</div></div>
    ${clin ? alertChips(p) : ''}
    ${missing.length ? `<div class="banner">Consent still needed: ${missing.map(k => esc(consentTitle(k))).join(', ')}.<button class="btn secondary small" data-act="consent">Get consent</button></div>` : ''}
    ${!can('edit') ? `<div class="banner info">View only. Copy what Apex's EMR needs from the summary at the bottom.</div>` : locked && clin ? `<div class="banner info"><span>This visit is signed, so notes, charts and treatment are view only.</span>${can('sign') ? ' <span>Press Reopen to change them.</span>' : ''} <span>The follow-up stays open.</span></div>` : ''}`;

  const cards = [];
  if (clin) {
    cards.push(servicesCard(v, locked));
    cards.push(notesCard(v, locked));
    cards.push(outcomeCard(v));
    cards.push(photosCard(v, p, locked));
    cards.push(chartCard(v, p));
    cards.push(treatCard(v, locked));
    cards.push(settingsCard(v, p, locked));
    cards.push(medsCard(v, p, locked));
    if (typeof visitToolsCard === 'function') cards.push(visitToolsCard(v, p, locked));
    if (typeof translatorCard === 'function') cards.push(translatorCard(v, p, locked));
    cards.push(consentCard(v, locked));
    cards.push(rxCard(v, locked));
    cards.push(aftercareCard(v, locked));
    cards.push(incidentCard(v));
  }
  cards.push(followCard(v));
  if (clin) { if (can('edit')) cards.push(emrSummaryCard(v, p)); else cards.unshift(emrSummaryCard(v, p)); }
  if (clin) cards.push(`<details class="card" id="vhist"><summary class="link-summary"><b>Changes to this visit</b></summary><div data-hist style="margin-top:10px"><p class="meta">Loading.</p></div></details>`);

  $app.innerHTML = shell('patients', head + `<div class="stack">${cards.join('')}</div>`);
  wireShell();
  wireVisit(v, p);
  wireOutcome(v);
}

// The title of a consent form in the screen language, else in English.
function consentTitle(k) { const t = S.templates.consent[k]; if (!t) return k; return consentText(t, 'title', curLang()); }

// ---------- treatments done ----------
// The treatments from the branch's list done on this visit. Each brings its consent forms,
// aftercare and device settings sheet.
function servicesCard(v, locked) {
  const list = v.services || [];
  return `<div class="card"><div class="card-head"><h2>Treatments done</h2>${locked ? '' : `<div class="row">${S.presets.length ? '<button class="btn secondary small" data-act="use-preset">Use a preset</button>' : ''}${canPresets() && (list.length || chartsOfVisit(v.id).some(c => (c.marks || []).length)) ? '<button class="btn quiet small" data-act="save-preset">Save as preset</button>' : ''}<button class="btn secondary small" data-act="add-service">${I.plus}Add treatment</button></div>`}</div>
    ${list.length ? `<div class="list flat">${list.map(s => { const sv = service(s.serviceId); return `<div class="li"><div class="grow"><div class="t medium">${esc(sv ? sv.name : s.name)}</div>${sv && sv.category ? `<div class="m">${esc(sv.category)}</div>` : ''}</div>${locked ? '' : `<button class="x" data-rm-service="${s.id}" aria-label="Remove">×</button>`}</div>`; }).join('')}</div>`
      : '<p class="muted">Add the treatments done today. Their consent forms, aftercare and device settings follow.</p>'}</div>`;
}

async function addServiceSheet(v) {
  const active = S.services.filter(s => s.active !== false).sort((a, b) => (a.category || '').localeCompare(b.category || '') || a.name.localeCompare(b.name));
  if (!active.length) return toast('Add the treatment list under Settings, Treatments first.');
  const f = await sheet({
    title: 'Add treatment',
    body: `<label class="field"><span class="label">Treatment</span><select name="serviceId">${groupOptions(active, s => s.category || 'Other', s => [s.id, s.name])}</select></label>`,
  });
  if (!f) return;
  const sv = service(val(f, 'serviceId'));
  if (!sv) return;
  const line = { id: uid(), serviceId: sv.id, name: sv.name };
  try {
    await pushTo('visits', v.id, 'services', [line], 'Treatment added');
    renderVisit(v.id);
  } catch (e) { fail(e); }
}


const supplyLines = v => (v.treatments || []).filter(t => t.source === 'supply');
function groupOptions(list, groupFn, optFn, selected) {
  const g = groupBy(list, groupFn);
  return [...g.entries()].map(([k, items]) => `<optgroup label="${esc(k)}">${items.map(x => { const [v, l] = optFn(x); return `<option value="${esc(v)}" ${v === selected ? 'selected' : ''}>${esc(l)}</option>`; }).join('')}</optgroup>`).join('');
}

// ---------- notes ----------
function notesCard(v, locked) {
  const ro = locked ? 'readonly' : '';
  return `<form class="card" id="notes"><div class="card-head"><h2>Notes</h2>${locked ? '' : `<div class="row">${typeof dictateButtonHTML === 'function' ? dictateButtonHTML() : ''}<button class="btn secondary small">Save notes</button></div>`}</div>
    <div class="grid2">
      ${field('Complaint', 'complaint', v.complaint, { type: 'textarea', ph: 'Wants softer frown lines before a wedding on 20 Nov.', attrs: ro })}
      ${field('Findings', 'findings', v.findings, { type: 'textarea', ph: 'Dynamic glabellar lines, grade 3 at maximum frown. Mild static forehead lines.', attrs: ro })}
      ${field('Assessment', 'assessment', v.assessment, { type: 'textarea', ph: 'Glabellar and forehead dynamic lines.', attrs: ro })}
      ${field('Plan', 'plan', v.plan, { type: 'textarea', ph: 'Botulinum toxin to glabella and forehead. Review in 2 weeks.', attrs: ro })}
    </div>${locked ? customKV(customPairs('visits', v.custom, 'notes')) : customFieldsHTML('visits', v.custom, 'notes')}</form>`;
}

// ---------- photos ----------
function photosCard(v, p, locked) {
  const mine = S.photos.filter(x => x.visitId === v.id).sort((a, b) => a.created - b.created);
  if (p.photoConsent === 'no') return `<div class="card"><div class="card-head"><h2>Photos</h2></div><p class="muted">The patient declined photos. Charts use the face drawing.</p></div>`;
  const areas = groupBy(mine, ph => (ph.area || '').trim());
  return `<div class="card" id="vphotos"><div class="card-head"><h2>Photos</h2>${locked ? '' : `<div class="row">
      <button class="btn primary small" data-act="guided-camera">Before and after camera</button>
      <button class="btn secondary small" data-act="collage">Before and after picture</button>
      <label class="btn secondary small">Take photo<input type="file" class="file-hidden" accept="image/*" capture="environment" data-add-photo></label>
      <label class="btn secondary small">Add from files<input type="file" class="file-hidden" accept="image/*" multiple data-add-photo></label></div>`}</div>
    ${p.photoConsent !== 'yes' ? `<div class="banner">Photo consent is not recorded. Get it under Consent before taking photos.</div>` : ''}
    ${locked ? '' : `<div class="photo-area">${field('Treated area', 'photoArea', photoAreaDefault(v), { ph: 'Underarms', attrs: 'list="photo-area-dl" data-photo-area', hint: 'New photos get this area. The first photos of an area are the baseline and photos on later visits are follow-ups.' })}${datalist('photo-area-dl', photoAreaHints(v))}</div>
      <div class="drop" data-drop>Drop photos here. You can add as many as you need.</div>`}
    ${mine.length ? [...areas.entries()].sort((a, b) => (a[0] ? 0 : 1) - (b[0] ? 0 : 1)).map(([area, list]) => photoGroupHTML(v, area, list, locked, areas.size > 1)).join('') : '<p class="muted">No photos for this visit.</p>'}
    <div class="progress-line hidden" data-up><span class="spin"></span><span data-up-text></span></div></div>`;
}
// One block per treated area. A follow-up block starts with the baseline photos so
// the change shows on the visit itself.
function photoGroupHTML(v, area, list, locked, many) {
  if (!area) return `${many ? '<h3 class="section-title">No area set</h3>' : ''}<div class="photo-grid">${list.map(ph => photoTile(ph, locked)).join('')}</div>`;
  const base = baselineOf(v.patientId, area);
  const fu = followUpNumber(v, area);
  const weeks = base.length && fu ? Math.round(daysBetween(base[0].date, v.date) / 7) : 0;
  return `<h3 class="section-title">${esc(area)} · ${fu ? `follow-up ${fu}${weeks ? `, ${plural(weeks, 'week')} after baseline` : ''}` : 'baseline'}</h3>
    <div class="photo-grid">${fu ? base.slice(0, 3).map(ph => `<div class="ph ref"><img loading="lazy" src="${thumbURL(ph.id)}" alt="Baseline" data-view-photo="${ph.id}"><div class="cap"><span>Baseline</span><span class="meta">${fmtDate(ph.date)}</span></div></div>`).join('') : ''}${list.map(ph => photoTile(ph, locked)).join('')}</div>`;
}
function photoTile(ph, locked) {
  return `<div class="ph" data-ph="${ph.id}"><img loading="lazy" src="${thumbURL(ph.id)}" alt="${esc(ph.view)}" data-view-photo="${ph.id}">
    ${locked ? `<div class="cap"><span>${esc(ph.area || ph.view)}</span><span class="meta">${esc(ph.stage || '')}</span></div>` : `
    <input type="text" data-ph-area value="${esc(ph.area || '')}" placeholder="Area" aria-label="Treated area" list="photo-area-dl">
    <select data-ph-view aria-label="View">${PHOTO_VIEWS.map(x => `<option ${ph.view === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
    <select data-ph-stage aria-label="Stage">${PHOTO_STAGES.map(x => `<option ${ph.stage === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
    <button class="rm" data-ph-rm aria-label="Delete photo">×</button>`}</div>`;
}
const areaKey = a => String(a || '').trim().toLowerCase();
const photoVisitDate = ph => { const v = ph.visitId && visit(ph.visitId); return (v && v.date) || ph.date || ''; };
// The baseline of an area is every photo of it from the first visit it was photographed on.
function baselineOf(patientId, area) {
  const list = S.photos.filter(x => x.patientId === patientId && areaKey(x.area) === areaKey(area)).sort((a, b) => photoVisitDate(a).localeCompare(photoVisitDate(b)) || (a.created || 0) - (b.created || 0));
  if (!list.length) return [];
  const first = list[0].visitId;
  return list.filter(x => x.visitId === first);
}
// 0 on the baseline visit, then 1, 2, 3 for each later visit with photos of the area.
function followUpNumber(v, area) {
  const visits = new Set(S.photos.filter(x => x.patientId === v.patientId && areaKey(x.area) === areaKey(area) && x.visitId !== v.id && photoVisitDate(x) < v.date).map(x => x.visitId));
  return visits.size;
}
function stageForArea(v, area) { return followUpNumber(v, area) ? 'Follow-up' : 'Baseline'; }
function photoAreaDefault(v) {
  const mine = S.photos.filter(x => x.visitId === v.id && x.area).sort((a, b) => (b.created || 0) - (a.created || 0));
  if (mine.length) return mine[0].area;
  const set = (v.settings || []).find(e => e.area);
  if (set) return set.area;
  const t = (v.treatments || []).find(x => x.area && x.source !== 'med');
  return t ? t.area.split(',')[0].trim() : '';
}
function photoAreaHints(v) {
  const out = new Set();
  for (const x of S.photos.filter(x => x.patientId === v.patientId && x.area)) out.add(x.area);
  for (const e of v.settings || []) if (e.area) out.add(e.area);
  for (const t of v.treatments || []) if (t.area && t.source !== 'med') for (const a of t.area.split(',')) out.add(a.trim());
  for (const a of ['Full face', 'Forehead', 'Glabella', 'Cheeks', 'Under eyes', 'Lips', 'Chin', 'Jawline', 'Neck', 'Underarms', 'Arms', 'Legs', 'Back', 'Chest']) out.add(a);
  return [...out];
}

async function addPhotos(files, v, areaIn) {
  const list = [...files].filter(f => /^image\//.test(f.type) || /\.(jpe?g|png|heic|webp)$/i.test(f.name));
  if (!list.length) return;
  const box = document.querySelector('[data-up]'), txt = document.querySelector('[data-up-text]');
  if (box) box.classList.remove('hidden');
  const order = ['Front', 'Left side', 'Right side', 'Left 45°', 'Right 45°'];
  const ai = document.querySelector('[data-photo-area]');
  const area = (areaIn !== undefined ? areaIn : ai ? ai.value : '').trim();
  let n = 0;
  for (const f of list) {
    n++;
    if (txt) txt.textContent = `Adding photo ${n} of ${list.length}.`;
    try {
      const existing = S.photos.filter(x => x.visitId === v.id);
      const stage = area ? stageForArea(v, area) : chartsOfVisit(v.id).some(c => (c.marks || []).length) ? 'After' : 'Before';
      const view = area ? 'Close-up' : order.find(o => !existing.some(x => x.view === o && x.stage === stage)) || 'Other';
      const full = await resizeImage(f, 2400, 0.9);
      const thumb = await resizeImage(full.blob, 480, 0.8);
      const date = (await exifDate(f)) || v.date;
      const fileId = await uploadFile(full.blob, { canWait: true });
      const thumbId = await uploadFile(thumb.blob, { canWait: true });
      await save('photos', { id: uid(), patientId: v.patientId, visitId: v.id, view, stage, area, date, w: full.width, h: full.height, name: f.name, fileId, thumbId }, { action: area ? `Photo added: ${area}, ${stage.toLowerCase()}` : 'Photo added' });
    } catch (e) { toast(`${f.name}: ${e.message}`, 6000); }
  }
  renderVisit(v.id);
}

// ---------- chart ----------
// Redraws only the chart cards, so a photo's new view shows there without losing typing elsewhere.
function repaintChartCards(visitId) {
  const box = document.querySelector('.chart-cards');
  if (!box) return;
  const v = visit(visitId), p = patient(v.patientId), card = box.closest('.card');
  card.insertAdjacentHTML('afterend', chartCard(v, p));
  card.remove();
  document.querySelectorAll('.chart-cards [data-chart]').forEach(b => { b.onclick = e => { e.preventDefault(); openChart(v.id, b.dataset.chart).catch(fail); }; });
  wireHeadChartCard(v, p);
}
function chartCard(v, p) {
  const cards = CHART_VIEWS.map(cv => {
    const c = S.charts.find(x => x.visitId === v.id && x.view === cv.key);
    if (!c && !cv.drawing && (p.photoConsent === 'no' || !defaultChartPhoto(v, cv.key))) return `<div class="chart-card blank off"><div class="ph-blank">${v.signedAt ? 'No chart' : 'Needs a photo'}</div><div class="cap"><b>${cv.label}</b><span class="meta">${p.photoConsent === 'no' ? 'The patient declined photos.' : `Add a ${cv.label} photo to chart on it.`}</span></div></div>`;
    if (!c) return `<button class="chart-card blank" data-chart="${cv.key}"><div class="ph-blank">${v.signedAt ? 'No chart' : 'Start chart'}</div><div class="cap"><b>${cv.label}</b><span class="meta">${p.photoConsent === 'no' ? 'Face drawing' : (defaultChartPhoto(v, cv.key) ? 'Opens on the photo' : 'Face drawing')}</span></div></button>`;
    const lines = linesFromMarks(c.marks || []);
    return `<button class="chart-card" data-chart="${cv.key}">${chartSVG(c, chartThumbURL(c), 'preserveAspectRatio="xMidYMid meet"')}<div class="cap"><b>${cv.label}</b><span class="meta">${lines.length ? esc(lines.map(l => matText(l, l.product || KINDS[l.kind].short)).join(', ')) : 'No treatment marks'}</span></div></button>`;
  }).join('');
  return `<div class="card"><div class="card-head"><h2>Treatment chart</h2><a class="btn secondary small" href="#/chart/${v.id}">Notes and chart side by side</a></div><div class="chart-cards">${cards}${headChartCard(v, p)}</div></div>`;
}

// ---------- treatment record ----------
function treatCard(v, locked) {
  const rows = (v.treatments || []).filter(t => t.source !== 'supply').map(t => `<tr>
    <td>${esc(KINDS[t.kind] ? KINDS[t.kind].label : t.kind)}${t.source === 'chart' ? ' <span class="chip tiny info">From the chart</span>' : t.source === 'med' ? ' <span class="chip tiny info">Medicine</span>' : ''}</td>
    <td>${esc(t.product)}</td><td>${esc(t.lot || '')}</td><td class="n">${trimNum(t.amount)} ${esc(t.unit)}</td><td>${esc(t.area || '')}${t.notes ? `<div class="meta">${esc(t.notes)}</div>` : ''}</td>
    <td class="n">${locked ? '' : t.source === 'med' ? `<button class="btn quiet small" data-med="${esc(t.medId)}">Edit</button>` : `<button class="btn quiet small" data-treat="${esc(t.id)}">Edit</button>`}</td></tr>`).join('');
  const used = materialsLine(v);
  return `<div class="card" id="materials"><div class="card-head"><h2>Materials used</h2>${locked ? '' : `<button class="btn quiet small" data-act="add-treat">More details</button>`}</div>
    ${used ? `<p class="mat-sum">${esc(used)}</p>` : ''}
    ${locked ? '' : materialsAddHTML()}
    ${rows ? `<div class="scroll-x"><table class="t"><tr><th>Type</th><th>Product</th><th>Lot</th><th class="n">Amount</th><th>Area</th><th></th></tr>${rows}</table></div>
    <p class="meta" style="margin-top:8px">Lines marked From the chart come from the treatment chart, and lines marked Medicine from Medicines given.</p>` : '<p class="muted">Marks on the treatment chart fill this in. Add anything not charted above.</p>'}</div>`;
}

// What was used on a visit in one line, such as "Botox 100 U 30 U · Juvederm Voluma 4 ml · Ulthera 200 shots".
function materialsLine(v) {
  return (v.treatments || []).filter(t => t.source !== 'supply' && t.product).map(t => matText(t)).join(' · ');
}
// A product and its amount. A syringe named by its size, such as Juvederm Volbella 1 ml, used
// whole reads once.
function matText(t, name = t.product) {
  const amt = `${trimNum(t.amount)} ${t.unit || ''}`.trim();
  return amt && !String(name).toLowerCase().endsWith(' ' + amt.toLowerCase()) ? `${name} ${amt}` : name;
}
// The quick way in: type or tap a product, the amount, Add. The products used most at the
// branch are a tap away.
function materialsAddHTML() {
  const count = new Map();
  for (const v of S.visits) for (const t of v.treatments || []) if (t.productId) count.set(t.productId, (count.get(t.productId) || 0) + 1);
  const prods = S.products.filter(p => p.active !== false);
  // The branch's most used, once there are any. Until then the list under Product has them all.
  const top = prods.filter(p => count.get(p.id)).sort((a, b) => count.get(b.id) - count.get(a.id) || a.name.localeCompare(b.name)).slice(0, 10);
  return `<form class="mat-add" data-mat-add autocomplete="off">
      <input type="text" name="product" list="mat-dl" placeholder="Product, such as Botox 100 U" aria-label="Product">
      <input name="amount" type="number" step="any" min="0" inputmode="decimal" placeholder="30" aria-label="Amount">
      <input type="text" name="unit" list="units-dl" placeholder="U" aria-label="Unit">
      <button class="btn primary small">${I.plus}Add</button>
    </form>${datalist('mat-dl', prods.map(p => p.name))}${datalist('units-dl', UNITS)}
    ${top.length ? `<div class="mat-chips">${top.map(p => `<button type="button" class="chip-btn" data-mat-pick="${esc(p.id)}">${esc(p.name)}</button>`).join('')}</div>` : ''}`;
}
async function addMaterial(v, form) {
  const name = form.product.value.trim(), amount = num(form.amount.value), unitIn = form.unit.value.trim();
  if (!name) { form.product.focus(); return toast('Enter the product.'); }
  if (!(amount > 0)) { form.amount.focus(); return toast('Enter the amount used.'); }
  const p = S.products.find(x => x.name.toLowerCase() === name.toLowerCase());
  const l = p ? pickLot(p.id) : null;
  const line = { id: uid(), source: 'manual', kind: p ? p.kind : 'other', lotId: l ? l.id : '', productId: p ? p.id : '', product: p ? p.name : name, lot: l ? l.lot : '', amount, unit: unitIn || (p ? p.unit : ''), area: '', notes: '' };
  try { await pushTo('visits', v.id, 'treatments', [line], 'Material added'); renderVisit(v.id); setTimeout(() => { const f = document.querySelector('[data-mat-add] [name=product]'); if (f) f.focus(); }, 50); }
  catch (e) { fail(e); }
}

function lotOptions(kind, selected) {
  return [['', 'Not in stock list'], ...(kind ? lotsForKind(kind) : S.lots.filter(l => !l.archived)).map(l => [l.id, lotOptionLabel(l)])].map(([i, l]) => `<option value="${i}" ${i === selected ? 'selected' : ''}>${esc(l)}</option>`).join('');
}

async function treatSheet(v, t) {
  const fromChart = t && t.source === 'chart';
  const kind0 = t ? t.kind : 'toxin';
  const l0 = t && t.lotId ? lot(t.lotId) : null, p0 = l0 ? product(l0.productId) : null;
  const f = await sheet({
    title: t ? 'Treatment line' : 'Add treatment line',
    extra: t && !fromChart ? '<button type="button" class="btn danger" data-del>Delete</button>' : '',
    body: fromChart ? `<p class="muted">${esc(t.product)} ${trimNum(t.amount)} ${esc(t.unit)} comes from the chart. Change the marks on the chart to change the amount.</p>`
      : `<div class="grid2">${field('Type', 'kind', kind0, { type: 'select', options: KIND_KEYS.map(k => [k, KINDS[k].label]), blank: false })}
        <label class="field"><span class="label">Product and lot</span><select name="lotId">${lotOptions(kind0, t ? t.lotId : (pickLot((S.products.find(p => p.kind === kind0) || {}).id) || {}).id)}</select></label></div>
        <div class="grid3">${field('Product', 'product', t ? t.product : '', { ph: 'Botox 100 U' })}${field('Amount', 'amount', t ? t.amount : '', { type: 'number' })}${field('Unit', 'unit', t ? t.unit : KINDS[kind0].unit, { attrs: 'list="units-dl"' })}</div>
        ${datalist('units-dl', UNITS)}
        <div class="grid2">${field('Area', 'area', t ? t.area : '', { ph: 'Glabella' })}${field('Notes', 'notes', t ? t.notes : '', { ph: '30G needle, 5 points' })}</div>`,
    onOpen: form => {
      const del = form.querySelector('[data-del]');
      if (del) del.onclick = async () => { form.close(null); try { await pullFrom('visits', v.id, 'treatments', [t.id], 'Treatment line deleted'); renderVisit(v.id); } catch (e) { fail(e); } };
      const kind = form.querySelector('[name=kind]'), sel = form.querySelector('[name=lotId]');
      if (!kind) return;
      const fill = () => { const l = lot(sel.value), p = l ? product(l.productId) : null; if (p) { form.querySelector('[name=product]').value = p.name; form.querySelector('[name=unit]').value = p.unit; } };
      kind.onchange = () => { sel.innerHTML = lotOptions(kind.value, ''); const first = sel.options[0] && sel.options.length > 1 ? sel.options[0] : null; if (first) sel.value = sel.options[0].value; form.querySelector('[name=unit]').value = KINDS[kind.value].unit; fill(); };
      sel.onchange = fill;
      if (!t) fill();
    },
    validate: form => (!fromChart && !val(form, 'product') ? 'Enter the product.' : !fromChart && nval(form, 'amount') <= 0 ? 'Enter the amount used.' : ''),
  });
  if (!f || fromChart) return;
  const l = lot(val(f, 'lotId'));
  const line = { id: t ? t.id : uid(), source: 'manual', kind: val(f, 'kind'), lotId: l ? l.id : '', productId: l ? l.productId : '', product: val(f, 'product'), lot: l ? l.lot : '', amount: nval(f, 'amount'), unit: val(f, 'unit'), area: val(f, 'area'), notes: val(f, 'notes') };
  try { await pushTo('visits', v.id, 'treatments', [line], t ? 'Treatment line edited' : 'Treatment line added'); renderVisit(v.id); }
  catch (e) { fail(e); }
}

// ---------- consent ----------
function consentCard(v, locked) {
  const list = v.consents || [];
  return `<div class="card"><div class="card-head"><h2>Consent</h2>${locked ? '' : `<button class="btn secondary small" data-act="consent">Get consent</button>`}</div>
    ${list.length ? `<div class="list flat">${list.map(c => `<div class="li"><div class="grow"><div class="t medium" translate="no">${esc(c.title)}</div><div class="m">Signed by ${esc(c.signer)} ${fmtStamp(c.signedAt)} · witness ${esc(c.witness)}${c.lang ? ` · <span translate="no">${esc((FORM_LANGS.find(x => x[0] === c.lang) || [])[1] || '')}</span>` : ''}</div></div>${c.signatureId ? `<img class="sig-img" src="${fileURL(c.signatureId)}" alt="Signature">` : ''}<button class="btn quiet small" data-print-consent="${c.id}">Print</button></div>`).join('')}</div>` : '<p class="muted">No consent signed on this visit.</p>'}</div>`;
}

async function consentFlow(v, p) {
  const keys = Object.keys(S.templates.consent);
  const wanted = consentsWanted(v, p);
  const done = new Set((v.consents || []).map(c => c.key));
  const pick = await sheet({
    title: 'Get consent', submit: 'Next',
    body: `<p class="muted">Pick the forms to sign. The forms for today's services and treatments are ticked.</p>
      ${keys.map(k => `<label class="check"><input type="checkbox" name="k_${k}" ${wanted.has(k) && !done.has(k) ? 'checked' : ''}><span>${esc(consentTitle(k))}${done.has(k) ? ' <span class="meta">signed on this visit</span>' : ''}</span></label>`).join('')}`,
    validate: f => (keys.some(k => val(f, 'k_' + k)) ? '' : 'Tick at least one form.'),
  });
  if (!pick) return;
  for (const k of keys.filter(k => val(pick, 'k_' + k))) {
    const ok = await signSheet(v, p, k);
    if (!ok) break;
  }
  renderVisit(v.id);
}

function signaturePad(canvas) {
  const r = canvas.getBoundingClientRect();
  canvas.width = r.width * 2; canvas.height = r.height * 2;
  const ctx = canvas.getContext('2d');
  ctx.scale(2, 2); ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#101C2B';
  let last = null;
  const state = { drawn: false, clear() { ctx.clearRect(0, 0, canvas.width, canvas.height); state.drawn = false; } };
  const pos = e => { const b = canvas.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top]; };
  canvas.onpointerdown = e => { canvas.setPointerCapture(e.pointerId); last = pos(e); state.drawn = true; };
  canvas.onpointermove = e => { if (!last) return; const p2 = pos(e); ctx.beginPath(); ctx.moveTo(last[0], last[1]); ctx.lineTo(p2[0], p2[1]); ctx.stroke(); last = p2; };
  canvas.onpointerup = canvas.onpointercancel = () => { last = null; };
  return state;
}

// The patient reads the form in Thai, English or Chinese and signs it. The signed copy
// keeps the exact text and the language it was read in.
function signSheet(v0, p, key) {
  const t = S.templates.consent[key];
  const doc = byId('users', v0.doctorId);
  const langs = FORM_LANGS.filter(([l]) => consentHas(t, l));
  let lang = langs.some(([l]) => l === p.plang) ? p.plang : (langs[0] || ['en'])[0];
  const textFor = l => { let x = consentText(t, 'text', l); if (doc) x = x.split(DOCTOR_PHRASE[l] || DOCTOR_PHRASE.en).join(l === 'th' && doc.nameTh ? doc.nameTh : doc.name); return x; };
  let pad;
  return sheet({
    title: consentText(t, 'title', lang), wide: true, submit: 'Save signed form',
    body: `<div data-ui-lang="${lang}" class="consent-sign">${langs.length > 1 ? `<div class="seg" role="group" aria-label="Language">${langs.map(([l, n]) => `<button type="button" data-clang="${l}" class="${l === lang ? 'on' : ''}" translate="no">${n}</button>`).join('')}</div>` : ''}
      <h3 class="consent-title" translate="no">${esc(consentText(t, 'title', lang))}</h3><div class="consent-text" translate="no">${esc(textFor(lang))}</div>
      ${field('Patient or guardian name', 'signer', lang === 'th' && p.nameTh ? p.nameTh : p.name)}
      <div class="field"><span class="label">Signature</span><canvas class="sigpad" data-sig></canvas><span class="hint">Sign with a finger or stylus. <a href="#" data-clear>Clear</a></span></div>
      <p class="meta">Witness: ${esc(S.me.name)}</p></div>`,
    onOpen: form => {
      pad = signaturePad(form.querySelector('[data-sig]'));
      form.querySelector('[data-clear]').onclick = e => { e.preventDefault(); pad.clear(); };
      form.querySelectorAll('[data-clang]').forEach(b => b.onclick = () => {
        lang = b.dataset.clang;
        form.querySelectorAll('[data-clang]').forEach(x => x.classList.toggle('on', x === b));
        form.querySelector('.consent-title').textContent = consentText(t, 'title', lang);
        form.querySelector('.consent-text').textContent = textFor(lang);
        const box = form.querySelector('[data-ui-lang]'); box.dataset.uiLang = lang; retranslate(box);
        const h = form.closest('.sheet') && form.closest('.sheet').querySelector('h2'); if (h) h.textContent = consentText(t, 'title', lang);
      });
    },
    validate: form => (!val(form, 'signer') ? 'Enter who is signing.' : !pad.drawn ? 'The form needs a signature.' : ''),
  }).then(async f => {
    if (!f) return false;
    try {
      const blob = await new Promise(r => f.querySelector('[data-sig]').toBlob(r, 'image/png'));
      const signatureId = await uploadFile(blob, { canWait: true });
      const entry = { id: uid(), key, lang, title: consentText(t, 'title', lang), titleEn: consentText(t, 'title', 'en'), text: textFor(lang), apexWording: !!t.apex, signer: val(f, 'signer'), signatureId, signedAt: Date.now(), witness: S.me.name, witnessId: S.me.id };
      await pushTo('visits', v0.id, 'consents', [entry], 'Consent signed: ' + entry.titleEn);
      const cur = patient(p.id);
      if (key === 'photos' && cur.photoConsent !== 'yes') await save('patients', { ...cur, photoConsent: 'yes' }, { action: 'Photo consent signed' });
      if (key === 'privacy') await save('patients', { ...patient(p.id), privacyConsentAt: entry.signedAt, privacyConsentVisit: v0.id }, { action: 'PDPA notice signed' });
      if (key === 'marketing' && cur.marketingConsent !== 'yes') await save('patients', { ...patient(p.id), marketingConsent: 'yes', marketingConsentAt: Date.now() }, { action: 'Marketing consent signed' });
      return true;
    } catch (e) { fail(e); return false; }
  });
}

// ---------- prescription ----------
function rxCard(v, locked) {
  const list = v.rx || [];
  const edit = !locked && isPrescriber();
  return `<form class="card" id="rx"><div class="card-head"><h2>Prescription</h2><div class="row">${list.length ? `<button type="button" class="btn secondary small" data-act="print-rx">${I.print}Print</button>` : ''}${edit ? '<button class="btn secondary small">Save</button>' : ''}</div></div>
    ${!edit ? (list.length ? `<table class="t"><tr><th>Medicine</th><th>Quantity</th><th>Directions</th></tr>${list.map(r => `<tr><td>${esc(r.drug)}</td><td>${esc(r.qty)}</td><td>${esc(r.sig)}</td></tr>`).join('')}</table>` : `<p class="muted">${locked ? 'No prescription.' : 'Only doctors write prescriptions.'}</p>`)
      : rowsBlock('rx', [{ k: 'drug', label: 'Medicine and strength', ph: 'Mupirocin 2% ointment', w: '1.4fr' }, { k: 'qty', label: 'Quantity', ph: '1 tube', w: '0.6fr' }, { k: 'sig', label: 'Directions', ph: 'Apply to the injection points 3 times a day for 5 days', w: '1.6fr' }], list, 'Add medicine')}</form>`;
}

// ---------- aftercare ----------
function aftercareCard(v, locked) {
  const text = v.aftercare ?? defaultAftercare(v);
  return `<form class="card" id="after"><div class="card-head"><h2>Aftercare</h2><div class="row">
      <button type="button" class="btn secondary small" data-act="copy-after">Copy text</button>
      <button type="button" class="btn secondary small" data-act="print-after">${I.print}Print</button>
      ${locked ? '' : '<button type="button" class="btn quiet small" data-act="reset-after">Use templates</button><button class="btn secondary small">Save</button>'}</div></div>
    <textarea name="aftercare" class="autosize" style="height:${Math.max(160, text.split('\n').length * 24 + 24)}px" ${locked ? 'readonly' : ''} placeholder="Add a service, treatment line or chart mark and the matching aftercare fills in here.">${esc(text)}</textarea>
    <p class="meta" style="margin-top:6px">Copy text puts it on the clipboard for LINE, WhatsApp or WeChat.</p></form>`;
}

// ---------- follow-up ----------
function followCard(v) {
  return `<form class="card" id="follow"><div class="card-head"><h2>Follow-up</h2><button class="btn secondary small">Save</button></div>
    <div class="grid2">
      <div class="field"><span class="label">Date</span><input type="date" name="followUp" value="${esc(v.followUp || '')}"><span class="hint"><a href="#" data-in="7">1 week</a> · <a href="#" data-in="14">2 weeks</a> · <a href="#" data-in="28">4 weeks</a> · <a href="#" data-in="91">3 months</a> · <a href="#" data-in="122">4 months</a></span></div>
      ${field('Reason', 'followReason', v.followReason, { ph: 'Toxin review and top-up' })}
    </div>${(() => { const bk = S.bookings.filter(b => b.patientId === v.patientId && b.date >= todayISO() && BOOK_LIVE(b)).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))[0]; return bk ? `<p class="meta">Booked for ${fmtDate(bk.date)} at ${esc(bk.time)}${bk.doctorId ? ' with ' + esc(userName(bk.doctorId)) : ''}.</p>` : v.followUp && canBook() ? `<div class="row"><button type="button" class="btn secondary small" data-book-visit="${v.id}">${I.plus}Book the follow-up</button></div>` : ''; })()}</form>`;
}

// ---------- for Apex's EMR ----------
// What the staff re-encode into Apex's own system: the patient, the treatments with
// products, amounts and lots, the prescription and the follow-up, as plain text to copy
// or print. Written in English, since Apex's EMR keeps clinical notes in English.
function emrSummaryText(v, p) {
  const doc = byId('users', v.doctorId);
  const lines = [];
  lines.push(`${p.name}${p.nameTh && p.nameTh !== p.name ? ' / ' + p.nameTh : ''}`);
  lines.push([p.hn ? 'HN ' + p.hn : 'HN not entered', p.no, p.dob ? `DOB ${p.dob}` : '', p.sex].filter(Boolean).join(' · '));
  lines.push(`Visit ${v.no || ''} · ${v.date}${v.time ? ' ' + v.time : ''} · ${v.type || 'Visit'} · ${doc ? doc.name : ''}${doc && doc.licence ? ' (' + doc.licence + ')' : ''}`);
  const al = (p.allergies || []).map(a => a.what).join(', ');
  lines.push(`Allergies: ${al || (p.nka ? 'None known' : 'Not recorded')}`);
  const sv = (v.services || []).map(x => (service(x.serviceId) || {}).name || x.name).filter(Boolean);
  if (sv.length) lines.push(`Treatments: ${sv.join(', ')}`);
  const tr = (v.treatments || []).filter(t => t.source !== 'supply');
  if (tr.length) { lines.push('Products used:'); for (const t of tr) lines.push(`- ${matText(t, t.product || (KINDS[t.kind] || {}).short || '')}${t.area ? ', ' + t.area : ''}${t.lot ? ', lot ' + t.lot : ''}`); }
  for (const [k, l] of [['complaint', 'Complaint'], ['findings', 'Findings'], ['assessment', 'Assessment'], ['plan', 'Plan']]) if (v[k]) lines.push(`${l}: ${v[k]}`);
  if ((v.meds || []).length) { lines.push('Medicines given:'); for (const m of v.meds) lines.push(`- ${m.drug} ${trimNum(m.dose)} ${m.unit || ''} ${m.route || ''}${m.site ? ', ' + m.site : ''}${m.lot ? ', lot ' + m.lot : ''}${m.time ? ' at ' + m.time : ''}`); }
  if ((v.rx || []).length) { lines.push('Prescription:'); for (const r of v.rx) lines.push(`- ${r.drug}${r.qty ? ', ' + r.qty : ''}${r.sig ? ': ' + r.sig : ''}`); }
  if ((v.consents || []).length) lines.push(`Consent signed: ${v.consents.map(c => c.title + (c.lang ? ` (${c.lang})` : '')).join(', ')}`);
  if (v.followUp) lines.push(`Follow-up: ${v.followUp}${v.followReason ? ', ' + v.followReason : ''}`);
  lines.push(v.signedAt ? `Signed ${isoOf(new Date(v.signedAt))} by ${userName(v.signedBy)}` : 'Not signed yet');
  return lines.join('\n');
}
function emrSummaryCard(v, p) {
  const text = emrSummaryText(v, p);
  return `<div class="card" id="emr"><div class="card-head"><h2>For Apex's EMR</h2><div class="row"><button type="button" class="btn secondary small" data-act="copy-emr">Copy text</button><button type="button" class="btn secondary small" data-act="print-emr">${I.print}Print</button></div></div>
    <pre class="emr-text" translate="no">${esc(text)}</pre><p class="meta">The staff copy this into Apex's own system.</p></div>`;
}

// ---------- signing ----------
// Used by the visit page and the Full chart page. patch carries notes not saved yet.
async function signVisitFlow(id, patch = {}) {
  const r = await ask({ title: 'Sign this visit?', body: 'Notes, charts and treatment become view only. A doctor can reopen it, and every change after signing shows in the visit history.', buttons: [{ label: 'Cancel', value: null }, { label: 'Sign', value: true, kind: 'primary' }] });
  if (!r) return;
  const c = { ...visit(id), ...patch };
  try {
    await save('visits', { ...c, signedAt: Date.now(), signedBy: S.me.id }, { action: 'Visit signed' });
    render();
  } catch (ex) { fail(ex); }
}
async function reopenVisitFlow(id) {
  const r = await ask({ title: 'Reopen this visit?', body: 'The visit history keeps the signed version and every change after it.', buttons: [{ label: 'Cancel', value: null }, { label: 'Reopen', value: true, kind: 'primary' }] });
  if (!r) return;
  try { await save('visits', { ...visit(id), signedAt: null, signedBy: null }, { action: 'Visit reopened' }); render(); } catch (e) { fail(e); }
}

// ---------- wiring ----------
function wireVisit(v, p) {
  if (!v.signedAt && can('edit')) phrasesWire(document.getElementById('notes'), v);
  const on = (sel, fn) => document.querySelectorAll(sel).forEach(b => b.onclick = e => { e.preventDefault(); fn(b); });
  const cur = () => visit(v.id);
  on('[data-act="add-incident"]', () => incidentSheet(null, { patientId: p.id, visitId: v.id }));
  wireIncidents();
  markSeen(p.id, 'visit');
  const notes = document.getElementById('notes');
  if (notes) notes.onsubmit = async e => {
    e.preventDefault();
    const miss = customMissing(notes, 'visits'); if (miss) return toast(miss);
    try { await save('visits', { ...cur(), complaint: val(notes, 'complaint'), findings: val(notes, 'findings'), assessment: val(notes, 'assessment'), plan: val(notes, 'plan'), custom: readCustomFields(notes, 'visits', cur().custom) }, { action: 'Notes saved' }); delete notes.dataset.dirty; toast('Notes saved.'); }
    catch (ex) { fail(ex); }
  };
  on('[data-act="add-service"]', () => addServiceSheet(cur()));
  on('[data-act="use-preset"]', () => usePresetSheet(cur()));
  on('[data-act="save-preset"]', async () => { if (await savePresetSheet(cur())) renderVisit(v.id); });
  on('[data-rm-service]', async b => {
    try { await pullFrom('visits', v.id, 'services', [b.dataset.rmService], 'Treatment removed'); renderVisit(v.id); } catch (e) { fail(e); }
  });
  // photos
  document.querySelectorAll('[data-add-photo]').forEach(inp => inp.onchange = () => { if (inp.files.length) addPhotos(inp.files, cur(), inp.dataset.area); });
  document.querySelectorAll('[data-act="guided-camera"]').forEach(b => b.onclick = () => openGuidedCamera(cur()).catch(fail));
  document.querySelectorAll('[data-act="checkin"]').forEach(b => b.onclick = () => openCheckin(cur()));
  document.querySelectorAll('[data-act="collage"]').forEach(b => b.onclick = () => openCollage(p.id, { visitId: v.id }).catch(fail));
  const drop = document.querySelector('[data-drop]');
  if (drop) {
    drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
    drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); addPhotos(e.dataTransfer.files, cur()); };
  }
  const vids = [...new Set([...document.querySelectorAll('[data-view-photo]')].map(i => i.dataset.viewPhoto))];
  document.querySelectorAll('[data-view-photo]').forEach(img => img.onclick = () => photoViewer(vids, img.dataset.viewPhoto));
  document.querySelectorAll('[data-ph]').forEach(tile => {
    const ph = () => photoMeta(tile.dataset.ph);
    const vs = tile.querySelector('[data-ph-view]'), ss = tile.querySelector('[data-ph-stage]'), rm = tile.querySelector('[data-ph-rm]'), as = tile.querySelector('[data-ph-area]');
    if (as) as.onchange = async () => {
      const area = as.value.trim(), cur = ph();
      const stage = area ? stageForArea(visit(v.id), area) : (['Baseline', 'Follow-up'].includes(cur.stage) ? 'Before' : cur.stage);
      try { await save('photos', { ...cur, area, stage }, { action: area ? `Photo area set: ${area}` : 'Photo area cleared' }); renderVisit(v.id); } catch (e) { fail(e); }
    };
    if (vs) vs.onchange = () => save('photos', { ...ph(), view: vs.value }, { action: 'Photo view set' }).then(() => { toast('Saved.'); repaintChartCards(v.id); }).catch(fail);
    if (ss) ss.onchange = () => save('photos', { ...ph(), stage: ss.value }, { action: 'Photo stage set' }).then(() => toast('Saved.')).catch(fail);
    if (rm) rm.onclick = async () => {
      const used = S.charts.filter(c => c.base && c.base.photoId === tile.dataset.ph);
      const r = await confirmDanger('Delete this photo?', used.length ? 'A chart is drawn on this photo and switches to the face drawing.' : '');
      if (!r) return;
      try {
        for (const c of used) await save('charts', { ...c, base: { type: 'drawing' }, w: FACE_W, h: FACE_H }, { action: 'Chart moved to face drawing' });
        await remove('photos', tile.dataset.ph);
        renderVisit(v.id);
      } catch (e) { fail(e); }
    };
  });
  on('[data-chart]', b => openChart(v.id, b.dataset.chart).catch(fail));
  wireHeadChartCard(v, p);
  on('[data-act="add-treat"]', () => treatSheet(cur(), null));
  const mf = document.querySelector('[data-mat-add]');
  if (mf) {
    const unitFor = () => { const p = S.products.find(x => x.name.toLowerCase() === mf.product.value.trim().toLowerCase()); if (p && !mf.unit.value) mf.unit.value = p.unit || ''; };
    mf.product.addEventListener('change', unitFor);
    mf.onsubmit = e => { e.preventDefault(); unitFor(); addMaterial(cur(), mf); };
    document.querySelectorAll('[data-mat-pick]').forEach(b => b.onclick = () => { const p = product(b.dataset.matPick); mf.product.value = p.name; mf.unit.value = p.unit || ''; mf.amount.focus(); });
  }
  on('[data-treat]', b => treatSheet(cur(), cur().treatments.find(t => t.id === b.dataset.treat)));
  wireTreatLog(v);
  on('[data-act="consent"]', () => consentFlow(cur(), patient(p.id)));
  on('[data-print-consent]', b => printConsent(cur(), cur().consents.find(c => c.id === b.dataset.printConsent)));
  const rx = document.getElementById('rx');
  if (rx && rx.querySelector('[data-rows]')) {
    wireRows(rx);
    rx.onsubmit = async e => { e.preventDefault(); try { await save('visits', { ...cur(), rx: readRows(rx, 'rx') }, { action: 'Prescription saved' }); delete rx.dataset.dirty; toast('Prescription saved.'); renderVisit(v.id); } catch (ex) { fail(ex); } };
  }
  on('[data-act="print-rx"]', async () => {
    if (rx && rx.querySelector('[data-rows]')) { const rows = readRows(rx, 'rx'); if (JSON.stringify(rows) !== JSON.stringify(cur().rx || [])) await save('visits', { ...cur(), rx: rows }, { action: 'Prescription saved' }); }
    printRx(cur());
  });
  const after = document.getElementById('after');
  if (after) after.onsubmit = async e => { e.preventDefault(); try { await save('visits', { ...cur(), aftercare: after.querySelector('textarea').value }, { action: 'Aftercare saved' }); delete after.dataset.dirty; toast('Aftercare saved.'); } catch (ex) { fail(ex); } };
  on('[data-act="reset-after"]', () => { after.querySelector('textarea').value = defaultAftercare(cur()); after.dataset.dirty = '1'; });
  on('[data-act="copy-after"]', async () => { try { await navigator.clipboard.writeText(after.querySelector('textarea').value); } catch (e) { after.querySelector('textarea').select(); document.execCommand('copy'); } toast('Aftercare copied.'); });
  on('[data-act="print-after"]', () => printAftercare(cur(), after.querySelector('textarea').value));
  on('[data-act="copy-emr"]', async () => { const ok = await copyText(emrSummaryText(cur(), patient(p.id))); toast(ok ? 'Copied.' : 'The text could not be copied on this device.'); });
  on('[data-act="print-emr"]', () => printEmrSummary(cur(), patient(p.id)));
  if (typeof wireVisitTools === 'function') wireVisitTools(v, p);
  if (typeof wireTranslatorCard === 'function') wireTranslatorCard(v, p);
  const follow = document.getElementById('follow');
  follow.querySelectorAll('[data-in]').forEach(a => a.onclick = e => { e.preventDefault(); follow.querySelector('[name=followUp]').value = addDays(cur().date, +a.dataset.in); follow.dataset.dirty = '1'; });
  follow.onsubmit = async e => {
    e.preventDefault();
    const date = val(follow, 'followUp'), reason = val(follow, 'followReason');
    try {
      await save('visits', { ...cur(), followUp: date, followReason: reason }, { action: 'Follow-up set' });
      delete follow.dataset.dirty;
      toast('Follow-up saved.'); renderVisit(v.id);
    } catch (ex) { fail(ex); }
  };
  on('[data-act="sign"]', () => signVisitFlow(v.id, notes ? { complaint: val(notes, 'complaint'), findings: val(notes, 'findings'), assessment: val(notes, 'assessment'), plan: val(notes, 'plan'), custom: readCustomFields(notes, 'visits', cur().custom) } : {}));
  on('[data-act="reopen"]', () => reopenVisitFlow(v.id));
  on('[data-act="print-visit"]', () => printVisit(cur()));
  const hist = document.getElementById('vhist');
  if (hist) hist.ontoggle = async () => {
    if (!hist.open) return;
    const ids = [v.id, ...chartsOfVisit(v.id).map(c => c.id), ...S.photos.filter(x => x.visitId === v.id).map(x => x.id)];
    try { const rows = (await Promise.all(ids.map(historyOf))).flat().sort((a, b) => b.at - a.at); hist.querySelector('[data-hist]').innerHTML = historyHTML(rows); }
    catch (e) { fail(e); }
  };
}
