// Start-up, first-run setup, sign-in and lock, and the screen router.

const APP_VERSION = '1.1.0';
let hello = null;
// A page can leave a function here to finish up (save what is typed) before the next screen draws.
let leavePage = null;

// ---------- render ----------
function render() {
  S.stale = false;
  if (!S.me) return;
  if (leavePage) { const f = leavePage; leavePage = null; try { f(); } catch (e) { console.error(e); } }
  if (typeof E !== 'undefined' && E) { dockFlush(); edClose(); }
  const { parts, q } = route();
  const [a, b, c] = parts;
  const routes = {
    today: () => renderToday(q),
    book: () => renderBookings(q),
    patients: () => renderPatients(q),
    patient: () => (b === 'new' ? renderPatientForm(null, q) : c === 'edit' ? renderPatientForm(b) : renderPatient(b, c)),
    visit: () => renderVisit(b),
    chart: () => renderFullChart(b, c),
    team: () => renderTeam(b),
    me: () => renderTeam('me'),
    complications: () => renderIncidentReport(q),
    settings: () => renderSettings(b || 'clinic', q),
    conflicts: () => renderConflicts(),
    // Short addresses carried by the printed QR codes.
    p: () => openPatientNo(b),
  };
  // Staff read records and change nothing, so the screens that only edit send them back.
  if (!can('edit') && ((a === 'patient' && (b === 'new' || c === 'edit')) || a === 'chart')) return go(a === 'chart' ? '#/visit/' + b : b === 'new' ? '#/patients' : '#/patient/' + b);
  const fn = routes[a] || routes.today;
  // The bookings page is the staff's own, so it stays open to them.
  try { fn(); if (!can('edit') && a !== 'book') viewOnly(); }
  catch (err) {
    console.error(err);
    $app.innerHTML = shell('', `<div class="empty"><h2>This screen could not open.</h2><p translate="no">${esc(err.message)}</p><a class="btn secondary" href="#/today">Go to Today</a></div>`);
    wireShell();
  }
}
window.addEventListener('hashchange', () => { if (S.me) render(); });

// Opens a patient from the number on their card, their Apex HN or the QR.
function openPatientNo(no) {
  const p = findPatientByNo(no);
  if (!p) { toast(`No patient with the number ${no || ''}.`); return go('#/patients'); }
  location.replace('#/patient/' + p.id);
  render();
}

// Changes made while the branch PC was away that could not go in as they were.
function renderConflicts() {
  const mine = S.conflicts.filter(c => isOwner() || c.userId === S.me.id).sort((a, b) => b.at - a.at);
  const linkOf = c => ({ patients: `#/patient/${c.recId}`, visits: `#/visit/${c.recId}` }[c.store] || '');
  const nameOf = c => { const d = byId(c.store, c.recId); const p = c.patientId && patient(c.patientId); return `${STORE_LABELS[c.store] || c.store}${d && d.no ? ' ' + d.no : ''}${p ? ' · ' + p.name : c.label ? ' · ' + c.label : ''}`; };
  const show = v => (v === null || v === undefined || v === '' ? '<span class="meta">blank</span>' : esc(typeof v === 'string' ? v : JSON.stringify(v)));
  $app.innerHTML = shell('today', `
    <div class="page-head"><div><h1>Settle sync conflicts</h1><div class="meta sub">The same field was changed on this device and on the branch PC while they were apart. Pick which value to keep.</div></div></div>
    ${mine.length ? `<div class="stack">${mine.map(c => `<div class="card" data-conflict="${c.id}"><div class="card-head"><h2>${nameOf(c)}: ${esc(FIELD_NAMES[c.field] || c.field)}</h2>${linkOf(c) ? `<a class="btn quiet small" href="${linkOf(c)}">Open the record</a>` : ''}</div>
        <div class="grid2"><div class="card flush" style="padding:12px"><div class="meta">${esc(c.byName || 'This device')}, away, ${fmtStamp(c.at)}</div><p class="pre">${show(c.mine)}</p><button class="btn primary small" data-keep="mine">Keep this one</button></div>
          <div class="card flush" style="padding:12px"><div class="meta">On the branch PC, ${esc(userName(c.theirsBy) || 'someone')}, ${fmtStamp(c.theirsAt)}</div><p class="pre">${show(c.theirs)}</p><button class="btn secondary small" data-keep="theirs">Keep this one</button></div></div></div>`).join('')}</div>` : ''}
    ${S.failed.length ? `<h3 class="section-title">Saves the branch PC refused</h3><div class="stack">${S.failed.map(f => `<div class="card" data-failed="${f.seq}"><div class="card-head"><h2>${esc(STORE_LABELS[f.store] || f.store)}: ${esc(f.action || 'change')}</h2></div><p class="bad-text">${esc(f.error)}</p><p class="meta">Made ${fmtStamp(f.at)} by ${esc(f.byName || '')}.</p><details><summary class="meta link">What was in it</summary><p class="pre meta">${esc(JSON.stringify({ patch: f.patch, push: f.push, pull: f.pull }, null, 1))}</p></details><div class="row end"><button class="btn danger small" data-discard>Discard</button></div></div>`).join('')}</div>` : ''}
    ${!mine.length && !S.failed.length ? empty('Nothing to settle.') : ''}`);
  wireShell();
  document.querySelectorAll('[data-conflict]').forEach(card => {
    const c = byId('conflicts', card.dataset.conflict);
    card.querySelectorAll('[data-keep]').forEach(b => b.onclick = async () => {
      try {
        if (b.dataset.keep === 'mine') { const cur = byId(c.store, c.recId); if (cur) await save(c.store, { ...cur, [c.field]: c.mine }, { action: `Kept this device's ${c.field} after a sync conflict` }); }
        await remove('conflicts', c.id);
        render();
      } catch (e) { fail(e); }
    });
  });
  document.querySelectorAll('[data-failed]').forEach(card => { card.querySelector('[data-discard]').onclick = async () => { await discardFailed(+card.dataset.failed); render(); }; });
}

// A view-only person sees every screen with its fields locked and the buttons that change
// a record taken away. The server refuses those changes as well.
const VIEW_ONLY_KEEP = /^(print|print-visit|print-seen|print-emr|copy-emr|scan|export-csv|cmp|compare|copy|tr-open)/;
function viewOnly() {
  const main = document.getElementById('main') || document.body;
  main.querySelectorAll('input:not([type="search"]), textarea, select').forEach(x => { if (x.closest('.search, [data-keep]')) return; x.disabled = true; x.removeAttribute('placeholder'); });
  main.querySelectorAll('[data-act]').forEach(x => { if (!VIEW_ONLY_KEEP.test(x.dataset.act)) x.hidden = true; });
  main.querySelectorAll('a[href$="/edit"], a[href="#/patient/new"], a[href^="#/patient/new?"], a[href^="#/chart/"], label:has(> input[type="file"]), [data-drop], [data-vt], [data-ft], [data-ph-rm], [data-ft-rm], [data-send], [data-pview], .chart-card.blank, .rm').forEach(x => { x.hidden = true; });
}

// ---------- boot ----------
async function boot() {
  if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('sw.js').catch(() => { /* the app works without it */ });
  try { hello = await api('/api/hello'); }
  catch (e) { return showUnreachable(e); }
  if (!hello.ready) return renderSetup();
  if (hello.signedIn === false) return showSignIn();
  try {
    await loadAll();
    afterSignIn();
  } catch (e) {
    if (e.status === 401) return showSignIn();
    showUnreachable(e);
  }
}

function afterSignIn() {
  startEvents();
  lastActive = Date.now();
  document.querySelectorAll('.lock').forEach(x => x.remove());
  setLang(S.me.lang || curLang());
  if (!location.hash || location.hash === '#/') location.hash = '#/today';
  render();
  resumeCheckin();
  resumePatientView();
  // Saves left waiting from an earlier session on this device go over now.
  if (S.pending && S.online) onReconnect();
}

function showUnreachable(e) {
  $app.innerHTML = `<div class="setup-hero"><img class="logo" src="assets/logo.png" alt="Apex"><h1>Patient Management System</h1></div>
    <div class="setup-body"><div class="card"><h2>The branch PC isn't answering.</h2>
      <p class="muted">Check that this tablet is on the branch wifi and that the black Apex PMS window is open on the PC. This page connects by itself once the PC answers.</p>
      <p class="meta" translate="no">${esc(location.host)} · ${esc(e.message)}</p>
      <div class="row end"><button class="btn primary" onclick="location.reload()">Try again</button></div></div></div>`;
  clearTimeout(showUnreachable.t);
  showUnreachable.t = setTimeout(async function again() {
    try { const r = await fetch('/api/hello', { cache: 'no-store' }); if (r.ok) return location.reload(); } catch (err) { /* still away */ }
    showUnreachable.t = setTimeout(again, 5000);
  }, 5000);
}

// Called by the API layer when the server says the session is gone.
function signedOut() {
  if (!S.me && document.querySelector('.lock')) return;
  stopEvents();
  S.lastUserId = S.me ? S.me.id : S.lastUserId;
  S.me = null;
  showSignIn();
}

// ---------- setup ----------
function renderSetup() {
  $app.innerHTML = `
  <div class="setup-hero"><img class="logo" src="assets/logo.png" alt="Apex"><h1>Patient Management System</h1><p class="meta">Patient records, doctors' notes, charts and photos for an Apex branch</p>
    <div class="seg light" role="group" aria-label="Screen language">${[['th', 'ไทย'], ['en', 'English']].map(([k, l]) => `<button type="button" data-pick-lang="${k}" class="${curLang() === k ? 'on' : ''}" translate="no">${l}</button>`).join('')}</div></div>
  <div class="setup-body"><form class="card" id="setup" novalidate>
    <h2>Set up this branch</h2>
    <p class="muted">This PC keeps the branch's patient records. Enter the branch details and your own as the admin. The doctors and assistants are added later, each with their own PIN.</p>
    <div class="grid2">${field('Hospital or clinic name', 'name', 'Apex Medical Center', { ph: 'Apex Medical Center' })}${field('Branch', 'branchName', '', { ph: 'Siam Square One' })}</div>
    <div class="grid3">${field('Branch code', 'branchCode', '', { ph: 'SQ', hint: '2 to 4 letters. Starts every patient number, such as SQ-00012.', attrs: 'maxlength="4" autocapitalize="characters"' })}${field('Phone', 'phone', '', { type: 'tel', ph: '02 123 4567' })}${field('Email', 'email', '', { type: 'email', ph: 'siam@apexmedicalcenter.co.th' })}</div>
    ${field('Address', 'address', '', { ph: '388 Rama I Road, Pathum Wan, Bangkok 10330' })}
    <h3 class="sub-head">You, the admin</h3>
    <div class="grid2">${field('Name in English', 'owner', '', { ph: 'Dr. Nantapat Srisuk' })}${field('Name in Thai', 'ownerTh', '', { ph: 'นพ. นันทพัทธ์ ศรีสุข' })}</div>
    <div class="grid2">${field('Medical licence number', 'licence', '', { ph: 'ว. 12345' })}${field('Also treats patients', 'clinicalRole', 'doctor', { type: 'select', options: [['doctor', 'Yes, as a doctor'], ['none', 'No']], blank: false })}</div>
    <div class="grid2">${field('PIN', 'pin', '', { type: 'password', hint: '4 to 8 digits', attrs: 'inputmode="numeric" autocomplete="new-password" maxlength="8"' })}${field('PIN again', 'pin2', '', { type: 'password', attrs: 'inputmode="numeric" autocomplete="new-password" maxlength="8"' })}</div>
    ${field('Add Apex\'s product list', 'apexProducts', true, { type: 'check', hint: 'Every injectable, device and procedure on Apex\'s procedure list, with its unit, for Materials used and the chart.' })}
    ${field('Add the starter list of treatments', 'starter', true, { type: 'check', hint: 'Consultation, Botox, fillers, skin booster, HIFU, thread lift and review. Apex\'s own list replaces it later.' })}
    <p class="form-err" data-err></p>
    <div class="row end"><button class="btn primary">Start</button></div>
  </form></div>`;
  document.querySelectorAll('[data-pick-lang]').forEach(b => b.onclick = () => { setLang(b.dataset.pickLang); renderSetup(); });
  const form = document.getElementById('setup');
  form.onsubmit = async e => {
    e.preventDefault();
    const err = m => { form.querySelector('[data-err]').textContent = tr(m); };
    if (!val(form, 'name')) return err('Enter the hospital or clinic name.');
    if (!/^[A-Za-z0-9]{2,4}$/.test(val(form, 'branchCode'))) return err('The branch code needs 2 to 4 letters or numbers.');
    if (!val(form, 'owner')) return err('Enter your name in English.');
    const pin = val(form, 'pin');
    if (!/^\d{4,8}$/.test(pin)) return err('The PIN needs 4 to 8 digits.');
    if (pin !== val(form, 'pin2')) return err('The two PINs are different.');
    try {
      await api('/api/setup', {
        clinic: { name: val(form, 'name'), branchName: val(form, 'branchName'), branchCode: val(form, 'branchCode').toUpperCase(), address: val(form, 'address'), phone: val(form, 'phone'), email: val(form, 'email'), currency: '฿', dateEra: 'be', lockMinutes: 10 },
        templates: { consent: JSON.parse(JSON.stringify(CONSENT_DEFAULTS)), aftercare: JSON.parse(JSON.stringify(AFTERCARE_DEFAULTS)) },
        owner: { name: val(form, 'owner'), nameTh: val(form, 'ownerTh'), licence: val(form, 'licence'), clinicalRole: val(form, 'clinicalRole') }, pin,
      });
      await loadAll();
      await api('/api/me/lang', { lang: curLang() });
      if (val(form, 'apexProducts')) { await api('/api/products/apex', {}); await loadAll(); }
      if (val(form, 'starter')) for (const sv of STARTER_SERVICES) await save('services', { id: uid(), ...sv, active: true }, { action: 'Treatment added' });
      afterSignIn();
    } catch (ex) { err(ex.message); }
  };
}

// ---------- sign-in and lock ----------
let lastActive = Date.now();
async function lockNow() {
  if (!S.me) return;
  S.lastUserId = S.me.id;
  try { await api('/api/logout', {}); } catch (e) { /* signed out either way */ }
  stopEvents();
  S.me = null;
  showSignIn();
}

async function showSignIn() {
  try { hello = await api('/api/hello'); } catch (e) { /* use the last list */ }
  document.querySelectorAll('.lock').forEach(x => x.remove());
  const el = document.createElement('div');
  el.className = 'lock';
  document.body.appendChild(el);
  const last = hello && hello.users.find(u => u.id === S.lastUserId);
  lockScreen(el, last || (hello && hello.users.length === 1 ? hello.users[0] : null));
}

// Doctors first, since they sign in most, then assistants, staff and the admin.
const SIGN_IN_GROUPS = [['doctor', 'Doctors'], ['nurse', 'Assistants'], ['staff', 'Staff'], ['owner', 'Admin']];
function whoListHTML(users) {
  const btn = u => `<button data-u="${u.id}"><span class="avatar">${u.photo ? `<img src="${fileURL(u.photo)}" alt="">` : esc(initials(u.name))}</span><span>${esc(u.name)}<small>${esc(u.title || (ROLES[u.role] || {}).label || '')}</small></span></button>`;
  return SIGN_IN_GROUPS.map(([r, label]) => { const list = users.filter(u => u.role === r).sort((a, b) => a.name.localeCompare(b.name)); return list.length ? `<h2 class="who-head">${esc(label)}</h2><div class="who-list">${list.map(btn).join('')}</div>` : ''; }).join('');
}

// The clinic PC is for the admin and the staff. Doctors and assistants sign in on their tablets.
const PC_ROLES = ['owner', 'staff'];
function lockScreen(el, who) {
  const pc = typeof onClinicPC === 'function' && onClinicPC();
  const users = ((hello && hello.users) || []).filter(u => !pc || PC_ROLES.includes(u.role));
  if (who && pc && !PC_ROLES.includes(who.role)) who = null;
  const clinicName = (hello && hello.clinic && hello.clinic.name) || '';
  if (!who) {
    el.innerHTML = `<div class="box wide"><img class="logo" src="assets/logo.png" alt="Apex"><h1>${esc(clinicName)}</h1>${hello && hello.clinic && hello.clinic.branchName ? `<p class="meta">${esc(hello.clinic.branchName)}</p>` : ''}<p class="sub">Who is signing in?</p>
      ${whoListHTML(users)}${pc ? `<p class="meta">Doctors and assistants sign in on their tablets.</p>` : ''}
      <div class="seg" role="group" aria-label="Screen language">${[['th', 'ไทย'], ['en', 'English']].map(([k, l]) => `<button type="button" data-pick-lang="${k}" class="${curLang() === k ? 'on' : ''}" translate="no">${l}</button>`).join('')}</div></div>`;
    el.querySelectorAll('[data-u]').forEach(b => b.onclick = () => lockScreen(el, users.find(u => u.id === b.dataset.u)));
    el.querySelectorAll('[data-pick-lang]').forEach(b => b.onclick = () => { setLang(b.dataset.pickLang); lockScreen(el, null); });
    return;
  }
  pinPad(el, who, {
    title: 'Enter your PIN',
    onPin: async pin => {
      await api('/api/login', { userId: who.id, pin });
      const same = S.lastUserId === who.id && S.users.length;
      await loadAll();
      el.remove();
      if (same) { startEvents(); lastActive = Date.now(); if (!document.getElementById('editor')) render(); resumeCheckin(); resumePatientView(); }
      else afterSignIn();
    },
    back: users.length > 1 ? () => lockScreen(el, null) : null,
  });
}

// A PIN pad that calls onPin(pin) and shows the server's error when it throws.
function pinPad(el, who, { title, onPin, back, extra = '', onExtra, sub = '' }) {
  let pin = '', busy = false;
  el.innerHTML = `<div class="box"><span class="avatar xl">${who.photo ? `<img src="${fileURL(who.photo)}" alt="">` : esc(initials(who.name))}</span><h1>${esc(who.name)}</h1><p class="sub">${esc(title)}</p>${sub}
    <div class="dots"></div><div class="err" data-err></div>
    <div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 'Clear', 0, 'OK'].map(k => `<button data-k="${k}" ${typeof k === 'string' ? 'class="word"' : ''}>${k}</button>`).join('')}</div>
    ${back ? '<button class="ghost" data-back>Someone else</button>' : ''}${extra}</div>`;
  const dots = () => { const n = Math.max(4, who.pinLen || 4, pin.length); el.querySelector('.dots').innerHTML = Array.from({ length: n }, (_, i) => `<i class="${i < pin.length ? 'on' : ''}"></i>`).join(''); };
  const tryPin = async () => {
    if (pin.length < 4 || busy) return;
    busy = true;
    try { await onPin(pin); }
    catch (e) { pin = ''; dots(); const er = el.querySelector('[data-err]'); if (er) er.textContent = tr(e.message); }
    finally { busy = false; }
  };
  const press = k => {
    const er = el.querySelector('[data-err]'); if (er) er.textContent = '';
    if (k === 'Clear') pin = '';
    else if (k === 'OK') return tryPin();
    else if (pin.length < 8) pin += k;
    dots();
    if (pin.length >= 4 && pin.length === (who.pinLen || 0)) tryPin();
  };
  dots();
  el.querySelectorAll('[data-k]').forEach(b => b.onclick = () => press(b.dataset.k));
  const bk = el.querySelector('[data-back]'); if (bk) bk.onclick = back;
  const ex = el.querySelector('[data-kiosk]'); if (ex && onExtra) ex.onclick = onExtra;
  el.tabIndex = -1; el.focus();
  el.onkeydown = e => { if (/^\d$/.test(e.key)) press(e.key); else if (e.key === 'Enter') tryPin(); else if (e.key === 'Backspace') { pin = pin.slice(0, -1); dots(); } };
}


['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, () => { lastActive = Date.now(); }, { passive: true }));
setInterval(() => {
  if (!S.me || !S.clinic) return;
  const mins = num(S.me.lockMinutes || S.clinic.lockMinutes);
  if (mins > 0 && Date.now() - lastActive > mins * 60000) lockNow();
}, 15000);

boot();
