// Screen language. Every screen is written in English, and this file turns what shows into
// Thai (staff and patient screens) or Chinese (patient screens only) as it lands on the
// page, so the rest of the code keeps one set of words.
//
// - Staff pick Thai or English, per person. The choice is kept on their record and on the device.
// - A part of the page can carry data-ui-lang="zh" (or th, en) to show in the patient's
//   language, such as check-in, consent and the patient view.
// - Patient names, notes and anything typed in stay as typed: only exact matches of the
//   screen's own words are changed, and translate="no" or class="pre" keeps a part as it is.
// - Stored values stay in English, so a record reads the same on every device.

const LANG_KEY = 'apex_lang';
let LANG = (() => { try { return localStorage.getItem(LANG_KEY) || 'th'; } catch (e) { return 'th'; } })();
function curLang() { return LANG; }
function setLang(l) {
  if (!['th', 'en'].includes(l)) l = 'th';
  LANG = l;
  try { localStorage.setItem(LANG_KEY, l); } catch (e) { /* this page only */ }
  document.documentElement.lang = l;
  document.documentElement.dataset.lang = l;
  retranslate(document.body);
}

// I18N[lang] maps the English words to the translation. I18N_RULES[lang] holds patterns
// for words with a number or a name inside them. Both are filled in by i18n-th.js and i18n-zh.js.
const I18N = { th: {}, zh: {} };
const I18N_RULES = { th: [], zh: [] };
const I18N_MISSING = { th: new Set(), zh: new Set() };

// Words with a number or name inside them, written as 'Visit {1} not signed'. Turns them into
// a rule: each {n} matches any text, and the translation puts each piece back by its number.
function addRules(lang, pairs) {
  for (const [en, to] of pairs) {
    const parts = en.split(/(\{\d+\})/);
    const order = [];
    const src = parts.map(p => { const m = p.match(/^\{(\d+)\}$/); if (m) { order.push(+m[1]); return '(.+?)'; } return p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('');
    I18N_RULES[lang].push({ re: new RegExp('^' + src + '$', 's'), order, to });
  }
}

// One string in one language. Inner pieces of a rule are translated too, so "Consent missing:
// Clinical photographs" turns both halves.
function tr(s, lang = LANG) {
  if (s === null || s === undefined) return s;
  s = String(s);
  if (lang === 'en' || !I18N[lang]) return s;
  const core = s.trim();
  if (!core || !/[A-Za-z]/.test(core)) return s;
  const hit = trCore(core, lang, 0);
  if (hit === null) { if (I18N_MISSING[lang].size < 5000) I18N_MISSING[lang].add(core); return s; }
  return s.replace(core, hit);
}
function trCore(core, lang, depth) {
  const d = I18N[lang];
  if (Object.prototype.hasOwnProperty.call(d, core)) return d[core];
  // A sentence that ends in a full stop is often in the list without it, and the other way round.
  if (core.endsWith('.') && Object.prototype.hasOwnProperty.call(d, core.slice(0, -1))) return d[core.slice(0, -1)];
  if (depth > 4) return null;
  // Values joined with " · " are turned one by one, before any pattern can swallow a piece.
  if (core.includes(' · ')) {
    const parts = core.split(' · '), out = parts.map(p => (/[A-Za-z]/.test(p) ? trCore(p.trim(), lang, depth + 1) : null));
    return out.some(x => x !== null) ? parts.map((p, i) => (out[i] === null ? p : out[i])).join(' · ') : null;
  }
  for (const r of I18N_RULES[lang]) {
    const m = core.match(r.re);
    if (!m) continue;
    // A value the pattern leaves in English is a name, a number or a product: a few words at
    // most. A longer piece means the pattern caught a sentence it was not written for.
    const pieces = r.order.map((_, i) => { const piece = m[i + 1] || ''; const t = /[A-Za-z]/.test(piece) ? trCore(piece.trim(), lang, depth + 1) : null; return { piece, t }; });
    if (pieces.some(x => x.t === null && /[A-Za-z]/.test(x.piece) && x.piece.trim().split(/\s+/).length > 4)) continue;
    return r.to.replace(/\{(\d+)\}/g, (_, n) => { const x = pieces[r.order.indexOf(+n)] || { piece: '' }; return x.t === null || x.t === undefined ? x.piece : x.t; });
  }
  return null;
}

// The language a node shows in: the nearest data-ui-lang above it, else the person's own.
function langOf(node) {
  const el = node.nodeType === 1 ? node : node.parentElement;
  const box = el && el.closest ? el.closest('[data-ui-lang]') : null;
  return box ? box.dataset.uiLang : LANG;
}
const SKIP = 'script,style,textarea,code,[translate="no"],.pre,[contenteditable="true"]';
const ATTRS = ['placeholder', 'title', 'aria-label'];
function skipped(el) { return !el || (el.closest && el.closest(SKIP)); }

// Each text node and attribute remembers its English words, so switching back and forth works.
function trText(node) {
  const el = node.parentElement;
  if (skipped(el)) return;
  if (node.__en === undefined || (node.__tr !== undefined && node.nodeValue !== node.__tr)) node.__en = node.nodeValue;
  const out = tr(node.__en, langOf(node));
  node.__tr = out;
  if (node.nodeValue !== out) node.nodeValue = out;
}
function trAttrs(el) {
  if (skipped(el)) return;
  const lang = langOf(el);
  el.__en = el.__en || {};
  for (const a of ATTRS) {
    if (!el.hasAttribute(a)) continue;
    const v = el.getAttribute(a);
    if (el.__en[a] === undefined || (el.__tr && el.__tr[a] !== v)) el.__en[a] = v;
    const out = tr(el.__en[a], lang);
    el.__tr = el.__tr || {};
    el.__tr[a] = out;
    if (v !== out) el.setAttribute(a, out);
  }
  // Buttons drawn as <input type="submit" value="...">.
  if (el.tagName === 'INPUT' && (el.type === 'submit' || el.type === 'button') && el.value) {
    if (el.__en.value === undefined || (el.__tr && el.__tr.value !== el.value)) el.__en.value = el.value;
    const out = tr(el.__en.value, lang); el.__tr.value = out; if (el.value !== out) el.value = out;
  }
}
function retranslate(root) {
  if (!root) return;
  if (root.nodeType === 3) return trText(root);
  if (root.nodeType !== 1) return;
  if (skipped(root)) return;
  trAttrs(root);
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode: n => (n.nodeType === 1 && n.matches(SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
  let n;
  while ((n = w.nextNode())) { if (n.nodeType === 3) trText(n); else trAttrs(n); }
}

// Everything that lands on the page is translated as it arrives.
const i18nObserver = new MutationObserver(list => {
  for (const m of list) {
    if (m.type === 'childList') m.addedNodes.forEach(retranslate);
    else if (m.type === 'characterData') { const n = m.target; if (n.nodeValue !== n.__tr) trText(n); }
    else if (m.type === 'attributes') { const el = m.target; if (m.attributeName === 'data-ui-lang') retranslate(el); else if (!el.__tr || el.getAttribute(m.attributeName) !== el.__tr[m.attributeName]) trAttrs(el); }
  }
});
function startI18n() {
  document.documentElement.lang = LANG;
  document.documentElement.dataset.lang = LANG;
  i18nObserver.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: [...ATTRS, 'data-ui-lang'] });
  retranslate(document.body);
}
// The browser's own dialogs and the print window go through tr() directly.
if (typeof document !== 'undefined' && document.body) startI18n();
else if (typeof document !== 'undefined') document.addEventListener('DOMContentLoaded', startI18n);

if (typeof module !== 'undefined') module.exports = { tr, addRules, I18N, I18N_RULES };
