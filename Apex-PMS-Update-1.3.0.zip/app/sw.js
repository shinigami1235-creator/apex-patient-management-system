// Keeps the app's own files on the tablet, so the home screen icon opens straight away and
// shows the sign-in or the "can't reach the branch PC" message instead of a browser error.
// The app's files come from the PC first whenever it answers, so an update shows on the next
// open. Patient data, photos and the live updates always go to the PC and are never kept here.
const CACHE = 'apex-pms-shell';

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    try {
      const html = await (await fetch('./', { cache: 'no-store' })).text();
      const files = ['./', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'assets/logo.png', 'assets/logo-white.png', 'assets/apex-mark.png', 'fonts/LINESeedSansTH-Rg.woff2', 'fonts/LINESeedSansTH-Bd.woff2',
        ...[...html.matchAll(/(?:src|href)="([^"#:]+\.(?:js|css|webmanifest|png))"/g)].map(m => m[1])];
      await c.addAll([...new Set(files)]);
    } catch (err) { /* the PC answers next time */ }
    self.skipWaiting();
  })());
});
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

const PASS = /^\/(api|files|ca\.|tablet\.html|camera\/|collage\/|features\/|vendor\/)/;
self.addEventListener('fetch', e => {
  const r = e.request, url = new URL(r.url);
  if (r.method !== 'GET' || url.origin !== location.origin || PASS.test(url.pathname)) return;
  e.respondWith((async () => {
    try {
      const res = await fetch(r);
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(r.mode === 'navigate' ? './' : r, copy)); }
      return res;
    } catch (err) {
      const hit = await caches.match(r.mode === 'navigate' ? './' : r, { ignoreSearch: true });
      if (hit) return hit;
      throw err;
    }
  })());
});
