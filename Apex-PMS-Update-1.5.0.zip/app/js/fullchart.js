// Full chart: one visit on one screen. The notes sit on the left and the treatment chart
// on the right, docked so it can be drawn on in place or taken full screen. Laid out after
// the split charting screens of injector systems: notes in four parts, what went in per
// site with its lot, the patient's warnings in view, and last visit one glance away.

const FC_SPLIT_KEY = 'cc_chart_split';
const FC_NOTE_KEYS = ['complaint', 'findings', 'assessment', 'plan', 'followUp', 'followReason'];
let FC = null;

function fcSplit() {
  try { const n = +localStorage.getItem(FC_SPLIT_KEY); return n >= 28 && n <= 72 ? n : 44; } catch (e) { return 44; }
}
// The chart sits on the left by default, the notes on the right. Each device remembers a swap.
const FC_SIDE_KEY = 'apex_chart_side';
function fcPicLeft() { try { return localStorage.getItem(FC_SIDE_KEY) !== 'right'; } catch (e) { return true; } }
function fcSetSplit(n) { try { localStorage.setItem(FC_SPLIT_KEY, String(Math.round(n))); } catch (e) { /* not kept */ } }

// The visit before this one, for the Last visit card.
function fcPrevVisit(v) {
  return visitsOf(v.patientId).find(x => x.id !== v.id && (x.date + (x.time || '')) < (v.date + (v.time || '')));
}
// The view a chart opens on: the one asked for, else the first with marks, else Front.
function fcStartView(v, want) {
  if (want && CHART_VIEWS.some(x => x.key === want)) return want;
  const c = CHART_VIEWS.find(cv => S.charts.some(x => x.visitId === v.id && x.view === cv.key && (x.marks || []).length));
  return c ? c.key : CHART_VIEWS[0].key;
}

function renderFullChart(id, want) {
  const v = visit(id);
  if (!v) return go('#/patients');
  if (!can('clinical')) return go('#/visit/' + id);
  const p = patient(v.patientId) || { name: 'Unknown patient', id: v.patientId };
  const locked = !!v.signedAt;
  const doc = byId('users', v.doctorId);
  const facts = [p.no, p.dob ? `${ageOf(p.dob)} years` : '', p.sex, p.skin ? `Fitzpatrick ${p.skin}` : ''].filter(Boolean);
  const head = `
    <a class="crumb" href="#/visit/${v.id}">${I.back}Visit page</a>
    <div class="fc-head">
      ${avatar(p, 'lg')}
      <div class="grow"><h1>${esc(p.name)}</h1>
        <div class="meta sub">${esc(facts.join(' · '))}</div>
        <div class="meta">${esc(v.type || 'Visit')} · ${fmtDate(v.date)}${v.time ? ' ' + fmtTime(v.time) : ''}${doc ? ' · ' + esc(doc.name) : ''}${v.no ? ' · ' + esc(v.no) : ''} · ${locked ? `signed by ${esc(userName(v.signedBy))}` : 'open'}</div></div>
      <div class="row wrap-end">${showPatientButtonHTML(p.id, v.id)}${sendButtonHTML('#/chart/' + v.id, p.name + '\'s chart')}<button class="btn secondary" data-fc="swap" title="Put the chart on the other side">Swap sides</button><button class="btn secondary" data-fc="print">${I.print}Print summary</button>
        ${can('sign') ? (locked ? '<button class="btn secondary" data-fc="reopen">Reopen</button>' : '<button class="btn primary" data-fc="sign">Sign visit</button>') : ''}</div>
    </div>
    ${alertChips(p)}
    ${locked ? `<div class="banner info"><span>This visit is signed, so the notes and chart are view only.</span>${can('sign') ? ' <span>Press Reopen to change them.</span>' : ''}</div>` : ''}`;

  const body = `<div class="fc ${fcPicLeft() ? 'pic-left' : ''}" id="fc" style="--fc-doc:${fcSplit()}%">
    <div class="fc-doc">
      ${head}
      ${fcNotesCard(v, locked)}
      ${fcAreasCard(v, p)}
      <div class="card" id="fctreat">${fcTreatHTML(v)}</div>
      ${fcMedicalCard(p)}
      ${fcLastCard(v)}
    </div>
    <div class="fc-gutter" role="separator" aria-orientation="vertical" aria-label="Notes and chart divider. Drag, or use the arrow keys." tabindex="0" aria-valuemin="28" aria-valuemax="72" aria-valuenow="${fcSplit()}"><span class="grip"></span></div>
    <section class="fc-pic" id="fcpic" aria-label="Chart">
      <div class="fc-dock" id="chartdock"><div class="fc-wait"><span class="spin"></span>Opening the chart</div></div>
      ${fcStripHTML(v, p, locked)}
    </section>
  </div>`;

  $app.innerHTML = shell('patients', body, { wide: true });
  wireShell();
  FC = { visitId: v.id, timer: null, saving: false };
  wireFullChart(v, p);
  markSeen(p.id, 'chart');
  openChart(v.id, fcStartView(v, want), { dock: document.getElementById('chartdock') })
    .then(() => { fcStripMark(); if (want === HEAD_CHART.key) return openChart(v.id, HEAD_CHART.key); }).catch(fail);
}

// ---------- notes ----------
function fcNotesCard(v, locked) {
  const ro = locked ? 'readonly' : '';
  const box = (k, letter, label, ph) => `<label class="field fc-note"><span class="label"><span class="soap" aria-hidden="true">${letter}</span>${label}</span>
    <textarea name="${k}" rows="3" placeholder="${esc(ph)}" ${ro}>${esc(v[k] || '')}</textarea></label>`;
  return `<form class="card" id="notes" autocomplete="off"><div class="card-head"><h2>Notes</h2><div class="row">${!locked && typeof dictateButtonHTML === 'function' ? dictateButtonHTML() : ''}<span class="meta fc-state" id="fcnotes" role="status">${locked ? 'View only' : 'Saves as you type'}</span></div></div>
    ${box('complaint', 'S', 'Complaint', 'Wants softer frown lines before a wedding on 20 Nov.')}
    ${box('findings', 'O', 'Findings', 'Dynamic glabellar lines, grade 3 at maximum frown. Mild static forehead lines.')}
    ${box('assessment', 'A', 'Assessment', 'Glabellar and forehead dynamic lines.')}
    ${box('plan', 'P', 'Plan', 'Botulinum toxin to glabella and forehead. Review in 2 weeks.')}
    ${locked ? customKV(customPairs('visits', v.custom, 'notes')) : customFieldsHTML('visits', v.custom, 'notes')}
    <div class="grid2 fc-follow">
      <div class="field"><span class="label">Follow-up</span><input type="date" name="followUp" value="${esc(v.followUp || '')}" ${ro}>${locked ? '' : '<span class="hint"><a href="#" data-in="14">2 weeks</a> · <a href="#" data-in="28">4 weeks</a> · <a href="#" data-in="91">3 months</a></span>'}</div>
      ${field('Reason', 'followReason', v.followReason, { ph: 'Toxin review and top-up', attrs: ro })}
    </div></form>`;
}

function fcReadNotes(form) {
  const out = {};
  for (const k of FC_NOTE_KEYS) { const el = form.querySelector(`[name=${k}]`); if (el) out[k] = el.value.trim(); }
  return out;
}
async function fcSaveNotes() {
  const form = document.getElementById('notes');
  if (!form || !FC || FC.saving) return;
  const v = visit(FC.visitId);
  if (!v || v.signedAt) return;
  const vals = fcReadNotes(form);
  const custom = readCustomFields(form, 'visits', v.custom);
  const changed = FC_NOTE_KEYS.some(k => (v[k] || '') !== vals[k]) || JSON.stringify(custom) !== JSON.stringify(v.custom || {});
  const state = document.getElementById('fcnotes');
  if (!changed) { delete form.dataset.dirty; if (state) state.textContent = 'Saved'; return; }
  FC.saving = true;
  if (state) state.textContent = 'Saving';
  try {
    await save('visits', { ...v, ...vals, custom }, { action: 'Notes saved' });
    if (state) state.textContent = 'Saved';
    // typing during the save leaves the form dirty for the next round
    if (JSON.stringify(fcReadNotes(form)) === JSON.stringify(vals)) delete form.dataset.dirty;
  } catch (e) { if (state) state.textContent = 'Not saved'; fail(e); }
  finally { if (FC) FC.saving = false; }
}

// ---------- areas ----------
// The face and the body areas in use, folding open, each with its charts and notes. A chart
// tapped here opens in the chart panel.
function fcAreasCard(v, p) {
  return `<div class="card" id="fcareas"><div class="card-head"><h2>Areas</h2></div>${areasHTML(v, p)}</div>`;
}
function fcRepaintAreas(visitId) {
  const box = document.getElementById('fcareas');
  if (!box || !FC || FC.visitId !== visitId) return;
  const v = visit(visitId);
  box.outerHTML = fcAreasCard(v, patient(v.patientId));
  fcWireAreas(v);
}
function fcWireAreas(v) {
  const box = document.getElementById('fcareas');
  if (!box) return;
  wireAreas(box, v.id, {
    repaint: () => fcRepaintAreas(v.id),
    onOpen: async key => {
      if (E && E.chart && E.chart.view === key && E.kind !== 'head') return;
      const blocked = chartViewBlocked(v.id, key);
      if (blocked) return toast(blocked);
      if (E && E.dirty && !E.readOnly) await edSave(E);
      const max = !!(E && E.max);
      edClose();
      await openChart(v.id, key, { dock: document.getElementById('chartdock'), max }).catch(fail);
      fcStripMark();
      const pic = document.getElementById('fcpic');
      if (pic && window.matchMedia('(max-width: 900px)').matches) pic.scrollIntoView({ block: 'start', behavior: 'smooth' });
    },
  });
}

// ---------- treatment ----------
function fcTreatHTML(v) {
  const lines = (v.treatments || []).filter(t => t.source !== 'supply');
  const svc = (v.services || []).map(s => (service(s.serviceId) || {}).name || s.name).filter(Boolean);
  const total = linesFromMarks(chartsOfVisit(v.id).flatMap(c => c.marks || []));
  const points = chartsOfVisit(v.id).reduce((n, c) => n + (c.marks || []).filter(m => m.t === 'toxin').length, 0);
  return `<div class="card-head"><h2>Treatment on this visit</h2><a class="btn quiet small" href="#/visit/${v.id}">Edit on the visit page</a></div>
    ${svc.length ? `<div class="chips" style="margin-bottom:10px">${svc.map(n => chip(n, 'info')).join('')}</div>` : ''}
    ${lines.length ? `<div class="scroll-x"><table class="t"><tr><th>Product</th><th>Lot</th><th class="n">Amount</th><th>Area</th></tr>
      ${lines.map(t => `<tr><td><b>${esc(t.product || (KINDS[t.kind] || {}).label || '')}</b>${t.source === 'med' ? ' <span class="chip tiny info">Medicine</span>' : ''}</td><td>${esc(t.lot || '')}</td><td class="n">${trimNum(t.amount)} ${esc(t.unit)}</td><td>${esc(t.area || '')}</td></tr>`).join('')}</table></div>
      ${total.length ? `<p class="meta" style="margin-top:8px">From the chart: ${points ? plural(points, 'injection point') + ', ' : ''}${esc(total.map(l => `${l.product || KINDS[l.kind].label} ${trimNum(l.amount)} ${l.unit}`).join(', '))}.</p>` : ''}`
      : '<p class="muted">Nothing yet. Marks on the chart fill this in, with the lot each one came from.</p>'}`;
}
// Called by the chart after each save, so the lines here keep up with the drawing.
function fcAfterChartSave(visitId) {
  const box = document.getElementById('fctreat');
  if (!box || !FC || FC.visitId !== visitId) return;
  box.innerHTML = fcTreatHTML(visit(visitId));
  fcRepaintAreas(visitId);
}

// ---------- patient ----------
function fcMedicalCard(p) {
  const meds = (p.meds || []).map(m => `<b>${esc(m.name)}</b> ${esc(m.dose || '')}${m.freq ? ', ' + esc(m.freq) : ''}`);
  const cond = (p.conditions || []).map(c => `${esc(c.name)}${c.year ? ` <span class="meta">since ${esc(c.year)}</span>` : ''}`);
  const past = (p.surgeries || []).map(s => `${esc(s.what)}${s.year ? ' · ' + esc(s.year) : ''}`);
  const allergy = (p.allergies || []).map(a => `<b>${esc(a.what)}</b>${a.reaction ? ', ' + esc(a.reaction) : ''}${a.severity ? ` <span class="meta">${esc(a.severity.toLowerCase())}</span>` : ''}`);
  const row = (label, items, none) => `<div><dt>${label}</dt><dd>${items.length ? items.join('<br>') : `<span class="muted">${none}</span>`}</dd></div>`;
  return `<details class="card fc-med" open><summary class="link-summary"><b>Medical history</b><a class="meta" href="#/patient/${p.id}/record" style="margin-left:auto">Full record</a></summary>
    <dl class="kv" style="margin-top:10px">
      ${row('Allergies', allergy, p.nka ? 'None known' : 'Not recorded')}
      ${row('Medicines', meds, 'None recorded')}
      ${row('Conditions', cond, 'None recorded')}
      ${row('Past treatments', past, 'None recorded')}
    </dl></details>`;
}

function fcLastCard(v) {
  const pv = fcPrevVisit(v);
  if (!pv) return `<div class="card"><div class="card-head"><h2>Last visit</h2></div><p class="muted">This is the patient's first visit.</p></div>`;
  const charts = CHART_VIEWS.map(cv => S.charts.find(c => c.visitId === pv.id && c.view === cv.key && (c.marks || []).length)).filter(Boolean);
  const lines = (pv.treatments || []).filter(t => t.source !== 'supply');
  const doc = byId('users', pv.doctorId);
  const text = (label, s) => s ? `<div><dt>${label}</dt><dd class="pre">${esc(s)}</dd></div>` : '';
  return `<div class="card fc-last"><div class="card-head"><h2>Last visit</h2><a class="btn quiet small" href="#/chart/${pv.id}">Open its chart</a></div>
    <p class="meta">${fmtDate(pv.date)} · ${esc(pv.type || 'Visit')}${doc ? ' · ' + esc(doc.name) : ''} · ${plural(daysBetween(pv.date, v.date), 'day')} before this one</p>
    ${lines.length ? `<p><b>${esc(lines.map(t => `${matText(t, t.product || '')}${t.area ? ' ' + t.area : ''}`).join(', '))}</b></p>` : ''}
    <dl class="kv one">${text('Assessment', pv.assessment)}${text('Plan', pv.plan)}</dl>
    ${charts.length ? `<div class="fc-last-charts">${charts.map(c => `<button type="button" class="chart-card" data-fc-compare="${c.view}" title="Open today's ${esc(CHART_VIEWS.find(x => x.key === c.view).label)} chart full screen with this one beside it">${chartSVG(c, chartThumbURL(c), 'preserveAspectRatio="xMidYMid meet"')}<div class="cap"><b>${esc(CHART_VIEWS.find(x => x.key === c.view).label)}</b><span class="meta">Compare full screen</span></div></button>`).join('')}</div>` : ''}
  </div>`;
}

// ---------- photo strip ----------
function fcStripHTML(v, p, locked) {
  if (p.photoConsent === 'no') return '<p class="meta fc-strip-note">The patient declined photos. The charts use the drawings.</p>';
  const mine = S.photos.filter(x => x.visitId === v.id).sort((a, b) => (a.created || 0) - (b.created || 0));
  const older = photosOf(p.id).filter(x => x.visitId !== v.id && photoVisitDate(x) <= v.date).sort((a, b) => photoVisitDate(b).localeCompare(photoVisitDate(a))).slice(0, Math.max(0, 12 - mine.length));
  const list = [...mine, ...older];
  const tile = ph => `<div class="tile" data-fc-tile="${ph.id}">
      <button type="button" class="pick" data-fc-photo="${ph.id}" ${locked ? 'disabled' : ''} title="${locked ? '' : 'Draw on this photo'}"><img loading="lazy" src="${thumbURL(ph.id)}" alt="${esc(ph.view || 'Photo')}"><span class="cap">${ph.visitId === v.id ? esc(ph.stage || ph.view || '') : fmtDay(photoVisitDate(ph))}</span></button>
      <button type="button" class="zoom" data-fc-zoom="${ph.id}" aria-label="Show this photo full size">${ICON_MAX}</button></div>`;
  return `<div class="fc-strip-head"><span class="meta">${locked ? 'Photos' : 'Tap a photo to draw on it'}</span>${list.length ? '' : `<a class="meta" href="#/visit/${v.id}">Add photos on the visit page</a>`}</div>
    <div class="fc-strip" role="list">
      ${locked ? '' : `<div class="tile face"><button type="button" class="pick" data-fc-photo="" title="Draw on the drawing">${faceThumbSVG()}<span class="cap">Drawing</span></button></div>`}
      ${list.map(tile).join('')}
    </div>`;
}
// The drawing of the open chart's view, or the front of the face before one opens.
function faceThumbSVG(view = (E && E.chart && E.chart.view) || 'front') {
  return `<svg viewBox="0 0 ${FACE_W} ${FACE_H}" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><rect width="${FACE_W}" height="${FACE_H}" fill="#fff"/>${chartArt(view)}</svg>`;
}
// Marks the strip tile the chart is drawn on.
function fcStripMark() {
  const base = E && E.chart && E.chart.base;
  const tile = document.querySelector('.fc-strip .tile.face .pick');
  if (tile && E && E.chart && tile.dataset.view !== E.chart.view) { tile.dataset.view = E.chart.view; tile.querySelector('svg').outerHTML = faceThumbSVG(E.chart.view); }
  document.querySelectorAll('.fc-strip .tile').forEach(t => {
    const id = t.dataset.fcTile || '';
    const on = base && (base.type === 'photo' ? base.photoId === id && id : t.classList.contains('face') && base.type === 'drawing');
    t.classList.toggle('on', !!on);
  });
}

// ---------- wiring ----------
function wireFullChart(v, p) {
  const cur = () => visit(v.id);
  const form = document.getElementById('notes');
  if (form && !cur().signedAt && can('edit')) phrasesWire(form, v);
  const later = debounce(() => fcSaveNotes(), 1500);
  if (form && !cur().signedAt) {
    form.addEventListener('input', () => { form.dataset.dirty = '1'; const s = document.getElementById('fcnotes'); if (s) s.textContent = 'Typing'; later(); });
    form.addEventListener('change', () => fcSaveNotes());
    // voice commands for the notes submit the form
    form.onsubmit = e => { e.preventDefault(); fcSaveNotes(); };
    form.querySelectorAll('[data-in]').forEach(a => a.onclick = e => { e.preventDefault(); form.querySelector('[name=followUp]').value = addDays(cur().date, +a.dataset.in); fcSaveNotes(); });
  } else if (form) form.onsubmit = e => e.preventDefault();
  // the page saves what is left when it closes
  leavePage = () => { if (form && form.dataset.dirty) fcSaveNotes(); FC = null; };

  const on = (sel, fn) => document.querySelectorAll(sel).forEach(b => b.onclick = e => { e.preventDefault(); fn(b); });
  on('[data-fc="print"]', () => printVisit(cur()));
  on('[data-fc="sign"]', async () => { await fcSaveNotes(); if (E && E.docked && E.dirty) await edSave(E); signVisitFlow(v.id); });
  on('[data-fc="reopen"]', () => reopenVisitFlow(v.id));
  on('[data-fc-photo]', async b => {
    if (!E || E.kind === 'head' || E.readOnly) return;
    const id = b.dataset.fcPhoto;
    if (id) await edAction('photo', { dataset: { id } }); else await edAction('drawing');
    E.changedAt = (E.changedAt || 0) + 1;
    fcStripMark();
  });
  const ids = [...document.querySelectorAll('[data-fc-zoom]')].map(b => b.dataset.fcZoom);
  on('[data-fc-zoom]', b => photoViewer(ids, b.dataset.fcZoom));
  on('[data-fc-compare]', async b => {
    if (!E) return;
    const view = b.dataset.fcCompare;
    if (E.chart && E.chart.view === view && E.kind !== 'head') { E.showPrev = true; edSetMax(true); return; }
    if (E.dirty && !E.readOnly) await edSave(E);
    edClose();
    await openChart(v.id, view, { dock: document.getElementById('chartdock'), max: true });
  });
  fcWireAreas(v);
  fcWireGutter();
  const sw = document.querySelector('[data-fc="swap"]');
  if (sw) sw.onclick = () => {
    const fc = document.getElementById('fc');
    fc.classList.toggle('pic-left');
    try { localStorage.setItem(FC_SIDE_KEY, fc.classList.contains('pic-left') ? 'left' : 'right'); } catch (e) { /* this time only */ }
    if (E && E.docked && !E.kind) edSize();
  };
}

function fcWireGutter() {
  const fc = document.getElementById('fc'), g = fc && fc.querySelector('.fc-gutter');
  if (!g) return;
  const set = n => {
    n = Math.min(72, Math.max(28, n));
    fc.style.setProperty('--fc-doc', n + '%');
    g.setAttribute('aria-valuenow', Math.round(n));
    return n;
  };
  const refit = () => { if (E && E.docked && !E.kind) edSize(); };
  g.addEventListener('pointerdown', e => {
    e.preventDefault();
    g.setPointerCapture(e.pointerId);
    g.classList.add('drag');
    const r = fc.getBoundingClientRect();
    let n = fcSplit();
    const left = fc.classList.contains('pic-left');
    const move = ev => { n = set(((left ? r.right - ev.clientX : ev.clientX - r.left) / r.width) * 100); refit(); };
    const up = () => { g.classList.remove('drag'); g.removeEventListener('pointermove', move); g.removeEventListener('pointerup', up); g.removeEventListener('pointercancel', up); fcSetSplit(n); refit(); };
    g.addEventListener('pointermove', move);
    g.addEventListener('pointerup', up);
    g.addEventListener('pointercancel', up);
  });
  g.addEventListener('keydown', e => {
    const flip = fc.classList.contains('pic-left') ? -1 : 1;
    const step = (e.key === 'ArrowLeft' ? -4 : e.key === 'ArrowRight' ? 4 : 0) * flip;
    if (!step) return;
    e.preventDefault();
    fcSetSplit(set(+g.getAttribute('aria-valuenow') + step));
    refit();
  });
  g.addEventListener('dblclick', () => { fcSetSplit(set(44)); refit(); });
}
