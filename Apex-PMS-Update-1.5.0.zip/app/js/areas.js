// The areas of a visit's chart, each folding open on its own with its views and a notes box.
// Lean view, the default, shows the face and the areas the visit uses: a chart, a photo or notes,
// or an area someone added. Inside an area it shows the main view and the views in use, so the
// 45s and the sides of the face stay out of the way until they are charted. Full view shows every
// area and every view, with the empty areas folded. Each device remembers which view it was left on.

const AREAS_FULL_KEY = 'apex_areas_full';
function areasFull() { try { return localStorage.getItem(AREAS_FULL_KEY) === '1'; } catch (e) { return false; } }
function setAreasFull(on) { try { localStorage.setItem(AREAS_FULL_KEY, on ? '1' : ''); } catch (e) { /* this screen only */ } }

const viewDef = key => CHART_VIEWS.find(cv => cv.key === key);
const viewsOfGroup = g => CHART_VIEWS.filter(cv => cv.group === g);
const groupOfView = key => (viewDef(key) || {}).group || 'face';
const groupDef = g => CHART_GROUPS.find(x => x.key === g);

// A view is in use on a visit when it has a chart or a photo of that view was taken on the visit.
function viewInUse(v, key) {
  const cv = viewDef(key);
  return S.charts.some(c => c.visitId === v.id && c.view === key) || (!!cv && S.photos.some(ph => ph.visitId === v.id && ph.view === cv.photo));
}
function groupInUse(v, g) {
  return viewsOfGroup(g).some(cv => viewInUse(v, cv.key)) || !!String((v.areaNotes || {})[g] || '').trim();
}
function groupShown(v, g, full) { return full || g === 'face' || groupInUse(v, g) || (v.areas || []).includes(g); }
function viewShown(v, cv, full, open) { return full || open || cv.main || viewInUse(v, cv.key); }

// Which areas and extra views someone opened on this screen, by visit, so a re-render keeps them.
const AREA_MORE = new Set();   // visitId + ':' + group, with every view of the area shown
const AREA_SHUT = new Set();   // visitId + ':' + group, folded
const AREA_OPEN = new Set();   // visitId + ':' + group, opened in Full view while empty

// One chart card: the chart if there is one, or a blank to start it.
function chartViewCard(v, p, cv) {
  const c = S.charts.find(x => x.visitId === v.id && x.view === cv.key);
  const name = cv.group === 'face' ? cv.label : cv.short;
  if (!c && !cv.drawing && (p.photoConsent === 'no' || !defaultChartPhoto(v, cv.key))) return `<div class="chart-card blank off"><div class="ph-blank">${v.signedAt ? 'No chart' : 'Needs a photo'}</div><div class="cap"><b>${esc(name)}</b><span class="meta">${p.photoConsent === 'no' ? 'The patient declined photos.' : `Add a ${esc(cv.label)} photo to chart on it.`}</span></div></div>`;
  if (!c) return `<button class="chart-card blank" data-chart="${cv.key}"><div class="ph-blank">${v.signedAt ? 'No chart' : 'Start chart'}</div><div class="cap"><b>${esc(name)}</b><span class="meta">${p.photoConsent === 'no' ? 'Drawing' : (defaultChartPhoto(v, cv.key) ? 'Opens on the photo' : 'Drawing')}</span></div></button>`;
  const lines = linesFromMarks(c.marks || []);
  return `<button class="chart-card" data-chart="${cv.key}">${chartSVG(c, chartThumbURL(c), 'preserveAspectRatio="xMidYMid meet"')}<div class="cap"><b>${esc(name)}</b><span class="meta">${lines.length ? esc(lines.map(l => matText(l, l.product || KINDS[l.kind].short)).join(', ')) : 'No treatment marks'}</span></div></button>`;
}

// What an area holds, for its folded line: the products charted on it, or how many views.
function groupSummary(v, g) {
  const lines = linesFromMarks(S.charts.filter(c => c.visitId === v.id && groupOfView(c.view) === g).flatMap(c => c.marks || []));
  if (lines.length) return lines.map(l => matText(l, l.product || KINDS[l.kind].short)).join(', ');
  const used = viewsOfGroup(g).filter(cv => viewInUse(v, cv.key)).length;
  return used ? plural(used, 'view') + ' in use' : (String((v.areaNotes || {})[g] || '').trim() ? 'Notes' : 'Nothing charted yet');
}

function areaSectionHTML(v, p, g, full) {
  const id = v.id + ':' + g, more = AREA_MORE.has(id);
  const all = viewsOfGroup(g), shown = all.filter(cv => viewShown(v, cv, full, more)), hidden = all.length - shown.length;
  const locked = !!v.signedAt, note = String((v.areaNotes || {})[g] || '');
  const removable = !full && g !== 'face' && !groupInUse(v, g) && (v.areas || []).includes(g) && !locked;
  // In Full view an empty area starts folded, so the page stays short until one is opened.
  const open = !AREA_SHUT.has(id) && (!full || groupShown(v, g, false) || AREA_OPEN.has(id));
  return `<details class="area" data-area="${g}" ${open ? 'open' : ''}>
    <summary><span class="area-name">${esc(groupDef(g).label)}</span><span class="meta area-sum">${esc(groupSummary(v, g))}</span></summary>
    <div class="area-body">
      <div class="chart-cards">${shown.map(cv => chartViewCard(v, p, cv)).join('')}</div>
      <div class="row area-actions">${hidden ? `<button type="button" class="btn quiet small" data-area-more="${g}">${plural(hidden, 'more view')}</button>` : (more && !full ? `<button type="button" class="btn quiet small" data-area-less="${g}">Fewer views</button>` : '')}${removable ? `<button type="button" class="btn quiet small" data-area-drop="${g}">Take this area off</button>` : ''}</div>
      ${locked && !note ? '' : `<label class="field area-note"><span class="label">Notes</span><textarea rows="2" data-area-note="${g}" placeholder="${esc(AREA_NOTE_HINTS[g] || '')}" ${locked ? 'readonly' : ''}>${esc(note)}</textarea></label>`}
    </div></details>`;
}
const AREA_NOTE_HINTS = {
  face: 'Asymmetry, skin quality, what the patient wants changed.',
  neck: 'Platysmal bands, neck lines, chest skin.',
  arms: 'Skin laxity and fat on the back of the upper arms.',
  abdomen: 'Pinch thickness, laxity, scars, diastasis.',
  back: 'Bra-line fat, skin, scars.',
  buttocks: 'Shape, cellulite, inner and outer thigh fat.',
  legs: 'Calf size, ankles, veins.',
  body: 'Overall shape, weight, anything not in another area.',
};

// The Areas block: Lean or Full, the areas, and the areas that can be added.
function areasHTML(v, p) {
  const full = areasFull();
  const shown = CHART_GROUPS.filter(g => groupShown(v, g.key, full));
  const rest = CHART_GROUPS.filter(g => !groupShown(v, g.key, full));
  return `<div class="areas" data-areas="${v.id}">
    <div class="areas-head"><div class="seg" role="group" aria-label="Areas shown"><button type="button" data-areas-mode="lean" aria-pressed="${!full}">Lean</button><button type="button" data-areas-mode="full" aria-pressed="${full}">Full view</button></div>
      ${rest.length && !v.signedAt ? `<label class="area-add"><select data-area-add aria-label="Add an area"><option value="">Add an area</option>${rest.map(g => `<option value="${g.key}">${esc(g.label)}</option>`).join('')}</select></label>` : ''}</div>
    ${shown.map(g => areaSectionHTML(v, p, g.key, full)).join('')}
  </div>`;
}

// Wires an Areas block. onOpen(viewKey) opens a chart; repaint() draws the block again.
function wireAreas(root, visitId, { onOpen, repaint }) {
  const box = root.querySelector('[data-areas]');
  if (!box) return;
  const cur = () => visit(visitId);
  box.querySelectorAll('[data-chart]').forEach(b => b.onclick = e => { e.preventDefault(); onOpen(b.dataset.chart); });
  box.querySelectorAll('[data-areas-mode]').forEach(b => b.onclick = () => { setAreasFull(b.dataset.areasMode === 'full'); repaint(); });
  box.querySelectorAll('details.area').forEach(d => d.addEventListener('toggle', () => { const id = visitId + ':' + d.dataset.area; if (d.open) { AREA_SHUT.delete(id); AREA_OPEN.add(id); } else { AREA_SHUT.add(id); AREA_OPEN.delete(id); } }));
  box.querySelectorAll('[data-area-more]').forEach(b => b.onclick = () => { AREA_MORE.add(visitId + ':' + b.dataset.areaMore); repaint(); });
  box.querySelectorAll('[data-area-less]').forEach(b => b.onclick = () => { AREA_MORE.delete(visitId + ':' + b.dataset.areaLess); repaint(); });
  const add = box.querySelector('[data-area-add]');
  if (add) add.onchange = async () => {
    const g = add.value; if (!g) return;
    const v = cur();
    AREA_SHUT.delete(visitId + ':' + g);
    try { await save('visits', { ...v, areas: [...new Set([...(v.areas || []), g])] }, { action: `Area added: ${groupDef(g).label}` }); } catch (e) { fail(e); }
    repaint();
    const sec = document.querySelector(`[data-areas] details[data-area="${g}"]`); if (sec) sec.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  };
  box.querySelectorAll('[data-area-drop]').forEach(b => b.onclick = async () => {
    const v = cur();
    try { await save('visits', { ...v, areas: (v.areas || []).filter(x => x !== b.dataset.areaDrop) }, { action: `Area taken off: ${groupDef(b.dataset.areaDrop).label}` }); } catch (e) { fail(e); }
    repaint();
  });
  // Notes save a moment after typing stops, and when the box loses focus.
  box.querySelectorAll('[data-area-note]').forEach(t => {
    if (t.readOnly) return;
    const g = t.dataset.areaNote;
    const write = async () => {
      const v = cur(), val = t.value.trim();
      if (!v || v.signedAt || String((v.areaNotes || {})[g] || '') === val) return;
      try { await save('visits', { ...v, areaNotes: { ...(v.areaNotes || {}), [g]: val } }, { action: `Area notes saved: ${groupDef(g).label}` }); delete t.dataset.dirty; }
      catch (e) { fail(e); }
    };
    const later = debounce(write, 1200);
    t.addEventListener('input', () => { t.dataset.dirty = '1'; later(); });
    t.addEventListener('change', write);
  });
}
