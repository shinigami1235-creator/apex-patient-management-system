// Complication log: bruising, a lump, a suspected vascular occlusion, an allergic
// reaction. Each entry sits on the patient and the visit it followed, with what was done,
// a follow-up date and where it stands. Doctors and assistants write it, and the
// Complications page lists them all.

const incidentsOf = pid => S.incidents.filter(x => x.patientId === pid).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
const incidentOpen = x => x.outcome !== 'Resolved';

function incidentRow(x, { showPatient = false } = {}) {
  const v = x.visitId && visit(x.visitId), p = patient(x.patientId);
  return `<div class="li at-top"><div class="date-col"><b>${fmtDate(x.date)}</b></div><div class="grow">
    <div class="t medium">${showPatient && p ? `<a href="#/patient/${p.id}">${esc(p.name)}</a> · ` : ''}${esc(x.type)} · ${esc(x.severity)}${x.area ? ' · ' + esc(x.area) : ''}</div>
    ${x.what ? `<div class="m pre">${esc(x.what)}</div>` : ''}
    ${x.given ? `<div class="m"><b>Done:</b> ${esc(x.given)}</div>` : ''}
    <div class="m">${v ? `After <a href="#/visit/${v.id}">${esc(visitSummary(v) || 'the visit')} on ${fmtDate(v.date)}</a> · ` : ''}Logged by ${esc(userName(x.by || x.createdBy))}${x.followUp && incidentOpen(x) ? ` · check ${fmtDate(x.followUp)}` : ''}${x.resolvedOn ? ` · resolved ${fmtDate(x.resolvedOn)}` : ''}${x.outcomeNote ? ' · ' + esc(x.outcomeNote) : ''}</div></div>
    ${chip(x.outcome, x.outcome === 'Resolved' ? 'ok' : x.severity === 'Severe' ? 'bad' : 'warn')}
    ${can('clinical') ? `<button class="btn quiet small" data-incident="${x.id}">Update</button>` : ''}</div>`;
}
function incidentCard(v) {
  const list = S.incidents.filter(x => x.visitId === v.id);
  return `<div class="card" id="vincidents"><div class="card-head"><h2>Complications</h2><button class="btn secondary small" data-act="add-incident">${I.plus}Log a complication</button></div>
    ${list.length ? `<div class="list flat">${list.map(x => incidentRow(x)).join('')}</div>` : '<p class="muted">None logged. Log bruising, a lump, a suspected vascular occlusion or a reaction here, even after the visit is signed.</p>'}</div>`;
}
function patientIncidentsCard(p) {
  const list = incidentsOf(p.id);
  if (!list.length) return '';
  return `<div class="card"><div class="card-head"><h2>Complications</h2></div><div class="list flat">${list.map(x => incidentRow(x)).join('')}</div></div>`;
}
function wireIncidents(root = document) {
  root.querySelectorAll('[data-incident]').forEach(b => b.onclick = () => incidentSheet(byId('incidents', b.dataset.incident)));
}

async function incidentSheet(x, ctx = {}) {
  const pid = x ? x.patientId : ctx.patientId;
  const p = patient(pid);
  const v = x ? x.visitId && visit(x.visitId) : ctx.visitId && visit(ctx.visitId);
  const f = await sheet({
    title: x ? `${x.type} · ${p ? p.name : ''}` : `Log a complication${p ? ' · ' + p.name : ''}`, wide: true, submit: x ? 'Save' : 'Log it',
    body: `${v ? `<p class="meta">After ${esc(visitSummary(v) || 'the visit')} on ${fmtDate(v.date)}.</p>` : ''}
      <div class="grid3">${field('Noticed on', 'date', x ? x.date : todayISO(), { type: 'date' })}${field('What happened', 'type', x ? x.type : '', { type: 'select', options: INCIDENT_TYPES, blank: 'Pick one' })}${field('Severity', 'severity', x ? x.severity : 'Mild', { type: 'select', options: INCIDENT_SEVERITY, blank: false })}</div>
      ${field('Area', 'area', x ? x.area : '', { ph: 'Left nasolabial fold' })}
      ${field('What was seen', 'what', x ? x.what : '', { type: 'textarea', ph: 'Blanching and mottling of the left upper lip 10 minutes after filler, with pain.' })}
      ${field('What was done', 'given', x ? x.given : '', { type: 'textarea', ph: 'Hyaluronidase 1500 IU in divided doses, warm compress, aspirin 325 mg. Recorded under Medicines given with the lot.', hint: 'Record a medicine given under Medicines given on the visit too, so its lot comes off stock.' })}
      <div class="grid3">${field('Check again on', 'followUp', x ? x.followUp : addDays(todayISO(), 2), { type: 'date' })}${field('Where it stands', 'outcome', x ? x.outcome : 'Ongoing', { type: 'select', options: INCIDENT_OUTCOMES, blank: false })}${field('Outcome note', 'outcomeNote', x ? x.outcomeNote : '', { ph: 'Colour back to normal at 48 hours' })}</div>`,
    validate: form => (!val(form, 'type') ? 'Pick what happened.' : !val(form, 'date') ? 'Enter the date.' : ''),
  });
  if (!f) return;
  const rec = { ...(x || { id: uid(), patientId: pid, visitId: v ? v.id : '', by: S.me.id }) };
  for (const k of ['date', 'type', 'severity', 'area', 'what', 'given', 'followUp', 'outcome', 'outcomeNote']) rec[k] = val(f, k);
  try { await save('incidents', rec, { action: x ? `Complication updated: ${rec.outcome}` : `Complication logged: ${rec.type}` }); toast(x ? 'Saved.' : 'Logged.'); render(); } catch (e) { fail(e); }
}

// Complications: every one in the period, by type and by the treatment before it.
function barList(rows) {
  const max = Math.max(1, ...rows.map(r => r.value));
  return `<div class="bars">${rows.map(r => `<div class="bar-row"><span class="bar-l">${esc(r.label)}</span><span class="bar"><i style="width:${Math.round(r.value / max * 100)}%"></i></span><b>${trimNum(r.value)}</b></div>`).join('')}</div>`;
}
function renderIncidentReport(q) {
  const from = q.from || addDays(todayISO(), -89), to = q.to || todayISO();
  const list = S.incidents.filter(x => x.date >= from && x.date <= to).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const open = S.incidents.filter(incidentOpen);
  const treated = new Set(S.visits.filter(v => v.date >= from && v.date <= to && ((v.services || []).length || (v.treatments || []).length)).map(v => v.id));
  const byType = [...groupBy(list, x => x.type).entries()].map(([k, l]) => ({ label: k, value: l.length })).sort((a, b) => b.value - a.value);
  const after = list.filter(x => x.visitId && visit(x.visitId));
  const byService = [...groupBy(after.flatMap(x => (visit(x.visitId).services || []).map(s => ({ x, name: (service(s.serviceId) || {}).name || s.name || 'Treatment' }))), r => r.name).entries()].map(([k, l]) => ({ label: k, value: l.length })).sort((a, b) => b.value - a.value);
  $app.innerHTML = shell('complications', `<div class="page-head"><div><h1>Complications</h1></div>
      <form class="row" id="per">${field('From', 'from', from, { type: 'date' })}${field('To', 'to', to, { type: 'date' })}</form></div>
    <div class="stats">
      <div class="stat"><span class="meta">Complications</span><b>${list.length}</b><span class="meta">in these dates</span></div>
      <div class="stat"><span class="meta">Severe</span><b class="${list.some(x => x.severity === 'Severe') ? 'bad-text' : ''}">${list.filter(x => x.severity === 'Severe').length}</b><span class="meta">${list.filter(x => x.type === 'Suspected vascular occlusion').length} suspected occlusion</span></div>
      <div class="stat"><span class="meta">Still open</span><b>${open.length}</b><span class="meta">any date</span></div>
      <div class="stat"><span class="meta">Per 100 treatment visits</span><b>${treated.size ? trimNum(Math.round(after.filter(x => treated.has(x.visitId)).length / treated.size * 1000) / 10) : 0}</b><span class="meta">${plural(treated.size, 'treatment visit')}</span></div>
    </div>
    <div class="cols">
      <div class="card"><h2 class="card-title">By type</h2>${byType.length ? barList(byType) : '<p class="muted">None in these dates.</p>'}</div>
      <div class="card"><h2 class="card-title">By the treatment before it</h2>${byService.length ? barList(byService) : '<p class="muted">None linked to a visit.</p>'}</div>
    </div>
    ${list.length ? `<h3 class="section-title">Entries</h3><div class="card"><div class="list flat">${list.map(x => incidentRow(x, { showPatient: true })).join('')}</div></div>` : ''}
    ${open.filter(x => !(x.date >= from && x.date <= to)).length ? `<h3 class="section-title">Open from before these dates</h3><div class="card"><div class="list flat">${open.filter(x => !(x.date >= from && x.date <= to)).map(x => incidentRow(x, { showPatient: true })).join('')}</div></div>` : ''}`, { wide: true });
  wireShell(); wireIncidents();
  const per = document.getElementById('per');
  per.querySelectorAll('input').forEach(i => i.onchange = () => { setQuery({ from: val(per, 'from'), to: val(per, 'to') }); renderIncidentReport(route().q); });
}
