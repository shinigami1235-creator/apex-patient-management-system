// The before and after camera. It steps through the five standard views, or takes close-ups
// of a treated area, each lined up on the patient's last photo of the same view. Needs the
// camera, so it works on the branch PC and on the secure address.

const CAM_VIEWS = ['Front', 'Right 45°', 'Left 45°', 'Right side', 'Left side'];

// The patient's latest photo of a view from an earlier visit, or of the area for close-ups.
function guidePhotoFor(v, view, area) {
  const list = S.photos.filter(ph => ph.patientId === v.patientId && ph.visitId !== v.id && (area ? ph.view === 'Close-up' && areaKey(ph.area) === areaKey(area) : ph.view === view && !ph.area));
  return list.sort((a, b) => photoVisitDate(b).localeCompare(photoVisitDate(a)) || (b.created || 0) - (a.created || 0))[0] || null;
}

// The before and after camera: Camera Overlay in a frame over the visit. The patient's
// last photo of each view is its ghost and outline, with the tilt and lighting checks and
// Focus mode. Every photo taken goes onto this visit under its view.
async function openOverlayCamera(v) {
  const p = patient(v.patientId);
  if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    await ask({ title: 'The camera needs the secure address', body: secureNote('The camera') || '<p>This browser has no camera access.</p>', buttons: [{ label: 'Close', value: null }] });
    return;
  }
  const ai = document.querySelector('[data-photo-area]');
  const area = (ai ? ai.value : '').trim();
  const views = area ? ['Close-up'] : CAM_VIEWS;
  const taken = () => S.photos.filter(x => x.visitId === v.id);
  const isTaken = x => taken().some(ph => ph.view === x && (!area || areaKey(ph.area) === areaKey(area)));
  let view = area ? 'Close-up' : CAM_VIEWS.find(x => !isTaken(x)) || 'Front';
  let ready = false, busy = false;
  const el = document.createElement('div');
  el.className = 'camera ovcam';
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Before and after camera');
  el.innerHTML = `<div class="ovcam-top"><div class="grow"><b>${esc(p.name)}</b><span class="meta" data-cam-hint></span></div>
      <div class="seg wrap" role="group" data-cam-views>${views.map(x => `<button type="button" data-cam-view="${esc(x)}">${esc(x)}</button>`).join('')}</div>
      <button class="btn primary small" data-cam-close>Done</button></div>
    <iframe class="ovcam-frame" src="camera/index.html?embed=1" allow="camera; microphone; fullscreen" title="Camera"></iframe>`;
  document.body.appendChild(el);
  document.body.classList.add('ov-open');
  const frame = el.querySelector('iframe'), hint = el.querySelector('[data-cam-hint]');
  const post = m => { try { frame.contentWindow.postMessage(m, location.origin); } catch (e) { /* frame not ready */ } };
  // The earlier photo of the view, as a data URL the frame can draw on.
  const sendBefore = async () => {
    const g = guidePhotoFor(v, view, area);
    el.querySelectorAll('[data-cam-view]').forEach(b => { b.setAttribute('aria-pressed', b.dataset.camView === view); b.classList.toggle('done', isTaken(b.dataset.camView)); });
    hint.textContent = `${view}${area ? ', ' + area : ''} · ${g ? `lined up on the photo from ${fmtDate(photoVisitDate(g))}` : 'no earlier photo of this view'}${isTaken(view) ? ' · taken' : ''}`;
    if (!ready) return;
    if (!g) return post({ type: 'apex:before', dataUrl: null });
    try { const blob = await (await fetch(fullURL(g.id))).blob(); post({ type: 'apex:before', dataUrl: await blobToDataURL(blob), tilt: g.tilt || null }); }
    catch (e) { post({ type: 'apex:before', dataUrl: null }); }
  };
  const onMsg = async e => {
    if (e.origin !== location.origin || e.source !== frame.contentWindow) return;
    const m = e.data || {};
    if (m.type === 'apex:ready') { ready = true; sendBefore(); }
    if (m.type === 'apex:captured' && !busy) {
      busy = true;
      try {
        const blob = await dataURLToBlob(m.afterDataUrl);
        await addPhotoBlob(blob, v, { view, area, name: `${view} ${todayISO()}.jpg`, tilt: m.tilt || null });
        const next = area ? null : CAM_VIEWS.find(x => !isTaken(x));
        post({ type: 'apex:flash', text: tr(`${view} saved${next ? `. Next: ${next}` : ''}.`) });
        if (next) view = next;
        await sendBefore();
      } catch (ex) { toast(ex.message, 6000); }
      busy = false;
    }
  };
  const close = () => { window.removeEventListener('message', onMsg); document.removeEventListener('keydown', onKey); el.remove(); document.body.classList.remove('ov-open'); renderVisit(v.id); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  window.addEventListener('message', onMsg);
  document.addEventListener('keydown', onKey);
  el.querySelector('[data-cam-close]').onclick = close;
  el.querySelectorAll('[data-cam-view]').forEach(b => b.onclick = () => { view = b.dataset.camView; sendBefore(); });
  sendBefore();
}
const openGuidedCamera = openOverlayCamera;

// One photo from the camera, filed under its view, with a thumbnail, like a picked file.
async function addPhotoBlob(blob, v, { view, area = '', name = 'photo.jpg', tilt = null }) {
  const stage = area ? stageForArea(v, area) : chartsOfVisit(v.id).some(c => (c.marks || []).length) ? 'After' : 'Before';
  const full = await resizeImage(blob, 2400, 0.9);
  const thumb = await resizeImage(full.blob, 480, 0.8);
  const fileId = await uploadFile(full.blob, { canWait: true });
  const thumbId = await uploadFile(thumb.blob, { canWait: true });
  return save('photos', { id: uid(), patientId: v.patientId, visitId: v.id, view, stage, area, date: v.date, w: full.width, h: full.height, name, fileId, thumbId, guided: true, tilt }, { action: `Photo taken with the camera: ${view}${area ? ', ' + area : ''}` });
}

// ---------- before and after pictures ----------
// Proofline, the collage maker, in a frame over the patient. The doctor ticks the photos to
// compare, lines them up, labels them and covers the eyes there, and the finished picture
// comes back to the patient's photos, or downloads.
async function openCollage(pid, { visitId = '', pick = [] } = {}) {
  const p = patient(pid);
  if (!p) return;
  const all = photosOf(pid).filter(ph => ph.view !== 'Comparison');
  if (!all.length) return toast('This patient has no photos yet.');
  let chosen = pick.length ? pick : (() => {
    const fronts = all.filter(x => x.view === 'Front');
    const list = fronts.length > 1 ? fronts : all;
    return [...new Set([list[list.length - 1].id, list[0].id])];
  })();
  const f = await sheet({
    title: 'Before and after picture', submit: 'Open', wide: true,
    body: `<p class="muted">Tick the photos to put together. They open in the order of their dates.</p>
      <div class="pick-grid">${all.map(ph => `<label class="pick-ph"><input type="checkbox" value="${ph.id}" ${chosen.includes(ph.id) ? 'checked' : ''}><img loading="lazy" src="${thumbURL(ph.id)}" alt=""><span>${esc(ph.area || ph.view)} · ${esc(fmtDay(photoVisitDate(ph)))}</span></label>`).join('')}</div>`,
    validate: form => (form.querySelectorAll('input:checked').length ? '' : 'Tick at least one photo.'),
  });
  if (!f) return;
  chosen = [...f.querySelectorAll('input:checked')].map(x => x.value).map(photoMeta).filter(Boolean).sort((a, b) => photoVisitDate(a).localeCompare(photoVisitDate(b)) || (a.created || 0) - (b.created || 0));
  const el = document.createElement('div');
  el.className = 'camera ovcam collage-ov';
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Before and after picture');
  el.innerHTML = `<div class="ovcam-top"><div class="grow"><b>${esc(p.name)}</b><span class="meta">Before and after picture · Save in the panel files it on the patient's photos</span></div><button class="btn primary small" data-close>Done</button></div>
    <iframe class="ovcam-frame" src="collage/index.html?embed=1" title="Before and after picture"></iframe>`;
  document.body.appendChild(el);
  document.body.classList.add('ov-open');
  const frame = el.querySelector('iframe');
  const onMsg = async e => {
    if (e.origin !== location.origin || e.source !== frame.contentWindow) return;
    const m = e.data || {};
    if (m.type === 'apex:ready') {
      try {
        const files = [];
        for (const ph of chosen) {
          const blob = await (await fetch(fullURL(ph.id))).blob();
          const d = new Date(photoVisitDate(ph) + 'T12:00:00');
          files.push(new File([blob], `${ph.area || ph.view} ${photoVisitDate(ph)}.jpg`, { type: blob.type || 'image/jpeg', lastModified: d.getTime() }));
        }
        frame.contentWindow.postMessage({ type: 'apex:photos', files }, location.origin);
      } catch (ex) { toast(ex.message, 6000); }
    }
    if (m.type === 'apex:file') {
      const isImage = /^image\//.test(m.blob.type);
      const isVideo = /^video\//.test(m.blob.type);
      const r = await ask({ title: isVideo ? 'The video is ready' : 'The picture is ready', body: isImage ? `<p>Save it on ${esc(p.name)}'s photos, or download it to this device.</p>` : isVideo ? '<p>The video downloads to this device.</p>' : '<p>The PDF downloads to this device.</p>', buttons: [{ label: 'Download', value: 'dl', kind: isImage ? '' : 'primary' }, ...(isImage ? [{ label: 'Save on the record', value: 'rec', kind: 'primary' }] : [])] });
      if (r === 'dl') saveBlob(m.blob, m.name);
      if (r === 'rec') {
        try {
          const v = visitId ? visit(visitId) : visitsOf(pid)[0];
          const full = await resizeImage(m.blob, 3000, 0.92), thumb = await resizeImage(full.blob, 480, 0.8);
          const fileId = await uploadFile(full.blob, { canWait: true }), thumbId = await uploadFile(thumb.blob, { canWait: true });
          await save('photos', { id: uid(), patientId: pid, visitId: v ? v.id : '', view: 'Comparison', stage: 'Comparison', area: '', date: v ? v.date : todayISO(), w: full.width, h: full.height, name: m.name, fileId, thumbId, from: chosen.map(x => x.id) }, { action: 'Before and after picture saved' });
          toast(`Saved on ${p.name}'s photos.`);
        } catch (ex) { fail(ex); }
      }
    }
  };
  const close = () => { window.removeEventListener('message', onMsg); el.remove(); document.body.classList.remove('ov-open'); render(); };
  window.addEventListener('message', onMsg);
  el.querySelector('[data-close]').onclick = close;
}
