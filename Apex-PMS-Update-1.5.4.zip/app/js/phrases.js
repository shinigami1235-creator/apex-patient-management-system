// Easy typing for the notes: the clinic's common phrases a tap away under each box, and the
// last visit's notes copied in with one press. The phrases are the clinic's own; any doctor
// adds to them or takes one out, and the starting list is below.

const PHRASE_FIELDS = ['complaint', 'findings', 'assessment', 'plan'];
const DEFAULT_PHRASES = {
  complaint: ['Wants softer frown lines.', 'Forehead lines.', 'Crow\'s feet.', 'Wants fuller lips.', 'Tired look under the eyes.', 'Wants a slimmer jawline.', 'Sagging lower face.', 'Dull, dry skin.', 'Acne scars.', 'Review after the last treatment.'],
  findings: ['Dynamic glabellar lines, grade 2.', 'Static forehead lines.', 'Tear trough hollowing, both sides.', 'Masseter hypertrophy, both sides.', 'Thin upper lip.', 'Mild jowling.', 'No bruising, no swelling.', 'Good result, symmetric.', 'No signs of infection.'],
  assessment: ['Dynamic facial lines.', 'Mid-face volume loss.', 'Masseter hypertrophy.', 'Skin laxity.', 'Lip volume loss.', 'Satisfactory result.'],
  plan: ['Botulinum toxin as charted.', 'Filler as charted.', 'Review in 2 weeks.', 'Review in 4 weeks.', 'Aftercare explained.', 'Photos taken.', 'Consent signed.', 'Touch-up at review if needed.'],
};
const phrasesFor = k => ((S.phrases && Array.isArray(S.phrases[k])) ? S.phrases[k] : DEFAULT_PHRASES[k]) || [];
const canEditPhrases = () => isOwner() || (S.me && S.me.role === 'doctor');

// Puts the chips under each notes box of a notes form, and Copy last visit in its header.
function phrasesWire(form, v) {
  if (!form) return;
  for (const k of PHRASE_FIELDS) {
    const box = form.querySelector(`textarea[name="${k}"]`);
    if (!box || box.readOnly || box.disabled) continue;
    const row = document.createElement('div');
    row.className = 'phrase-row';
    row.setAttribute('translate', 'no');
    row.dataset.phrases = k;
    row.innerHTML = phraseChipsHTML(k);
    box.after(row);
  }
  form.addEventListener('click', e => {
    const chip = e.target.closest('[data-phrase]');
    if (chip) { e.preventDefault(); const k = chip.closest('[data-phrases]').dataset.phrases; insertPhrase(form.querySelector(`textarea[name="${k}"]`), chip.dataset.phrase); return; }
    const ed = e.target.closest('[data-phrase-edit]');
    if (ed) { e.preventDefault(); editPhrases(ed.closest('[data-phrases]').dataset.phrases); }
  });
  // The last signed or earlier visit's notes, into the boxes that are still empty.
  const prev = visitsOf(v.patientId).filter(x => x.id !== v.id && (x.date || '') <= (v.date || '') && PHRASE_FIELDS.some(k => x[k])).sort((a, b) => (b.date || '').localeCompare(a.date || ''))[0];
  const head = form.querySelector('.card-head .row');
  if (prev && head && PHRASE_FIELDS.some(k => { const b = form.querySelector(`textarea[name="${k}"]`); return b && !b.readOnly && !b.disabled; })) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'btn quiet small'; b.dataset.copyLast = '';
    b.title = `Notes from ${fmtDate(prev.date)}`;
    b.textContent = 'Copy last visit';
    head.prepend(b);
    b.onclick = () => {
      let n = 0;
      for (const k of PHRASE_FIELDS) { const box = form.querySelector(`textarea[name="${k}"]`); if (box && !box.value.trim() && prev[k]) { box.value = prev[k]; box.dispatchEvent(new Event('input', { bubbles: true })); n++; } }
      toast(n ? `Copied from the visit on ${fmtDate(prev.date)} into the empty boxes.` : 'The boxes already have notes, so nothing was copied.');
    };
  }
}
function phraseChipsHTML(k) {
  return phrasesFor(k).map(t => `<button type="button" class="phrase" data-phrase="${esc(t)}">${esc(t.replace(/\.$/, ''))}</button>`).join('') + (canEditPhrases() ? `<button type="button" class="phrase edit" data-phrase-edit title="${esc(tr('Add or remove phrases'))}">+</button>` : '');
}
function insertPhrase(box, text) {
  if (!box) return;
  const at = document.activeElement === box ? box.selectionStart : box.value.length, end = document.activeElement === box ? box.selectionEnd : at;
  const before = box.value.slice(0, at);
  const ins = (before && !/\s$/.test(before) ? ' ' : '') + text;
  box.value = before + ins + box.value.slice(end);
  const pos = at + ins.length;
  box.focus(); box.setSelectionRange(pos, pos);
  box.dispatchEvent(new Event('input', { bubbles: true }));
}
async function editPhrases(k) {
  const label = { complaint: 'Complaint', findings: 'Findings', assessment: 'Assessment', plan: 'Plan' }[k];
  const f = await sheet({
    title: `${label} phrases`,
    body: `<label class="field"><span class="label">One phrase on each line</span><textarea name="list" rows="10">${esc(phrasesFor(k).join('\n'))}</textarea><span class="hint">These show under ${esc(label)} on every visit, for every doctor.</span></label>`,
  });
  if (!f) return;
  const list = val(f, 'list').split('\n').map(x => x.trim()).filter(Boolean).slice(0, 40);
  const all = { ...DEFAULT_PHRASES, ...(S.phrases || {}), [k]: list };
  try { await setMeta('phrases', all); } catch (e) { return fail(e); }
  document.querySelectorAll(`[data-phrases="${k}"]`).forEach(r => { r.innerHTML = phraseChipsHTML(k); });
}
