// Builds a patient's 3D head from the standard photos: front, both 45s and both laterals.
// The fit, the head shell and the texture bake come from the planner core. What is
// added here is the look Gid approved: a face mask that runs back to just in front of
// each tragus, skips the ear and carries on down to the jaw, with the kept skin made
// solid and wall samples thrown out of the bake.
import * as core from './planner-core.mjs';
const { THREE, S } = core;
export const lm3Of = () => S.lm3;

// Clinic photo views and the planner's slot for each.
export const VIEW_ROLES = { front: 'front', right45: 'r45', left45: 'l45', right: 'r90', left: 'l90' };
export const VIEW_KEYS = Object.keys(VIEW_ROLES);

// Gid's cut, in mm from the landmarks. See the TRAGUS block of the test rig.
const CUT = { under: 5, fwd: 6, top: 2, slope: 1.0, topmax: 6, over: -1.5,
  // The face outline (MediaPipe face oval) from ear level up to the upper temple.
  rim: [234, 127, 162, 21, 54, 284, 251, 389, 356, 454] };
const ALPHA = { pad: 3, up: 6 };
const OUTLIER = { minWeight: 0.02, dist: 34, pale: 14, radius: 40, minRef: 400, rim: 240 };
// Eye and mouth rings of the face mesh (MediaPipe indices), kept out of the outlier pass.
const PROTECT = { grow: 36, rings: [
  [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246],
  [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398],
  [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185],
] };
// Lateral photos paint the shell strip in front of the cut, where the front and 45 cameras
// only graze and pick up the wall (the pale patch at gid's sideburn). A profile's fitted
// camera can be several degrees off, which put kyla's ear on that strip, so each lateral
// paints only inside the face outline MediaPipe finds in that photo (lateralGate).
const LATERALS = true;
const lateralsOn = () => globalThis.HEAD_LATERALS ?? LATERALS;
const LATERAL = { handoff: 0.15, minWeight: 0.02, margin: () => globalThis.HEAD_LAT_MARGIN ?? 0 };
// MediaPipe's face outline, in order. On a profile its back edge runs just in front of the ear.
const FACE_OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109];

let configured = false;
export function configure(opts) { core.configure(opts); configured = true; }

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('A photo could not be opened.'));
    img.src = src;
  });
}

// photos: { front: url|Image, right45, left45, right, left }, any of them missing.
// progress(text) is called at each step.
// Which way a side photo faces, from its own landmarks: the nose tip's offset from the
// middle of the cheek line, as a share of the face's width. A right 45 or right side
// photo reads above 0 and a left one below 0 (0.46 to 2.3 against -0.48 to -2.3 on the
// test sets; a front is within 0.02). pnun's 45s, filed the wrong way round, read -0.64
// and 0.67.
const SIDE_SIGN = { right45: 1, right: 1, left45: -1, left: -1 };
const SIDE_PAIR = { right45: 'left45', left45: 'right45', right: 'left', left: 'right' };
export function sideOffset(lm) { const w = Math.abs(lm[454].x - lm[234].x) || 1; return (lm[1].x - (lm[234].x + lm[454].x) / 2) / w; }

// onSides(wrong): called when a side photo faces the other way. wrong is a list of
// { key, looksLike }. Return 'swap' to file them the other way round for this build, or
// anything else to build them as filed. The result's moved says where each one went.
export async function buildHead(photos, { progress = () => {}, perCamera = rejectWallSamples, onSides = null } = {}) {
  if (!configured) core.configure({});
  core.configure({ perCamera });
  if (!photos.front) throw new Error('A front photo is needed.');
  const sides = VIEW_KEYS.filter(k => k !== 'front' && photos[k]);
  if (!sides.length) throw new Error('A front photo and at least one side photo are needed.');

  progress('Opening the photos');
  S.photos.length = 0; S.frontId = null; S.refId = null; S.seq = 1;
  for (const k of VIEW_KEYS) {
    if (!photos[k]) continue;
    const img = typeof photos[k] === 'string' ? await loadImage(photos[k]) : photos[k];
    const rec = { id: 'ph' + (S.seq++), name: k, role: 'other', dataUrl: k + ':' + (img.src || ''), img };
    S.photos.push(rec);
    core.fileInto(rec, VIEW_ROLES[k]);
  }

  progress('Loading the face model');
  const lmk = await core.getLandmarker();
  const front = S.photos.find(p => p.id === S.frontId);
  progress('Finding the face in each photo');
  const frontLm0 = await core.detectFor(front, lmk);
  if (!frontLm0) throw new Error('No face found in the front photo.');
  const alar = core.applyAlarMarks(frontLm0, front);
  const frontLm = alar.lm;
  const extra = [], geoNoLm = [], noFace = [];
  for (const p of S.photos) {
    if (p.id === S.frontId) continue;
    const lm = await core.detectFor(p, lmk);
    if (!lm) { geoNoLm.push(p); continue; }
    p.lm2 = lm;
    extra.push({ id: p.id, role: p.role, lm, img: p.img, aspect: p.img.naturalWidth / p.img.naturalHeight, photo: p });
  }
  const moved = {};
  {
    const wrong = [];
    for (const p of S.photos) if (p.lm2 && SIDE_SIGN[p.name] && sideOffset(p.lm2) * SIDE_SIGN[p.name] < -0.15) wrong.push({ key: p.name, looksLike: SIDE_PAIR[p.name] });
    // Only a pair that both face the other way, or one whose other slot is empty, can be switched.
    const can = wrong.filter(w => wrong.some(x => x.key === w.looksLike) || !S.photos.some(p => p.name === w.looksLike));
    if (can.length && onSides && (await onSides(can)) === 'swap') {
      const recs = can.map(w => S.photos.find(x => x.name === w.key));
      can.forEach((w, i) => {
        const p = recs[i];
        if (!p) return;
        moved[w.looksLike] = w.key;
        p.name = w.looksLike; p.role = VIEW_ROLES[w.looksLike];
        const e = extra.find(x => x.photo === p); if (e) e.role = p.role;
      });
    }
  }

  progress(extra.length ? `Fitting the face from ${extra.length + 1} photos` : 'Building the face');
  await tick();
  const views = [{ id: front.id, role: 'front', lm: frontLm, img: front.img, aspect: front.img.naturalWidth / front.img.naturalHeight, photo: front }, ...extra];
  const fov = 45;
  const fit = extra.length ? core.fitMultiView(views, { fov }) : null;
  let pos3Final = fit ? fit.pos3 : null;
  {
    const arF = front.img.naturalWidth / front.img.naturalHeight;
    const rawF = core.lmToRaw(frontLm, arF);
    const camZF = fit ? fit.camZ : 0.5 / Math.tan((fov * Math.PI) / 360);
    if (!fit) {
      const s0r = core.referenceDepthPrior(rawF, camZF);
      if (s0r) pos3Final = rawF.map((q, i) => [s0r[i] * q[0], s0r[i] * q[1], camZF * (1 - s0r[i])]);
    }
    const prof = core.profileAnchors(rawF, camZF);
    const obl = fit ? core.obliqueAnchors(fit, rawF, camZF, pos3Final || rawF) : null;
    if (obl && obl.anchors.size) { for (const [i, Z] of obl.anchors) if (!prof.anchors.has(i)) prof.anchors.set(i, Z); prof.any = true; }
    if (prof.any) {
      const { nb } = core.frontTopology(frontLm, arF);
      pos3Final = core.applyProfileAnchors(pos3Final || rawF, rawF, nb, camZF, prof.anchors);
    }
  }
  core.installFaceMesh(frontLm, front.img, true, pos3Final);

  // Cameras for every photo: solved by the fit, or from the outline for a lateral the detector could not read.
  const fc = { params: [0, 0, fit ? fit.camZ : 0.5 / Math.tan(fov * Math.PI / 360), 0, 0, 0], rms: 0, n: frontLm.length };
  front.pose = core.poseFromFit(fc, fit ? fit.fov : fov, S.lmNorm, front.img);
  if (fit) for (const v of fit.views.slice(1)) {
    if (!v.solved) continue;
    v.photo.pose = core.poseFromFit(v.solved, fit.fov, S.lmNorm, v.photo.img);
    v.photo.check = core.classifyCamera(v.solved.params.slice(0, 3), v.photo.role, false);
  }
  const frontMask = geoNoLm.length ? core.headMask(front.img) : null;
  for (const p of geoNoLm) {
    const r = core.estimateSilhouettePose(p, frontMask && frontMask.ok ? frontMask : null);
    if (r.pose) p.pose = r.pose; else noFace.push(p.name);
  }

  progress('Building the head');
  await tick();
  const hl = core.estimateHairline();
  const shell = core.attachCanonicalShell({ hairH: hl ? hl.hairH : 0.45, temple: hl && hl.temple !== null ? hl.temple : 0.40 });
  if (!shell.ok) throw new Error('The head could not be built: ' + shell.why);
  S.shellInfo = shell;
  core.applyShellRefinement();

  progress('Baking the texture');
  await tick();
  // The planner leaves a landmark-posed profile out of the bake, since a traced profile
  // is a poor measurement. Here it paints only the strip in front of the cut, where no
  // other camera reaches, so for the bake it is let in and the blend below keeps it there.
  const lats = lateralsOn() ? S.photos.filter(p => (p.role === 'r90' || p.role === 'l90') && p.pose && p.pose.auto && !p.pose.silOnly) : [];
  const maxTex = core.renderer.capabilities.maxTextures || 8;
  const letIn = Math.max(2, Math.min(6, Math.floor((maxTex - 2) / 2))) >= S.photos.length ? lats : [];
  for (const p of letIn) p.pose.auto = false;
  let bake;
  try { bake = core.buildAtlas(); } finally { for (const p of letIn) p.pose.auto = true; }
  if (bake.error) throw new Error(bake.error);

  progress('Cutting at the ears');
  await tick();
  const mesh = core.targets[0];
  const cut = tragusCut(mesh);
  const fix = solidSkin(mesh);

  const stats = { verts: mesh.geometry.attributes.position.count, tris: mesh.geometry.index.count / 3, atlasW: fix.W, atlasH: fix.H, baked: bake.n, fitViews: views.length, cut, fix: { set: fix.set, unseen: fix.unseen, left: fix.left } };
  const filed = { ...photos }; for (const [to, from] of Object.entries(moved)) filed[to] = photos[from];
  for (const from of Object.values(moved)) if (!moved[from]) delete filed[from];
  return { mesh, lm3: S.lm3, stats, noFace, missing: VIEW_KEYS.filter(k => !filed[k]), moved };
}

const tick = () => new Promise(r => setTimeout(r, 20));

// ---------- the cut ----------
// Fringe and skin triangles are clipped exactly (Sutherland and Hodgman) against three
// planes per side: just in front of the fitted ear, under the jaw, and a sloped top
// starting above eye level at the tragus line. The face group is left whole and the
// normals are carried over rather than recomputed, which caused creases.
function tragusCut(m) {
  const g = m.geometry, pos = g.attributes.position, uv = g.attributes.uv, nrm = g.attributes.normal, I = g.index.array;
  const P = [], U = [], N = [];
  for (let i = 0; i < pos.count; i++) { P.push([pos.getX(i), pos.getY(i), pos.getZ(i)]); U.push([uv.getX(i), uv.getY(i)]); N.push([nrm.getX(i), nrm.getY(i), nrm.getZ(i)]); }
  const inv = new THREE.Matrix4().copy(m.matrixWorld).invert();
  const ear = {};
  for (const c of m.children) if (c.userData.isEarMesh) { c.updateMatrixWorld(true); ear[c.userData.side] = new THREE.Box3().setFromObject(c).applyMatrix4(inv); }
  if (!ear.R || !ear.L) throw new Error('The head has no ears to cut at.');
  for (const c of m.children.slice()) if (c.userData.isEarMesh) { m.remove(c); c.geometry.dispose(); }
  const L = S.lm3, mm = core.mm2u(1);
  const zT = { R: ear.R.max.z + CUT.fwd * mm, L: ear.L.max.z + CUT.fwd * mm };
  const men = L[152], gR = L[172], gL = L[397];
  const n0 = new THREE.Vector3().subVectors(new THREE.Vector3(...gR), new THREE.Vector3(...men)).cross(new THREE.Vector3().subVectors(new THREE.Vector3(...gL), new THREE.Vector3(...men))).normalize();
  if (n0.y < 0) n0.negate();
  const d0 = n0.dot(new THREE.Vector3(...men)) - CUT.under * mm;
  const yT0 = (L[33][1] + L[263][1]) / 2 + CUT.top * mm;
  const side = p => (p[0] > 0 ? 'L' : 'R');
  // Behind the face, the top follows the face's own outline up to the upper temple, and a
  // straight line from there down to just above eye level at the tragus line, so it meets
  // the forehead's edge with no step.
  const lineOf = s => {
    const pts = [[zT[s], yT0], ...CUT.rim.filter(i => side(L[i]) === s).map(i => [L[i][2], L[i][1] + CUT.over * mm]).filter(q => q[0] > zT[s] && q[1] > yT0)].sort((a, b) => a[0] - b[0]);
    const out = [pts[0]];
    for (const q of pts.slice(1)) if (q[1] >= out[out.length - 1][1]) out.push(q);
    return out;
  };
  const line = { R: lineOf('R'), L: lineOf('L') };
  const topY = p => {
    const ln = line[side(p)], z = p[2];
    if (z <= ln[0][0]) return ln[0][1];
    for (let k = 1; k < ln.length; k++) if (z <= ln[k][0]) { const a = ln[k - 1], b = ln[k]; return a[1] + (b[1] - a[1]) * (z - a[0]) / (b[0] - a[0] || 1); }
    // In front of the outline the skin lies under the face, and the old low top keeps it from showing through the forehead.
    return Math.min(ln[ln.length - 1][1], yT0 + CUT.topmax * mm);
  };
  const fns = [
    p => p[2] - zT[side(p)],
    p => n0.x * p[0] + n0.y * p[1] + n0.z * p[2] - d0,
    p => topY(p) - p[1],
  ];
  const lerpV = (i, j, t) => {
    P.push(P[i].map((v, k) => v + (P[j][k] - v) * t)); U.push(U[i].map((v, k) => v + (U[j][k] - v) * t));
    const nn = N[i].map((v, k) => v + (N[j][k] - v) * t), l = Math.hypot(...nn) || 1; N.push(nn.map(v => v / l));
    return P.length - 1;
  };
  const clipPoly = (poly, f) => {
    const res = [];
    for (let k = 0; k < poly.length; k++) {
      const a = poly[k], b = poly[(k + 1) % poly.length], fa = f(P[a]), fb = f(P[b]);
      if (fa >= 0) res.push(a);
      if ((fa >= 0) !== (fb >= 0)) res.push(lerpV(a, b, fa / (fa - fb)));
    }
    return res;
  };
  const group = i => g.groups.find(x => x.materialIndex === i);
  const keepGroup = gr => {
    const o = [];
    for (let t = gr.start; t < gr.start + gr.count; t += 3) {
      let poly = [I[t], I[t + 1], I[t + 2]];
      for (const f of fns) { poly = clipPoly(poly, f); if (poly.length < 3) break; }
      for (let k = 1; k + 1 < poly.length; k++) o.push(poly[0], poly[k], poly[k + 1]);
    }
    return o;
  };
  const fc = group(0), fr = group(1), sk = group(2);
  const faceIdx = Array.from(I.slice(fc.start, fc.start + fc.count));
  const fringeIdx = keepGroup(fr), skinIdx = keepGroup(sk);
  flattenSlivers(fringeIdx, P, U, N);
  const ng = compactGeometry(P, U, N, [faceIdx, fringeIdx, skinIdx]);
  const mats = Array.isArray(m.material) ? m.material : [m.material];
  m.geometry.dispose();
  m.geometry = ng;
  m.material = [mats[0], mats[1], mats[2]];
  return { skinKept: skinIdx.length / 3, skinWas: sk.count / 3, fringe: fringeIdx.length / 3, slivers: flattenSlivers.last };
}

// A fringe sliver is a long thin face triangle bridging the face rim and the skin. Its
// vertex normals point the way the face does there while the sliver itself lies along the
// cheek, so the light caught it as a pale streak. A sliver more than 45 degrees off its
// vertex normals gets vertices of its own with the sliver's own normal.
function flattenSlivers(idx, P, U, N) {
  const cos45 = Math.cos(45 * Math.PI / 180);
  let n = 0;
  for (let t = 0; t < idx.length; t += 3) {
    const a = idx[t], b = idx[t + 1], c = idx[t + 2];
    const e1 = [P[b][0] - P[a][0], P[b][1] - P[a][1], P[b][2] - P[a][2]], e2 = [P[c][0] - P[a][0], P[c][1] - P[a][1], P[c][2] - P[a][2]];
    const fn = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
    const fl = Math.hypot(...fn) || 1; fn[0] /= fl; fn[1] /= fl; fn[2] /= fl;
    const vn = [0, 1, 2].map(k => N[a][k] + N[b][k] + N[c][k]), vl = Math.hypot(...vn) || 1;
    if ((fn[0] * vn[0] + fn[1] * vn[1] + fn[2] * vn[2]) / vl >= cos45) continue;
    for (let k = 0; k < 3; k++) { const i = idx[t + k]; P.push(P[i].slice()); U.push(U[i].slice()); N.push(fn.slice()); idx[t + k] = P.length - 1; }
    n++;
  }
  flattenSlivers.last = n;
}

// Only the vertices the kept triangles use, in a fresh geometry with three groups.
function compactGeometry(P, U, N, groupsIdx) {
  const map = new Map(), pos = [], uv = [], nrm = [];
  const remap = i => { let j = map.get(i); if (j === undefined) { j = pos.length / 3; map.set(i, j); pos.push(...P[i]); uv.push(...U[i]); nrm.push(...N[i]); } return j; };
  const idx = []; const groups = [];
  for (let gi = 0; gi < groupsIdx.length; gi++) {
    const start = idx.length;
    for (const i of groupsIdx[gi]) idx.push(remap(i));
    groups.push({ start, count: idx.length - start, materialIndex: gi });
  }
  const ng = new THREE.BufferGeometry();
  ng.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  ng.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  ng.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  ng.setIndex(idx);
  for (const gr of groups) ng.addGroup(gr.start, gr.count, gr.materialIndex);
  ng.computeBoundingBox(); ng.computeBoundingSphere();
  return ng;
}

// ---------- solid skin ----------
// Every texel under a kept skin or fringe triangle, and under face triangles below eye
// level + 6 mm, gets full alpha. See-through texels and texels no camera saw take their
// colour from the seen skin around them, then from any solid texel.
function solidSkin(m) {
  const g = m.geometry, mats = m.material, tex = mats[0].map, img = tex.image;
  const W = img.width, H = img.height;
  const cv = img instanceof HTMLCanvasElement ? img : (() => { const c = document.createElement('canvas'); c.width = W; c.height = H; c.getContext('2d').drawImage(img, 0, 0); return c; })();
  const ctx = cv.getContext('2d'), id = ctx.getImageData(0, 0, W, H), D = id.data;
  const mk = document.createElement('canvas'); mk.width = W; mk.height = H;
  const mc = mk.getContext('2d');
  mc.fillStyle = '#fff'; mc.strokeStyle = '#fff'; mc.lineWidth = ALPHA.pad; mc.lineJoin = 'round';
  const pos = g.attributes.position, uv = g.attributes.uv, I = g.index.array, L = S.lm3;
  const yCut = (L[33][1] + L[263][1]) / 2 + ALPHA.up * core.mm2u(1);
  const fy = tex.flipY !== false;
  const px = i => [uv.getX(i) * W, (fy ? 1 - uv.getY(i) : uv.getY(i)) * H];
  let n = 0;
  for (const gr of g.groups) {
    if (gr.materialIndex > 2) continue;
    for (let t = gr.start; t < gr.start + gr.count; t += 3) {
      const a = I[t], b = I[t + 1], c = I[t + 2];
      if (gr.materialIndex === 0 && Math.max(pos.getY(a), pos.getY(b), pos.getY(c)) > yCut) continue;
      const A = px(a), B = px(b), C = px(c);
      mc.beginPath(); mc.moveTo(...A); mc.lineTo(...B); mc.lineTo(...C); mc.closePath(); mc.fill(); mc.stroke(); n++;
    }
  }
  const md = mc.getImageData(0, 0, W, H).data;
  const need = new Uint8Array(W * H);
  const SE = core.atlasState.seen;
  const seenAt = q => { if (!SE) return 1; const x = q % W, y = (q - x) / W; return SE.seen[(H - 1 - y) * W + x]; };
  let set = 0, unseen = 0;
  for (let q = 0; q < W * H; q++) if (md[q * 4 + 3] > 0) {
    const sn = seenAt(q);
    if (D[q * 4 + 3] < 128 || !sn) { need[q] = 1; if (!sn) unseen++; }
    if (D[q * 4 + 3] < 255) { D[q * 4 + 3] = 255; set++; }
  }
  const grow = (passes, offs, fromSeen) => {
    for (let pass = 0; pass < passes; pass++) {
      const fill = [];
      for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
        const q = y * W + x; if (!need[q]) continue;
        let r = 0, gg = 0, bb = 0, c = 0;
        for (const o of offs) { const z = q + o; if (!need[z] && D[z * 4 + 3] >= 128 && (!fromSeen || seenAt(z))) { r += D[z * 4]; gg += D[z * 4 + 1]; bb += D[z * 4 + 2]; c++; } }
        if (c) fill.push(q, r / c, gg / c, bb / c);
      }
      if (!fill.length) return pass;
      for (let k = 0; k < fill.length; k += 4) { const q = fill[k]; D[q * 4] = fill[k + 1]; D[q * 4 + 1] = fill[k + 2]; D[q * 4 + 2] = fill[k + 3]; need[q] = 0; }
    }
    return passes;
  };
  grow(200, [-1, 1, -W, W, -W - 1, -W + 1, W - 1, W + 1], true);
  grow(400, [-1, 1, -W, W], false);
  let left = 0;
  for (let q = 0; q < W * H; q++) left += need[q];
  ctx.putImageData(id, 0, 0);
  for (const x of mats) if (x.map === tex && cv !== img) x.map.image = cv;
  tex.needsUpdate = true;
  return { W, H, tris: n, set, unseen, left, canvas: cv };
}

// ---------- the per-camera pass ----------
// Runs on the bake's blend with each camera's own sample and weight beside it.
// 1. A lateral photo paints only the shell strip in front of the cut, and only where the
//    front and 45 cameras barely reach. The face chart is blended from the other cameras.
// 2. A texel no camera reached with any weight is marked unseen, so the solid-skin pass
//    fills it from seen skin instead of leaving a grazing-angle smear.
// 3. Wall samples are rejected (below), away from the eyes and mouth.
export function rejectWallSamples(px, perCam, W, H, photos) {
  const n = perCam.length;
  if (n < 2) return false;
  const isLat = photos.map(p => p.role === 'r90' || p.role === 'l90');
  const half = W >> 1, anyLat = isLat.some(Boolean);
  // A lateral sample outside its gate is dropped here, so the wall pass below never sees it.
  for (let i = 0; i < n; i++) if (isLat[i]) { const gt = lateralGate(photos[i], W, H), a = perCam[i]; for (let q = 0; q < W * H; q++) if (gt[q] < 255) a[q * 4 + 3] = Math.round(a[q * 4 + 3] * gt[q] / 255); }
  let relit = 0, dark = 0;
  {
    for (let q = 0; q < W * H; q++) {
      const o = q * 4;
      if (px[o + 3] <= 8) continue;
      const x = q % W;
      let wo = 0, wl = 0;
      for (let i = 0; i < n; i++) { const w = perCam[i][o + 3] / 255; if (isLat[i]) wl += w; else wo += w; }
      // With a lateral in the bake, its sample is in px even where the gate dropped it, so blend again.
      if (wl < 0.004 && !anyLat) { if (wo < LATERAL.minWeight) { px[o + 3] = 0; dark++; } continue; }
      const k = x < half ? 0 : Math.max(0, Math.min(1, 1 - wo / LATERAL.handoff));
      let r = 0, g = 0, b = 0, ws = 0;
      for (let i = 0; i < n; i++) {
        if (isLat[i] && k < 1) perCam[i][o + 3] = Math.round(perCam[i][o + 3] * k);
        const w = perCam[i][o + 3] / 255;
        if (w < 0.004) continue;
        r += perCam[i][o] * w; g += perCam[i][o + 1] * w; b += perCam[i][o + 2] * w; ws += w;
      }
      if (ws < LATERAL.minWeight) { px[o + 3] = 0; dark++; continue; }
      px[o] = r / ws; px[o + 1] = g / ws; px[o + 2] = b / ws; relit++;
    }
  }
  const prot = protectMask(W, H);
  const band = rimBand(px, W, H, OUTLIER.rim);
  const r = rejectWall(px, perCam, W, H, prot, band);
  rejectWallSamples.last = { ...r, n, relit, dark };
  return true;
}

// Where a lateral photo may paint: shell texels whose point, seen from that photo's camera,
// falls inside the face outline MediaPipe found in the photo itself. The fitted camera can
// be off by several degrees on a profile, which put the ear on the strip in front of it;
// the outline is read from the pixels, so it stops in front of the real ear whatever the
// camera says. margin is a share of the outline's height: above 0 pulls the edge in.
function lateralGate(photo, W, H) {
  const out = new Uint8Array(W * H);
  const lm = photo.lm2, mesh = core.targets[0];
  const cam = lm && mesh && core.projCameraFor(photo);
  if (!cam) return out;
  const MW = 1024, MH = Math.round(MW * photo.img.naturalHeight / photo.img.naturalWidth);
  const cv = document.createElement('canvas'); cv.width = MW; cv.height = MH;
  const g = cv.getContext('2d', { willReadFrequently: true });
  g.fillStyle = '#000'; g.fillRect(0, 0, MW, MH);
  let y0 = 1, y1 = 0;
  for (const k of FACE_OVAL) { y0 = Math.min(y0, lm[k].y); y1 = Math.max(y1, lm[k].y); }
  // Feathered by a hundredth of the face's height, so the hand-over has no stair-steps.
  g.filter = `blur(${Math.max(1, 0.01 * (y1 - y0) * MH).toFixed(1)}px)`;
  g.beginPath();
  FACE_OVAL.forEach((k, i) => { const q = lm[k]; if (i) g.lineTo(q.x * MW, q.y * MH); else g.moveTo(q.x * MW, q.y * MH); });
  g.closePath(); g.fillStyle = '#fff'; g.fill();
  const m = LATERAL.margin();
  if (m) { g.lineWidth = 2 * Math.abs(m) * (y1 - y0) * MH; g.lineJoin = 'round'; g.strokeStyle = m > 0 ? '#000' : '#fff'; g.stroke(); }
  const md = g.getImageData(0, 0, MW, MH).data;
  const inside = (x, y) => { const X = x * MW | 0, Y = y * MH | 0; return X >= 0 && Y >= 0 && X < MW && Y < MH ? md[4 * (Y * MW + X)] : 0; };

  mesh.updateMatrixWorld(true);
  const geo = mesh.geometry, P = geo.attributes.position, uv = geo.attributes.uv, I = geo.index.array;
  const nv = P.count, sx = new Float32Array(nv), sy = new Float32Array(nv), ok = new Uint8Array(nv);
  const v = new THREE.Vector3();
  for (let i = 0; i < nv; i++) {
    v.fromBufferAttribute(P, i).applyMatrix4(mesh.matrixWorld).project(cam);
    sx[i] = (v.x + 1) / 2; sy[i] = (1 - v.y) / 2; ok[i] = v.z < 1 ? 1 : 0;
  }
  const half = W >> 1;
  for (let t = 0; t < I.length; t += 3) {
    const a = I[t], b = I[t + 1], c = I[t + 2];
    if (!ok[a] || !ok[b] || !ok[c]) continue;
    const ax = uv.getX(a) * W, ay = uv.getY(a) * H, bx = uv.getX(b) * W, by = uv.getY(b) * H, cx = uv.getX(c) * W, cy = uv.getY(c) * H;
    if (Math.max(ax, bx, cx) < half) continue;
    const den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
    if (Math.abs(den) < 1e-9) continue;
    const X0 = Math.max(half, Math.floor(Math.min(ax, bx, cx))), X1 = Math.min(W - 1, Math.ceil(Math.max(ax, bx, cx)));
    const Y0 = Math.max(0, Math.floor(Math.min(ay, by, cy))), Y1 = Math.min(H - 1, Math.ceil(Math.max(ay, by, cy)));
    for (let y = Y0; y <= Y1; y++) for (let x = X0; x <= X1; x++) {
      const px = x + 0.5, py = y + 0.5;
      const l1 = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / den, l2 = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / den, l3 = 1 - l1 - l2;
      if (l1 < -0.02 || l2 < -0.02 || l3 < -0.02) continue;
      const gv = inside(l1 * sx[a] + l2 * sx[b] + l3 * sx[c], l1 * sy[a] + l2 * sy[b] + l3 * sy[c]);
      if (gv > out[y * W + x]) out[y * W + x] = gv;
    }
  }
  // Grow by two texels so the bake's padding around each triangle keeps its colour.
  for (let pass = 0; pass < 2; pass++) {
    const prev = out.slice();
    for (let y = 1; y < H - 1; y++) for (let x = half + 1; x < W - 1; x++) {
      const q = y * W + x;
      if (!prev[q]) out[q] = Math.max(prev[q - 1], prev[q + 1], prev[q - W], prev[q + W]);
    }
  }
  return out;
}

// Texels under the eye and mouth rings, grown by a few millimetres.
function protectMask(W, H) {
  const m = new Uint8Array(W * H);
  const mesh = core.targets[0];
  const uv = mesh && mesh.geometry.attributes.uv;
  if (!uv) return m;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d', { willReadFrequently: true });
  g.fillStyle = '#fff'; g.strokeStyle = '#fff'; g.lineWidth = PROTECT.grow * 2; g.lineJoin = 'round';
  for (const ring of PROTECT.rings) {
    if (ring.some(i => i >= uv.count)) continue;
    g.beginPath();
    ring.forEach((i, k) => { const x = uv.getX(i) * W, y = uv.getY(i) * H; if (k) g.lineTo(x, y); else g.moveTo(x, y); });
    g.closePath(); g.fill(); g.stroke();
  }
  const d = g.getImageData(0, 0, W, H).data;
  for (let q = 0; q < W * H; q++) if (d[q * 4 + 3] > 0) m[q] = 1;
  return m;
}

// Where the wall can show: the whole shell chart, and the face chart within `band` texels
// of an unpainted texel, which is the face's silhouette as the front camera saw it.
function rimBand(px, W, H, band) {
  const half = W >> 1, FAR = 1e9;
  const d = new Float32Array(half * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < half; x++) d[y * half + x] = px[4 * (y * W + x) + 3] > 8 ? FAR : 0;
  const relax = (y, x, dy, dx, cost) => {
    const yy = y + dy, xx = x + dx;
    if (yy < 0 || yy >= H || xx < 0 || xx >= half) return;
    const c = d[yy * half + xx] + cost;
    if (c < d[y * half + x]) d[y * half + x] = c;
  };
  for (let y = 0; y < H; y++) for (let x = 0; x < half; x++) { relax(y, x, -1, 0, 1); relax(y, x, 0, -1, 1); relax(y, x, -1, -1, 1.414); relax(y, x, -1, 1, 1.414); }
  for (let y = H - 1; y >= 0; y--) for (let x = half - 1; x >= 0; x--) { relax(y, x, 1, 0, 1); relax(y, x, 0, 1, 1); relax(y, x, 1, 1, 1.414); relax(y, x, 1, -1, 1.414); }
  const m = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) m[y * W + x] = x >= half || d[y * half + x] <= band ? 1 : 0;
  return m;
}

// ---------- wall samples ----------
// Where the mesh is a little wider than the real cheek, the front photo samples the wall
// behind the patient: much paler and greyer than the skin around it. Two checks:
// 1. Where two or more photos see a texel, a sample far paler than the weighted blend of
//    the others is dropped and the texel is blended again from the rest.
// 2. A texel only one photo sees is compared with the skin nearby that two or more photos
//    agree on. Far paler and greyer than that, it is marked unseen, and the bake fills it
//    from its neighbours like any texel no camera reached.
// Both run only where the wall can show (rimBand) and never on the eyes or mouth.
function rejectWall(px, perCam, W, H, prot, band) {
  const n = perCam.length;
  let changed = 0, flagged = 0;
  const c = new Float32Array(n * 4);
  const seenN = new Uint8Array(W * H);
  const lum = v => (v[0] + v[1] + v[2]) / 3, sat = v => Math.max(v[0], v[1], v[2]) - Math.min(v[0], v[1], v[2]);
  for (let q = 0; q < W * H; q++) {
    const o = q * 4;
    if (px[o + 3] <= 8) continue;
    let seen = 0, wsum = 0;
    for (let i = 0; i < n; i++) {
      const s = perCam[i], w = s[o + 3] / 255;
      c[i * 4 + 3] = w >= OUTLIER.minWeight ? w : 0;
      if (c[i * 4 + 3]) { seen++; wsum += w; c[i * 4] = s[o]; c[i * 4 + 1] = s[o + 1]; c[i * 4 + 2] = s[o + 2]; }
    }
    seenN[q] = seen;
    if (seen < 2 || prot[q] || !band[q]) continue;
    let worst = -1, worstD = 0;
    for (let i = 0; i < n; i++) {
      const wi = c[i * 4 + 3]; if (!wi) continue;
      const rest = wsum - wi; if (rest <= wi) continue; // only a sample the other cameras outweigh
      let r = 0, g = 0, b = 0;
      for (let j = 0; j < n; j++) { if (j === i) continue; const wj = c[j * 4 + 3]; if (!wj) continue; r += c[j * 4] * wj; g += c[j * 4 + 1] * wj; b += c[j * 4 + 2] * wj; }
      r /= rest; g /= rest; b /= rest;
      const me = [c[i * 4], c[i * 4 + 1], c[i * 4 + 2]], them = [r, g, b];
      const d = Math.hypot(me[0] - r, me[1] - g, me[2] - b);
      if (d > OUTLIER.dist && lum(me) > lum(them) + OUTLIER.pale && sat(me) < sat(them) && d > worstD) { worst = i; worstD = d; }
    }
    if (worst < 0) continue;
    let r = 0, g = 0, b = 0, ws = 0;
    for (let j = 0; j < n; j++) { if (j === worst) continue; const wj = c[j * 4 + 3]; if (!wj) continue; r += c[j * 4] * wj; g += c[j * 4 + 1] * wj; b += c[j * 4 + 2] * wj; ws += wj; }
    px[o] = r / ws; px[o + 1] = g / ws; px[o + 2] = b / ws;
    changed++;
  }
  // Summed-area tables of the texels two or more cameras agree on, for the local comparison.
  const SW = W + 1, N1 = SW * (H + 1);
  const M = [new Float64Array(N1), new Float64Array(N1), new Float64Array(N1), new Float64Array(N1)];
  for (let y = 1; y <= H; y++) {
    const rm = [0, 0, 0, 0];
    for (let x = 1; x <= W; x++) {
      const q = (y - 1) * W + (x - 1), o = q * 4;
      if (seenN[q] >= 2) { rm[0] += px[o]; rm[1] += px[o + 1]; rm[2] += px[o + 2]; rm[3]++; }
      const k = y * SW + x, up = (y - 1) * SW + x;
      for (let i = 0; i < 4; i++) M[i][k] = M[i][up] + rm[i];
    }
  }
  const R = OUTLIER.radius;
  const box = (t, x0, y0, x1, y1) => t[y1 * SW + x1] - t[y0 * SW + x1] - t[y1 * SW + x0] + t[y0 * SW + x0];
  // On the shell no second camera reaches the strip in front of the ear, so the cheek
  // tone the front photo measured stands in for the local reference there.
  const tone = core.skinToneFromFront(), toneRef = [(tone >> 16) & 255, (tone >> 8) & 255, tone & 255];
  const half = W >> 1;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const q = y * W + x;
    if (seenN[q] !== 1 || prot[q] || !band[q]) continue;
    const x0 = Math.max(0, x - R), y0 = Math.max(0, y - R), x1 = Math.min(W, x + R + 1), y1 = Math.min(H, y + R + 1);
    const cm = box(M[3], x0, y0, x1, y1);
    if (cm < OUTLIER.minRef && x < half) continue;
    const ref = cm < OUTLIER.minRef ? toneRef : [box(M[0], x0, y0, x1, y1) / cm, box(M[1], x0, y0, x1, y1) / cm, box(M[2], x0, y0, x1, y1) / cm];
    const o = q * 4, me = [px[o], px[o + 1], px[o + 2]];
    if (lum(me) > lum(ref) + OUTLIER.pale && sat(me) < sat(ref) * 0.85 && Math.hypot(me[0] - ref[0], me[1] - ref[1], me[2] - ref[2]) > OUTLIER.dist) { px[o + 3] = 0; flagged++; }
  }
  return { changed, flagged };
}

export { meshBlob, parseMesh, atlasBlobs, atlasFromFiles } from './head-files.mjs';
export function atlasCanvas(mesh) { return mesh.material[0].map.image; }
