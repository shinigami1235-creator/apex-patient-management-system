// The stored form of a head: one binary mesh file, a colour JPEG and an alpha PNG.
// The mesh as one binary file: a JSON header, then positions, normals, uvs and indices.
export function meshBlob(mesh, lm3) {
  const g = mesh.geometry;
  const pos = g.attributes.position.array, nrm = g.attributes.normal.array, uv = g.attributes.uv.array;
  const idx = g.index.array instanceof Uint32Array ? g.index.array : Uint32Array.from(g.index.array);
  const header = { format: 'cygnus-head', v: 1, verts: pos.length / 3, tris: idx.length / 3, groups: g.groups.map(x => ({ start: x.start, count: x.count, materialIndex: x.materialIndex })), lm3: lm3 ? lm3.map(p => p.map(v => +v.toFixed(5))) : null };
  const hb = new TextEncoder().encode(JSON.stringify(header));
  const pad = (4 - (hb.length % 4)) % 4;
  const head = new Uint8Array(8 + hb.length + pad);
  new DataView(head.buffer).setUint32(0, 0x48454144, true); // HEAD
  new DataView(head.buffer).setUint32(4, hb.length + pad, true);
  head.set(hb, 8);
  return new Blob([head, new Float32Array(pos), new Float32Array(nrm), new Float32Array(uv), idx], { type: 'application/octet-stream' });
}

export function parseMesh(buf) {
  const dv = new DataView(buf);
  if (dv.getUint32(0, true) !== 0x48454144) throw new Error('The head file is not readable.');
  const hl = dv.getUint32(4, true);
  const header = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 8, hl)).replace(/\0+$/, ''));
  let off = 8 + hl;
  const take = (T, n) => { const a = new T(buf, off, n); off += n * T.BYTES_PER_ELEMENT; return a; };
  const pos = take(Float32Array, header.verts * 3), nrm = take(Float32Array, header.verts * 3), uv = take(Float32Array, header.verts * 2), idx = take(Uint32Array, header.tris * 3);
  return { header, pos, nrm, uv, idx };
}

// The texture as a colour JPEG and an alpha PNG, since a JPEG has no alpha and a PNG of
// a 4096 by 2048 photo texture is far too large.
export async function atlasBlobs(canvas) {
  const W = canvas.width, H = canvas.height;
  const src = canvas.getContext('2d').getImageData(0, 0, W, H);
  const col = document.createElement('canvas'); col.width = W; col.height = H;
  const alp = document.createElement('canvas'); alp.width = W; alp.height = H;
  const cd = col.getContext('2d').createImageData(W, H), ad = alp.getContext('2d').createImageData(W, H);
  const s = src.data, c = cd.data, a = ad.data;
  for (let i = 0; i < W * H; i++) {
    c[4 * i] = s[4 * i]; c[4 * i + 1] = s[4 * i + 1]; c[4 * i + 2] = s[4 * i + 2]; c[4 * i + 3] = 255;
    a[4 * i] = a[4 * i + 1] = a[4 * i + 2] = s[4 * i + 3]; a[4 * i + 3] = 255;
  }
  col.getContext('2d').putImageData(cd, 0, 0); alp.getContext('2d').putImageData(ad, 0, 0);
  const toBlob = (cv, type, q) => new Promise(r => cv.toBlob(r, type, q));
  return { atlas: await toBlob(col, 'image/jpeg', 0.92), alpha: await toBlob(alp, 'image/png') };
}

// The atlas back into one canvas from the two files.
function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('A head file could not be opened.'));
    img.src = src;
  });
}

// max caps the width: a tablet gets the atlas at 2048 wide, a quarter of the memory.
export async function atlasFromFiles(atlasUrl, alphaUrl, { max = 0 } = {}) {
  const [ci, ai] = await Promise.all([loadImage(atlasUrl), loadImage(alphaUrl)]);
  const k = max && ci.naturalWidth > max ? max / ci.naturalWidth : 1;
  const W = Math.round(ci.naturalWidth * k), H = Math.round(ci.naturalHeight * k);
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  ctx.drawImage(ci, 0, 0, W, H);
  const id = ctx.getImageData(0, 0, W, H);
  const ac = document.createElement('canvas'); ac.width = W; ac.height = H;
  const actx = ac.getContext('2d'); actx.drawImage(ai, 0, 0, W, H);
  const ad = actx.getImageData(0, 0, W, H).data;
  for (let i = 0; i < W * H; i++) id.data[4 * i + 3] = ad[4 * i];
  ctx.putImageData(id, 0, 0);
  return cv;
}

