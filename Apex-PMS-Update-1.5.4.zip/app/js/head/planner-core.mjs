// Head build core, taken from Gid's Facial Design Planner (face-planner.html v36).
// This file is generated: the planner's fit, head shell and atlas bake with the page,
// marking, simulation and reporting code left out. Settings the planner read from its
// controls are fixed in UI below. Edit the planner and regenerate rather than editing here.
import * as THREE from '../../vendor/three.module.min.js';

const CFG = {
  canvas: null,
  visionBundle: '/vendor/tasks-vision/vision_bundle.mjs',
  visionWasm: '/vendor/tasks-vision/wasm',
  landmarkerModel: '/vendor/face_landmarker.task',
  delegate: 'GPU',
  earMask: false,     // the photographs' ears are not masked: masking smeared the cheek in front of them
  facingMin: 0.08,
  atlasW: 4096,
  perCamera: null,    // (blend, perCamera[], w, h, photos) => true when it changed the blend
  facePow: 16,        // how strongly each texel prefers the photo that faces it best (the planner used 3)
  photoMax: 2048,     // long side each photo is cut to before the bake
  usm: { r: 2, amt: 0.7 }, // unsharp mask on the finished skin; null turns it off
};
export function configure(o) { Object.assign(CFG, o); }

const KP_DEFS = [
  { id:'forehead',  label:'Forehead (upper midline)', mp:10  },
  { id:'nasion',    label:'Nasion (root of nose)',    mp:168 },
  { id:'noseTip',   label:'Nose tip',                 mp:1   },
  { id:'subnasale', label:'Subnasale (under nose)',   mp:2   },
  { id:'chin',      label:'Chin (menton)',            mp:152 },
  { id:'browR',     label:'Right brow (mid)',         mp:105 },
  { id:'browL',     label:'Left brow (mid)',          mp:334 },
  { id:'canthOutR', label:'Right eye — outer corner', mp:33  },
  { id:'canthInR',  label:'Right eye — inner corner', mp:133 },
  { id:'canthInL',  label:'Left eye — inner corner',  mp:362 },
  { id:'canthOutL', label:'Left eye — outer corner',  mp:263 },
  { id:'mouthR',    label:'Right mouth corner',       mp:61  },
  { id:'mouthL',    label:'Left mouth corner',        mp:291 },
  { id:'jawR',      label:'Right jaw angle (gonion)', mp:172 },
  { id:'jawL',      label:'Left jaw angle (gonion)',  mp:397 },
];

function viewDir(az, el){
  const a = az*Math.PI/180, e = el*Math.PI/180;
  return [Math.sin(a)*Math.cos(e), Math.sin(e), Math.cos(a)*Math.cos(e)];
}

const VIEW_DEFS = [
  { id:'front', label:'Front',        short:'FRONT',  az:  0, el:  0, geo:true,  core:true,  hint:'Level, relaxed' },
  { id:'r45',   label:'Right ¾',      short:'R 45°',  az:-45, el:  0, geo:true,  core:true,  hint:'45° to patient right' },
  { id:'r90',   label:'Right profile',short:'R 90°',  az:-90, el:  0, geo:true,  core:true,  hint:'True profile' },
  { id:'l45',   label:'Left ¾',       short:'L 45°',  az: 45, el:  0, geo:true,  core:true,  hint:'45° to patient left' },
  { id:'l90',   label:'Left profile', short:'L 90°',  az: 90, el:  0, geo:true,  core:true,  hint:'True profile' },
  { id:'up',    label:'Submental',    short:'SUBMENT',az:  0, el:-55, geo:true,  core:true,  hint:'From below, chin up' },
  { id:'down',  label:'Vertex',       short:'VERTEX', az:  0, el: 55, geo:true,  core:true,  hint:'From above, chin down' },
  { id:'smile', label:'Smiling',      short:'SMILE',  az:  0, el:  0, geo:false, core:false, hint:'Full smile, front' },
  { id:'brow',  label:'Brow raised',  short:'BROW',   az:  0, el:  0, geo:false, core:false, hint:'Brows up, front' },
].map(v => ({ ...v, dir: viewDir(v.az, v.el) }));

const VIEW_BY_ID = Object.fromEntries(VIEW_DEFS.map(v => [v.id, v]));

const S = {
  photos: [], frontId: null, refId: null,
  // Multi-view fit: the fitted landmark positions, the centre/scale map that
  // took them into model space, and what the fit cost.
  fitPos: null, lmNorm: null, fitInfo: null, shellInfo: null,
  markers: [], sel: null, tool: 'orbit', proc: 'ha',
  mmPerUnit: null, ruler: null,
  pending: [], mode: null,
  hiddenProcs: new Set(), seq: 1,
  rawLm: null, lm3: null, keyPts: null,
  dzOff: new Set(), kpMode: null, kpQueue: [],
  compare: null,
  basePos: null,      // Float32Array — undeformed vertex positions
  sculpt: null,       // Float32Array — manual displacement per vertex
  morph: 0,
  volOn: false,
  simShown: null,     // ISO timestamp when marked as shown to a patient
  calib: [],          // calibration records
  prices: {},         // { procId: { unit:Number, flat:Number } }
  currency: '฿',
  visits: [],         // labelled snapshots — visits and plan variants
  patient: { name:'', age:'', sex:'', proc:'', date:'' },
  guideShots: {},     // angle id -> dataURL captured from this patient's model
  testMode: false, pendingTestMode: false,
  poseMode: null,     // photo id currently being marked for alignment
  poseQueue: [],
  tplCal: {},         // areaId -> [{dx,dy}] — this clinic's own template offsets
  kpPresets: {},      // mesh signature -> a saved set of key points
  kpArm: null,        // landmark armed for placing, out of sequence
  lmImages: {},       // landmark id -> a reference picture the clinic supplied
  muted: new Set(),   // markers excluded from the simulation, dose kept
  isolate: null,      // show only this marker's contribution
  wipe: 0,            // 0 = off; otherwise the wipe line as a fraction of width
};

// The planner read these from controls on its page. Here they are fixed, and any other
// control it asks for is a dummy that takes writes and answers nothing.
const UI = { '#projOcclude': { checked: true }, '#hullOn': { checked: true }, '#poseFov': { value: '45' }, '#hlH': { value: '45' }, '#hlT': { value: '40' }, '#optWire': { checked: false } };
const DUMMY_CLASSES = { add() {}, remove() {}, toggle() {}, contains() { return false; } };
const $ = s => UI[s] || { classList: DUMMY_CLASSES, style: {}, value: undefined, checked: false, innerHTML: '', textContent: '', disabled: false, dataset: {} };

const mm2u = mm => S.mmPerUnit ? mm / S.mmPerUnit : mm * 0.02;

const renderer = new THREE.WebGLRenderer({ canvas: CFG.canvas || document.createElement('canvas'), antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1);
renderer.outputColorSpace = THREE.SRGBColorSpace;

function makeScene(){
  const sc = new THREE.Scene();
  sc.background = new THREE.Color(0x0b0e12);
  sc.add(new THREE.HemisphereLight(0xd9e6f2, 0x1b1f26, 1.05));
  const k = new THREE.DirectionalLight(0xffffff, 1.5); k.position.set(1.4, 1.6, 3);
  const f = new THREE.DirectionalLight(0xbcd4ea, 0.55); f.position.set(-2.2, 0.4, 1.2);
  const r = new THREE.DirectionalLight(0x9fb6cc, 0.4);  r.position.set(0, 1.2, -3);
  sc.add(k, f, r);
  return sc;
}

const scene = makeScene();

const camera = new THREE.PerspectiveCamera(32, 1, 0.01, 100);

const modelRoot = new THREE.Group(), annoRoot = new THREE.Group();

const gridRoot = new THREE.Group(), dangerRoot = new THREE.Group();

const kpRoot = new THREE.Group(), rulerRoot = new THREE.Group();

const phiRoot = new THREE.Group();
scene.add(modelRoot, annoRoot, gridRoot, dangerRoot, kpRoot, rulerRoot, phiRoot);

let targets = [], wireMeshes = [], baseMats = [];

function resize(){}

function delaunay(P){
  const n = P.length;
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  for (const p of P){ minX=Math.min(minX,p.x); minY=Math.min(minY,p.y); maxX=Math.max(maxX,p.x); maxY=Math.max(maxY,p.y); }
  const dmax = Math.max(maxX-minX, maxY-minY) || 1, mx=(minX+maxX)/2, my=(minY+maxY)/2;
  const pts = P.concat([{x:mx-20*dmax,y:my-dmax},{x:mx,y:my+20*dmax},{x:mx+20*dmax,y:my-dmax}]);
  const withR = t => {
    const a=pts[t[0]], b=pts[t[1]], c=pts[t[2]];
    const d = 2*(a.x*(b.y-c.y) + b.x*(c.y-a.y) + c.x*(a.y-b.y));
    if (Math.abs(d) < 1e-14) return { x:0,y:0,r2:Infinity };
    const aa=a.x*a.x+a.y*a.y, bb=b.x*b.x+b.y*b.y, cc=c.x*c.x+c.y*c.y;
    const ux=(aa*(b.y-c.y)+bb*(c.y-a.y)+cc*(a.y-b.y))/d;
    const uy=(aa*(c.x-b.x)+bb*(a.x-c.x)+cc*(b.x-a.x))/d;
    return { x:ux, y:uy, r2:(a.x-ux)**2+(a.y-uy)**2 };
  };
  let tris=[[n,n+1,n+2]], circ=tris.map(withR);
  for (let i=0;i<n;i++){
    const p=pts[i], bad=[], keep=[], keepC=[];
    for (let t=0;t<tris.length;t++){
      const c=circ[t];
      if ((p.x-c.x)**2+(p.y-c.y)**2 < c.r2-1e-12) bad.push(tris[t]);
      else { keep.push(tris[t]); keepC.push(c); }
    }
    const edges=[];
    for (const t of bad) edges.push([t[0],t[1]],[t[1],t[2]],[t[2],t[0]]);
    const bound=[];
    for (let a=0;a<edges.length;a++){
      let sh=false;
      for (let b=0;b<edges.length;b++){
        if(a===b) continue;
        const e1=edges[a], e2=edges[b];
        if ((e1[0]===e2[1]&&e1[1]===e2[0])||(e1[0]===e2[0]&&e1[1]===e2[1])){ sh=true; break; }
      }
      if(!sh) bound.push(edges[a]);
    }
    tris=keep; circ=keepC;
    for (const e of bound){ const t=[e[0],e[1],i]; tris.push(t); circ.push(withR(t)); }
  }
  return tris.filter(t => t[0]<n && t[1]<n && t[2]<n);
}

function lmToRaw(lm, aspect){
  return lm.map(p => [ (p.x-0.5)*aspect, -(p.y-0.5), -p.z*aspect ]);
}

const FACE_SUBDIV = 2;

const FACE_SUBDIV_BULGE = 0.75;

function phongSubdivide(pos, uv, idx, levels, bulge){
  let P = pos.slice(), U = uv.slice(), I = idx.slice();
  const parents = [];
  for (let lv=0; lv<levels; lv++){
    const nv = P.length/3;
    const N = new Float64Array(nv*3);
    for (let t=0;t<I.length;t+=3){
      const a=I[t], b=I[t+1], c=I[t+2];
      const ux=P[3*b]-P[3*a], uy=P[3*b+1]-P[3*a+1], uz=P[3*b+2]-P[3*a+2];
      const vx=P[3*c]-P[3*a], vy=P[3*c+1]-P[3*a+1], vz=P[3*c+2]-P[3*a+2];
      const nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
      for (const q of [a,b,c]){ N[3*q]+=nx; N[3*q+1]+=ny; N[3*q+2]+=nz; }
    }
    for (let q=0;q<nv;q++){
      const L=Math.hypot(N[3*q],N[3*q+1],N[3*q+2])||1; N[3*q]/=L; N[3*q+1]/=L; N[3*q+2]/=L;
    }
    const mid = new Map();
    const midOf = (a,b) => {
      const k = a<b ? a*1e7+b : b*1e7+a;
      let m = mid.get(k); if (m !== undefined) return m;
      const mx=(P[3*a]+P[3*b])/2, my=(P[3*a+1]+P[3*b+1])/2, mz=(P[3*a+2]+P[3*b+2])/2;
      // Project the midpoint onto each end's tangent plane.
      const pa = (x,y,z,q) => { const d=(x-P[3*q])*N[3*q]+(y-P[3*q+1])*N[3*q+1]+(z-P[3*q+2])*N[3*q+2];
                                return [x-d*N[3*q], y-d*N[3*q+1], z-d*N[3*q+2]]; };
      const A=pa(mx,my,mz,a), B=pa(mx,my,mz,b);
      const qx=(A[0]+B[0])/2, qy=(A[1]+B[1])/2, qz=(A[2]+B[2])/2;
      /* Where the two end normals part by more than about 50 degrees the
         edge crosses a crease, the alar groove above all, and rounding it
         only digs the groove into a slot. Such an edge is split flat. */
      const nd = N[3*a]*N[3*b] + N[3*a+1]*N[3*b+1] + N[3*a+2]*N[3*b+2];
      /* Nor under the nose. The detector's nostril floor is folded, and seen
         from a three-quarter view below it already reads as a dark slot;
         rounding a surface that faces the floor only widens the slot. So the
         bulge fades out as either end turns to face down. */
      const down = Math.min(N[3*a+1], N[3*b+1]);
      const fd = Math.min(1, Math.max(0, (down + 0.55)/0.25));
      const bl = nd < 0.64 ? 0 : bulge*Math.min(1, (nd-0.64)/0.16)*fd;
      let ox=bl*(qx-mx), oy=bl*(qy-my), oz=bl*(qz-mz);
      /* Never more than an eighth of the edge. Across the alar crease the two
         end normals disagree by nearly a right angle, and uncapped the new
         point overshoots into a fold. */
      const el=Math.hypot(P[3*b]-P[3*a],P[3*b+1]-P[3*a+1],P[3*b+2]-P[3*a+2]), ol=Math.hypot(ox,oy,oz);
      if (ol > 0.125*el){ const f=0.125*el/ol; ox*=f; oy*=f; oz*=f; }
      P.push(mx+ox, my+oy, mz+oz);
      U.push((U[2*a]+U[2*b])/2, (U[2*a+1]+U[2*b+1])/2);
      parents.push(a, b);
      m = P.length/3 - 1; mid.set(k, m); flat.set(m, [mx,my,mz]); return m;
    };
    const flat = new Map();
    const J = [], parN = [];
    for (let t=0;t<I.length;t+=3){
      const a=I[t], b=I[t+1], c=I[t+2];
      const ab=midOf(a,b), bc=midOf(b,c), ca=midOf(c,a);
      J.push(a,ab,ca, ab,b,bc, ca,bc,c, ab,bc,ca);
      const ux=P[3*b]-P[3*a], uy=P[3*b+1]-P[3*a+1], uz=P[3*b+2]-P[3*a+2];
      const vx=P[3*c]-P[3*a], vy=P[3*c+1]-P[3*a+1], vz=P[3*c+2]-P[3*a+2];
      const n=[uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx], L=Math.hypot(...n)||1;
      parN.push(n[0]/L, n[1]/L, n[2]/L);
    }
    /* A child that turned away from its parent is a fold. Put that child's
       new points back on the flat midpoints and look again; the flat split
       can never fold, so this ends. */
    for (let pass=0; pass<4; pass++){
      let bad = 0;
      for (let t=0;t<J.length;t+=3){
        const a=J[t], b=J[t+1], c=J[t+2], pi=Math.floor(t/12)*3;
        const ux=P[3*b]-P[3*a], uy=P[3*b+1]-P[3*a+1], uz=P[3*b+2]-P[3*a+2];
        const vx=P[3*c]-P[3*a], vy=P[3*c+1]-P[3*a+1], vz=P[3*c+2]-P[3*a+2];
        const n=[uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx], L=Math.hypot(...n)||1;
        if ((n[0]*parN[pi]+n[1]*parN[pi+1]+n[2]*parN[pi+2])/L > 0.3) continue;
        for (const q of [a,b,c]){ const f=flat.get(q); if (f){ P[3*q]=f[0]; P[3*q+1]=f[1]; P[3*q+2]=f[2]; flat.delete(q); bad++; } }
      }
      if (!bad) break;
    }
    I = J;
  }
  return { pos:P, uv:U, idx:I, parents };
}

let faceSubdivLevel = FACE_SUBDIV;

function fixFaceNormals(g, sub){
  sub = sub || (g && g.userData && g.userData.faceSub);
  if (!sub || !g.attributes.normal) return;
  const P = g.attributes.position.array, Nn = g.attributes.normal.array;
  const nC = sub.nC, I = sub.cIdx, par = sub.parents;
  const acc = new Float64Array(nC*3);
  for (let t=0;t<I.length;t+=3){
    const a=I[t], b=I[t+1], c=I[t+2];
    const ux=P[3*b]-P[3*a], uy=P[3*b+1]-P[3*a+1], uz=P[3*b+2]-P[3*a+2];
    const vx=P[3*c]-P[3*a], vy=P[3*c+1]-P[3*a+1], vz=P[3*c+2]-P[3*a+2];
    const nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
    for (const q of [a,b,c]){ acc[3*q]+=nx; acc[3*q+1]+=ny; acc[3*q+2]+=nz; }
  }
  for (let q=0;q<nC;q++){
    const L=Math.hypot(acc[3*q],acc[3*q+1],acc[3*q+2]);
    if (L>1e-12){ Nn[3*q]=acc[3*q]/L; Nn[3*q+1]=acc[3*q+1]/L; Nn[3*q+2]=acc[3*q+2]/L; }
  }
  for (let k=0, q=nC; k<par.length; k+=2, q++){
    const a=par[k], b=par[k+1];
    const x=Nn[3*a]+Nn[3*b], y=Nn[3*a+1]+Nn[3*b+1], z=Nn[3*a+2]+Nn[3*b+2], L=Math.hypot(x,y,z)||1;
    Nn[3*q]=x/L; Nn[3*q+1]=y/L; Nn[3*q+2]=z/L;
  }
  g.attributes.normal.needsUpdate = true;
}

function buildGeometry(lm, imgW, imgH, pos3){
  const ar = imgW / imgH;
  const raw = pos3 || lmToRaw(lm, ar);
  const pos = [], uv = [];
  for (let i=0;i<lm.length;i++){ pos.push(raw[i][0], raw[i][1], raw[i][2]); uv.push(lm[i].x, lm[i].y); }
  let tris = delaunay(lm.map(p => ({ x:p.x*ar, y:p.y })));
  const dist=(a,b)=>Math.hypot((lm[a].x-lm[b].x)*ar, lm[a].y-lm[b].y);
  const el=[]; for(const t of tris) el.push(dist(t[0],t[1]),dist(t[1],t[2]),dist(t[2],t[0]));
  el.sort((a,b)=>a-b);
  const cap=(el[Math.floor(el.length/2)]||0.01)*6;
  tris=tris.filter(t=>dist(t[0],t[1])<cap&&dist(t[1],t[2])<cap&&dist(t[2],t[0])<cap);
  const idx=[];
  for (const t of tris){
    const [a,b,c]=t;
    // Mesh axes are X=(x-0.5)*ar, Y=-(y-0.5), Z=-z*ar, so the signed area in
    // mesh XY is -ar * (signed area in image xy). A front-facing (outward-normal)
    // triangle therefore needs a NEGATIVE signed area in image coordinates.
    // Getting this backwards points every normal into the head, which silently
    // turns an outward filler bump into a dent.
    const area=(lm[b].x-lm[a].x)*(lm[c].y-lm[a].y)-(lm[c].x-lm[a].x)*(lm[b].y-lm[a].y);
    if (area<0) idx.push(a,b,c); else idx.push(a,c,b);
  }
  /* Sessions saved before v34 were drawn on the 468-vertex face, and their
     sculpt buffers are one value per vertex of it, so they reopen at the
     level they were saved at. See faceSubdivLevel. */
  const sub = faceSubdivLevel > 0 ? phongSubdivide(pos, uv, idx, faceSubdivLevel, FACE_SUBDIV_BULGE) : { pos, uv, idx };
  const g=new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(sub.pos,3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(sub.uv,2));
  g.setIndex(sub.idx); g.computeVertexNormals();
  if (faceSubdivLevel > 0){
    g.userData.faceSub = { nC: lm.length, cIdx: Uint32Array.from(idx), parents: Int32Array.from(sub.parents), level: faceSubdivLevel };
    fixFaceNormals(g);
  }
  g.computeBoundingBox();
  const c=new THREE.Vector3(); g.boundingBox.getCenter(c);
  const sz=new THREE.Vector3(); g.boundingBox.getSize(sz);
  const sc=2/sz.y;
  g.translate(-c.x,-c.y,-c.z); g.scale(sc,sc,sc); g.computeBoundingSphere();
  const lm3 = raw.map(p => [ (p[0]-c.x)*sc, (p[1]-c.y)*sc, (p[2]-c.z)*sc ]);
  // The same rigid+uniform map the geometry just went through, so anything
  // solved in raw landmark space — a fitted camera, above all — can be carried
  // into model space without re-deriving it.
  return { g, lm3, norm:{ c:[c.x,c.y,c.z], sc } };
}

function makeFaceMesh(lm, img, pos3){
  const { g, lm3, norm } = buildGeometry(lm, img.naturalWidth, img.naturalHeight, pos3);
  const tex = new THREE.Texture(img);
  tex.flipY=false; tex.colorSpace=THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy(); tex.needsUpdate=true;
  const mat = new THREE.MeshStandardMaterial({ map:tex, side:THREE.DoubleSide, roughness:0.72, metalness:0 });
  return { mesh:new THREE.Mesh(g, mat), lm3, mat, norm };
}

let landmarker = null;

async function getLandmarker(){
  if (landmarker) return landmarker;
  const vision = await import(CFG.visionBundle);
  const files = await vision.FilesetResolver.forVisionTasks(CFG.visionWasm);
  // Confidence thresholds LOWERED from the defaults. The detector is tuned for
  // frontal faces and gives up on true profiles at the stock 0.5 — which threw
  // away exactly the views that carry nasal projection and the ears. At 0.25 it
  // recovers many profiles; the ones it still cannot read fall through to the
  // silhouette-only path rather than being discarded.
  const opts = { baseOptions:{ modelAssetPath: CFG.landmarkerModel, delegate: CFG.delegate || 'GPU' }, runningMode:'IMAGE', numFaces:1,
    minFaceDetectionConfidence:0.25, minFacePresenceConfidence:0.25 };
  try { landmarker = await vision.FaceLandmarker.createFromOptions(files, opts); }
  catch { opts.baseOptions.delegate='CPU'; landmarker = await vision.FaceLandmarker.createFromOptions(files, opts); }
  return landmarker;
}

function clearGroup(gr){
  while (gr.children.length){
    const c = gr.children.pop();
    c.traverse?.(o => { o.geometry?.dispose?.(); if (o.material) [].concat(o.material).forEach(m=>m.dispose?.()); });
    gr.remove(c);
  }
}

function clearModel(){
  clearGroup(modelRoot); wireMeshes=[]; targets=[]; baseMats=[];
  S.basePos=null; S.sculpt=null; S.baseNrm=null;
  devField=null; devSource='';
  const sel=$('#devSrc'); if(sel) sel.value='';
  const lg=$('#devLegend'); if(lg) lg.classList.remove('on');
  const dsw=$('#devScaleWrap'); if(dsw) dsw.classList.add('hide');
  const so=$('#symOut'); if(so) so.innerHTML='';
}

function captureBase(){
  const m = targets[0];
  if (!m) return;
  const p = m.geometry.attributes.position.array;
  S.basePos = Float32Array.from(p);
  S.sculpt = new Float32Array(p.length);
  // Normals of the UNDEFORMED surface. Volume bumps and outcome measurement must
  // both reference these — using the live (already simulated) normals would feed
  // the simulation back into itself and skew any measurement taken against it.
  if (!m.geometry.attributes.normal) m.geometry.computeVertexNormals();
  S.baseNrm = Float32Array.from(m.geometry.attributes.normal.array);
  buildVGrid();
}

function installFaceMesh(lm, img, isPhotoBuild, pos3){
  clearModel();
  const { mesh, lm3, mat, norm } = makeFaceMesh(lm, img, pos3);
  modelRoot.add(mesh); mesh.updateMatrixWorld(true);
  targets=[mesh]; baseMats=[{ mat, map:mat.map }];
  captureBase(); addWireframes();
  // The pristine face, kept so a shell attach always starts from it. Reading
  // mesh.geometry instead compounds: the second attach treats the first
  // attach's shell as part of the face and grows the mesh without bound.
  S.faceBase = {
    pos: Float32Array.from(mesh.geometry.attributes.position.array),
    uv:  Float32Array.from(mesh.geometry.attributes.uv.array),
    idx: Uint32Array.from(mesh.geometry.index.array),
    sub: mesh.geometry.userData.faceSub || null,
  };
  // A fresh mesh invalidates any atlas: different vertices, different chart.
  S.atlasGroups = [0];
  S.shellUV = null;
  atlasState.on = false; atlasState.photoUV = null; atlasState.coverage = 0;
  S.lm3 = lm3;
  S.lmNorm = norm;
  S.rawLm = lm.map(p => ({ x:p.x, y:p.y, z:p.z }));
  S.fitPos = pos3 ? pos3.map(p => [+p[0].toFixed(6), +p[1].toFixed(6), +p[2].toFixed(6)]) : null;
  S.keyPts = {};
  for (const k of KP_DEFS) S.keyPts[k.id] = lm3[k.mp].slice();
  $('#splash').classList.add('hide');
  $('#shellWarn').classList.toggle('hide', !isPhotoBuild);
  bindAllMarkers(); kpUiState(); applyDeform(); rebuildOverlays(); redrawAnno(); updateSimUi();
  requestAnimationFrame(()=>{ resize(); frameCamera(new THREE.Box3().setFromObject(mesh)); });
}

const REF_SHAPE = new Float32Array([-0.0021,-0.5431,0.2903,-0.0029,-0.1394,0.4691,-0.0043,-0.2428,0.3011,-0.1005,0.2436,0.3554,-0.0052,-0.0236,0.5010,-0.0034,0.1313,0.4606,-0.0037,0.5261,0.2355,-0.8187,0.5652,-0.0313,-0.0175,0.8341,0.1994,-0.0262,0.9881,0.2438,-0.0430,1.5225,0.2154,0.0005,-0.6028,0.2929,-0.0006,-0.6525,0.2717,0.0001,-0.6735,0.2565,0.0011,-0.7060,0.2246,0.0028,-0.7649,0.2111,0.0033,-0.8340,0.2284,0.0021,-0.9077,0.2109,0.0060,-0.9816,0.1356,-0.0022,-0.2015,0.3744,-0.1090,-0.1920,0.3012,-1.3497,1.1176,-0.6744,-0.4851,0.4795,0.0027,-0.5952,0.4650,0.0014,-0.7058,0.4672,-0.0156,-0.8672,0.5323,-0.0840,-0.3946,0.5136,-0.0012,-0.6382,0.7597,0.1098,-0.5234,0.7566,0.0951,-0.7483,0.7436,0.0872,-0.8268,0.7066,0.0383,-0.9438,0.4739,-0.1298,-0.4520,-1.1622,-0.0957,-0.8644,0.5928,-0.0505,-1.4037,0.5770,-0.6981,-1.1620,0.5515,-0.3116,-0.6169,-0.0424,0.0660,-0.1343,-0.5251,0.2703,-0.1123,-0.6523,0.2464,-0.2687,-0.5638,0.2110,-0.3523,-0.6106,0.1542,-0.2083,-0.6617,0.2043,-0.2811,-0.6733,0.1577,-0.4845,-0.7988,-0.0500,-0.0963,-0.1391,0.4408,-0.1101,-0.0267,0.4763,-1.0674,0.8592,-0.1329,-0.3741,0.2550,0.0752,-0.3520,-0.1161,0.2487,-0.3653,-0.0518,0.1948,-0.9943,-0.0263,-0.0762,-0.1058,0.1184,0.4249,-0.7926,0.9736,0.1041,-0.9534,0.9371,0.0041,-1.2082,1.2899,-0.4152,-0.2371,0.8747,0.1458,-0.4243,0.7259,0.0568,-0.5553,-0.6945,-0.0164,-1.3051,-0.5935,-1.1357,-0.2703,-0.1671,0.2613,-0.1802,-0.2084,0.2140,-0.4499,-0.6965,0.0292,-0.3958,-0.6846,0.0801,-1.0152,1.0211,-0.0497,-0.3301,-0.1537,0.2511,-0.5567,0.9653,0.1475,-0.5835,1.0506,0.1779,-0.7075,1.4824,0.0482,-1.1002,1.1454,-0.2192,-0.6374,1.2574,0.1466,-1.1370,0.9200,-0.2229,-1.2377,1.0019,-0.4296,-0.1236,-0.5949,0.2711,-0.2352,-0.6210,0.2183,-0.3183,-0.6423,0.1635,-0.2420,-0.1911,0.2301,-0.4214,-0.6938,0.0515,-0.3802,-0.7209,0.0463,-0.3846,-0.6715,0.1005,-0.2148,-0.1286,0.3396,-0.2560,-0.6636,0.1803,-0.1831,-0.6657,0.2109,-0.0957,-0.6701,0.2380,-0.1381,-0.9765,0.1308,-0.1396,-0.8963,0.1989,-0.1318,-0.8212,0.2109,-0.1207,-0.7532,0.1896,-0.1105,-0.7021,0.2034,-0.2788,-0.6923,0.1372,-0.2982,-0.7151,0.1041,-0.3285,-0.7526,0.0678,-0.3537,-0.7963,0.0569,-0.4698,-0.4774,0.0783,-1.3968,0.0475,-0.8066,-0.0008,-0.2224,0.3329,-0.3261,-0.6876,0.1185,-0.3507,-0.7011,0.0868,-0.1409,-0.2448,0.2003,-0.3034,-0.2102,0.1936,-0.1584,-0.2267,0.2041,-0.5036,0.1909,0.0445,-0.7042,0.1106,0.0206,-0.3833,-0.1047,0.1496,-1.0048,1.4145,-0.1670,-0.9096,1.2378,-0.0291,-0.8305,1.0658,0.0902,-0.3931,-0.8636,0.0300,-0.3010,1.0191,0.2254,-0.3593,1.2444,0.2403,-0.4013,1.5139,0.1729,-0.8063,0.4890,-0.0516,-1.1713,0.3697,-0.2505,-0.3406,0.5490,-0.0019,-0.9474,0.6868,-0.0702,-0.2842,0.3261,0.1102,-0.2699,-0.0721,0.3327,-1.2983,0.3031,-0.4053,-1.0926,0.2741,-0.1450,-0.9333,0.2233,-0.0488,-0.6889,0.2420,-0.0010,-0.5146,0.2958,0.0149,-0.3893,0.3504,0.0388,-0.1165,0.4981,0.1997,-1.2793,0.0448,-0.3886,-1.1166,0.7195,-0.2513,-0.0597,-0.1968,0.3702,-0.3489,0.1327,0.1045,-1.4916,0.6373,-1.0295,-0.2920,0.4120,0.0673,-0.3910,-0.1095,0.0716,-0.9051,0.5995,-0.0851,-0.3007,0.0012,0.2700,-1.3469,-0.2349,-0.8690,-0.3451,0.5892,-0.0057,-0.1856,0.0740,0.3710,-1.0062,-0.9072,-0.4663,-1.0267,-1.0475,-0.6816,-1.4393,0.0689,-1.2237,-1.1653,-0.7374,-0.6363,-1.3272,0.8120,-0.5835,-0.4847,-1.2752,-0.1488,-0.0485,-0.2172,0.3352,-0.4643,0.0492,0.0738,-1.2709,0.5435,-0.4282,-0.6964,0.5377,0.0171,-0.5942,0.5308,0.0238,-0.4117,-0.7473,0.0081,-1.2486,-0.1962,-0.4547,-0.3289,-1.4073,-0.0726,-0.6534,-1.2954,-0.3585,-0.8228,-1.2011,-0.4926,-0.0405,1.2399,0.2578,0.1624,-1.3913,0.0112,-0.5013,0.5426,0.0122,-0.4197,0.5667,-0.0021,-0.3694,0.5818,-0.0064,-1.2077,0.7582,-0.3622,-0.4355,0.6244,0.0188,-0.5294,0.6272,0.0626,-0.6197,0.6251,0.0798,-0.7162,0.6144,0.0586,-0.7840,0.6015,0.0179,-1.4361,0.9141,-0.8815,-0.7670,0.5519,-0.0053,0.0224,-0.3503,0.2252,-0.3589,-0.4100,0.1249,-0.2731,-0.1471,0.2856,-0.1241,-0.3729,0.2159,-0.0029,0.6815,0.1867,-0.8287,-1.0626,-0.3588,-0.6561,-1.1776,-0.2741,-0.2987,-1.3386,-0.0190,-1.1816,-0.8605,-0.9136,-0.3733,0.6058,-0.0046,-0.1685,0.3033,0.2452,0.1133,-1.3239,0.0490,-0.4957,-1.3649,-0.2046,-1.3842,-0.2537,-1.2519,-0.2047,-0.6960,0.1695,-0.2235,-0.7352,0.1423,-0.2431,-0.7871,0.1482,-0.2590,-0.8536,0.1482,-0.2798,-0.9271,0.1027,-0.3481,-0.6795,0.1162,-0.3838,-0.6726,0.1000,-0.4179,-0.6519,0.0917,-0.5653,-0.5728,0.0239,-1.0838,-0.2695,-0.2190,-0.1711,0.4305,0.1743,-0.2624,0.6713,0.0165,-0.3240,0.6541,0.0042,-0.3210,-0.6604,0.1492,-1.0983,-0.5598,-0.3809,-0.1563,0.6650,0.1129,-0.4008,-1.0512,-0.0352,-0.0027,0.2617,0.3822,-0.1111,0.3619,0.2749,-0.0035,0.3852,0.3095,-0.2720,0.1041,0.2082,0.0811,-1.2186,0.0744,0.0620,-1.0908,0.0769,-0.2192,-1.1106,0.0440,-0.6637,-0.8486,-0.1253,-0.4919,-0.2023,0.0428,-0.5386,-0.9704,-0.1086,-0.8086,-0.1811,0.0197,-0.6183,-0.3197,0.0421,-0.9119,-0.3691,-0.0761,-0.2640,-1.2338,0.0210,-0.3354,0.0430,0.1290,-0.7826,-0.9299,-0.2234,-0.6106,-1.0584,-0.1859,-0.7615,-0.6969,-0.1118,-1.2131,-0.4048,-0.5152,-0.9305,-0.7057,-0.2440,-1.2855,-0.4994,-0.8272,-0.7120,-0.4803,-0.0130,-0.2703,0.2101,0.1643,-0.2468,-0.1122,0.3320,-0.3130,-0.1464,0.2685,-0.2030,-0.0369,0.3979,-0.3652,0.7735,0.0567,-0.5357,0.8276,0.1060,-0.6828,0.8354,0.1102,-0.8078,0.8139,0.0724,-0.8918,0.7711,0.0117,-0.9907,0.5852,-0.1746,-1.4224,0.3139,-0.7386,-0.8825,0.4242,-0.0838,-0.7690,0.3881,-0.0350,-0.6204,0.3911,-0.0052,-0.4838,0.4218,0.0039,-0.3787,0.4638,0.0082,-0.3042,0.5025,0.0194,-1.4838,0.3625,-1.1234,-0.3131,-0.1688,0.2460,-0.1686,0.1919,0.3213,-0.1732,-0.1211,0.3876,-0.1154,-0.1764,0.3369,-0.1725,-0.1373,0.3605,-0.2838,-0.2024,0.2128,-0.0960,-0.1895,0.3372,-0.0838,-0.2101,0.3011,-0.3033,0.5853,0.0013,-0.2397,0.5523,0.0411,-0.1992,0.5318,0.0894,-0.8301,0.5943,-0.0205,-0.8928,0.6701,-0.0266,0.0937,0.2461,0.3544,0.8196,0.5841,-0.0461,0.1042,-0.1911,0.2968,1.3140,1.1547,-0.6839,0.4807,0.4891,0.0017,0.5925,0.4761,-0.0013,0.7015,0.4816,-0.0213,0.8673,0.5518,-0.0952,0.3898,0.5219,0.0004,0.6279,0.7762,0.1087,0.5134,0.7703,0.0955,0.7412,0.7640,0.0814,0.8228,0.7279,0.0237,0.9440,0.4957,-0.1347,0.4889,-1.1227,-0.0914,0.8653,0.6114,-0.0694,1.3840,0.6163,-0.6977,1.1423,0.5912,-0.3083,0.6119,-0.0123,0.0642,0.1343,-0.5235,0.2796,0.1159,-0.6514,0.2527,0.2722,-0.5625,0.2253,0.3585,-0.6109,0.1630,0.2122,-0.6590,0.2136,0.2874,-0.6730,0.1668,0.5000,-0.7930,-0.0371,0.0902,-0.1360,0.4314,0.1023,-0.0226,0.4773,1.0385,0.8948,-0.1318,0.3649,0.2787,0.0765,0.3457,-0.1016,0.2528,0.3555,-0.0276,0.1822,0.9905,0.0145,-0.0671,0.0979,0.1224,0.4318,0.7658,1.0057,0.1018,0.9234,0.9708,0.0039,1.1720,1.3236,-0.4180,0.2228,0.8909,0.1548,0.4133,0.7370,0.0575,0.5679,-0.6890,-0.0077,1.3093,-0.5560,-1.1789,0.2674,-0.1647,0.2615,0.1756,-0.2063,0.2257,0.4601,-0.6966,0.0330,0.4062,-0.6820,0.0830,0.9829,1.0564,-0.0496,0.3266,-0.1515,0.2530,0.5339,0.9879,0.1495,0.5596,1.0754,0.1785,0.6708,1.5023,0.0414,1.0670,1.1789,-0.2222,0.6063,1.2804,0.1407,1.1059,0.9567,-0.2230,1.2068,1.0407,-0.4345,0.1268,-0.5958,0.2765,0.2375,-0.6202,0.2294,0.3239,-0.6419,0.1738,0.2379,-0.1877,0.2309,0.4323,-0.6924,0.0528,0.3905,-0.7186,0.0530,0.3935,-0.6719,0.1048,0.2065,-0.1270,0.3334,0.2618,-0.6627,0.1891,0.1886,-0.6658,0.2170,0.1017,-0.6694,0.2437,0.1523,-0.9746,0.1290,0.1475,-0.8946,0.2007,0.1381,-0.8193,0.2178,0.1241,-0.7500,0.1965,0.1139,-0.6995,0.2102,0.2867,-0.6883,0.1514,0.3051,-0.7103,0.1207,0.3365,-0.7514,0.0856,0.3653,-0.7907,0.0725,0.4755,-0.4510,0.0820,1.3921,0.0938,-0.7972,0.3358,-0.6863,0.1290,0.3593,-0.7021,0.0934,0.1379,-0.2443,0.2115,0.3032,-0.2068,0.2005,0.1569,-0.2286,0.2133,0.4956,0.2184,0.0429,0.6971,0.1415,0.0215,0.3783,-0.0789,0.1380,0.9668,1.4395,-0.1739,0.8787,1.2679,-0.0329,0.8030,1.0939,0.0887,0.4091,-0.8577,0.0396,0.2795,1.0336,0.2292,0.3340,1.2566,0.2372,0.3687,1.5220,0.1701,0.8068,0.5042,-0.0610,1.1576,0.4091,-0.2425,0.3363,0.5556,0.0001,0.9477,0.7137,-0.1017,0.2723,0.3492,0.1091,0.2663,-0.0685,0.3422,1.2857,0.3444,-0.3940,1.0813,0.3140,-0.1395,0.9225,0.2564,-0.0436,0.6812,0.2732,0.0010,0.5052,0.3222,0.0162,0.3784,0.3727,0.0375,0.1081,0.5009,0.1976,1.2723,0.0888,-0.3784,1.0908,0.7584,-0.2494,0.0558,-0.1972,0.3588,0.3464,0.1597,0.1112,1.4690,0.6798,-1.0282,0.2767,0.4301,0.0671,0.3932,-0.0824,0.0737,0.9061,0.6205,-0.1055,0.2892,0.0266,0.2677,1.3497,-0.1887,-0.8652,0.3400,0.5986,-0.0042,0.1811,0.0774,0.3871,1.0298,-0.8615,-0.4737,1.0525,-1.0032,-0.6962,1.4297,0.1140,-1.2292,1.1811,-0.6921,-0.6440,1.3007,0.8490,-0.5827,0.5257,-1.2375,-0.1558,0.0445,-0.2183,0.3143,0.4642,0.0756,0.0798,1.2504,0.5844,-0.4205,0.6938,0.5519,0.0067,0.5920,0.5441,0.0212,0.4228,-0.7426,0.0143,1.2479,-0.1499,-0.4475,0.3708,-1.3810,-0.0851,0.6973,-1.2603,-0.3636,0.8624,-1.1557,-0.5017,0.4995,0.5525,0.0123,0.4145,0.5757,-0.0009,0.3641,0.5920,-0.0054,1.1800,0.7989,-0.3616,0.4300,0.6350,0.0218,0.5243,0.6415,0.0641,0.6166,0.6400,0.0759,0.7154,0.6308,0.0496,0.7859,0.6191,0.0015,1.4057,0.9521,-0.8936,0.7637,0.5665,-0.0182,0.3648,-0.3880,0.1223,0.2679,-0.1453,0.2844,0.1395,-0.3539,0.2152,0.8629,-1.0159,-0.3614,0.6987,-1.1345,-0.2715,0.3352,-1.3092,-0.0298,1.1970,-0.8227,-0.9415,0.3675,0.6160,-0.0023,0.1649,0.3044,0.2460,0.5376,-1.3329,-0.2164,1.3817,-0.2132,-1.2701,0.2079,-0.6931,0.1808,0.2279,-0.7297,0.1558,0.2511,-0.7842,0.1641,0.2687,-0.8491,0.1604,0.2937,-0.9209,0.1117,0.3560,-0.6782,0.1223,0.3937,-0.6709,0.1054,0.4273,-0.6531,0.0956,0.5722,-0.5428,0.0345,1.0867,-0.2274,-0.2131,0.1658,0.4340,0.1649,0.2538,0.6788,0.0155,0.3169,0.6638,0.0068,0.3285,-0.6601,0.1588,1.1091,-0.5154,-0.3828,0.1480,0.6723,0.1055,0.4363,-1.0110,-0.0240,0.1038,0.3627,0.2789,0.2630,0.1253,0.2114,0.2532,-1.0729,0.0476,0.6911,-0.8045,-0.1103,0.4997,-0.1757,0.0541,0.5684,-0.9300,-0.0967,0.8066,-0.1443,0.0221,0.6212,-0.2874,0.0511,0.9152,-0.3278,-0.0695,0.2961,-1.2013,0.0113,0.3319,0.0666,0.1315,0.8099,-0.8840,-0.2186,0.6466,-1.0193,-0.1759,0.7773,-0.6561,-0.1028,1.2177,-0.3584,-0.5122,0.9486,-0.6598,-0.2418,1.2940,-0.4546,-0.8311,0.7186,-0.4432,-0.0025,0.2604,0.2326,0.1661,0.2427,-0.1091,0.3343,0.3095,-0.1420,0.2719,0.1956,-0.0362,0.4062,0.3560,0.7855,0.0582,0.5235,0.8428,0.1038,0.6756,0.8559,0.1047,0.7974,0.8368,0.0629,0.8889,0.7956,-0.0106,0.9919,0.6102,-0.1900,1.4100,0.3592,-0.7327,0.8810,0.4412,-0.0855,0.7674,0.4030,-0.0354,0.6180,0.4035,-0.0042,0.4800,0.4319,0.0044,0.3734,0.4733,0.0095,0.2994,0.5096,0.0183,1.4648,0.4047,-1.1258,0.3111,-0.1689,0.2445,0.1635,0.1946,0.3202,0.1668,-0.1182,0.3824,0.1098,-0.1744,0.3285,0.1648,-0.1362,0.3487,0.2816,-0.2024,0.2116,0.0912,-0.1878,0.3239,0.0794,-0.2097,0.2978,0.2988,0.5945,0.0008,0.2329,0.5589,0.0363,0.1923,0.5369,0.0822,0.8313,0.6127,-0.0373,0.8926,0.6903,-0.0527]);

function referenceDepthPrior(P0, camZ){
  const n = P0.length;
  if (!REF_SHAPE || REF_SHAPE.length < n*3) return null;
  let ox=0, oy=0, rx=0, ry=0;
  for (let i=0;i<n;i++){ ox+=P0[i][0]; oy+=P0[i][1]; rx+=REF_SHAPE[3*i]; ry+=REF_SHAPE[3*i+1]; }
  ox/=n; oy/=n; rx/=n; ry/=n;
  // 2-D Procrustes, closed form.
  let a=0, b=0, den=0;
  for (let i=0;i<n;i++){
    const px=REF_SHAPE[3*i]-rx, py=REF_SHAPE[3*i+1]-ry;
    const qx=P0[i][0]-ox,       qy=P0[i][1]-oy;
    a += px*qx + py*qy;
    b += px*qy - py*qx;
    den += px*px + py*py;
  }
  if (!(den > 1e-12)) return null;
  const k = Math.hypot(a,b)/den;                 // uniform scale
  if (!(k > 1e-9) || !isFinite(k)) return null;
  // In-plane rotation leaves depth alone, so the reference z needs only the
  // scale. Centre it so the cloud sits about z = 0, which is where the rest of
  // the build expects to find it.
  let mz=0; for (let i=0;i<n;i++) mz += REF_SHAPE[3*i+2];
  mz/=n;
  return P0.map((_,i) => Math.max(0.25, 1 - (k*(REF_SHAPE[3*i+2]-mz))/camZ));
}

const FIT = {
  passes: 4,          // camera / depth alternations
  /* Views whose CAMERA is solved and used to paint, but whose landmarks are
     not allowed to move depth. See the note in fitMultiView's depth stage:
     the ¾ views lose against the reference face in every configuration
     measured, and they are the only views that see an ear. Splitting the two
     jobs is what lets the accuracy advice and the appearance advice be the
     same advice.

     The true profiles are on this list for a different and blunter reason.
     MediaPipe DOES return 468 landmarks for a 90° lateral — it returned them
     for the clinician's own Left Lateral 1 and Right Lateral 2 — and roughly
     half of them are invented, because half the face is not in the photograph.
     A detection is not an observation. The entire hand-traced profile path
     (§4d.1) exists because of this. Letting those landmarks vote on depth
     would undo it, and the app now tells people to file every photograph, so
     the case is no longer hypothetical. */
  /* Which roles are allowed to move depth. See the allowlist note in
     fitMultiView for why this runs as an allowlist rather than a blocklist.

     `up` and `down` are on it because test18 guards a contract the clinician
     reported as broken once already: filing a second and third photograph has
     to change the mesh. Those are defined slots, shot at a known angle, and
     the suite measures them putting back 60% of a deliberately flattened
     front depth. They have never been scored on real detections, which is the
     open question, and it is recorded rather than pre-empted.

     `other` is NOT on it. An extra is whatever happened to be in the folder:
     no known angle, no test, no way for the clinician to see that it moved the
     geometry. It still solves a camera and still paints the atlas. */
  depthRoles: ['up', 'down'],
  texOnlyRoles: ['r45', 'l45', 'r90', 'l90'],   // kept: the fit report reads it
  obliqueDepth: false,
  smoothIters: 90,    // Gauss-Seidel sweeps for the coupled depth solve
  lambdaSmooth: 0.55, // pull toward the neighbourhood mean
  /* Pull back toward the REFERENCE FACE, which is what s0 now holds.

     0.05 was right when s0 was the detector's generic guess and deserved
     little trust. s0 is a real scanned head now, and the multi-view depth
     solve was measured doing worse than leaving it alone. Sweeping this
     against a real scanned face, with the reference built from a different
     person so the test face is never in its own model:

       0.05  median 4.32 mm   depth RMS 4.76
       0.3          4.21                4.50
       1.0          3.97                4.04
       3.0          3.58                3.54
       10           3.22                3.16
       reference face alone, no fit at all:  3.13

     Monotonic all the way, so the fit contributes nothing positive on this
     face. 1.0 is a deliberate middle: a measured gain that still lets the
     photographs move depth. Going further scores better and starts imposing
     the reference's depth on every patient, and picking the winner off ONE
     face with a ONE-face reference would be tuning to the test. Re-choose it
     by leave-one-out once the reference is built from ten scans.

     Left at 0.05 for now. Raising it to 1.0 was tried and reverted: it cost
     test18's tolerance on how closely the fit tracks the truth from seven
     views, and buying 0.35 mm on one real face with a one-face reference is
     not worth loosening the one test built to prove the photographs move the
     geometry. */
  lambdaPrior: 0.05,  // pull back toward the reference face
  minWeight: 0.18,    // below this the view is not really seeing the point
  /* Tried and reverted, 2026-09-10. The silhouette diagnosis was right: on a
     true profile the midline normal is perpendicular to the ray, so cos^1.5
     with this floor throws away the points the profile measures best. Loosening
     it to a plain visibility ramp was measured against a real scan and does not
     pay. With two PERFECT profile views in the fit it took the median from 4.27
     to 4.06 mm, and with no profile in the fit, which is what actually happens
     since the detector cannot read one, it went the wrong way, 4.66 to 4.71.

     The reason it buys so little sits deeper. Cameras and depths alternate, so
     a systematically wrong depth field with camera poses that compensate for it
     reprojects as well as the truth, and the residual that would move the depth
     never appears. Two perfect profiles reprojecting at 0.4% of frame moved the
     nose tip 0.2 mm and the menton 0.7 mm, and turning the prior and the
     smoothing off changed neither. Depth is corrected by anchoring it directly,
     which is what the traced profile does: the same menton moved 12 mm.
     See tests/groundtruth/. */
  huberPx: 0.012,     // robust cut-off, as a fraction of the image diagonal
  poseSubset: 160,    // landmarks used for the camera solve
};

function fitCamera(P3, obs, wts, fov, aspect, seed, iters){
  iters = iters || 60;
  const n3 = P3.length;
  const cam = new THREE.PerspectiveCamera(fov, aspect, 0.05, 100);
  const M = new THREE.Matrix4(), e = M.elements;
  const huber = FIT.huberPx * Math.hypot(1, 1/aspect) * 2;   // in NDC-ish units
  const resid = p => {
    cam.position.set(p[0],p[1],p[2]);
    cam.rotation.set(p[3],p[4],p[5]);
    cam.updateMatrixWorld(true);
    cam.updateProjectionMatrix();
    M.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse);
    const r = new Float64Array(n3*2);
    for (let i=0;i<n3;i++){
      const w = wts[i];
      if (w <= 0){ continue; }
      const x=P3[i][0], y=P3[i][1], z=P3[i][2];
      const cw = e[3]*x + e[7]*y + e[11]*z + e[15];
      if (cw <= 1e-6){ r[2*i]=r[2*i+1]=0; continue; }
      const cx = (e[0]*x + e[4]*y + e[8]*z  + e[12]) / cw;
      const cy = (e[1]*x + e[5]*y + e[9]*z  + e[13]) / cw;
      let dx = cx - obs[i][0], dy = cy - obs[i][1];
      // Huber: a badly detected landmark should cost, not dominate.
      const m = Math.hypot(dx,dy);
      const k = m > huber ? Math.sqrt(huber/m) : 1;
      r[2*i]   = dx*k*w;
      r[2*i+1] = dy*k*w;
    }
    return r;
  };
  const cost = r => { let s=0; for (let i=0;i<r.length;i++) s+=r[i]*r[i]; return s; };

  let params = seed.slice();
  let r = resid(params), c = cost(r), lambda = 1e-3;
  for (let iter=0; iter<iters; iter++){
    const m = r.length, N = 6;
    const J = [];
    for (let j=0;j<N;j++){
      const eps = (j<3 ? 1e-4 : 1e-5);
      const pp = params.slice(); pp[j]+=eps;
      const rp = resid(pp);
      const col = new Float64Array(m);
      for (let i=0;i<m;i++) col[i] = (rp[i]-r[i])/eps;
      J.push(col);
    }
    const JTJ = Array.from({length:N},()=>new Array(N).fill(0));
    const JTr = new Array(N).fill(0);
    for (let a=0;a<N;a++){
      const Ja = J[a];
      for (let i=0;i<m;i++) JTr[a] += Ja[i]*r[i];
      for (let b=a;b<N;b++){
        const Jb = J[b]; let s=0;
        for (let i=0;i<m;i++) s += Ja[i]*Jb[i];
        JTJ[a][b]=JTJ[b][a]=s;
      }
    }
    let stepped = false;
    for (let t=0;t<7;t++){
      const A = JTJ.map((row,i)=>row.map((v,j)=> i===j ? v*(1+lambda) + 1e-12 : v));
      const d = solveLinear(A, JTr.map(v=>-v));
      if (!d || d.some(v=>!isFinite(v))){ lambda*=10; continue; }
      const cand = params.map((v,i)=>v+d[i]);
      const rc = resid(cand), cc = cost(rc);
      if (cc < c){ params=cand; r=rc; c=cc; lambda=Math.max(lambda*0.35,1e-8); stepped=true; break; }
      lambda*=10;
    }
    if (!stepped) break;
  }
  let wsum=0; for (let i=0;i<n3;i++) if (wts[i]>0) wsum++;
  // The median UNWEIGHTED residual over the points this camera claims to see.
  // A summed cost cannot be compared between two candidate directions that
  // disagree about which landmarks are visible — the sums are over different
  // sets. A per-point median can, which is what makes the mis-filing check
  // possible at all.
  cam.position.set(params[0],params[1],params[2]);
  cam.rotation.set(params[3],params[4],params[5]);
  cam.updateMatrixWorld(true); cam.updateProjectionMatrix();
  M.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse);
  const errs=[];
  for (let i=0;i<n3;i++){
    if (wts[i]<=0) continue;
    const x=P3[i][0], y=P3[i][1], z=P3[i][2];
    const cw = e[3]*x + e[7]*y + e[11]*z + e[15];
    if (cw <= 1e-6) continue;
    errs.push(Math.hypot((e[0]*x+e[4]*y+e[8]*z+e[12])/cw - obs[i][0],
                         (e[1]*x+e[5]*y+e[9]*z+e[13])/cw - obs[i][1]));
  }
  errs.sort((a,b)=>a-b);
  const med = errs.length ? errs[errs.length>>1] : Infinity;
  return { params, cost:c, rms: wsum ? Math.sqrt(c/wsum) : Infinity, n:wsum, med, seen:errs.length };
}

function landmarkNormals(P, tris){
  const N = P.map(()=>[0,0,0]);
  for (const [a,b,c] of tris){
    const ux=P[b][0]-P[a][0], uy=P[b][1]-P[a][1], uz=P[b][2]-P[a][2];
    const vx=P[c][0]-P[a][0], vy=P[c][1]-P[a][1], vz=P[c][2]-P[a][2];
    const nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
    for (const i of [a,b,c]){ N[i][0]+=nx; N[i][1]+=ny; N[i][2]+=nz; }
  }
  for (const n of N){
    const L = Math.hypot(n[0],n[1],n[2]) || 1;
    n[0]/=L; n[1]/=L; n[2]/=L;
  }
  return N;
}

function frontTopology(lm, aspect){
  let tris = delaunay(lm.map(p => ({ x:p.x*aspect, y:p.y })));
  const dist=(a,b)=>Math.hypot((lm[a].x-lm[b].x)*aspect, lm[a].y-lm[b].y);
  const el=[]; for(const t of tris) el.push(dist(t[0],t[1]),dist(t[1],t[2]),dist(t[2],t[0]));
  el.sort((a,b)=>a-b);
  const cap=(el[Math.floor(el.length/2)]||0.01)*6;
  tris = tris.filter(t=>dist(t[0],t[1])<cap&&dist(t[1],t[2])<cap&&dist(t[2],t[0])<cap);
  const nb = lm.map(()=>new Set());
  for (const [a,b,c] of tris){ nb[a].add(b); nb[a].add(c); nb[b].add(a); nb[b].add(c); nb[c].add(a); nb[c].add(b); }
  return { tris, nb: nb.map(s=>[...s]) };
}

const SIG_LM = { nose:1, right:234, left:454, top:10, chin:152 };

function headSignature(px){
  const S = SIG_LM, e = 1e-6;
  const wR = px[S.nose][0]-px[S.right][0], wL = px[S.left][0]-px[S.nose][0];
  const hU = px[S.top][1]-px[S.nose][1],   hD = px[S.nose][1]-px[S.chin][1];
  return [
    (wL-wR)/(Math.abs(wL)+Math.abs(wR)+e),
    (hU-hD)/(Math.abs(hU)+Math.abs(hD)+e),
    (px[S.left][0]-px[S.right][0]) / (Math.abs(px[S.top][1]-px[S.chin][1])+e),
  ];
}

const sigDist = (a,b) =>
  Math.hypot((a[0]-b[0])*1.6, (a[1]-b[1])*1.1, (a[2]-b[2])*0.7);

function nominalProject(P3, dir, dist, fov, aspect){
  const c = new THREE.PerspectiveCamera(fov, aspect, 0.05, 100);
  const L = Math.hypot(dir[0],dir[1],dir[2]) || 1;
  c.position.set(dir[0]/L*dist, dir[1]/L*dist, dir[2]/L*dist);
  c.lookAt(0,0,0); c.updateMatrixWorld(true); c.updateProjectionMatrix();
  const e = new THREE.Matrix4().multiplyMatrices(c.projectionMatrix, c.matrixWorldInverse).elements;
  return P3.map(p => {
    const w = e[3]*p[0]+e[7]*p[1]+e[11]*p[2]+e[15] || 1e-6;
    return [ (e[0]*p[0]+e[4]*p[1]+e[8]*p[2]+e[12])/w*aspect,
             (e[1]*p[0]+e[5]*p[1]+e[9]*p[2]+e[13])/w ];
  });
}

function rankViews(P3, obsNdc, fov, aspect, dist, keep, mustInclude){
  const obsSig = headSignature(obsNdc);
  const scored = VIEW_DEFS.filter(v=>v.geo).map(v => ({
    def: v,
    d: sigDist(obsSig, headSignature(nominalProject(P3, v.dir, dist, fov, aspect))),
  }));
  scored.sort((a,b)=>a.d-b.d);
  const out = scored.slice(0, keep || 3);
  if (mustInclude && !out.some(s=>s.def.id===mustInclude)){
    const extra = scored.find(s=>s.def.id===mustInclude);
    if (extra) out.push(extra);
  }
  return out;
}

function poseSubset(lm, count){
  const idx = lm.map((p,i)=>i);
  const cell = Math.ceil(Math.sqrt(count));
  const pick = new Map();
  for (const i of idx){
    const k = Math.min(cell-1, Math.floor(lm[i].x*cell)) + cell*Math.min(cell-1, Math.floor(lm[i].y*cell));
    if (!pick.has(k)) pick.set(k, i);
  }
  const out = [...pick.values()];
  // Always keep the named anatomy — those are the points every other part of
  // the app anchors to.
  for (const k of KP_DEFS) if (!out.includes(k.mp)) out.push(k.mp);
  return out;
}

function fitMultiView(views, opts){
  opts = opts || {};
  const front = views[0];
  const aspect = front.aspect;
  /* The lens is an input, not a fitted quantity. Field of view and camera
     distance trade off against each other almost exactly over a face-sized
     object — the dolly-zoom degeneracy — so "solving" for it mostly fits noise.
     It is offered as a field the clinic can set to whatever their camera
     actually is, and the reprojection figures in the report say whether the
     value is doing the geometry any harm. */
  const fov = opts.fov || 45;
  const P0 = lmToRaw(front.lm, aspect);
  const { tris, nb } = frontTopology(front.lm, aspect);

  // The front camera. Placed so the full frame subtends the chosen field of
  // view in the same units buildGeometry works in — image x spans ±aspect/2,
  // image y spans ±1/2.
  const camZ = () => 0.5 / Math.tan(fov*Math.PI/360);
  const C = [0, 0, camZ()];

  /* The ray each point is allowed to slide along: from the front camera
     through the landmark's position IN THE IMAGE, which is the plane z = 0.

     Not through the detector's 3-D guess — that is the mistake worth spelling
     out. The guess carries a depth, and a depth tilts the line, so sliding
     along it moves the landmark sideways in the front photograph as well as
     forwards. The image ray is the only line every point on it shares a
     photographic observation with. */
  const dir = P0.map(p => [p[0]-C[0], p[1]-C[1], -C[2]]);
  // Start where the detector put it: the point on that ray at the guessed
  // depth. This also quietly undoes the orthographic placement the single-view
  // build has to live with, since we now know where the camera was.
  /* The reference face, when there is one, in place of the detector's own
     depth. Everything downstream reads s0: it is the starting point, what
     lambdaPrior pulls back toward, and what the smoothing measures its
     correction against. Replacing it therefore re-bases the whole solve on a
     real head rather than on a generic one. */
  const s0 = referenceDepthPrior(P0, C[2]) || P0.map(p => Math.max(0.25, 1 - p[2]/C[2]));
  const s = Float64Array.from(s0);
  const at = i => [C[0]+s[i]*dir[i][0], C[1]+s[i]*dir[i][1], C[2]+s[i]*dir[i][2]];
  const pts = () => P0.map((_,i)=>at(i));
  const Pinit = pts();

  // Observations in the same normalised device space the projection produces.
  for (const v of views){
    v.obs = v.lm.map(p => [ p.x*2-1, 1-p.y*2 ]);
    v.seedDir = (VIEW_BY_ID[v.role] || VIEW_BY_ID.front).dir;
  }
  const sub = poseSubset(front.lm, FIT.poseSubset);

  const seedFor = (d, dist) => {
    const L = Math.hypot(d[0],d[1],d[2]) || 1;
    const c = new THREE.PerspectiveCamera(fov, aspect, 0.05, 100);
    c.position.set(d[0]/L*dist, d[1]/L*dist, d[2]/L*dist);
    c.lookAt(0,0,0);
    const e = new THREE.Euler().setFromQuaternion(c.quaternion,'XYZ');
    return [c.position.x, c.position.y, c.position.z, e.x, e.y, e.z];
  };

  const others = views.slice(1);

  for (let pass=0; pass<FIT.passes; pass++){
    const P = pts();
    const N = landmarkNormals(P, tris);

    /* ── cameras ── */
    for (const v of others){
      // Visibility against the current surface, from the direction this view is
      // nominally looking, so the far cheek of a profile carries no weight.
      const d = v.solved
        ? [v.solved.params[0], v.solved.params[1], v.solved.params[2]]
        : (()=>{ const q=v.seedDir, L=Math.hypot(q[0],q[1],q[2]); const r=camZ()*1.4;
                 return [q[0]/L*r, q[1]/L*r, q[2]/L*r]; })();
      const P3  = sub.map(i=>P[i]);
      const obs = sub.map(i=>v.obs[i]);
      const weightsFrom = c3 => sub.map(i => {
        const vx=c3[0]-P[i][0], vy=c3[1]-P[i][1], vz=c3[2]-P[i][2];
        const L=Math.hypot(vx,vy,vz)||1;
        const c = (N[i][0]*vx + N[i][1]*vy + N[i][2]*vz)/L;
        return c > FIT.minWeight ? Math.pow(c, 1.5) : 0;
      });

      let best = v.solved
        ? fitCamera(P3, obs, weightsFrom(d), fov, v.aspect, v.solved.params)
        : null;
      // Multi-seed on the first pass. Seeding only from the box the photo was
      // filed in makes a mis-filed photograph converge to a confident wrong
      // answer; trying every standard direction and keeping the best both fixes
      // that and is what the slot check reads to say the picture is in the
      // wrong box. Candidates are compared on MEDIAN residual, not summed cost
      // — each candidate weights a different set of landmarks as visible, so
      // the sums are not the same quantity.
      if (!best){
        // Seeded from the three directions whose predicted view most resembles
        // the photograph, NOT from the box it was filed in — a mis-filed
        // photograph would otherwise converge to a confident wrong pose and
        // drag every depth with it. Signature first because it survives the
        // planar mirror ambiguity that PnP alone does not.
        const ranked = rankViews(P, v.obs, fov, v.aspect, camZ()*1.35, 3, v.role);
        let coarse = null;
        for (const cand of ranked){
          for (const dist of [camZ()*1.15, camZ()*1.8]){
            const seed = seedFor(cand.def.dir, dist);
            const r = fitCamera(P3, obs, weightsFrom(seed.slice(0,3)), fov, v.aspect, seed, 16);
            if (r.seen < 25) continue;
            if (!coarse || r.med < coarse.med) coarse = r;
          }
        }
        if (coarse)
          best = fitCamera(P3, obs, weightsFrom(coarse.params.slice(0,3)), fov, v.aspect, coarse.params);
      }
      v.solved = best;
    }

    /* ── depths ──
       Each point's depth is a 1-D least squares against every view that can see
       it, coupled to its neighbours by a Laplacian term and pulled weakly back
       toward the detector's own guess. Gauss-Seidel because the system is
       diagonally dominant and a direct solve of 468 coupled unknowns would be
       pointless machinery for the same answer. */
    /* ── which views are allowed to move depth (v28) ──

       Every view still gets its CAMERA solved above, because a solved camera is
       what the atlas needs to paint from, and the ¾ views are the only ones
       that see the ear and the preauricular cheek at all. But a solved camera
       and a trustworthy depth observation are two different things, and this
       code used to treat them as one.

       Measured on a real scanned face against an honest leave-one-out prior,
       adding the two ¾ views to the depth solve:

         with a traced profile   2.36 mm  ->  3.57 mm
         with nothing traced     2.97 mm  ->  4.33 mm

       They lose in every configuration. The detector's landmarks on a 45° view
       are poor for the central face, and the multi-view solve lets the cameras
       absorb the disagreement rather than rejecting it. Raising the prior
       weight walks the result monotonically back toward the front-only figure
       and no further, which says the same thing from the other side: on this
       face the oblique depth contributes nothing at all.

       So obliques are TEXTURE-ONLY. Depth comes from the reference face and
       from the hand-traced profile, which is where the measurements say it
       should come from. Set FIT.obliqueDepth true to put them back and watch
       the numbers get worse.

       Re-measured (v31) against a leave-one-out prior built from 25 other
       scanned faces rather than one, which is the test the paragraph above
       asked for. The finding held:

         with a traced profile   2.45 mm  ->  3.88 mm
         raising lambdaPrior     3.88  3.77  3.56  3.27 mm  at 0.05 0.15 0.4 1.0

       Same shape as before: the obliques lose, and leaning harder on the prior
       walks the loss back toward the front-only figure without ever reaching
       it. Twenty-five strangers do not rescue a 45° detection.

       One consequence worth knowing before anything here is tuned: with the
       shipping roles every view other than the front is texture-only, so
       `useable` is empty and this depth stage never runs at all. FIT.lambdaPrior
       and FIT.smoothIters have no effect on a front-plus-laterals build — a
       sweep of lambdaPrior from 0.02 to 1.0 returns the same 2.45 mm to the
       hundredth. They matter only with obliqueDepth on. Depth comes from the
       reference face and the traced profile, and nothing else touches it. */
    /* An ALLOWLIST, not a blocklist (v31).

       `texOnlyRoles` named the four slots that had been measured and rejected,
       and everything unnamed was trusted by default: a submental, a vertex, or
       anything dropped in the extras tray. Front plus submental plus vertex
       moved depth by 2.86% of face height, worst point 15.6%, on detections
       nobody has ever scored. The hole that matters is `other`: an extra
       dropped in the tray has no known angle, no test behind it, and no line
       in the report saying it moved the geometry, and it was voting on depth
       because nobody had thought to name it. So the list runs the other way
       and a role has to be added deliberately rather than by being forgotten.
       FIT.obliqueDepth still puts the ¾ views back for anyone re-measuring
       §4j. */
    const mayMoveDepth = v =>
      FIT.depthRoles.includes(v.role) ||
      (FIT.obliqueDepth && (v.role === 'r45' || v.role === 'l45'));
    const useable = others.filter(v => v.solved && isFinite(v.solved.rms) && mayMoveDepth(v));
    if (useable.length){
      const cams = useable.map(v => {
        const c = new THREE.PerspectiveCamera(fov, v.aspect, 0.05, 100);
        c.position.set(v.solved.params[0], v.solved.params[1], v.solved.params[2]);
        c.rotation.set(v.solved.params[3], v.solved.params[4], v.solved.params[5]);
        c.updateMatrixWorld(true); c.updateProjectionMatrix();
        const M = new THREE.Matrix4().multiplyMatrices(c.projectionMatrix, c.matrixWorldInverse);
        return { e:M.elements, pos:[c.position.x,c.position.y,c.position.z], v };
      });
      // Per view, per point visibility weight against the surface as it stands.
      const W = cams.map(cm => P0.map((_,i)=>{
        const vx=cm.pos[0]-P[i][0], vy=cm.pos[1]-P[i][1], vz=cm.pos[2]-P[i][2];
        const L=Math.hypot(vx,vy,vz)||1;
        const c = (N[i][0]*vx + N[i][1]*vy + N[i][2]*vz)/L;
        return c > FIT.minWeight ? Math.pow(c, 1.5) : 0;
      }));

      for (let it=0; it<FIT.smoothIters; it++){
        for (let i=0; i<P0.length; i++){
          // Prior: back toward the detector's own depth, weakly.
          let A = FIT.lambdaPrior, B = FIT.lambdaPrior * s0[i];
          const nbi = nb[i];
          if (nbi.length){
            // Smooth the CORRECTION, not the depth. Smoothing depth itself
            // planes off the nose and the chin — exactly the features the
            // extra photographs were brought in to measure. The correction
            // field is what is allowed to be gentle; the detector's own fine
            // structure rides along underneath it untouched.
            let mean=0; for (const j of nbi) mean += (s[j]-s0[j]);
            mean /= nbi.length;
            A += FIT.lambdaSmooth; B += FIT.lambdaSmooth * (s0[i] + mean);
          }
          for (let k=0;k<cams.length;k++){
            const w = W[k][i]; if (w<=0) continue;
            const e = cams[k].e, o = cams[k].v.obs[i];
            // x(s) and y(s) are each a ratio of two affine functions of s.
            // Linearise about the current s — one Newton step per sweep, and
            // the sweeps repeat, so this converges without the algebra of a
            // closed form that would not be exact anyway.
            const px=C[0]+s[i]*dir[i][0], py=C[1]+s[i]*dir[i][1], pz=C[2]+s[i]*dir[i][2];
            const cw = e[3]*px + e[7]*py + e[11]*pz + e[15];
            if (cw <= 1e-6) continue;
            const cx = (e[0]*px + e[4]*py + e[8]*pz  + e[12]) / cw;
            const cy = (e[1]*px + e[5]*py + e[9]*pz  + e[13]) / cw;
            const dw = e[3]*dir[i][0] + e[7]*dir[i][1] + e[11]*dir[i][2];
            const dxn= e[0]*dir[i][0] + e[4]*dir[i][1] + e[8]*dir[i][2];
            const dyn= e[1]*dir[i][0] + e[5]*dir[i][1] + e[9]*dir[i][2];
            const gx = (dxn - cx*dw)/cw, gy = (dyn - cy*dw)/cw;   // d(cx)/ds, d(cy)/ds
            const rx = o[0]-cx, ry = o[1]-cy;
            const m = Math.hypot(rx,ry);
            const hw = m > FIT.huberPx*2 ? (FIT.huberPx*2)/m : 1;  // robust
            const ww = w*hw;
            A += ww*(gx*gx + gy*gy);
            B += ww*(gx*gx + gy*gy)*s[i] + ww*(gx*rx + gy*ry);
          }
          if (A > 1e-9){
            const ns = B/A;
            // A landmark is not allowed to run away from the detector's depth
            // by more than a factor of two. Anything that wants to is being
            // driven by a bad correspondence, not by anatomy.
            if (isFinite(ns)) s[i] = Math.min(s0[i]*2, Math.max(s0[i]*0.5, ns));
          }
        }
      }
      // Pin the gauge. Pure bookkeeping — see the note above; the shape is not
      // touched by this.
      let mean=0; for (let i=0;i<s.length;i++) mean += s[i]/s0[i];
      mean /= s.length;
      if (mean > 1e-6) for (let i=0;i<s.length;i++) s[i] /= mean;
    }

  }

  const P = pts();
  // How far the fit actually moved the surface away from the detector's guess,
  // as a share of face height — the honest headline number for "did the extra
  // photographs do anything".
  let moved = 0, maxMove = 0;
  for (let i=0;i<P.length;i++){
    const d = Math.hypot(P[i][0]-Pinit[i][0], P[i][1]-Pinit[i][1], P[i][2]-Pinit[i][2]);
    moved += d; maxMove = Math.max(maxMove, d);
  }
  moved /= P.length;
  // Reported as a share of face height, which is what "how much did this
  // change" has to be measured against — raw landmark units mean nothing.
  let y0=Infinity, y1=-Infinity;
  for (const p of Pinit){ y0=Math.min(y0,p[1]); y1=Math.max(y1,p[1]); }
  const height = (y1-y0) || 1;

  return { pos3:P, fov, camZ:camZ(), views, moved:moved/height, maxMove:maxMove/height, tris };
}

async function detectFor(photo, lmk){
  if (photo._lm && photo._lmFor === photo.dataUrl) return photo._lm;
  const res = lmk.detect(photo.img);
  const lm = res.faceLandmarks?.[0] || null;
  photo._lm = lm; photo._lmFor = photo.dataUrl;
  return lm;
}

function poseFromFit(solved, fov, norm, img){
  const c = norm.c, sc = norm.sc;
  return {
    params: [
      (solved.params[0]-c[0])*sc, (solved.params[1]-c[1])*sc, (solved.params[2]-c[2])*sc,
      solved.params[3], solved.params[4], solved.params[5],
    ],
    fov,
    rmsPx: solved.rms * 0.5 * img.naturalHeight,
    n: solved.n,
    diag: Math.hypot(img.naturalWidth, img.naturalHeight),
    auto: true,
  };
}

function build(){}

const HULL = {
  nTheta: 144, nPhi: 88,   // directions round and over the head
  march: 80,               // radial samples per direction
  maskLong: 220,           // long side of the working silhouette, in pixels
  smooth: 4,               // blur passes over r(θ,φ)
  erode: 2,                // cells the face region is shrunk before the shell yields to it
  minViews: 2,
};

function headMask(img, longSide){
  longSide = longSide || HULL.maskLong;
  const s = longSide / Math.max(img.naturalWidth, img.naturalHeight);
  const w = Math.max(16, Math.round(img.naturalWidth*s));
  const h = Math.max(16, Math.round(img.naturalHeight*s));
  const c = document.createElement('canvas'); c.width=w; c.height=h;
  const g = c.getContext('2d', { willReadFrequently:true });
  g.drawImage(img, 0, 0, w, h);
  let px;
  try { px = g.getImageData(0,0,w,h).data; }
  catch { return { ok:false, why:'the browser would not let this photograph be read back' }; }

  // Border samples: top and sides only. The bottom edge belongs to the torso.
  const band = Math.max(2, Math.round(Math.min(w,h)*0.05));
  const samples = [];
  const sampleAt = (x,y)=>{ const i=(y*w+x)*4; samples.push([px[i],px[i+1],px[i+2]]); };
  for (let y=0;y<band;y++) for (let x=0;x<w;x++) sampleAt(x,y);
  for (let y=band;y<h;y++) for (let x=0;x<band;x++){ sampleAt(x,y); sampleAt(w-1-x,y); }

  /* The palette: quantise the samples, take the biggest bins as cluster seeds,
     refine each centre with the mean of its members and give it a tolerance
     from its own spread. Cheap and entirely adequate for "wall, frame, mirror". */
  const Q = 28, bins = new Map();
  for (const smp of samples){
    const k = ((smp[0]/Q)|0)*10000 + ((smp[1]/Q)|0)*100 + ((smp[2]/Q)|0);
    let b = bins.get(k);
    if (!b){ b = { n:0, r:0, g:0, b:0 }; bins.set(k, b); }
    b.n++; b.r+=smp[0]; b.g+=smp[1]; b.b+=smp[2];
  }
  const ranked = [...bins.values()].sort((a,b)=>b.n-a.n)
    .filter(b => b.n >= samples.length*0.02).slice(0, 4);
  if (!ranked.length)
    return { ok:false, why:'the backdrop is too busy — no dominant colour anywhere round the frame' };
  const clusters = ranked.map(b => ({ c:[b.r/b.n, b.g/b.n, b.b/b.n], tol:30 }));
  for (const cl of clusters){
    const ds = [];
    for (const smp of samples){
      const d = Math.hypot(smp[0]-cl.c[0], smp[1]-cl.c[1], smp[2]-cl.c[2]);
      if (d < 60) ds.push(d);
    }
    ds.sort((a,b)=>a-b);
    cl.tol = Math.max(30, (ds[Math.floor(ds.length*0.9)]||0) * 1.7);
  }
  const covered = samples.reduce((n,smp)=> n + (clusters.some(cl =>
    Math.hypot(smp[0]-cl.c[0], smp[1]-cl.c[1], smp[2]-cl.c[2]) <= cl.tol) ? 1 : 0), 0);
  const borderFrac = covered / samples.length;

  const isBg = new Uint8Array(w*h);
  for (let i=0, p=0; i<w*h; i++, p+=4){
    for (const cl of clusters){
      if (Math.hypot(px[p]-cl.c[0], px[p+1]-cl.c[1], px[p+2]-cl.c[2]) <= cl.tol){ isBg[i]=1; break; }
    }
  }

  // Flood the background inward from the frame edge. Anything it cannot reach
  // is the subject, holes included.
  const seen = new Uint8Array(w*h);
  const stack = [];
  for (let x=0;x<w;x++){ for (const y of [0,h-1]){ const i=y*w+x; if (isBg[i] && !seen[i]){ seen[i]=1; stack.push(i); } } }
  for (let y=0;y<h;y++){ for (const x of [0,w-1]){ const i=y*w+x; if (isBg[i] && !seen[i]){ seen[i]=1; stack.push(i); } } }
  while (stack.length){
    const i = stack.pop(), x = i%w, y = (i/w)|0;
    if (x>0)   { const j=i-1; if (isBg[j] && !seen[j]){ seen[j]=1; stack.push(j); } }
    if (x<w-1) { const j=i+1; if (isBg[j] && !seen[j]){ seen[j]=1; stack.push(j); } }
    if (y>0)   { const j=i-w; if (isBg[j] && !seen[j]){ seen[j]=1; stack.push(j); } }
    if (y<h-1) { const j=i+w; if (isBg[j] && !seen[j]){ seen[j]=1; stack.push(j); } }
  }
  const mask = new Uint8Array(w*h);
  let fg = 0;
  for (let i=0;i<w*h;i++){ mask[i] = seen[i] ? 0 : 1; fg += mask[i]; }
  const fgFrac = fg/(w*h);
  if (fgFrac < 0.05) return { ok:false, why:'almost nothing in the frame reads as subject' };
  if (fgFrac > 0.80) return { ok:false, why:'almost the whole frame reads as subject — no usable backdrop round it' };

  // Keep the biggest blob only. A towel or a stand becomes its own island and
  // is dropped; the head-and-torso is always the biggest thing in a head shot.
  const lab = new Int32Array(w*h).fill(-1);
  let best=-1, bestN=0, nComp=0, total=0;
  for (let i0=0;i0<w*h;i0++){
    if (!mask[i0] || lab[i0]>=0) continue;
    const id = nComp++; let n=0; const st=[i0]; lab[i0]=id;
    while (st.length){
      const i=st.pop(); n++;
      const x=i%w, y=(i/w)|0;
      const push=j=>{ if (mask[j] && lab[j]<0){ lab[j]=id; st.push(j); } };
      if (x>0) push(i-1); if (x<w-1) push(i+1);
      if (y>0) push(i-w); if (y<h-1) push(i+w);
    }
    total += n;
    if (n>bestN){ bestN=n; best=id; }
  }
  if (best>=0 && bestN < total*0.55)
    return { ok:false, why:'no single subject stands out — several things of similar size are in front of the backdrop' };
  for (let i=0;i<w*h;i++) if (mask[i] && lab[i]!==best) mask[i]=0;

  // The head must be roughly where a head is in a head shot: some of the blob
  // in the central upper part of the frame. Guards against a mask that is all
  // furniture along one side.
  let central = false;
  for (let y=(h*0.10)|0; y<h*0.72 && !central; y++)
    for (let x=(w*0.25)|0; x<w*0.75; x++)
      if (mask[y*w+x]){ central = true; break; }
  if (!central)
    return { ok:false, why:'the subject is not where a head would be in the frame' };

  return { ok:true, w, h, data:mask, fgFrac, borderFrac };
}

function headStats(m){
  const rows = [];
  let yTop=-1, yBot=-1;
  for (let y=0;y<m.h;y++){
    let x0=-1, x1=-1, n=0;
    for (let x=0;x<m.w;x++) if (m.data[y*m.w+x]){ if (x0<0) x0=x; x1=x; n++; }
    rows.push({x0,x1,n});
    if (n){ if (yTop<0) yTop=y; yBot=y; }
  }
  if (yTop<0) return null;
  const blobH = yBot-yTop+1;
  let wMax = 0;
  for (let y=yTop; y<yTop+Math.max(1, blobH*0.4) && y<=yBot; y++)
    if (rows[y].n) wMax = Math.max(wMax, rows[y].x1-rows[y].x0+1);
  const hEnd = Math.min(yBot, Math.round(yTop + Math.max(wMax*1.35, blobH*0.2)));
  let sx=0, sy=0, n=0;
  for (let y=yTop; y<=hEnd; y++){
    const r = rows[y]; if (!r.n) continue;
    sx += (r.x0+r.x1)/2; sy += y; n++;
  }
  if (!n) return null;
  return { hFrac:(hEnd-yTop+1)/m.h,
           cx:(sx/n)/(m.w-1)*2-1, cy:1-(sy/n)/(m.h-1)*2 };
}

function estimateSilhouettePose(photo, frontMask){
  const def = VIEW_BY_ID[photo.role];
  if (!def || !def.geo) return { why:'no fixed direction for this box' };
  const mask = headMask(photo.img);
  if (!mask.ok) return { why:mask.why };
  const st = headStats(mask);
  if (!st) return { why:'empty outline' };
  const fov = parseFloat($('#poseFov')?.value) || 45;
  const tR = S.lm3[234], tL = S.lm3[454];
  const C = new THREE.Vector3((tR[0]+tL[0])/2, (tR[1]+tL[1])/2, (tR[2]+tL[2])/2);
  const front = S.photos.find(p=>p.id===S.frontId);
  const dRef = front && front.pose
    ? new THREE.Vector3(front.pose.params[0], front.pose.params[1], front.pose.params[2]).distanceTo(C)
    : 6;
  const fst = frontMask ? headStats(frontMask) : null;
  const d = fst ? dRef * (fst.hFrac/st.hFrac) : dRef*1.15;

  const dir = new THREE.Vector3(...def.dir).normalize();
  const ar = photo.img.naturalWidth/photo.img.naturalHeight;
  const cam = new THREE.PerspectiveCamera(fov, ar, 0.05, 100);
  const T = C.clone();
  for (let it=0; it<4; it++){
    cam.position.copy(C).add(dir.clone().multiplyScalar(d));
    cam.lookAt(T); cam.updateMatrixWorld(true); cam.updateProjectionMatrix();
    const p = C.clone().project(cam);
    const ex = p.x - st.cx, ey = p.y - st.cy;
    if (Math.hypot(ex, ey) < 0.005) break;
    const right = new THREE.Vector3().setFromMatrixColumn(cam.matrixWorld, 0);
    const up    = new THREE.Vector3().setFromMatrixColumn(cam.matrixWorld, 1);
    const k = d*Math.tan(fov*Math.PI/360);
    T.add(right.multiplyScalar(ex*k*ar)).add(up.multiplyScalar(ey*k));
  }
  const e = new THREE.Euler().setFromQuaternion(cam.quaternion, 'XYZ');
  return { pose:{
    params:[cam.position.x, cam.position.y, cam.position.z, e.x, e.y, e.z],
    fov, rmsPx:0, n:0, diag:Math.hypot(photo.img.naturalWidth, photo.img.naturalHeight),
    auto:true, silOnly:true,
  } };
}

function faceRadiusGrid(pos, index, centre, nT, nP){
  const rad = new Float32Array(nT*nP).fill(0);
  const dir = new Float32Array(3);
  const sph = (i) => {
    const x = pos[3*i]-centre[0], y = pos[3*i+1]-centre[1], z = pos[3*i+2]-centre[2];
    const r = Math.hypot(x,y,z) || 1e-6;
    return [ Math.atan2(x, z), Math.acos(Math.max(-1, Math.min(1, y/r))), r ];
  };
  const TAU = Math.PI*2;
  for (let t=0; t<index.length; t+=3){
    const a = sph(index[t]), b = sph(index[t+1]), c = sph(index[t+2]);
    // Unwrap across the θ seam, or a triangle straddling the back of the head
    // paints a stripe all the way round.
    const th = [a[0], b[0], c[0]];
    const mn = Math.min(...th);
    for (let k=0;k<3;k++) if (th[k]-mn > Math.PI) th[k] -= TAU;
    const P = [[th[0], a[1], a[2]], [th[1], b[1], b[2]], [th[2], c[1], c[2]]];
    const gx = p => p[0]/TAU*nT, gy = p => p[1]/Math.PI*nP;
    let x0=Math.floor(Math.min(gx(P[0]),gx(P[1]),gx(P[2]))), x1=Math.ceil(Math.max(gx(P[0]),gx(P[1]),gx(P[2])));
    let y0=Math.floor(Math.min(gy(P[0]),gy(P[1]),gy(P[2]))), y1=Math.ceil(Math.max(gy(P[0]),gy(P[1]),gy(P[2])));
    y0=Math.max(0,y0); y1=Math.min(nP-1,y1);
    if (x1-x0 > nT) continue;
    const ax=gx(P[0]), ay=gy(P[0]), bx=gx(P[1]), by=gy(P[1]), cx=gx(P[2]), cy=gy(P[2]);
    const den = (by-cy)*(ax-cx) + (cx-bx)*(ay-cy);
    if (Math.abs(den) < 1e-9) continue;
    for (let y=y0; y<=y1; y++){
      for (let x=x0; x<=x1; x++){
        const sx=x+0.5, sy=y+0.5;
        const l1 = ((by-cy)*(sx-cx) + (cx-bx)*(sy-cy))/den;
        const l2 = ((cy-ay)*(sx-cx) + (ax-cx)*(sy-cy))/den;
        const l3 = 1-l1-l2;
        if (l1<-0.02 || l2<-0.02 || l3<-0.02) continue;
        const r = l1*P[0][2] + l2*P[1][2] + l3*P[2][2];
        const xi = ((x % nT) + nT) % nT;
        const k = y*nT + xi;
        // Outermost wins: a ray that grazes both the nose tip and the lip below
        // it should report the skin it would actually reach first from outside.
        if (r > rad[k]) rad[k] = r;
      }
    }
  }
  return rad;
}

function smoothRadii(rad, nT, nP, passes){
  let a = rad;
  for (let p=0; p<passes; p++){
    const b = new Float32Array(a.length);
    for (let j=0;j<nP;j++){
      const j0 = Math.max(0, j-1), j1 = Math.min(nP-1, j+1);
      for (let i=0;i<nT;i++){
        const i0 = (i-1+nT)%nT, i1 = (i+1)%nT;
        b[j*nT+i] = (a[j*nT+i]*4 + a[j*nT+i0] + a[j*nT+i1] + a[j0*nT+i] + a[j1*nT+i]) / 8;
      }
    }
    a = b;
  }
  for (const j of [0, nP-1]){
    let s=0; for (let i=0;i<nT;i++) s += a[j*nT+i];
    s/=nT; for (let i=0;i<nT;i++) a[j*nT+i]=s;
  }
  return a;
}

function erodeMask(m, nT, nP, k){
  let a = m;
  for (let p=0;p<k;p++){
    const b = new Uint8Array(a.length);
    for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
      const i0=(i-1+nT)%nT, i1=(i+1)%nT, j0=Math.max(0,j-1), j1=Math.min(nP-1,j+1);
      b[j*nT+i] = (a[j*nT+i] && a[j*nT+i0] && a[j*nT+i1] && a[j0*nT+i] && a[j1*nT+i]) ? 1 : 0;
    }
    a = b;
  }
  return a;
}

function shellGeometry(rad, faceR, nT, nP, centre, cutY, ears){
  const has = new Uint8Array(nT*nP);
  for (let k=0;k<nT*nP;k++) has[k] = faceR[k] > 0 ? 1 : 0;
  const inner = erodeMask(has, nT, nP, HULL.erode);
  /* Where the face already exists the shell is pinned just BENEATH it — not to
     whichever of the two is larger. That single choice is the difference
     between a clean join and a torn one. The face's boundary is the Delaunay
     edge of a landmark cloud, which is genuinely ragged; the shell's is a grid
     cell, which is stepped. Take the larger and the two ragged edges interleave,
     so the shell shows through the face in a sawtooth all round the jaw. Tucked
     under, the face simply covers the join and the only visible edge is the
     face's own.

     The pinned values are then blurred outward — smooth, restore, smooth — so
     the tuck rises to meet the carved hull over several cells instead of
     stepping up to it. */
  const r = new Float32Array(nT*nP);
  /* Interior cells tuck 1.5% under the face. The RING — the last cells before
     the face's edge — sits 1% PROUD of it, not flush. Flush looked right until
     the photo wrap ran: the wrap's occlusion test compares depths with a small
     bias, and a surface at exactly the face's depth sits on the knife edge of
     its own shadow — the ring came out as alternating skin and grey spikes all
     round the trimmed fringe. Proud of the face, the ring IS the nearest
     surface where it shows, passes its own depth test cleanly, and the 1%
     ledge disappears under the texture. (Tucking the ring instead opened a
     dark gap under the chin — the face oval has no underside.) */
  /* Nearly flush, where it used to be 1.5% under (v26).

     The tuck existed because the face's ragged Delaunay edge and the shell's
     stepped grid edge interleave, so a shell at the same radius pokes through
     the face in a sawtooth. Dropping the shell under the face hid that. What
     it could not hide is itself: 1.5% of the head's radius is about a
     millimetre and a half, so the face patch stood on a lip all the way round,
     and the lip caught the light in exactly the sawtooth the tuck was there to
     prevent. Same artefact, one step further down the pipeline.

     A tenth of that is still enough to settle which surface wins, and too
     small to catch light. What actually removes the seam is welding the
     normals across it, which happens once the geometry is assembled. */
  const pinR = k => faceR[k] * (inner[k] ? 0.9985 : 1.0015);

  /* ── the crater, and how it is filled (v26) ──

     Five passes of blur were not enough, and no number of them would have
     been. The problem was not the smoothing, it was what was being smoothed
     TOWARD. Outside the face every cell started at the canonical head's own
     radius, which around the cheek and the jaw sits well outside the face, so
     the field had a cliff at the face's edge and blurring a cliff gives a
     ramp two or three cells wide. On screen that is a trench with the face
     sitting at the bottom of it, which is what a mask stuck on a mannequin
     looks like.

     So carry the face outward first. Every cell outside the face takes the
     radius of the nearest cell inside it, found by a two-pass chamfer sweep
     over the grid, and only then is that blended toward the canonical head
     over a long band. Near the face the surface continues the face; far from
     it the head is the head; in between is a ramp thirteen cells wide instead
     of two. The blur that follows is then tidying a smooth field rather than
     trying to hide a cliff. */
  /* Lift the ears out of the way first.

     Everything below smooths hard, and an ear is a small bump on a big head:
     eighteen passes of blur flatten it into the skull, and the marks that size
     it then have nothing to show for themselves. So separate the canonical
     head into a base and its relief, work on the base, and put the relief back
     afterwards. The ear keeps its shape, the skull loses its faceting, and the
     two do not have to be traded against each other. */
  const radBase = smoothRadii(rad, nT, nP, 7);
  const relief = new Float32Array(nT*nP);
  let reliefMax = 0;
  for (let k=0;k<nT*nP;k++){
    relief[k] = Math.max(0, rad[k] - radBase[k]);
    if (relief[k] > reliefMax) reliefMax = relief[k];
  }
  const BAND = 13;
  const far = 1e9;
  const dist = new Float32Array(nT*nP).fill(far);
  const near = new Float32Array(nT*nP);
  for (let k=0;k<nT*nP;k++) if (has[k]){ dist[k] = 0; near[k] = pinR(k); }
  // Chamfer distance, forward then backward, wrapping in theta and clamped in
  // phi. Two sweeps is exact enough for a field this smooth.
  const relax = (j, i, dj, di, d) => {
    const jj = j+dj; if (jj < 0 || jj >= nP) return;
    const ii = ((i+di)%nT + nT)%nT;
    const from = jj*nT+ii, to = j*nT+i;
    const cand = dist[from] + d;
    if (cand < dist[to]){ dist[to] = cand; near[to] = near[from]; }
  };
  for (let pass=0; pass<2; pass++){
    for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
      relax(j,i,-1,0,1); relax(j,i,0,-1,1); relax(j,i,-1,-1,1.414); relax(j,i,-1,1,1.414);
    }
    for (let j=nP-1;j>=0;j--) for (let i=nT-1;i>=0;i--){
      relax(j,i,1,0,1); relax(j,i,0,1,1); relax(j,i,1,1,1.414); relax(j,i,1,-1,1.414);
    }
  }
  for (let k=0;k<nT*nP;k++){
    if (has[k]){ r[k] = pinR(k); continue; }
    if (dist[k] >= far){ r[k] = rad[k]; continue; }
    const t = Math.min(1, dist[k]/BAND);
    let w = t*t*(3-2*t);                                // smoothstep
    /* An ear sits only a few cells outside the face oval, so the ramp above
       would have it barely out of the face's shadow and its own shape would be
       three-quarters replaced by an extrapolated cheek. Anywhere the canonical
       head has real relief, the head wins. */
    if (reliefMax > 0) w = Math.max(w, Math.min(1, relief[k]/(0.35*reliefMax)));
    /* Never let the head duck INSIDE what the face is doing as it leaves the
       face. A canonical skull narrower than this patient's cheek would pinch
       the surface in just past the jaw, which reads as a dent. */
    const head = Math.max(rad[k], near[k]*(1-0.12*w));
    r[k] = near[k]*(1-w) + head*w;
  }
  /* Now blur, and blur properly. The field is already smooth, so these passes
     are removing the grid's own faceting rather than papering over a step, and
     the face cells are re-pinned each pass so the patch itself never drifts. */
  /* Ear cells are held through the blur, exactly the way face cells are.
     Adding the relief back afterwards was not enough: eighteen passes pull the
     ear's shoulders in as well as its peak, and an ear reduced to a bump on
     the side of the skull fails the only thing the ear marks are for. Held, it
     keeps the shape the marks gave it, and the ring of cells just outside it
     is still free to smooth, so it does not arrive out of a step. */
  /* The held cells are the EARS, named, not everything with relief on it.

     Thresholding the relief field looked like a cheap way to find them and was
     not: the canonical head is a union of ellipsoids, so it has creases at the
     jaw and at the neck junction that carry as much relief as an ear does.
     Holding those unsmoothed put a terraced ridge down the jawline and along
     the temple, which is worse than the flattened ear it was fixing. So test
     each direction against the ear ellipsoids themselves and hold only what
     actually hits one. */
  const earHold = new Uint8Array(nT*nP);
  if (ears){
    for (const side of ['R','L']){
      const e = ears[side]; if (!e) continue;
      const oc = [centre[0]-e.c[0], centre[1]-e.c[1], centre[2]-e.c[2]];
      for (let j=0;j<nP;j++){
        const phi = (j+0.5)/nP*Math.PI, sp = Math.sin(phi), cp = Math.cos(phi);
        for (let i=0;i<nT;i++){
          const th = (i+0.5)/nT*Math.PI*2;
          const d = [sp*Math.sin(th), cp, sp*Math.cos(th)];
          // |(o + t d - c)/r| = 1, solved in the ellipsoid's own scaled space.
          let A=0, B=0, C=-1;
          for (let a=0;a<3;a++){
            const dr = d[a]/e.r[a], or_ = oc[a]/e.r[a];
            A += dr*dr; B += 2*dr*or_; C += or_*or_;
          }
          if (A < 1e-12) continue;
          const disc = B*B - 4*A*C;
          if (disc < 0) continue;
          const t = (-B + Math.sqrt(disc))/(2*A);
          if (t > 0) earHold[j*nT+i] = 1;
        }
      }
    }
  }
  for (let k=0;k<nT*nP;k++) if (earHold[k] && !has[k]) r[k] = Math.max(r[k], rad[k]);
  for (let pass=0; pass<18; pass++){
    const sm = smoothRadii(r, nT, nP, 1);
    for (let k=0;k<nT*nP;k++){
      if (has[k]){ r[k] = pinR(k); continue; }
      if (earHold[k]){ r[k] = Math.max(rad[k], sm[k]); continue; }
      r[k] = sm[k];
    }
  }
  /* Put the relief back. Where it is strong — which on this head means the
     ears and nothing else — the canonical shape wins outright rather than
     being added to a smoothed base, because a blurred peak is a shorter peak
     and an ear that has been through eighteen passes of blur is not an ear.
     Everywhere else the relief is small and simply added, so the skull keeps
     the smoothing it was given. */
  for (let k=0;k<nT*nP;k++) if (!has[k] && !earHold[k]) r[k] += relief[k];

  /* `uv` here is the shell's own grid, which is the natural atlas for it: the
     surface IS a (theta, phi) lattice, so i/nT across and j/nP down is an
     unwrap with no distortion beyond the sphere's own, no seam inside the
     head, and no packing to solve. The seam column is a separate vertex
     already, because `at` keys on i up to nT rather than wrapping, so u
     reaches 1 there instead of jumping back to 0 and smearing the whole
     texture across the back of the head. */
  const pos = [], idx = [], uv = [];
  const vid = new Int32Array((nT+1)*nP).fill(-1);
  const at = (i,j) => {
    const ii = i%nT, key = j*(nT+1) + i;
    if (vid[key] >= 0) return vid[key];
    uv.push(i/nT, 1 - (j+0.5)/nP);
    const phi = (j+0.5)/nP*Math.PI, th = (ii+0.5)/nT*Math.PI*2;
    const sp = Math.sin(phi);
    let R = r[j*nT+ii];
    // Downward-pointing cells are clamped to the cut plane, so the bottom is a
    // clean flat crop — the scanner look — instead of a frill of strands
    // reaching for the pole.
    const cp0 = Math.cos(phi);
    if (cutY !== undefined && cp0 < -1e-4){
      const Rcut = (cutY - centre[1]) / cp0;
      if (Rcut > 0 && R > Rcut) R = Rcut;
    }
    pos.push(centre[0] + sp*Math.sin(th)*R, centre[1] + Math.cos(phi)*R, centre[2] + sp*Math.cos(th)*R);
    return (vid[key] = pos.length/3 - 1);
  };
  /* The neck cut. In a real photograph the shoulders and chest cross the frame
     in every view, so the hull's downward rays never meet a silhouette edge and
     grow to the march limit — a skirt of torso hanging off the head. Clip it at
     a fixed anatomical depth below the chin, the way a scanner's own head crop
     does. The carved FIELD keeps the full data; only the geometry is cut, so
     the clip costs nothing on reload. */
  const yOf = (i,j) => {
    const ii = ((i%nT)+nT)%nT;
    return centre[1] + Math.cos((j+0.5)/nP*Math.PI) * r[j*nT+ii];
  };
  for (let j=0; j<nP-1; j++){
    for (let i=0; i<nT; i++){
      const i1 = (i+1)%nT;
      // A quad is drawn only if the face does not already own all four corners.
      const k00=j*nT+i, k10=j*nT+i1, k01=(j+1)*nT+i, k11=(j+1)*nT+i1;
      if (inner[k00] && inner[k10] && inner[k01] && inner[k11]) continue;
      if (cutY !== undefined &&
          (yOf(i,j) + yOf(i+1,j) + yOf(i+1,j+1) + yOf(i,j+1))/4 < cutY) continue;
      const a = at(i, j), b = at(i+1, j), c = at(i+1, j+1), d = at(i, j+1);
      idx.push(a, b, c, a, c, d);
    }
  }
  return { pos, idx, uv, r };
}

const CANON = { hairH: 0.45, temple: 0.40 };

const EAR_OUTLINE = [
  [0.02, 0.012, 0.042], [0.10, 0.006, 0.088], [0.25, 0.002, 0.142],
  [0.40,-0.001, 0.165], [0.50, 0.000, 0.175], [0.60, 0.000, 0.183],
  [0.75, 0.008, 0.175], [0.90, 0.022, 0.114], [0.98, 0.045, 0.089],
];

const EAR_RELIEF_V = [0.05, 0.20, 0.35, 0.50, 0.65, 0.80, 0.95];

const EAR_RELIEF_U = [0.05, 0.20, 0.35, 0.50, 0.65, 0.80, 0.95];

const EAR_RELIEF = [
  [ 0.026, 0.035, 0.041, 0.046, 0.049, 0.051, 0.054],   // v 0.05  lobe
  [-0.003, 0.023, 0.038, 0.046, 0.060, 0.077, 0.085],   // v 0.20
  [-0.001,-0.003,-0.009,-0.008, 0.039, 0.076, 0.096],   // v 0.35  concha
  [-0.007,-0.011,-0.017,-0.023, 0.030, 0.071, 0.089],   // v 0.50  concha
  [-0.009,-0.003,-0.001, 0.028, 0.053, 0.063, 0.094],   // v 0.65
  [-0.002, 0.008, 0.016, 0.028, 0.043, 0.048, 0.083],   // v 0.80
  [ 0.018, 0.030, 0.038, 0.043, 0.048, 0.053, 0.062],   // v 0.95  helix top
];

const EAR_TILT = 7*Math.PI/180;     // top sits posterior

const EAR_ATTACH_Z = 0.125;                                   // in W, behind the tragus landmark

const EAR_BACK_MAX = EAR_OUTLINE.reduce((m,r)=>Math.max(m,r[2]), 0);   // 0.183 W past that

const EAR_HALF_H   = 0.433/2;                                 // in H, half the standard height

function earLerp1(table, v){
  if (v <= table[0][0]) return [table[0][1], table[0][2]];
  const n = table.length;
  if (v >= table[n-1][0]) return [table[n-1][1], table[n-1][2]];
  for (let i=1;i<n;i++){
    if (v > table[i][0]) continue;
    const t = (v - table[i-1][0]) / (table[i][0] - table[i-1][0]);
    return [ table[i-1][1] + t*(table[i][1]-table[i-1][1]),
             table[i-1][2] + t*(table[i][2]-table[i-1][2]) ];
  }
  return [table[n-1][1], table[n-1][2]];
}

function earRelief(u, v){
  const axis = (arr, x) => {
    if (x <= arr[0]) return [0, 0];
    if (x >= arr[arr.length-1]) return [arr.length-1, 0];
    for (let i=1;i<arr.length;i++)
      if (x <= arr[i]) return [i-1, (x-arr[i-1])/(arr[i]-arr[i-1])];
    return [arr.length-1, 0];
  };
  const [j, fv] = axis(EAR_RELIEF_V, v);
  const [i, fu] = axis(EAR_RELIEF_U, u);
  const j1 = Math.min(EAR_RELIEF_V.length-1, j+1), i1 = Math.min(EAR_RELIEF_U.length-1, i+1);
  const a = EAR_RELIEF[j][i]*(1-fu) + EAR_RELIEF[j][i1]*fu;
  const b = EAR_RELIEF[j1][i]*(1-fu) + EAR_RELIEF[j1][i1]*fu;
  return a*(1-fv) + b*fv;
}

function earShape(t, sx, W, H, fit){
  const height = (fit && isFinite(fit.ry) ? fit.ry*2 : 0.433*H);
  const yc     = (fit && isFinite(fit.yc) ? fit.yc : t[1] - 0.01*H);
  // How deep the ear runs back. The mark, when there is one, scales the whole
  // outline rather than replacing it, so a marked ear keeps its shape.
  // `rz` is the marked reach BEHIND the attachment plane, so the standard ear
  // normalises to exactly 1. See EAR_BACK_MAX.
  const depth  = (fit && isFinite(fit.rz) ? fit.rz/(EAR_BACK_MAX*W) : 1);
  const attachX = t[0] + sx*0.01*W;
  const attachZ = (fit && isFinite(fit.attachZ)) ? fit.attachZ : t[2] - EAR_ATTACH_Z*W;
  const yBot = yc - height/2, yTop = yc + height/2;
  const at = p => {
    const v = (p[1]-yBot)/height;
    if (v < 0 || v > 1) return null;
    const shift = -(p[1]-yc)*Math.tan(EAR_TILT);
    const [a, b] = earLerp1(EAR_OUTLINE, v);
    const zF = attachZ - a*W*depth + shift, zB = attachZ - b*W*depth + shift;
    const span = zF - zB;
    if (!(span > 1e-9)) return null;
    const u = (zF - p[2]) / span;
    if (u < 0 || u > 1) return null;
    return { u, v };
  };
  return {
    // Inside the ear solid: on the outer side of the attachment plane, within
    // the outline, and no further out than the relief says.
    inside: p => {
      const q = at(p); if (!q) return false;
      const lat = (p[0]-attachX)*sx;
      if (lat < 0) return false;
      const R = earRelief(q.u, q.v);
      return R > 0 && lat <= R*W;
    },
    // What the ear-region tests and the smoothing hold want: a box round it.
    c: [attachX + sx*0.05*W, yc, attachZ - 0.09*W*depth],
    r: [0.075*W, height*0.55, 0.115*W*depth],
    attachX, attachZ, yBot, yTop, height, depth, sx,
    markedDepth: !!(fit && isFinite(fit.rz)),
    flare: fit && isFinite(fit.flare) ? fit.flare : 1,
  };
}

const HEAD_NA = 48, HEAD_NY = 33;

const HEAD_Y0 = -0.72, HEAD_Y1 = 0.72;

const HEAD_R = new Float32Array([
  0.470,0.468,0.464,0.460,0.456,0.455,0.454,0.453,0.447,0.415,0.381,0.341,0.336,0.331,0.326,0.328,
  0.324,0.308,0.306,0.304,0.310,0.323,0.332,0.333,0.339,0.333,0.332,0.323,0.310,0.304,0.306,0.308,
  0.324,0.328,0.326,0.331,0.336,0.341,0.381,0.415,0.447,0.453,0.454,0.455,0.456,0.460,0.464,0.468,
  0.475,0.472,0.468,0.464,0.459,0.456,0.454,0.453,0.447,0.415,0.382,0.344,0.336,0.327,0.318,0.315,
  0.312,0.299,0.301,0.307,0.319,0.338,0.356,0.371,0.370,0.371,0.356,0.338,0.319,0.307,0.301,0.299,
  0.312,0.315,0.318,0.327,0.336,0.344,0.382,0.415,0.447,0.453,0.454,0.456,0.459,0.464,0.468,0.472,
  0.478,0.477,0.473,0.469,0.463,0.459,0.455,0.454,0.447,0.415,0.385,0.350,0.339,0.329,0.321,0.319,
  0.316,0.312,0.318,0.329,0.344,0.360,0.375,0.382,0.381,0.382,0.375,0.360,0.344,0.329,0.318,0.312,
  0.316,0.319,0.321,0.329,0.339,0.350,0.385,0.415,0.447,0.454,0.455,0.459,0.463,0.469,0.473,0.477,
  0.481,0.480,0.478,0.474,0.469,0.463,0.458,0.454,0.447,0.415,0.389,0.361,0.347,0.340,0.336,0.334,
  0.331,0.332,0.338,0.350,0.367,0.380,0.392,0.401,0.404,0.401,0.392,0.380,0.367,0.350,0.338,0.332,
  0.331,0.334,0.336,0.340,0.347,0.361,0.389,0.415,0.447,0.454,0.458,0.463,0.469,0.474,0.478,0.480,
  0.482,0.481,0.481,0.479,0.475,0.470,0.463,0.456,0.447,0.417,0.393,0.377,0.372,0.364,0.359,0.354,
  0.355,0.359,0.365,0.370,0.378,0.390,0.401,0.408,0.411,0.408,0.401,0.390,0.378,0.370,0.365,0.359,
  0.355,0.354,0.359,0.364,0.372,0.377,0.393,0.417,0.447,0.456,0.463,0.470,0.475,0.479,0.481,0.481,
  0.482,0.482,0.482,0.481,0.480,0.477,0.471,0.462,0.449,0.423,0.399,0.394,0.391,0.382,0.378,0.378,
  0.382,0.385,0.391,0.392,0.391,0.398,0.417,0.428,0.429,0.428,0.417,0.398,0.391,0.392,0.391,0.385,
  0.382,0.378,0.378,0.382,0.391,0.394,0.399,0.423,0.449,0.462,0.471,0.477,0.480,0.481,0.482,0.482,
  0.482,0.482,0.482,0.482,0.482,0.481,0.479,0.473,0.455,0.430,0.421,0.416,0.407,0.398,0.399,0.402,
  0.406,0.408,0.410,0.411,0.406,0.411,0.433,0.453,0.457,0.453,0.433,0.411,0.406,0.411,0.410,0.408,
  0.406,0.402,0.399,0.398,0.407,0.416,0.421,0.430,0.455,0.473,0.479,0.481,0.482,0.482,0.482,0.482,
  0.487,0.487,0.487,0.487,0.487,0.487,0.487,0.486,0.470,0.446,0.437,0.430,0.419,0.416,0.419,0.421,
  0.423,0.424,0.427,0.425,0.420,0.421,0.443,0.462,0.466,0.462,0.443,0.421,0.420,0.425,0.427,0.424,
  0.423,0.421,0.419,0.416,0.419,0.430,0.437,0.446,0.470,0.486,0.487,0.487,0.487,0.487,0.487,0.487,
  0.496,0.496,0.496,0.496,0.496,0.496,0.496,0.495,0.480,0.462,0.452,0.441,0.434,0.433,0.434,0.435,
  0.438,0.439,0.441,0.440,0.436,0.441,0.458,0.475,0.480,0.475,0.458,0.441,0.436,0.440,0.441,0.439,
  0.438,0.435,0.434,0.433,0.434,0.441,0.452,0.462,0.480,0.495,0.496,0.496,0.496,0.496,0.496,0.496,
  0.497,0.497,0.497,0.497,0.497,0.497,0.497,0.496,0.488,0.482,0.465,0.454,0.448,0.446,0.446,0.448,
  0.450,0.453,0.453,0.453,0.448,0.447,0.462,0.480,0.484,0.480,0.462,0.447,0.448,0.453,0.453,0.453,
  0.450,0.448,0.446,0.446,0.448,0.454,0.465,0.482,0.488,0.496,0.497,0.497,0.497,0.497,0.497,0.497,
  0.497,0.497,0.497,0.497,0.497,0.497,0.497,0.496,0.493,0.488,0.473,0.465,0.458,0.455,0.455,0.458,
  0.462,0.465,0.465,0.463,0.454,0.444,0.454,0.472,0.478,0.472,0.454,0.444,0.454,0.463,0.465,0.465,
  0.462,0.458,0.455,0.455,0.458,0.465,0.473,0.488,0.493,0.496,0.497,0.497,0.497,0.497,0.497,0.497,
  0.504,0.504,0.504,0.504,0.504,0.504,0.504,0.504,0.504,0.501,0.483,0.474,0.468,0.463,0.463,0.469,
  0.475,0.477,0.475,0.471,0.460,0.439,0.455,0.480,0.500,0.480,0.455,0.439,0.460,0.471,0.475,0.477,
  0.475,0.469,0.463,0.463,0.468,0.474,0.483,0.501,0.504,0.504,0.504,0.504,0.504,0.504,0.504,0.504,
  0.519,0.519,0.519,0.519,0.519,0.519,0.519,0.519,0.519,0.518,0.493,0.482,0.476,0.471,0.473,0.480,
  0.487,0.488,0.484,0.478,0.463,0.445,0.481,0.518,0.547,0.518,0.481,0.445,0.463,0.478,0.484,0.488,
  0.487,0.480,0.473,0.471,0.476,0.482,0.493,0.518,0.519,0.519,0.519,0.519,0.519,0.519,0.519,0.519,
  0.528,0.528,0.528,0.528,0.528,0.528,0.528,0.528,0.527,0.523,0.501,0.487,0.483,0.480,0.483,0.490,
  0.497,0.498,0.492,0.478,0.460,0.445,0.478,0.532,0.556,0.532,0.478,0.445,0.460,0.478,0.492,0.498,
  0.497,0.490,0.483,0.480,0.483,0.487,0.501,0.523,0.527,0.528,0.528,0.528,0.528,0.528,0.528,0.528,
  0.545,0.545,0.545,0.545,0.545,0.545,0.545,0.544,0.540,0.527,0.503,0.493,0.491,0.489,0.491,0.497,
  0.504,0.504,0.495,0.475,0.455,0.440,0.458,0.514,0.538,0.514,0.458,0.440,0.455,0.475,0.495,0.504,
  0.504,0.497,0.491,0.489,0.491,0.493,0.503,0.527,0.540,0.544,0.545,0.545,0.545,0.545,0.545,0.545,
  0.559,0.559,0.559,0.559,0.559,0.559,0.558,0.558,0.556,0.528,0.505,0.498,0.497,0.495,0.496,0.500,
  0.504,0.503,0.493,0.472,0.450,0.432,0.444,0.493,0.515,0.493,0.444,0.432,0.450,0.472,0.493,0.503,
  0.504,0.500,0.496,0.495,0.497,0.498,0.505,0.528,0.556,0.558,0.558,0.559,0.559,0.559,0.559,0.559,
  0.555,0.555,0.555,0.555,0.555,0.555,0.555,0.554,0.550,0.527,0.508,0.503,0.502,0.498,0.497,0.499,
  0.499,0.496,0.485,0.468,0.447,0.428,0.429,0.471,0.488,0.471,0.429,0.428,0.447,0.468,0.485,0.496,
  0.499,0.499,0.497,0.498,0.502,0.503,0.508,0.527,0.550,0.554,0.555,0.555,0.555,0.555,0.555,0.555,
  0.554,0.554,0.554,0.554,0.554,0.553,0.552,0.549,0.545,0.528,0.512,0.510,0.505,0.500,0.497,0.496,
  0.493,0.485,0.475,0.467,0.460,0.434,0.419,0.449,0.467,0.449,0.419,0.434,0.460,0.467,0.475,0.485,
  0.493,0.496,0.497,0.500,0.505,0.510,0.512,0.528,0.545,0.549,0.552,0.553,0.554,0.554,0.554,0.554,
  0.553,0.553,0.553,0.552,0.552,0.550,0.548,0.545,0.541,0.527,0.518,0.516,0.508,0.500,0.494,0.490,
  0.488,0.481,0.478,0.479,0.477,0.455,0.421,0.433,0.453,0.433,0.421,0.455,0.477,0.479,0.478,0.481,
  0.488,0.490,0.494,0.500,0.508,0.516,0.518,0.527,0.541,0.545,0.548,0.550,0.552,0.552,0.553,0.553,
  0.535,0.535,0.535,0.534,0.534,0.533,0.532,0.531,0.529,0.525,0.523,0.522,0.510,0.498,0.489,0.484,
  0.483,0.485,0.488,0.489,0.486,0.464,0.436,0.440,0.451,0.440,0.436,0.464,0.486,0.489,0.488,0.485,
  0.483,0.484,0.489,0.498,0.510,0.522,0.523,0.525,0.529,0.531,0.532,0.533,0.534,0.534,0.535,0.535,
  0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.528,0.511,0.496,0.484,0.478,
  0.480,0.490,0.498,0.499,0.491,0.470,0.457,0.460,0.466,0.460,0.457,0.470,0.491,0.499,0.498,0.490,
  0.480,0.478,0.484,0.496,0.511,0.528,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,0.529,
  0.535,0.535,0.535,0.535,0.535,0.535,0.535,0.535,0.535,0.535,0.534,0.530,0.512,0.495,0.480,0.475,
  0.477,0.488,0.499,0.503,0.496,0.485,0.480,0.476,0.474,0.476,0.480,0.485,0.496,0.503,0.499,0.488,
  0.477,0.475,0.480,0.495,0.512,0.530,0.534,0.535,0.535,0.535,0.535,0.535,0.535,0.535,0.535,0.535,
  0.556,0.556,0.556,0.556,0.556,0.556,0.556,0.556,0.556,0.555,0.553,0.539,0.513,0.498,0.480,0.474,
  0.473,0.481,0.489,0.497,0.496,0.490,0.484,0.479,0.477,0.479,0.484,0.490,0.496,0.497,0.489,0.481,
  0.473,0.474,0.480,0.498,0.513,0.539,0.553,0.555,0.556,0.556,0.556,0.556,0.556,0.556,0.556,0.556,
  0.561,0.561,0.561,0.561,0.561,0.561,0.561,0.561,0.561,0.560,0.557,0.545,0.516,0.500,0.484,0.476,
  0.471,0.472,0.477,0.481,0.484,0.483,0.479,0.474,0.471,0.474,0.479,0.483,0.484,0.481,0.477,0.472,
  0.471,0.476,0.484,0.500,0.516,0.545,0.557,0.560,0.561,0.561,0.561,0.561,0.561,0.561,0.561,0.561,
  0.549,0.549,0.549,0.549,0.549,0.549,0.549,0.549,0.548,0.548,0.545,0.538,0.517,0.496,0.485,0.473,
  0.467,0.467,0.468,0.468,0.468,0.467,0.465,0.463,0.462,0.463,0.465,0.467,0.468,0.468,0.468,0.467,
  0.467,0.473,0.485,0.496,0.517,0.538,0.545,0.548,0.548,0.549,0.549,0.549,0.549,0.549,0.549,0.549,
  0.525,0.525,0.525,0.525,0.525,0.525,0.525,0.525,0.525,0.525,0.524,0.523,0.516,0.494,0.480,0.470,
  0.462,0.459,0.458,0.456,0.455,0.454,0.452,0.450,0.449,0.450,0.452,0.454,0.455,0.456,0.458,0.459,
  0.462,0.470,0.480,0.494,0.516,0.523,0.524,0.525,0.525,0.525,0.525,0.525,0.525,0.525,0.525,0.525,
  0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.502,0.492,0.473,0.463,
  0.454,0.450,0.449,0.447,0.446,0.445,0.441,0.437,0.435,0.437,0.441,0.445,0.446,0.447,0.449,0.450,
  0.454,0.463,0.473,0.492,0.502,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,0.505,
  0.490,0.490,0.490,0.490,0.490,0.490,0.490,0.490,0.490,0.489,0.489,0.489,0.488,0.483,0.466,0.452,
  0.442,0.437,0.437,0.435,0.434,0.433,0.432,0.428,0.425,0.428,0.432,0.433,0.434,0.435,0.437,0.437,
  0.442,0.452,0.466,0.483,0.488,0.489,0.489,0.489,0.490,0.490,0.490,0.490,0.490,0.490,0.490,0.490,
  0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.470,0.470,0.468,0.455,0.440,
  0.426,0.421,0.419,0.419,0.417,0.416,0.415,0.413,0.411,0.413,0.415,0.416,0.417,0.419,0.419,0.421,
  0.426,0.440,0.455,0.468,0.470,0.470,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,0.471,
  0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.445,0.437,0.421,
  0.410,0.401,0.398,0.395,0.392,0.393,0.393,0.390,0.390,0.390,0.393,0.393,0.392,0.395,0.398,0.401,
  0.410,0.421,0.437,0.445,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,0.447,
  0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.419,0.415,0.401,
  0.393,0.383,0.377,0.367,0.366,0.367,0.365,0.362,0.363,0.362,0.365,0.367,0.366,0.367,0.377,0.383,
  0.393,0.401,0.415,0.419,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,0.420,
  0.413,0.413,0.413,0.413,0.413,0.413,0.413,0.413,0.413,0.412,0.412,0.412,0.411,0.410,0.402,0.381,
  0.372,0.363,0.353,0.339,0.339,0.339,0.336,0.333,0.332,0.333,0.336,0.339,0.339,0.339,0.353,0.363,
  0.372,0.381,0.402,0.410,0.411,0.412,0.412,0.412,0.413,0.413,0.413,0.413,0.413,0.413,0.413,0.413,
  0.439,0.438,0.436,0.435,0.434,0.434,0.434,0.434,0.429,0.414,0.410,0.409,0.406,0.398,0.380,0.364,
  0.356,0.346,0.331,0.323,0.316,0.314,0.312,0.309,0.308,0.309,0.312,0.314,0.316,0.323,0.331,0.346,
  0.356,0.364,0.380,0.398,0.406,0.409,0.410,0.414,0.429,0.434,0.434,0.434,0.434,0.435,0.436,0.438,
]);

function headRadiusAt(a, y){
  let fa = (a/(Math.PI*2) + 0.5) * HEAD_NA;          // -180 deg is column 0
  fa -= Math.floor(fa/HEAD_NA)*HEAD_NA;
  const i0 = Math.floor(fa), i1 = (i0+1) % HEAD_NA, ta = fa - i0;
  const fy = (y - HEAD_Y0) / (HEAD_Y1 - HEAD_Y0) * (HEAD_NY-1);
  const j = Math.min(HEAD_NY-2, Math.max(0, Math.floor(fy)));
  const ty = Math.min(1, Math.max(0, fy - j));
  const r0 = HEAD_R[j*HEAD_NA+i0]*(1-ta) + HEAD_R[j*HEAD_NA+i1]*ta;
  const r1 = HEAD_R[(j+1)*HEAD_NA+i0]*(1-ta) + HEAD_R[(j+1)*HEAD_NA+i1]*ta;
  return r0*(1-ty) + r1*ty;
}

const EAR_MESH = {q:30000, n:2160, t:4196, lean:4.00, back:0.218, span:0.444, front:0.017, frontUp:0.094, v:'KQaw818N/gW58+QMpA8E9c8W/g8p9mUXdw9h9FcW8w+V9ScX+w/Q9pMX/Q+S98IXfhBo+PkX6BBK+TEYDxE0+mAYsQ638hgVYg/69F8WrA+x9esW3Q9Y9y4XOhB0+IoX/hAT+k4YFxGD+koYRBEr+4YYhhEz/KkYsBFH/c8Y6RFj/vYYARKH/xYZLw+c88QVtA5J9EgVaQ8M9nYWsw+49+IWyg8++PUWRBDb+HsXRhCC+WgXkhBy+dUX7RAg+98XDBGA+/cXhREa/XoY2xEd/wEZ4BHh/xoZ6hG5AC0Z2g3P8IMUew4i8sQUtw7w8isV1A6d82QVtQ+i9vQWXhAY+ZoXsxGL/boYYQ7D8XsULhC8+iIXuhDG+5kXWxF7/lEYoREX/6wYcxHH/4gYrRH8AUIZzxFDA1kZEBJvBHAZOw3l76kUxg2I8bMTQw5R840U9Q5r9cIVeQ579TcV4w4q9/EVXw+o+IYWng8E+b8WfQ9195sWWBCW+k0XGxFV/PAXNBGT/BQYrBEbANYYoBErAe0Y6w248eoTjw6v8ucU6A4u9skVGA+f9hEW/wt4+w4WmQuN/d0W/Qpo/qAWGBA0/VwXgg8Z/k8XIg/t/oAX9g6k/6wXKgvGAIYXdwtfAewXlAtbAhUYog28ABAYNQ+hAN8XowyWAUEYahAc/ooXmhB5/qsXChEgAV8YFhFYAXcYgA0z8V8TmQ0H8mMT3A3w8ukT/hFpBYsZ2w3K8xoUEhIfBoUZnw0d9pQUpw0d9/QUWAzz+V4Vewo66yMT0QuC7QQUJww97r0TFQ237zsUZQ2Y+FoVIw51+lkWQg6u+SYWLg1W+gAWvQwX+zQWAg9a+WIWww/j+eAWZAyO/L8WFAzV/MMWEA0m/R0X8g2O+6cWXg+F/BQX6w/d+x4XwQy2/OsWhg0K/RcXdQ9//TwXyw7P/BAXegu0/ioXwwxJ/mkXfQ2Q8BkUhQtfALQXvAz6/+sXCQ6Q9IMUTg74/VYX4w20/o4X6A0+9ZIU9g5e/l8Xug28/9YXJA569iYVnAtSAfsXMQ0eAPMXJQ7z95QVBw8U+CwWJgy6Ak4YfQytAlwYqw3GAT4Y6w8e+wYXExE9/foXuhCn/sMXMRHl/0sYehG+A/cYuxGZAzMZ0BFaBFUZGRJlBX8ZOgZ+5poNfwbA5tEN1gwI7wgUvQlg6tQRhApP67UT0AoK7JETgQt9/DAWmAvL7NUTzwoD/gkW+Qua7f0TNAwH7qMTkwzJ7o4TEAvJAs0X0AzY73YTLwuaA90X+gyT8A8T4gvGBBwYQw0V8tkSjAzXBEoY/QyI9acT/g9vAzoYUQ1X8zgT7A7DAzoYBQ3U9FsTKw15BFoYYg9UBDEYwRBNA3MYYgzR+MEUdREABfMYzgvD+ZMUeRF8BfgYjAvZ+gQV9RGoBocZRxJtB3AZcBJwB44ZdRJzB5sZ6giA6UwSjgsA/PIV6Aun+mgVswxH70oT3ArG/owW0Apj/7AWkwpRAJ8Wwg+Y/nMX+g/EAOgXlQ1e8mQTpgpaASAXBgv2AasXiA0w9MsT8A7rAR8Yugxg9rQTHw2f9ksU4w46AQUYbwz090oUvAwH+J4Uow8xAiEYsgyq+OwUXQx4+RIVIQwTBEMYxAzvAmUYoQ1TA10Ykg/zAikYRRDB/pIXSBDK/8wXJhB7ARkYFxHXAYcYtxAlAlsYJRHcA7IYsREGBicZvBHHBhoZUBIKB4wZahJpB5sZuwnU6pARDAsS/K0U0QpI/V0V1wlZ634Rogoo7KASoApz/nkVPAvs7BQTiAoe/5MVbwrR/7YVgwuj7bMSDQw37swSSQorAVYWPwqxAXsWaAr6AgYXJAzb7l0SQwzN7yMSWQucBbUXGg8RBSwYJhCMBTYYlwwO8bQRwhCvBW4YlQz99KASzw4nBgcYXAwU9uMSMBG4Bp4Y0gu8+KgTxhGjB/8YhwvX+eATghHrB7QY4AsR+RcUdgfc57APGAkC6v8QaAeD5xEPTQtC/MoV2Qp0/bIVqwozBFcXZwvRAwMYUQx9BSAYDg2BBTUYsg/RAzUYOQ7SBEEYBw0OBVAY9Az/8JQSqgwv89cRBQ2V8n0SbRBABF8Y7gxb840SBBGFBKEYywye9NwSLQxZ920TPwym99ITKhEPBqkYKRJ7Bz8Zewt3+n0UCAZv5kANWxJIB5QZfwZ35tQNEAc256UOUwwK9AgRCAmI6uIPdQxF9M4Rdwnr6sUQawwJ9UcS4Anv68UQbQo87OcR8As395ESpAq47MMRwws8+LgSUQsc7iURdAvs+RgTAAwu8OgQ3wrL/JMUeApi//kUPwqLAB8VIwo5AbcV9AlbArwVQAreBLYWwgpwBUQXuApaBu8WQAvpBkQXTAxoB5wXmwznB4MXbA+qBvMXzg/zBvIXfA5fB74XjBC3BjoYBhH9BzEYzxDbCLUXWBFTCF8YMAyz8P4QZBHeCPkXLQXt5iMM/AWg5hYNOQYf5+cMcQZa5wENEgdd51sOtQfM6JUO1ge76DUPNgwo9ooSawu87UUS7Ql3AqwVFgq7A3QWYApxAw4XGwsABmcXExAIBiEYcwwWB7oXBA2YB64Xlw3aBugXuQ1xBgEY0AWS5sEM8gek6GwRJRFWB3UYlghn6hsPVgxH88oQEAmK65wPLgxR9QYRCgxS9jARpwmb7IEPBgyu9iESagoH7a0QzQoI7vwPmwsM+VMSggt3+esSQwsP+2kTEgtz/DcTLAtl+yEU0gp5/c0TQAqeAK0UCwqcAa4U/QnVASQVygnhA9kU0wm3BFQVCgoYBUYWIQpUBWoWcwpYBpoWvwpTB7IWCgv9B8wWDxE/CakXMhGLCXoXGwWk5vcL7Qb35y0NCwc36CwNjgeU6IYOKwwR8YoQMgzz8SYQVwy+8rUQswp57cQQ0As37xcRwwpK/YgUfgtVCAEX7guBCCUXYQxXCFIXww+QB8YXBw73B44XSQ/2B5IXGxBFCKIXwggA6iQQUQyp8bsQUQtN75oPcwvZ74APRQbE9f0PygsZ8cEOYwbR9QkQ0gtx8P4P8gtb8U0PDwwM8koPQAwa9CIQLgxG9XsQ3gt7934RqgsU+ZkRWwuZ+zMS4Qo9/v0SnQr2/uMTYwpAABwU6QmAAsoUygmvA34UFQoDB7YVRQpvB/kVCwu+CHkWZAstCZkWcgtrCYYWVgyxCcwWiw08CQ0XwwzpCcEWfg+tCcYWeBB0CTMX6wTC5oQLmAUr548LWgb3534L/gag6IkMywcN6usNxAfM6kUNTghD660O1Ajt6+EOJAjl7IwNbQrw7TsP/ApI75wOQwzC81YQtAoc/gEUCgr4BfAV3QomCJUWhgxvCe4W3Q4YCRQXcg/aCDwXOBAjCUcX1ASL53sKtQcy6QsOIgui7vYP1gX787IOYguw8MkNjgvs8AgOxgbl830OXQRY9K4OoAWN9NcOswXp9XkPygZc9AAPVQQt9lwPFgzb8pYOPQzn88oOPQzP8/wOQQxb9DoPPgyG9BkQyQaQ+aEQcAYG+scQ1wZ/+q4QCAYz++kQAgwA9xgQVQsw/XcRNQsc/R8SBgta/kISvwpF//oSggpkAEoTYQp6Ae0STwo6AX8TEwqiAlcTywnoAxMUeAB+9CwOIAoVApgTeABf9bwOGgqwB4kVeAD49Q8PfgVx6N8IeABb8z4OtgUX6B8J1wpcCf0VIwZ16OkJOAspChAWUgtiCgQWIgyiCkAWRgd36V4M2gz6CiMWuwZB6rULow7nCaYWQAOa83AO8w2GClUWUQZS6x8Mfw+TCh0WCQer69sMeAAe9mwPkAZw7JcMeACf9m0PpwhE7cENwhBCCscWnQHq9pQPjglw7XMO3AlK7oUNKxFLCugWxAP/9rwPlwrk7hgOiQeH9rAPnQev+P0PAQTW9PQOJwYM9YUPkAbo9HkPvgaM9CUPwgWT9v0P/gbH9dIPNgwe86oP6QXY9iYQNQaW91sQMwaG9jAQvgZ49igQLQf590IQugXB+HoQfgVm+qsQjwar+I8QtgU++9YQgAtu+uwRcgu9+iESIQYM6KkKRAqkB+UV/wb16xENeAC98x8OeACF9McOeADU9SYPRQ8CCpEWChA9CnwWeACV84cOeABL9N8OwRCxCS0XeAAe8xkOxALh88cOCgOc84IOeAAj9TgPkwAy9VoPPwF79BgPeAC49UAPsABB9nwPiQGL9DMP+gJR9VcPAwQQ9RYPdwHt9YEPaQKx9qEPRwfM9PoOLQcI9xMQewVz86AN3wRw880NMwaR8wQOCAcC9FcOTQWR9EIOKQXy9AgO1gX39JQO+gQ29tYOdgXb9uIOswf39F0OGgxQ8zYOOAw19fgOJAz39TwPtgXx9xYPhQUd+OsOlwXR+DMPeAAG84QNeACE87EN5wdl+HkPeADJ9NoNiQV7+UkPeABE9jMO5ATa+isQwgRD+xkQQAUI+0IQQASp+38QGQWN+08QlAD48tcNJAc7+noQmwVD6HYIeADg9nwOeADy9sQO6QsD+HcPpQYW6acKeACg9+MO3gtR+A8Q4gaE6QkLAgZR6jsKwQvf+cwPVQav6qsKeACz90cPeABr+DwPrQtB+9MP5ARM7EMLrQsv+s4QDAEu+Y0PngsJ+loRJwYj7SEMfQTM/LoQ4Aeb7ZwM4wFL+ykQ/wX+/NwQTQVR/ekQaQIE/GcQ1QnP7s8MCwR5/KIQmwqp7xsNbwt8/F0REgvO/sIR2QrM/ysSxwm6BIITvQm7BfMT3AlVB64UNwr5CBwVFwvnCo8VZwslC6EV4AyqC6AV2g+/CgUWbg9qC20VwQ05C9oVlxDdCi4WMhEIC1AWXgSC8wsO4gQN9HAO4AVZ9dAO0AVp9gQP7QR99mwPvQcT9WIOxwe99dsOrgeh9nUPzgQo99EPAwR799QP1QS59/8PlQQt+UUQlARf+BwQeAAJ86QNeADC8/MNsQcL+eMP3wRW+mYQeACU9ZMOeADy8qcNeAC+8ksNTgU6/NgQhQEf8/0NXgUw7KwLqgH88soNKgM28/ANwgYn/KoQeAA39xcPdgUU/esQRAFj94oPJAHr94cPxgFG+cYPHAJ496wPoALu98gPWQPz994PBgP9+AIQTwNY+koQdQIr+0kQAAxqC78VoQPj+T8QeA7mCvoVFxFVCw8WcwVd9ioPWwQq80wNrAXB8y4NPQbJ8xwNJAba80INBwck9MgN4wRz9WIOAQdo9RoOTQVI9uUNTwW/9lAOBwft9oAOhgfZ9AgOOAeJ9RkOmwdX9SoO8we59zwPXAtf8fIMrwsi8lQNAwyd88MNEwxR9NINDgx+9fEN/wu29qgOxAZ3+NgOYgVV+cUO8gcO+BgPeAAh82oMeADN8q4MeACa86QM3wUt+nYP5ASm+34PeAD69b8NHAUC/MMPeACa9m4OfQWe+8sPeACZ8owM0wcy+icPeAC48l0NgwCR8p0MlQde+9wPLAct/FQQ+Ats9yEPugtL+dMOsAWO6ZsHtwvj+SQPxwX66KkH/QUj6WQIGAbs6VcInAsK/IUQeADY9xQOkAvj/C0QaAWc6qoIeAD795UOGQWe/JQPSwRx6zwJeADU+GUOdwNZ7PQJCQej/GcQeADb+LkOAwO37CEKGwb0/ZoQeADE+cYOEQQ77dcKRgUb7vAKeAAi+4kPXgfm7k8LfABF/KcPQAuf/vIQ/wj175kLdgGz/RUQvwpX8IcM+Qrd/38RiALo/UYQZgrBAp4RZAPw/WoQygQz/psQ7wkdA7oT3gmPBPASxwmrBQMTXQpFAkUSMQrtAoQSwwnuBvETDQrNCKwUOwrWCcEUbQqKCsAU4wr7CkkVaAuiCzQVqgzlC2QV+w39Cx0VXRDkCxkVShBhC5IVQxG1C7sVZgeL/PQPAAVf85cNvQUw9KkNdgbP9AkOmAah9qgOHgwt9SEOeADd8/wMeAAI9FUNkwZV98sOeAAI9vENIgZ89wUP3Aa9+NMO4QUm+V8PowHA8jQN3QGu8vAMXAPU8t8MXAXG+sUP7APp61gKugQ47T8LrAeK+dQPeAD5+CkPeABx+RMPAgme7kQMkwvi++kQeAA2+mAPBQFi+rAPAAEr/OgPYwGN+wIQ2QTl/bIQfQXd/boQAgJI/E4QhQua/MkQ1wrh/yESjQKH/HYQzwJ8/HsQygG//S4QOASC/aUQ2g2kC3oVtAVH9AQNZgUJ9W4NygUS9g4NnAoU8dsLBAvq8IUMjAVa97cNQQtk8mAMtwtw8wkN7Qtf9YUNtQUl+KINPgUA+poOmQeH93QOaQeg+IkO7QeC+NQOYgUF+hEOAwXd+lEPyQYV/LoOxQcG+4MPvwcq/CQPzAth9zkOngsi/NMPIQVG/XoP4gS0/WkPcAQf/hIPDAfa/d8PeABR8+kLeADO8gYMVAZ5/iYQeACU8xsMcAcK/Y0PYAfF/TcPeAD99IEMZgRi//4PvAVQ//EPeADs9JANeABm9yINdwCE8tcLMwuv/yEQNQst/60QWQMR6x8HNgLv61gIIwvK/4UQ8wGj8tQM4woDAeEQQwOe8tcLrQEn7SUJzgolATMRSQIY7mwJHwrAAyESpAS57hgKpAXE7okKeAB9+IgN3AlhBXYSWAYx790KeADG+JQN0AkZBm0SeADq+RkOyQjV74ILeAB1/SsPlQSf/DgPSQqlClIU8QrCC24U7ACr/n4PGw5ODLwUCA1+DMUUKAKF/vwPgw8bDKoU1A+hDB8U6A61CzAVLARC/woQiATj8kUMoAVa84cMQhEIDY4UQgeK9N0NXwc89kMOdgs88skM5QbQ+u4OQgZD+0cPdwVC/KUPuAdT+3kPeAB38gMM/QTN/lYQKQYN/+8PQQY0/lsQ2AQQ6iQHeAA6+roO6gT86XIH5AOV63MIeAAS+4IOeABG+w0PeABF/CIPeADa/WsP0gyXDKUUsQAn/cEPwQOM/kwQEBFaDCcVtwYY9JgNcAiU8AcL4AlS8XALhQmH9PMLmQr58bILaQeH9CAMMwja9CoMcgYC9XAMlgZM9V8MYAaq9sQMkAdx9VQM2gfE9WgMngiW9WYMJwng9XYMpAju9rEMlQkP97gMHwtb8zIMPAu591kN/QUy+E4NrgUl+Z8NMwaW9wkN7AhQ97wMBwUe+4wOwQQc/FgOhASW/H4OQwdG+8IOqgay/I0Oqgdb/J4OZwDP8h0LdwAO9IEL1ATG6r4GOgOF63EGeACB9R0MKQW4/UcP/QUP/fIOeQF57AsHeADd9rEM6QQz/g8PbwCb7QwIdgB08ssLngB78pYK8QFt7r4InAY//yIPsQfa/NAOXwMM75wJlATa79kJZgcR/i0OOgS28rcLmQXe7zoKeAB499cMeAAD+H8NeADR+RcNhAtB/W4PeAAN/GoOeAD+/GsO7wpTARwQaQTi/JwOzgoIAukPqwp/AiYQeADZ/XIOEwqVBIsReAAi/gwP5QnHBc4ReABj/hYPpwCy/lgPygDz/jUPxQkNCFUSYgEo/2oPSQR5/YQOXgpYAxsRRAQY/r8O+AG4/yUP2gKE/5cPIQphCu8TOwQ1AEQPXAqMCzcT3gTA8mkLjQpUC0cUFwZB8/ULDwuODCkTrguGDEoUugZ68+IL8w3bDAkU6QvmDLYTXAzeDBIUdw5aDRkTpxC0DGMUBxGEDNEUwAcQ9OcL4wVT9dsMPgbl84YMyAWD9jYNvghn9pkM8goF8vkLLgua80gMjgus9RcNmwtd9mUNxAeX+JYOeAA09PkLrAf++JMOmQei+asOXwes+aMOsQGA8ssLSQN368AGswF78mgLnQcV+94OswKF8i4Lkgtl+OwNbgsI+eYNeAAo+9wNdwuD+RoOYQui+kkOmwvC+uQObQvs+5oOhgsL/TcPSwSP/rcOcAJ8/4IPFQUwAFwPiwXn/3UPvwc8/OUOhQHo7qQIhwdU+LsMIwKd78EIJAfI+MUM7wL070MJlAZt+OYMGwV28OUJ3gej+MAMDAeM8ZcKEggj+dAMYAgJ+ugMdgmu+f8MiwqD+B0N/gjk+fUMOQYR+hENAwYx+wANmQQQ/Y0NZwfT/FoOBwe//F0Owwpe+oIN/woX+8UN9AUQ/lcOcgA682cLZADZ8+kKeAAG9XgLZAAg9hsLXQRB/04OzAS/ALkOFAYKAO8OUQDN8rkKDACh8h0KQQsg/l8ODgvm/wAOJwsRAN4OEgutABYPoAJ88rcKEAvDAJIPsQOL8vwK3griAVAPTwCz+JoLeAAj+QINeABI+oIM5gkdBhwReADb+kENeABX/GUNeACx/JMNzAldB6wReACd/fsNKwq8BFAQvgnOCL0ReAAe/zYOSQH56/AF0AkiCbUSvP8X7dcF1wkFCjkSyv/d7FoG8QmECn0SYQreC48STQRM/TMOPgA67ZsHdgr1C7IS0P847qsHTgDA7r4H8wDN/2cOmAsBDRgTNAIjAMEOXQ+uDAgUywIZAAUPvw8hDXcTHA8iDWkTsgbl8jELPAaP8s0KfxCODU4T5QaO8tQK7RBbDeMTqAe58vcKURHFDe8TswaK9qEMfgd396kM8gaK9DYMsAZ08GUK6Ac99oIMhQim8foKygmB9VQMdgrR9YEMtwfI9pUMZAqN9+AMjwpH9qMMYwkF8jgLmQry8r0LQwkY81gLlwo19BcMowrv9FMMeACf9f8LdgBv998Ltgow9+kMeAA99zQMVAcU+LsM9AXT+UANNwmj+OEMeADh+/kNGwo8+PUM+AB97icIXQdD/SkOUQRq8qAKhAQx8ksK3wRb/vsOZApU87sLQwid84sLPwno87AL/AFa8LMIoAb8+tIMkQIK8qUJGwUY/GgNjQNn8a4JHAWc/CAN6gea+7gM+wgb/L8MbAk2+/MMEwqX+xcNzAqM+4gNrwro/FANagd0/TkOpQYn/qgNngXP/gQOgQRE/1gOEAcj/1MO0Qag/9wNMAf0/twN+wWAAFwOAwUcASIOIAaPAKkN/v+o870JIQtD/vgNUQDX9csKSQBT9+wK3ArVAbQO8//98qAJEAo7BY0QJgFz8h0K3glPBmMQwQl7B84QfQJV8gQKigoqA1cPWAr6Aw4QdQAs+REMqAlJCdEQeAB5+uEL3wn/CnYReAAk/dwMeABK/d0MeABr/kUN7AtLDZgSeADm/mMN/ws7DdsS4QAWAMENZwxLDQQTSQ23DSkSRQQP/mgNyw4vDoIR0A+ODe0SFv+67QMG5gMM/9INcgBQ77AHIwE4AOkNPRFSDjwTYxGQDlITeAJ+AFMOvQQoAREOTAP28dIJ0QZQ+t8MbwRu8fAJxgeJ+dEM6Qcy+toM6QO98JwJngo3+TcNXQaZ8W8K8AXt8WQKFAok+igNYgfB+swM8Qm8+hkNsQr9+ngN+go5/LcNpAac/Q8OMv/w7ZAGyAN8ANMOXQd08tAK1AVd+WwNjwX5+oQNxgQEAVEOuQGrAIMNfwM1AUQNHATW/0QNKATU/2oNbAPRAC8O1QAg8ucIWgQXASUO3ARKAZoNBgeF/GoMHgbq/GIMxQfz/GYMEP8b7tIFEP8P7+YFIAox/eIMQP/l7qcGVP+t77EGsAS6/d0M0QQy/nMMCAdc/k4NJQGd8dsIJged/sMMngVx/1cNxQRN/y8O1gWY//0MUgZ2/68MzQaQ/+oMPQe3/ooN9AW9AD8N6AaK/2kNjApE/gsN1gpM/1wN/Qrl/74N1wo9AfANmgqJAhMOGArvBFsPxQlLBpwPjwnqB7kP2v9f9DwJcQphA7oOCgBR9LcJsf/S89cI4f+A9YQJfwm3CNYPSwBV9VAKGwBp9vkJtwkeCgERAgBc+LAKTAr/C1kR3AqoDPIRwP8e8yAJff/K8q4IrwtJDQoSeACw+k8LeAAH++QL4Q9ADgsSeAAz/DgMHBAWDmoSeAA3/QAMrBAlDscS/xBtDtQSXxExD6QSeACl/nsMeBFiD8ESiADv/0gNNgF+AD4N1f+p8o4JEgS6/20Nef9/8qIIYwBo8ioJcQFV8ooJ8AWF/JAMcAcK/JUMxf9n8GIHzQkB/OwMGAGh8G0IuQFF8IgIzgmD/NoMzwF+8RwJ5QqV/Y0N3wpZ/nYNRQAo93gKeABO/RMMsxAfDtgSuAHPAP8MWf+48kkIYATu/+UMtwQsAHwMEwRjAf4MMAC38VYIjv8e8t8HYQdT/oMMQAd9/k4MiQUaAL8MvwZC/ykMEP/07/gFpAi6/VYMkP8e8XwH6weC/h0MjAkT/mUM5Ans/ZsMHgqx/pQMhQUMARwNegp6/9wMvQpcAEQNhQoTAl0NQQrsA10O/gnVBIQOwwm0BbYOfQnbBu0Ouv+W9L8IkP9O9rYIogmDCkYQ2P93960Ja/8b80IIRQoADB8RiAqEDF0Q6/8r+RcKUQssDSERJwC3+bsKeADR+rcKTgzBDR0R+QuCDaEReADG/A8Lkw0ZDioReACq/HsLeAA6/dILeACH/wgM8BDBD3kR4xA8D+IReQD1/1YMbhHKD0kSLASP/jQNMwRT/80Mbv+o8oUI4wYN/UgMsQfg/VgMWAmZ/X0MUgA38TEI4woVAIINcAl6CdQPFgD69ukJhwmRCSkQPQBK+f8K5gYS/9EMawRQ/vAMhwW5/LoM8gB8AKIL1wS//w4MhgHTAEoMtAOIAfgL/ARQAGoMbARzAbkMKf/38mAH8QWk/t0LaAXZ/tgLLP+U8qYHmQZk/+QLLf9r8qoH8AQz/+sLvv9O8kkIOf898nYHUv+E8W8HcAcl/98LL/8x8lQHTv/08XMH6Qmd/0YM+AmYACIMSQV7AEIMBgVIATkMNgqpAtoMEP/B8EgGFP/98NUGgAqgARYN1QmFBJQNVwnhBcIN+wgCB+MNxggACAgOFwmiCdwOuQlUC5kPDwo4DNgOLf9583EH8QmnCw8QOf/M84AHggqRDPcPFgsiDT8QeADy++EJHAzIDZQQaQ6QDnMQeAA9/jYLtw6PDrcQcQ/FDuIQeABx/t0KsQ/hDuoQeAAa/9ULpxA+D4MRThFpEKkRiREcEeER3xEYEoQRoQQS/0gMYgY4/gcMkQXMAJAMmwZz/zwMVQbn/68MEP+p77MFEP8i8DsG3gjW/vsL1wh+/hkMfwnk/jMM9gRQAaIMRQqtAIYMNgpqA4ENQgp1A7YNewkeBkUOcBE6EEYS4wZW/xkMeADm/20L0wE8AQ8LXAIdAaMMtASCAXwLLgbK/5QLKge5AOcKWwgQAGALEP9C804GawlxAKoLEP9H8r8GEf8o8tUGwAl4AdoLHQrzAWQMAAp1AlsMEP9f8Z4GEP8X8qEGSwm2BI0MsQh6BhgNiwgKCdgN1wj3CToObgk3C8sOiAq1DDUPPQtRDcgPEwzZDRIQzg2XDtMP0A4DD9wPOBCDD7YQFf+588QGaf8O9esH7xCAEPcQPP+m+TgIgRHjESMRFgBu+m4JbQC0+1MJeAD8/NgJeACH/WIKeAAy/6oKOgWd/8ILqgWAAGoLWgfE/30LEP+J8qkGFf848+YGIAns/6wLKwU+AYALEf+Q8ckGHP8d8hIHuAneA6sM/whLBm4NgAncBB0NEAljCKkO3QgWCWYOYgXUAMkL5hEpE/cQ2xIQFHcRX//093EI/BE9EwwRc/+49AcIif+29+YIqf8Y+XAJXgBp/AMJeAAb/SgJeAAK/p8JeABg/x0KeACa/5cJyQBSANsJXgHzAJsKTAKjAToK2gP+AVgKTgYvAaQK3wS7AbsKLAdkAXcKngjyAAsLEP/t8xoGPgk2AkELEP/M8m0Grwj1BMELEP+D8noGEP9Z8noGEP9A8nMG8QfZBlAMEP8u8moGEP//8W4G/AcMCeoMzQgRChEO+gjyCqkNYwlrCxcO4QoPDVEP1gvtDXAOMQz9DZcP+gyPDsMOfg41DxcPig9IDzUQAxAKEOAPqBAtELwQtxAKEVkQ/BC8EXgQIxEVEo4QvQjaAC4LWAnVAV4LmQkAA+sLUAmaA8MLEP/y8moGiAnOAz8MvQiCBVcM6Qd6B54MCQglCAENEP/H8YEGNAg9CEMNDhCyD04Q9P9e/LgHdQC4/ecHeAD2/cgIeAB4/rUIeABH/2QJ6AFzAcgJBgMEAswJ0AXDAUMKoghXAqsKEP/N9M4Fgge/BpoLHgikBLsK6geABRoLZQeZCBoM4QfXCTYMLQgRCrEMXAgvCg8NBwlXC/sMgAnYC08N8wlqDPQMHgtvDdYNfwu6DQwODA4aD7wOLQ8gEHwOgA+PEI8O9w/JEDYPghDaEbQP4BChEv0PEP/I9BUGEP/R9QIG1wjSAeoKogiZA9kKYgcWB6cL5QgDBGMLgQerBysMnQe+CFwMEP8d8mYGFxA2ET0PY/8h+wcHqRGnFN4PkhKsFMkQ7RKMFFAQEP/k9pkF8//t+nwItP8h+9wHUxHKEnwQGP9p9bAGeAAt/0YI9gB7AOUIPQHLAHgIOQHSAHAJ4wF2AVIJKQNHAtAI4QOBAgoJbAMsAqoJrgX4AREK0AY9AtkJhAejAugJDwhEAz4K3gcvBDwKdQeJBXkKMgeMBuQK5waxBwsLDwdsCHULbQeBCXMLYQiyCkUMwwgcC6QM2go5DZoNKQxBDqINEQ46D20OQA6nD7kN+Q+iEeUOShC2EjgPWBBYEzAPkgdyAgEKAAhEAkkK+QcEBcwKFgcSCIYLlP/s+8UGGgAp/c0GYwCg/WgHdACv/nsHeABf/9gHeACN/1sHNQG/AOsHwAFXAX4IKwUnA58IKgYzAxMJrgY0A00JvwatAzQJSAeiA5wJnAbWB+wJtgYOCD8KBAcLCbcKlwf6CQsL8QddClALQAi5CpkLeAjxCt4LxghQC8cLqgktDIkMMAq7DCMM7gpfDboMXAu8DbgMBA0fDzsMtwy0DjQNZA2ADxAMMA6VD6ENvQ4yEJsNaQ8qEt8NzA9BE3UOHRDOE8EOExHEE8YPEP8j9+8EEP929/MEEAW+AiMJsgWKAncJJwfVBK0JeQcOBSsK3wbOBnAKGQetCHkLnA8gEWoOow9yEj4OFRJxFcUPEP9o+UcFEf8D+5EFEP9u+IEGlxBUE3EPEP/h9WsFEP+F+F4ENv89/K0Fpf+D/KAF7P+4/fIFdgBy/yAH4QBBAD4HYgLtAUcIIgOcAlgHwAP7ApcH3APkAhQIPgT/AkMIBAWZA/0HUgWPA0wI8gUJBHUIeQYMBOYIrAZZBq0JVwfACSIKXQj6CrMKBAmbC5gLuAleDMcKxAllDBsLbwoHDSgLgwsIDtkKLwukDfQLgAv4DWULBQxaDtYL0Q2bD+gMdg7pEEAMrg7DEOAMEQ9JEVwNRg+3EqcNyA//E08OogZGBSMJ2QZvBYIJxA6AEFINRf9V/tIDov8x/jcF5P/9/n4FIQCk/iEGdADe/w0GAgFgALQGeAH8AJ0GhgInAgAHFwRtAwUHkwU4BP0H+QXoBCAIXQaWB4II3AYECWwJ8gY4CZEJ5Qd9CsYJCAmxC6gKxQpiDYUKPgy/DrcKngwnD7gKAw1RD4cLLw5KEGIMuA6EEaUMxg66EuQMof/o/JcFLQYUBWoIJAb4BUcIWwZABswIWQb9Bs0Ipg6+E+IMWw8iFVkNfxIcFqoPnxFNF+QNDRDjFCcOyxLqFTYPMP/b/eAD/v+5/+8EqwF0ASYFwAFSATcG5wGIAbAFGwK8AV8GYQPwAqMGLASoA4oGZQW4BEoHvAWcBUAH+AUqBoUHKgYLB6IHUQe5CZoIhgcGCu8I3AdwCkYJuQlwDJsIjQg1Cx8KiQpGDQUJ3AmKDOQJiQo9DXgJMAvbDdEJTgvoDVcKYg3uDx4LKA5BEY0LRw4FEswLFQ7kEtwLEQ4yFCcMdA6YFJcMsw6QFN0MEg6mExcMuP9t/2wErQBuAOMEtwJ2AjgFFgO/AhAGNATRAxsGogRNBBIGKwUZBbEF1gQgBPwGOwZlB/UGXgbFBwwHhQYvCC8I3wbjCIUHAQdCCbAIpAhLC8EIsQt9DncJWAw0D6MJqQy6D6gJOw00EG8KmA2hEMcK+w3TEF0LKg68EYQL/A32EUsLkQ2mE28LhQ2aFF4LVg4GFUgMEP8H/O0CqQJUAgoGtA3WE6kL5w6YFZQMPg/zFuULIxDIFvAM+RD+FpQNEP/r+cQDEP83+zADEP98+4MDEP8z/BAEEf/j/rICUABgADcEzwCCAc4DXAF1AZIEjwGCApMDrAK6AmsEYgMlAysFdwNsA7gE8wOuA4UFkQWzBSQGFAb7Bt4FXgbCB8kG/wYTCSEHagesCZIGsgcvCgsIIgitClAHbAgIC/EHyQmTDNMHRgn7C/gHBgv3DYQIYAtGDusIJgyFD7sI4gxFELQJOg0ZEfwJEP/X/B8DEf8Y/WkDGP+c/WUDkg0QEZEKQQ1aEl8KCQ0TFL0KLA0sFOsKEP+c/wECf/+8/8UD+P8NAekCTgLqAtADwAPnAz0EagQZBdADwwTxBGME6gTxBPgEoQUGBlEFHwYQB2gFUQdvCZoF1QdBCnoGqQhYC6UGUwkWDEcHBwr7DEgHRwo4DagHGgt4Dq4HdQsDD8wH4wtHD3gIbQx/EMwIlwyFE+kJDQ0aFaEKEP9d/KwCEP9k/TYC2gxWEXAJAw1qEb0JpQxjEoQJ6wyVEv0JHg0FFcoKjA2mFfUKhg98GL4K0hBKGCsMhhIyF8cNEP9g/j8Clv8QAAEDPQDDAQcDVQJ2A4EDwwNuBM8DWQW2BXEEFQYOB1sEXAaQBwIFeAbMB8gEdwe8CdcEvQcoCh8FwwcjCt8FOAjgCoAFkghqC4sFDAkODMoFpQnEDE8GnQmaDKMG7QkwDV0GfwrjDQMHLgy2EZgINgzbEHAIIwwOEFwI6QsdE8oI5gsFFP0INAzhE2YJPgyZFGoJEP9d/sMBEP9W/0wBEP9f/5cBEP/rAO8AH//EALoBhP/zAZIBo/+bAUwC3f+gAuwBewBxApkCsQBTA0sCrgHAA5UCqwI0BBgDfAW3BrQD0QZ9CPoE1AraDtAGFQtEDwUHugt4ELcH+AvXEA0IZwutEaAHZguJFCMIyAvQD+MHuwtrEkYIfAtPE0kIowu4E44IfAs8FjgIdQxtF90I1w32FjYK6A2MGMoJ2w5/GDMKnAwLFdYJEP9VAM8ATAKEBJYCPAPjBA0DFwNLBdQCbARHBhsDVQU7Bz4D6QXtB24DbAZ7CKwDAwdkCdkDJwcKCrYDggfzCUUE4gfMCjQEIAiQCx4EVQhQC88ErwgpDIsE/whcDCEFYQnTDH4F7AkGDrEFYgpdDlMGwQpZD4AG4AobEJgGOwuGDxgHQwvZEDEHhAt+EGwHrQrlEfcGiQrLEhsHtQqwE1sHEP9PAVQAEP8uAZIANf9NAvEAeP8gAxoBFQDRA1sBOAHjBNYB2gLsBWICqwO2BpICmQRBB8oCdQmuDQgFvQmUDj0FjwgiETEFPwlqEhEGCwH+AxECHQpCD6UFPAqjD+IFqgnpELoF4Qm9EUUG4AmOE9kGdgmBFTkHZw4jGZIKEP8QAtr/E//AAioAEv9vAxcAVP/YA3wA1P97BOEATwAkBTEBEAGEBkkBIAHLBkoBQANxBxoCTQOGBxwCYgPnCAICXwXYCcAChgU3CscC1QXtCu0CAwcSDFkD4wgrDVUEHwkcDnMElAl+DyEFyQdaEekEVwdqEkQFGwjtEtQFjga8E6gFUAhrDAQEWgm6DsAEmwjIEbMFqwcUFPsFEP80Aur/EP+fApf/Iv+hBNz/Vf9CBT0AuQBuBhkB5gA1B/sA/ACNBwAB8gI7COIBVwPQCP0BpwLDCaUBLQWOCbMCmQMTCw0CbwS+C1wCXAYXDBAD/AWeDOcClgahDTIDvgXBEM8DkQdODwIEpwReE6MEkgW4E1gFWQWiCqgCNAeDDGcD+gdzDvUDUQiQDh8EfgUgERAE4wZqEZIEHQcLEDcERQUZEooEzgXdE2kFBwn5FK4GJQOhFrgFDAJsGNwGuQHuGJQH8wR4FHcFEP+gA2L/EP+fA5n/EP9xBHn/Uf8DBgIAbP8EBwsAAwB+B2gAnwDrB8UA5AAxCO4AZAEsCR8BAAJWCWIBRQKHCnEBOgMHDOoBsATYDYcCNQOMEOQC9AKcESwDNwLIEXYDhwOFEvMDEP/5Apn/4QKdCrABPwR7DEcCBgcKDl0DqwXbDiMDkAWhD1MDwAQlEGoDBgQaEY0DEP/OBCT/EP9tBRH/E/+kBWT/Ev94Bkz/Lf8DB6n/J//sB2//SP9jCLD/u/8uCh4AbwBxCpUAOgAvC48AqAAuDNYAxAEYDngBkgG6D9oBnQFuEEACoQEHEaIC3wGcEb0ClgD2EhQDEP83BD3/EP9wBD//Gv89Bnf/4f9OB1AA1P9wCTgAEwCXCWQAygCQCc8A4gDHCuwAcwFADDYBhALODKcBBAMEDdgBZQIJDrgBawQZDVcCQgO5DkwCigILDwwCawNHDlUCmgKZD0QCjgN2D50CSAKUEnwD2gHREqYD1wBRFKAD5v80FYcDgAEWFswEb/9zF9wEEP8OGAsFEP8hGOwEEP/pGP8FXQLkFRwF/wCYE7gDegO+E6gExAHBGc4HLwmoGR0J+ASLGpIIGwCWGf4GEP+7Bvv+EP9iB/P+Ef9wBxz/EP8/CBb/EP+kCAz/Fv8hCT//K/+FCXz/Vf8cCrj/Mv8OC6D/vf8lDEIAs//TDDwA4/9mDXoAbwAVDtQA8v9jD/0AEAA9EHUBdgAWERICEP8TBgT/EP9dBuv+Yf/ZCcn/Vv8eC9X/lP9/CxYA2v/OC1gAjABbDeIA2QCKDk4BlgAgD14BxQC+D3oBEP8DCOz+EP+ZCOj+EP8mCen+EP+iCf/+EP8SCwP/IP+7DIP/Mv8qDav/Mv9hDgsAFP8RD/P/QP9DEL0AEP93COb+Fv8cCjz/Ev9gCz//Gv+sC3P/O//yC7n/nP/hDUIAQf85D1cAgv9fD6IAav/0EFMBJP8VEpMBlf9QE3ICJv88FdsCE/9IFrADMP/mFu0DEP9LFzME1P9dEawBYAGEEYUCvP/NEpICEP/jCwv/EP+2DBH/EP9tDUv/EP9hDlv/EP8LD4L/E/+TD+r/EP+1Ce/+EP9WCvn+EP9tC/r+EP+QC//+EP85DDD/FP/RDXH/Ef/IDqb/EP+pDjz/EP84D23/EP+NEA8AEP91DRb/EP8ZDiL/EP9QDjD/EP9tD4r/EP9iEXgAEP9QEu0AEP/VEhoBEP9pFAQCEP+LFbACEP+sFnkDFP/AF2YEEP/kEJ8AEP+yE/MBEP/UFmgDWP+kENwAH/+zGHMFYv9pGZgGEP9LGckFEP9UE3ABEP/WD7T/', f:'QgVjBaUFfwVEBX4FfQV+BUEFfQVBBXoFQwWdBWMFMgWdBUMFdQWdBTIFnQWYBaUFYwWdBaUF1QVEBX8FmAVCBaUFMQVCBfEEQgWYBfEEnAV6BUAFegVBBUAFegWcBXgFnAVABWgFeAWZBXcFfgVEBUcFRAWgBW0FoAVEBdUFbQWgBUgFoAWCBaIFSAWgBaIFgwWhBUkFgwVJBYIFggVJBaIFogVJBUgFoQWDBUoFSQWhBUoFowVLBYQFhAWFBUwFpAWEBUwFWwVdBdEELQVzBS8FcgWzBS0FXAWyBXIFXgVfBXAFXgVwBR0FXgUbBRoFGwVeBR0FGwVdBRoFcwUtBbMFWwXRBHwEWQV8BFgFWQVbBXwEFgVWBXwEVgVYBXwEFAUTBRYFEwVWBRYFpAVMBaMFdAW1BTAFMAV1BTIFNQV2BTQFdgU3BTQFlwV2BTUFlwU1BTkFmAWXBfEE8QSXBS4FmAV2BZcFmQU3BXYFNwWZBT0FdgV3BZkFeAU9BZkFeAWcBWgFPQV4BWgFsgWwBbEFmAW4BXcFtwUwBbUFMAW3BXUFdAUVBrUFFQZzBbQFcwUVBnQFswW0BXMFcgWyBbMFdgWYBXcFsAWyBVwFsAVcBZYFWgWwBZYF4wWwBVoF4wVaBa8FlAWvBZUFrgWvBZQFrQUKBt8FdwW5BXgFuQXTBXgF0wV6BXgFtgWYBZ0FtwW2BZ0FtwWdBXUFmAW2BbgFdwW4BbkFuwXUBbkFuQXUBXoFuQV6BdMF1AV9BXoF1AV+BX0F1AW7BdUF1QV/BX4FiAVSBYcFWQXNBVsFzQVWBYsFzQVZBVYFVgVZBVgFEwVVBVYFVQWKBVYFiQVTBYgFiQVVBVMFWwWMBV0FUgWIBVMFhwVQBU4FUAWHBVIFTQWGBU4FxQWGBUwFhQXFBUwFhAWkBaMFFAVVBRMFjAVbBc0FzwVdBYwFzwUaBV0FjwVeBRoFzwWPBRoFkQVeBY8FkQVfBV4FkQVgBV8FHgVhBTkFYAWRBakFkQWmBakFpgWnBakFpwUIBqkFCgaTBZIFrQWTBQoGHgUfBWEFdAUvBXMFLwV0Be4ELwXuBNsE2gQvBdsELQUvBdoELQXaBBwF8QQfBfAELgUfBfEEdAUwBZwEcgUcBRkFcgUtBRwFNQWkBCwFqwQ1BSwFUASrBCwFTgRQBCwF7ANOBCwF4QTsAywFMAUyBfIEMAXyBJwENQU0BWIFNwX4BGIFNwViBTQFPQX2BGIFYgX2BPUEPQViBfgElwU5BR8FHwU5BWEFLgWXBR8FswT4BGQF+AQ3BWQFPQX4BHEF+AS0BHEFCgVQBQ0FFAUWBXUEFAV1BM4EywQUBc4EEAUUBcsEEAXLBFMFUwUNBQ4FUwXLBA0FDQXLBMoEdQQWBXoEKAUKBW8ECgXIBG8EKAUmBQoFbwQmBSgFJgVvBMUEBAXBBLwEBwW/BL4EtARkBXEFegQWBXwE0QTVBNMEXQUbBdEE0QQbBdUEGwXWBNUEGwXXBNYEGwUdBdcEHQXZBNcEcAXZBB0FOQWsBCsFrASrBCsFqwR7BCsFewQeBSsFHgU5BSsFpAThBCwFBAVIBQUFBwWjBb8ESgVLBQcFbwUHBQYFSQUHBW8FSgUHBUkFBgUFBW8FBQVJBW8FSQUFBUgFowUHBUsFbQUEBW4FSAUEBW0FvAREBW0FRAW8BAMFRAUDBUcFfgUCBWwFfgVHBQIFQQVsBQIFvARtBW4FbgUEBbwEowVMBcUEvwSjBcUExQRMBSYFTAWGBQoFJgVMBQoFhgVNBQoFTQVQBQoFUAVNBU4FUAVSBQ0FDQVSBQ4FDgVSBVMFUwVVBRQFEAVTBRQFaAVABWoFZAU3BXEFNwU9BXEFYwX3BGUFZQX3BLMEZQWzBGQFtARlBWQF/ARpBfoEPQVoBfwE9gQ9BfwEaQX8BGgFaQX9BPoEagX+BP0EagX9BGkFagX/BP4EaQVoBWoF1AXVBX4FagVABf8EQgUxBfcEQgX3BGMFMgVDBWsFYwUABWsFYwVrBUMFtgRjBWUFtgRlBbQEAAVjBbYEogQyBWsFogRrBQAFQQV+BWwFQAUBBf8EQQUCBQEFQAVBBQEFIQZCBvEFywVHBkkGyQUjBssFIwZHBssF9AUjBskFTgUiBvMF8gUiBk4F8gXxBUIG8AUhBvEFJAbMBfUFIAYhBu8FIAbvBe4FIAbuBe0F7AUfBu0FVgYfBuwFLAbsBQEGHgbsBSwGVgbsBR4GSgb2BSQGJAb2BcwFSgYkBiUG9wVXBvgFVwYmBvgF+AUmBgQGJgYnBvkFJgb5BQQGJwb6BfkFLQYuBt8F3wUuBi8GLwYwBuAFMAYxBg4GZAYzBjEGZAYxBjIGEwYUBhUGKQYqBhcGFwYqBrgFGAYpBhcGtgUXBrgFFgYXBrYFUga1BRUGtQVSBhYG5QUTBhUGGQYqBhgGtAUTBuUFEwbkBRIG5AUTBrQFEQYSBuQFEQYPBhAGDwYRBrIF4wUPBrIFDwYzBhAGGAYqBikGKgYZBucFGQYaBv4FGQb+BecFHAbpBRsG/gUaBuoFGwbrBSsGGwYrBuoFKwbrBeoFGwbpBesFHQb/BekFHQbpBRwGHQYBBv8FAQYdBiwGHQYeBiwG7QU+BiAGRAbyBUMG8gVEBiIGQgZDBvIFIQZxBkIGcQYhBkEGIAZABiEGQAZBBiEGQAYgBj8GIgZFBvMFPgY/BiAGPgYfBj0GHwY+Bu0FPAYfBlYGPQYfBjwGPAYdBjsGHQZWBh4GPAZWBh0GRQYiBkQGRQZ4BvMF8wV4BvQFeAYjBvQFRwYjBngGRwZ4BkYGRwZ5BkkGeQZHBkgGJAZJBiUGJQZJBkoGfAZXBvYF9gVXBvcFfAb2BUoGVwZLBlgGJgZXBlgGNgY3BlIGMwY0BhAGEAY0BhEGNAYSBhEGNAZlBhIGZQYTBhIGEwZlBmcGFAY1BhUGNQYUBhMGFQZRBlIGUQYVBjUGUgY3BhcGFgZSBhcGNwYYBhcGNQY2BlIGUQY1BlIGMwYPBuMFOQYYBjcGOAY5BjcGOQYZBhgGOQYaBhkGbgZVBhsGbgYbBlMGUwYbBlQGVQYcBhsGGgY5BlMGUwbqBRoG6gVTBlQGVAYbBuoFOgYdBlUGVQYdBhwGOgY7Bh0G0AXRBY8F4QXiBa8F4QWuBeAFrgXhBa8FrQXgBa4F4AWtBd8F0gWRBdEF+gWRBdIF0QWRBY8FrwXiBeMFzwXQBY8F3gXPBYwFzgXPBd4F3gWMBc0FzgXeBc0FiwXMBc0FVgXMBYsFzAWKBcsFsAXjBbEFsQXjBbIFsgURBrMF5AWzBREGswXkBbQFtAXlBRUGtwXmBbYFFga3BbUFFgbmBbcFFga2BeYFKgbnBbkFKga5BbgF5wX9BbkF/QW7BbkF/QXnBbsFwQXZBb0FxAWEBUsF3QXbBcQFSwXbBd0F2wVLBUoFSgXaBdsF2gVKBYMFgwXBBdoF2QWDBYIF3QXEBUsFwQWDBdkFggW9BdkF2AWCBaAF1gWCBdgFvQWCBdYFoAXWBdgF1gWgBdUF5wX+BbsFxAXFBYQFxAXvBcUFxQWFBYQFxgWGBcUFxwWGBcYFxwXxBYYFTgWGBfEFTgXIBYcFhwXIBYgFyAXJBYgFiAXKBYkFygWIBckFiQXLBYoFVQWJBYoFigXMBVYFBAbQBc8FCgYFBgsG3wUKBgsGLQbfBQsG+gXRBfkF0QX6BdIFBAb5BdAF+QXRBdAF+AUEBs8FBQYtBgsG+AXPBc4F+AX2BfcF+AXOBfYF9gXOBc0F9gXNBcwFzAXLBfUFJAb1BcsFJAbLBUkGTgamBQwGpgWRBQwGkQX6BQwG+gVOBgwGBgYHBqYFpgUHBqcFBgamBU4GBwYIBqcF3wUvBuAF4AUwBuIF4QXgBeIFMAYOBuMF4gUwBuMFMQbjBQ4GMQYzBuMF7AUCBtsF/gXVBbsF1QX+BdYF1gX+BQAG6gW9Bf4F/gW9BQAGAAa9BdYF6wXpBb0F6wW9BeoF6QX/BcEF6QXBBb0FwQX/BQEGAQbaBcEF7AXbBdoFAQbsBdoFAgbEBdsFBwW+BAYF7AXtBQIG7gXEBe0F7QXEBQIGxAXuBe8F7wUhBsYFxQXvBcYFIQbwBcYFxgXxBccF8QXGBfAF8QXyBU4FTgXzBcgF9AXIBfMFyAX0BckFyQXLBcoFywWJBcoFMAQ0BDEEdwPiA3kDbgPiAysE4gM+BCsEeQPiA24DNAQ8BHYDMwQ8BDQEMQQ0BMQDNAR2A8QD3gM+BOIDOQQxBMMDMQTEA8MDOAQ5BMMDOQRoAzEEaAM5BDgESAQ4BHUDOATDA3UDOAQ3BGgD3gPiA+AD6wPiAz8E3gMrBD4EQAR6AysEKwR6A3MDQAQrBN4DQATeA+QDdAN6A0AEdANCBDMEQgR0A0AE5gOJBEAE5gNABOQD6ANABIkEQATpA0IE6QNABOgDHQOTAyMDMARoA3EDLgRxA3ADbQNvAywEbQNwA28DLgRwA20DcQNoA2sDLARvA2oDKgRuAysEMAQxBGgDuwPcAkgDuwO8A9wCSAPcAkcDugNFA2EDtwNFA7oDuQO6A2EDtQO4A7kD6gPoA4kEMARxA3IDbQMyBC4EMgRtAysELgRzA3EDcwMuBDIEMgQrBHMDdAMzBDAEcgN0AzAEMwQ0BDAELwQ1BGkDNgRpAzUENgQ1BEgENgR1A2kDNgRIBHUDNwQ4BEgErwP4A9oD1wNiBJkDYgT8A5kD1gPpBNcD6QRiBNcD2gNeBPkDJgP5A48D+QNbBI8DXwReBNoDmQP9A/4D+ANfBNoDkwNbBLUEWwSTAx0DkwNXBCMDkANEBIADIwNEBJADVwREBCMDjwNbBFcD/QOZA/wD/wMqA/4DAQQqA/8DKgMDBJwDAwQqAwEEnAMDBJ4DoQMHBKMDBwShA2cEowMHBAsEbQQNBKEDqgNtBKEDoQMNBGcECwQOBKcDpwMOBBEEEQQTBBUEgAPvA34D6QOMBNADjATRA9ADMwTpA3YD6QPQA3YDQgTpAzMEPAQzBHYD7gOAA0QE7gPvA4AD8APTA9ED7wN/AxUD7wMVA34DTgQXBO0DFwR8A30DTgR8AxcEfANOBHsD5wPqA4kEHwRIA0kDjATwA9ED8QPUA/AD8APUA9MD8QNVBNQDVQSTBNYD1ANVBNYDkwTpBNYD8gOGA4cDfwPvA/ID8gNHBIYDhgNHBIoDsQRaBEcE8gOxBEcEWARZBPIDVwNbBB0DmALFA3YDEgPGAxADxgMRAxADDwMTAw4DEwN4Aw4DdwN5Aw4DDgN5AwoDeQNuAwoDdwMOA3gDegN0A3MDxQOYAg0DDQPEA8UDxAN2A8UDwwPEAw0DwwMNAwwDdQPDAwwDdQMMAwsDaQMLA8IDyAPKAxEDxgPIAxEDEgPIA8YDyQPKA8gDEgPJA8gDyQMSA6cCFAN7AxMDygNRA+oCygN+A1EDoQJ8A3sDQAN8A6ECfANAA30DFQNRA34DfwOHAxUDygPJA84DagO9A7YDbQNsA74DbAMsBL8DbAMFA74DbAO/AwUDBgMHA74DBgO+AwUDagNrA70DawNoA70DBwNtA74DaANJBL0DvQNJBLYDvANNA2QDZAPeAoQC3AJkA4QCvANkA9wCWwhfCG8IpwLOA8kDwAMHA40CjQIKA8ADbgNtAwcDwANuAwcDCgNuA8ADagNvA2sDbwNwA2sDcQNrA3ADcQNzA8EDdANyA3EDwQN0A3EDcwN0A8EDwgMLAwkDaQPCAwkDdQMLA2kDLgMqAzADCwSnA9ECowMLBDwDOQOjAzwDoQOjAzkDnAOeAzADnwMwA54DnwMzAzADnAMwAyoDPAMLBNECKwMqAy4D/gO1ApkDtQL+AyoD2gP5A9sDJgOPA1cDJgPbA/kD2gPbAyYDJQPaAyYDnwNtBMwCMwOfA8wCqgPMAm0EqgOhA8wCzAKhAzUD0QKnA9QC1AKnAxEEUgIVBK4DFQRSAhEErgOwA0EDsAOyA0EDsgO0A7UDQgOyA7UDtwNEA0UDRAMfBEkD1gM+AtUDzgOnAhYDzgN+A8oDFgMXA84DfgPOA4ADgAPOA9wDzgMXA9wDFwOAA9wDdgMYA5gCGAN2A9AD0APRA9MD0wOtAtAD1AOvAq0C0wPUA60C1APVA68C1QPUA9YDFQQWBLAD1wMZAz4C1gPXAz4ChgMbAxoDhwOGAxoDfwPyA4cDRwTYA4oDigPYAxwDigMcA4YDhgMcAxsDRwRaBNgDHQMgA1cDkAMXAyMDIwMXAyIDIgMXA98CkAOAAxcDZwS+BGkEBQVtBAQFBQW9BG0EbATBBG0EwQQEBW0EwQQDBLwEAwTBBGwEaQS+BGoEvgS/BGoEvQQNBG0EvQS+BGcEZQS8BAMEuwRlBP8DvARlBLsEuwT+A/0DuwT/A/4DuQT9A2IEugT9A7kEvwTFBG8EagS/BG8EbwTIBHEEyAQKBXEECgUNBXEEDQXKBHEEcQTLBBYEywRxBMoEywTOBHUEHQTLBHUEdwR1BHkEeQR1BHoEugPRBH0E0QS6A3wE0QTTBH0EsASxBFkEtAS1BLcEtQStBJMDkwOtBFcEXAS3BFsEswSyBLAEWASwBFkErwSwBFgEswSwBK8EtwS1BF0ErQRYBEQErQSvBFgErQREBFcE5wSoBFYE5ATnBFUE5wRWBFUE5ARVBFQE1QTtBH0EWwS3BF0EsQTxBJ4EWgSxBJ4EXwS2BF4EYAS3BF4EXgS3BFwEXgS2BGAEhQSiBF8EuATpBP4E/gTpBKgEqATpBFYE6QS4BOoE6QTqBGIE6gS4BLkE6gS5BGIE9gT8BPUEYAS2BLcEXwQABbYE9wTxBLEEMQXxBPcEtASvBLUE/gQjBf0EIwX+BKgE/QQjBfoEtAS3BLYEtQSvBPUErQS1BPUE/AQiBfUE/AT6BCIFswT3BLIEtAT4BCoFrwS0BCoFswSvBCoFogQABV8E/gT/BLgEAQW5BLgEAQW4BP8EAgUlBbkEAgW5BAEFJQW6BLkEJQX9A7oE/QMlBQIFRwW7BAIFAgW7BP0DuwQDBbwEAwW7BEcFBQUGBb0EvQQGBb4EpAQhBaMEfQTtBCUE1QR9BNME7QTWBCUE1QTWBO0E1gTXBIIE1wSDBIIE2QSDBNcE7gR0BZsEmwR0BZwEngTwBJ0E8QTwBJ4EnATyBKEEnwScBKEEoQQyBaIEMgWhBPIE5wRSBCMFIQWlBKME+gSlBCIFIgWlBCEFpQT6BCMFIwWoBOcErAQ1BasENQWsBDkFNQViBaQEpARiBSEF9QQiBWIFYgUiBSEFrQT1BK8E9wSxBLAEsgT3BLAE+ASzBCoFUgRTBFEEkgTxA/ADkQTwA48EkgTwA5EEjwTwA4wEUwRUBJEE5wORBOoDUwSRBOcDUQRTBJAEVARVBJEEUQSQBEwEkATnA4oEUwTnA5AEhwSQBIoERATvA+4D7QOrBE4EqwRQBE4EhwRMBJAEkQRVBJIEkgRVBPEDVQRWBJMEVgTpBJMEFwSrBO0DlATyA+8DRASUBO8DlARYBPIDRARYBJQE8gNZBLEEWwRdBLUEWgSeBPcDXgRcBFsE+QNeBFsE/ANiBP0DtQMdBLgDJwS8A7sDJQRIAyEESAMnBLsDJQQnBEgDugMfBLcDIgQfBLoDuAMdBLkDHQR5BLkDJwRNA7wDHwQhBEgDtwMfBEQDtAMdBLUDtAOwAxkEsAO0A7IDFgQZBLADrgMVBLAD/wNlBAMEKQRNAycEKQQnBIIE6wOHBOIDhwTgA+ID4APkA94DiQTmA+AD4APmA+QDhwSKBIkE4AOHBIkEigTnA4kE6AOMBOkD6gORBOgD6AOPBIwEjwToA5EETASHBOsDPwQTA5kEhAScBJ8EhQRfBJoEoQSFBJoE+AOhBJoEXwT4A5oETgTsA5kEewNOBJkEEwN7A5kEnASEBJsE6wM/BJkETATrA5kE7ANMBJkEEwM/BJgEeAMTA5gE4gN4A5gEPwTiA5gEeAPiA3cDngSdBN0EoQSiBIUE4ARrBE0E7APiBEwEowTsA6QEpATsA+EE7AOjBOIE4gRRBEwE5ARTBFIEUwTkBFQEowSlBOIE4gSlBFEEUgRRBKUEpQQjBVIEUgTnBOQEFgTLBLQD/wMDBAEEDQS9BGcEaQQHBGcEagQHBGkEBwRqBAsEAwRsBJ8DngMDBJ8DbQSfA2wEagRvBA4ECwRqBA4EDgRxBBEEcQQOBG8EEQRxBBMEEwRxBBUEFQRxBBYETAYnBiYGGQQWBLQDHQS0A8sEIgR9BB8EIQQfBH0EdwQdBHUEHQR3BHkEeQR6BLkDuQN8BLoDfAS5A3oEfQQiBLoDfQQlBCEEJQTWBCcE1gSCBCcEgwQpBIIEnQMXBH0D3ge+B50HuQfAB8IHuAfAB7kHnwe5B8IHuQefB6UHpQe/B7kHvwelB54Hvwe+B7kHvge/B54HnwfCB8AHvgeeB50H3gedB70Htwe9B7YHtwfeB70HtQe9B5wHtQe2B70HtQebB7QHswebB7wHwQegB8AHwAegB58HwAfaB8MHwQfAB8MHwQehB6AHoQfBB8MHugehB9oH2gehB8MHuweiB6EHuwehB7oHuwejB6IHuwfEB6MHpwejB8kHowfEB8kHxAe7B8kHqAepB44HqweSB6oHkgerB5MHqgeSB5EHqgfLB8wHqgeRB8sHyweRB5AHyweQB48HywePB44HqwesB5MHeQeoB44HowenB4sHoweLB6IHoQeiB4UHpgeFB4kHoQeFB6YHhAemB4kHyQfFB6cHrAerB80HrQeUB6wHrQeVB5QHrQeWB5UHlgevB5cHrweWB64HrgeWB60H0QewB68HsAfTB5gH0weyB5gHsQeyB9MHswe8B7IHsge8B5oHsgeaB5kHtAebB7MH3we+B94HwAfiB9kH4gfAB7gH4gfXB9kH1wfYB9kHuAfXB+IH1we4B+EH1wfgB98H1wfhB+AH3we5B74H1gfeB7cH1ge3B7YHAAjWB7YH3QcACLUHAAi2B7UH1QfdB7QH3Qe1B7QH1Qe0B7MHuQffB+AHuQfgB+EH4Qe4B7kH2QfaB8AHBwi6B9oH9AfLB8oH4wf1B/QH9Af1B8sH5Af1B+MH5AflB/UH9QflB8wH5gf2B+UH9gfNB+UH5gfnB80H5gfNB/YHqAfbB6kHzgf3B6wHzQerB+UH5QeqB8wH5QerB6oHywf1B8wH2wfLB44HygfLB9sH2weOB6kHzgesB+cHyAdbB1kHyAdZB1gHxwdYB8YHxwfIB1gHxgdYB4wHxQfGB4wHpwfFB4sHoQeEB6AH5wesB80H9wetB6wH9wfPB60H0AeuB60H0AetB88H0AevB64H0QevB9AH0gewB9EH0gfTB7AH1AexB9MH1AeyB7EH3AezB7IH1AfcB7IH1QezB9QH1AezB9wHfQeGB0kHYgeBB0wHfweAB2IHfwdgB34HfwdhB2AHfgdgB18HfgeGB30HSgd+B18Hhgd+B0oHgQdiB4AHfQdJB0cHfAd9B0cHfAdFB3sHRQd8B0cHewdEB0MHRAd7B0UHegdCB3kHQgd6B0MHTAeBB2MHYweBB2QHZAeyB2UHZQeyB2YHaAdnB2kHawdqB2wHnQdtB2wHnQduB20HnQeCB24HgwdvB4IHgwdwB28HgweHB3AHiAdxB4cHiAdyB3EHhweEB4kHbQczB2wHhwdxB3AHbwdwBzcHggdvBzcHggc1B24Hggc3BzUHbgc0B20HNAduBzUHMwdtBzQHcwdyB3QHMgdrBzMHawdsBzMHawcwB2oHMAdrBzIHaQdqBzAHaQcvB2gHLwdpBzAHiAeHB4kHcQdOB3AHcgdPB04HcQdyB04HcgdzB08HdAd1B3MHdAdyB3YHdQdRB1AHUQd1B3QHdgdSB3QHUgd2B3cHdAdSB1EHdwdVB1IHeAdWB1UHdwd4B1UHXgd5B0IHsAdkB4EHmwdpB2cHvAebB2cHmQdnB2YHmgdnB5kHvAdnB5oHmQdmB7IHsgewB5gHsAeyB2QHnAdqB7UHrwewB4EHlweBB5YHrweBB5cHlgeBB4AHlgeUB5UHlgeAB5QHlAeAB38HrAeUB38HtQdqB5sHmwdqB2kHvQekB2oHvQdqB5wHpAdsB2oHvQedB6QHpAedB2wHngeCB50HpQeDB4IHngelB4IHpQefB4MHnweHB4MHoAeEB58HhwefB4QHhAehB6YHjQckByMHcgeIB4kHcgeJB4oHhQeKB4kHigd2B3IHdgeKB4UHogeLB4UHhQd3B3YHdweFB4sHiwd4B3cHiwfFB3gHVgd4B1MHeAfFB1MHWAdTB4wHjAdTB8UHWgdZB1sH5wfoB/cHXAdbByMHWweNByMHeQeOB3oHjgdDB3oHjwd7B0MHjwdDB44Hjwd8B3sHkQd9B3wHkQd8B48HkQePB5AHfQeRB5IHkgeTB30HfQeTB34HkwesB34HrAd/B34HQghDCEkIQwhECEsI8gdDCEsI8wfyB0sIRAjzB0sIQwjyB0oIJQhDCEoI8QclCEoI8gfxB0oI8wdFCAgIJQhCCEkIQwglCEkIQgglCCQIQggkCDkIOQgjCEEIOQgkCCMIQAhBCCMIPwhACCIIRQjzB0QICAhFCAkICQhGCAoIRggJCEUIRghHCAoICghICAsISAgKCEcIUggzCDIIUwg0CDMIUghTCDMITAhUCDQIVAhMCFUIVAhVCDQIVQhNCFYITQhVCEwIMwg0CDsIPQgpCB4IPAgeCB0INAgdCDsINAg8CB0IVQg8CDQIMwg7CBwIOwgdCBwIMwgcCBsIPAg9CB4IMggaCDoIMggbCBoIMwgbCDIIMQgyCDoIOggaCBkIMQg6CDAIOggZCBgIVgg9CDwIPggqCCkIPQg+CCkIPQg1CD4INQg2CB8INQgfCD4IPggfCCoINgggCB8INgg3CD8INwg4CEAIPwg3CEAIQAg5CEEIPwghCCAINgg/CCAIPwgiCCEIQAgjCCIIYwhDCGIIZghpCGUIRghpCEcIaQhGCEUIZQhFCGQIZQhpCEUIaAhFCEQIYwhFCGgIZAhFCGMIXwhaCG8IQwhoCEQIYwhoCEMIZwhDCEIIYQhDCGcIYghDCGEIZwhCCGoIOQhnCGoIQgg5CGoIDAgLCA0ICwhICA0ISAhpCA0IaQhmCA0IZghrCA0IbAgVCG0IFQgOCG0IZQGWAWYBSQF1AZcBXwhRCFAI+gGWAZUBDggNCG0IDQhrCG0IawhsCG0IFQhsCBIIUAg4CFgIVQhWCDwITgg1CE0ITQg1CFYIVgg1CD0ITgg2CDUITgheCFcIVwg3CDYITghXCDYITwhXCF4IVwhPCDcITwhQCFgIWAg4CDcITwhYCDcIUQhACDgIUQg4CFAIMAgYCBcIXAhOCE0IXQhZCF4IXQheCE4IXAhdCE4IWQhaCF4IXwhQCE8IXwhPCFoIWghPCF4I+ADZAJQAOQhACGcIQAhRCGcIUQhfCGcIXwhbCGcIWwhgCGcIYAhhCGcI3wcBCAUI8wfZB/IH8wcGCNkH1wfyB9gH8QfyB9cHBQjXB98HBAjXBwUI8AfXBwQI8QfXB/AH8gfZB9gHAQjfB94HAggECAEIBAgFCAEI7wfwBwQIAgjvBwQI3gcDCAEIAwjeB9YHAAgDCNYHBgjaB9kHBgjzBwcIBggHCNoHCAi6BxAIugcHCBAIBwjzBxAI8wcICBAIuwe6BxEIugcICBEICAi7BxEICggPCMkHCgjJB7sHCgi7BwgICggICAkIDwjFB8kH+AfSB9EH6wfsB/sH+gfrB9MH6wfUB9MH+QfrB/oH6gfrB/kH+QfSB/gH+gfSB/kH+gfTB9IH6wf7B9QH+AfqB/kH6QfRB9AH6Qf4B9EH6QfQB88H9wfpB88H6AfpB/cH5wf3B84HCwjGBwoI7Qf8B+wH7Af8B9QH7AfUB/sH/AfVB9QH/Af9B9UH/QfuB/8H/gf9B/8H/gfdB9UH/Qf+B9UH/wcACP4H/gcACN0H/wfvBwIIAQj/BwII/wcDCAAIAwj/BwEIHwjsBysIIggsCCEIIAgsCPwHLAj9B/wHIAghCCwIHwggCO0HIAj8B+0HHwjtB+wHKwjsByoIIgjuB/0HKQgqCOsHKgjsB+sHKQjrB+oHKggfCCsIKAjqB/gHHQjqBygIHQgpCOoHHggpCB0ILAgiCP0HIggjCC0ILQj/B+4HIggtCO4HLQgjCC4ILgjvB/8HLQguCP8HIwgkCC8ILggjCC8ILggvCO8HJQjwByQIJAjwB+8HJAjvBy8IJQjxB/AHMAg6CBgIJgjlB+QHCgjGBw8IDwjGB8UHCwgMCMYHDAjHB8YHDgjHBw0IDQjHBwwIxwcVCMgHFQjHBw4IEgjIBxUIEggUCMgHyAcUCI0HyAeNB1sHEggTCBQIFAgTCI0HJggWCCcIaAcvB2cHJwjmB+UHJggnCOUHFwgYCOYHFwjmBxYIFgjmBycIGAjnB+YHGQjoBxgIGAjoB+cHGQgaCOgHGgjpB+gHGwgcCOkHGwjpBxoIHAj4B+kHHAgdCCgIHAgoCPgHmwavBo0GsgaPBrEGjwayBpAGsAaPBs4GsQaPBrAGzgaPBo4GjQbMBo4GzAbOBo4GrwbMBo0GkAazBrQGrgavBpsGjAatBpsGrQauBpsGrQaMBqwGrAaMBosGagasBosGyQasBmoGigarBskGtAa1BpEGkQa2BnIGtgaRBrUGtga3BnIGcga4BpIGuAZyBrcGkga5BnUGuQaSBrgGuQbRBnUGkwZ1BtEGugaVBpQGlQa6BkgGSAbVBpYG1QZIBroG1QZ6BpYGnwYGBqIGoQYlB6MGoQajBqAGoAafBuEGoAZZBp8GnwZZBgYGfgafBqIGTgZ+BqIGBgZOBqIGYQakBoIGwAafBn4GngbABn0GwAZ+Bn0GfQaYBp4GlwZ9BnwGlwZ8BnsGlwaYBn0GuwZ6BtUGhAaGBoUGwwaGBoQGwwaEBqUGhgamBogGhwaGBogGpwaIBqYGpwapBogGqQanBqgGqQbcBokG3AbFBokGiQaqBmYGqgaJBsUGqgarBmcGZgaqBmcGZwarBooGtwb6BrgG1Aa6BtMGugbUBtUG0waUBtIGlAbTBroGkwbSBpQG0QbSBpMGuQa4BtEGuAbQBtEG1ga7BtUGtga1BrcGtAazBrUGkAbPBrMGsgbPBpAG9gayBvQG9AayBrEGsAb0BrEGzgb0BrAG1gZ6BrsG1ga8BnoGvAbWBtcG3QbYBtkG2Aa9BtcG1wa9BrwG2AbBBr0GwQbYBt0G2Qa+BsEG3QbZBsEGvgbaBr8G2ga+BtkG2gbABr8G5AZbBloG4gbkBloGpgbcBqkGega8BpgGlwZ6BpgGvQbBBpgGvQaYBrwGmAbBBr4GvgaeBpgGvwbABr4GvgbABp4G/wYAB6QGgwbCBoQGwgaDBoIGhAbCBqUGhgbDBqYGpwamBqgGxAbcBqYGegaXBnsGpgapBqgGxQbcBsQGxQbuBqsGqgbFBqsGxgarBu4GxgbHBqsGxwbJBqsGyQbHBsgGyQbvBqwGrQasBu8GrQbKBq8GrgatBq8GygbMBq8GzAbKBssGzAbNBs4GfwZuBoAGcAZABj8GPgZwBj8GPQZwBj4GPAZvBj0GOwY6BjwGOgaPBjwGOgZVBm4GgAZuBlMGkQZxBnAGUwZ/BoAGUwZtBn8GbQZTBjkGbQY5BjgGbQY4BjcGbQY3BjYGbAY1BmsGNQZtBjYGcAZxBkEGcAZBBkAGcgZzBnEGcwZCBnEGcwZ0BkMGcwZDBkIGdAZEBkMGdQZ2BnQGdAZ2BkQGdgZFBkQGdgZ4BkUGeAZ2BncGRwZGBkgGeQZ6BkkGewaBBkkGKAZOBl0GYgYuBmEGYQYtBmAGLQZhBi4GTwZfBlAGowYIBqAGWQYIBgcGoAYIBlkGWQYHBgYGYgYvBi4GJwYoBl0G+gUnBl0GTgb6BV0GTQZOBigGTAYoBicGTQYoBkwGWAZMBiYGSQaBBkoGhQYwBi8GhQYvBmIGMAZjBjEGMQZjBjIGMgZjBmQGZAaIBjMGMwaJBmUGNAYzBmUGZQZmBmcGZwZoBhMGEwZpBjUGaQYTBmgGaQZqBjUGagZrBjUGbAZtBjUGmwacBn8GkAZvBo8GbwaQBj0GPAaPBm8GOgaOBo8GjQaOBjoGnQY6Bm4GjQY6Bp0GbgacBp0GPQaQBnAGnAZuBn8GnAabBp0GmwaNBp0GmgabBm0GmwZ/Bm0GjAaaBm0GmgaMBpsGjAZtBmwGtAZwBpAGcAa0BpEGcQaRBnIGcwZyBnQGkgZ0BnIGdAaSBnUGdgZ1BncGdwaTBngGkwZ3BnUGkwaUBngGeAaVBkYGlQZ4BpQGSAZGBpUGSAaWBnkGeQaWBnoGhAZiBoMGewZJBnoGewZ8BoEGgQZ8BkoGfAZ9BksGVwZ8BksGSwZ9BlgGfgZMBlgGfgZYBn0GfgZNBkwGfgZOBk0GYQaCBpkGmQZiBmEGgwZiBoIGggZiBpkGYgaEBoUG4gbjBuQGMAaGBmMGhgYwBoUGhgaHBmMGYwaHBmQGhwaIBmQGiAapBjMGMwapBokGZQaJBmYGZwZpBmgGyQZqBmcGZwZqBmkGyQZnBooGagZsBmsGjAZsBosGiwZsBmoGVAf7BhcHOQcYBzoHOQcdBxgHOQdVBx0HUQcYBzsHOgcYB1EHVAdRBzsHVAc7B/sGOwcYB/sGHQdVBzwHVAcXBxYHFAc4BxUHOAcTBzcHEwc4BxQHNwcSBzYHEgc3BxMHNQc2BxIHNQcRBzQHPAcfBx0HHwc8Bz0HPgc9Bz8HPQcZBx8HGQc9Bz4HPgc/BxkHJgdBB0IHQQcmB0AHQgdDBwUHRAdFBycHJwdGBwcHRgcnB0UHRgdHBygHBwdGBygHSAcoB0cHJgdCBwUHKgcJBykH6wYpBwkHKQcIB+oGCAcpB+sG6gboBigHBgcnBwcHRAfmBgUH5gZEBycHCQcqBwoHJAclB6EG3wYkB6EG4QbfBqEGIwckB98G3wbhBuAGIgfeBtoG3wbeBiIHSAdJB+oGDAcLBysHKwcsBw0HDQcsBw4HLQcOBywHLQfwBg4HLQdNB/AGTQctBy4HMAcPBy8HMAcxBw8HDwcxB/MGMQcQB/MGMwcQBzIHMgcQBzEHEQcQBzMHEQc1BxIHPwdYB10HXAcjB98GWwffBloHWwdcB98GWgffBiIHWQcaB1gHWgcaB1kHGgdaByIHWAcaB10HQQdeB0IHGgc/B10HUwdYBz8HPQdTBz8HVwdTBz0HVgdXBzwHVwc9BzwHVgdTB1cHVgc8B1UHBQdDB0QHRgdFB0cHSAdHB0kHSQeGB0oHSgdfB0sHYAdLB18HYQd/BwoHYAdhBwoHYgcKB38HCgdiB0wHTAdjB2QHZAdlBywHLAdlB2YHZgdnBy8HTQdmBy8HMQcwBzIHKAdIB+oGSgfqBkkH6gZKBykHSwcpB0oHKQdLByoHYAcqB0sHKgdgBwoHCwcKBysHTAcrBwoHKwdMBywHTAdkBywHLQcsBy4HLAdmB00HLgcsB00HDwdNBy8HIQcaByIHEQczBzQHNgc1BzcHNwdwBzgHOAdOBxUHTgc4B3AHTwdzBxUHTwcVB04HcwcWBxUHcwdUBxYHcwd1B1QHUAdUB3UHUAdRB1QHUgdVB1EHUQdVBzkHUQc5BzoH8QbyBswG9gbPBrIG9Ab1BvYGEAfyBvMGEAfOBvIGEAf0Bs4G8gbOBs0G8gbNBswGywbxBswGEgf4BvYGygbxBssG8QbKBvAGrQbwBsoG7wbwBq0GyQbIBu8GxgbuBscG7gbsBu0G7AbuBsUG9gb4Bs8G+AazBs8GswYUB7UGtQb5BvoGtwa1BvoGuAb6BtAG+gb7BtEG0Ab6BtEG0gb8BtMG/QbTBvwGAQf9BtcG1wb9BgIH/QbUBtMGAQfVBtQG/QYBB9QG/gb/BuUG/gbmBgAHggakBgAH4QahBqAG4AbeBt8G4AafBt4G4AbhBp8GwAbaBt4GnwbABt4G/wb+BgAH2wb+BuUG5AbbBuUGWwbkBuUGYQZbBuUGpAZhBuUG/wakBuUG4wbbBuQG1wbWBtUGAAfmBoIGBgfCBoIGggYnBwYHJweCBuYGBgfnBsIGwgbnBqUG5wbDBqUG6AbDBucGwwbpBqYG6QbDBugG6QbqBqYGpgbrBsQG6wamBuoG6wbsBsQGxAbsBsUGEwf3BhIHFwf6BhYH+QYVB/oGFQcWB/oGtQYVB/kGFAcVB7UG9wYUB7MGEwcUB/cG9wazBvgG+gYXB/sG+AYSB/cG9gYRBxIHEQf1BhAH9QYRB/YG9AYQB/UG8gYPB/MGDwfyBk0H8QZNB/IG0QYYB9IGGAfRBvsGGAf8BtIGHQf9BvwGGAcdB/wGHQceB/0GHgcdBx8H/QYeBx8HHwcCB/0GAgcfByAHHwcZByAHIAcZBwIHGQc/BwMHGgcDBz8HGgchBwMH6QboBuoGAQfXBtUGGQcDB9gGGQfYBgIH2AYDBwQHIQfZBgMHAwfZBgQHBAfZBtgGIQciB9kGAgfYBtcGIgfaBtkG/gYmB+YGJgcFB+YGBgcHB+cG5wYoB+gGKAfnBgcH3AKEAt0C6gYIB+sG6wYJB+0G7AbrBu0G7QYJB+4GCwfHBgoHCgfHBgkHCQfHBu4GDAfHBgsHDAcrB8gGxwYMB8gGDQfIBisHyAYNB+8GDQcOB/AG7wYNB/AG8AZNB/EGMQPuAksDOwO3AjgDPQO3AjsDPQO6ArcCOAO3ArQClwM4A7QClwMoA5YDKAOXA6QChgJLA+4CPQO9AroC7gIxAy8DjAPtAi8DjAOpAu0CjANVA6kCqAKpAlUDVQOmAqgCpgJVAykDKQOeAqYCPQNaA70CXQNaAz0DWgPAAr0CXgNaA10DXgPDAloDXQOaA18DXQNfA14DPwNfA5oDXgNfA8MCXwPFAsMCXwM/A2ADYANiA18DXwNiA8UCYgNgA8gCpQNDA2AD/QIAA0kCAgPLAgADAQMAAwMDSwIBAwMDyAICAwADAAP5AsgC+QIAA/0CYgPIAvkCxQJiA/kCAAPNAgMD+gJJAkYC+QJJAvoC/QJJAvkCwwL6AkYC+ALDAkYC+AJGAkECwwLFAvkCYANDA8gCzQIAA8sCzgIDA80C8wMeA50CHwPzA50CngIfA50CIQPHA58CnwLHA+UCnQIhA58CIQOdAh4D5QIkAycDJAPlAscDiQOiAicDiQMoA6ICKAOkAqICHwOeAikDAgQxA5QDCAQ9A5gDCATSAz0DmAM9AwUEBQQ9AzsDBQQ7AzgDlwMFBDgDlgMoA4kDlAMxA0sD0gNdAz0DAgTPAzEDAgQABM8DLwMxA80DLwPNA8sDMQPPA80DLwPLA4wDzQOMA8sDjQOMA80D0gNBBF0DQQSaA10DmwM/A5oDnQN9A0ADmwOgAz8DogM/A6ADogNgAz8DpAOlA2ADpANgA6IDpgOoA0MDpgNDA6UDqQOdA0ADHAOpA0ADqwOpAxwDqAPZA0YDzQJjA84CAACIAgEAiQIAAAEAAQCHAgUDTAOHAgEAhgJMA0sDYwNKA84CSgNGA60DRgNKA2MDvwNMAwEAywJGA80CRgNjA80CRgNDA6gDAgNGA8sCRgPIAkMDyAJGAwIDGwMcA0AD+QL6AsMCiQIBAIgCiQKIAmUDiAKKAmUDgQPzAx8DggPHA/MD8wPHAyED8wMhAx4DxwOFAyQDhQM6BCcDJAOFAycDiQMnAzoE+gOBAykDjAP6AykDVQOMAykDgQMfAykDBgIHAnMCPALbAXYCPALdAdsBMwJ2AskBMgIzAqQCrQFcAtYByQHbAf8B1gFcAnQCBwLWAXQCdgLbAckBBwJ0AnMCAgIGAnECBgJzAnECAgJxAi8CLwJxAnMCBQIvAm8CLwKoAm8CJAL9AcsBMwI2AnYCPAJ2AjYCPAJ4AuAB3QE8AuABPAJ5AngCPAI9AnkCPQJBAnkCeAJ7AuABeAJ5AnsCeQJ8AnsCewLkAeABfAJ9AuQBfALkAXsCQQJ+AnkCeQJ+AnwC5AENAhEC/QElAmoCJQL9ASQCfQJlAuQB5AERAuABEALgARECDALgARAC3QHgAQwC2wHdAQwCJwMnAsUBDQLkAQ4CEAIRAg0CCQIMAhACCQIQAg0C6AEGAg8CBgLoAa0B1gEGAq0BQQJ6An4CJwPFASUCJQLFAWoCagLFAf0BbQLHAScCJwLHAcUBbQLJAccBpAJtAikCMwLJAW0CMwJtAqQCbgIkAmkCJAJuAm8CywFuAmkCywFpAiQCBQJvAm4CywEFAm4CdAIvA+0CMwK3AjYCtAK3AjMClwMzAjICpAKXAzIChgJ0AlwC7gJ0AoYCdALuAi8DcwJ0Au0CtAIzApcDcwLtAuwCcwLsAi8C7QIvAuwCqQIvAu0CqQKoAi8CpgJvAqgCngJvAqYCbwKeAiQCtwI8AjYCugK9ArcC8wI9Ar0CvQI9AjwCvQI8ArcCvQL0AvMC8wJBAj0C8wL0AkECvQLAAvQCWgP3AvQCWgP0AsAC+AJBAvcC9wJBAvQCWgPDAvcC9wLDAvgCSwItAkkCegJ/An4CfAJ+An0CfQJnAmUCZwJ9An4CRgJ6AkECegJGAn8CRgKAAn8CggJsAn4CfwKCAn4CfwIqAmwCggJ/AmwCRgJJAoACgAItAn8CLQKAAkkCfwItAioCRgPZA60DAAMBA0kCAQNLAkkCngKdAiQCnwLlAp0CnQLlAiUCnQIlAiQCJQLlAuYC5QInA+YCogInAicD5gInAyUCogJtAicC6AIpAm0CogLoAm0CpAIpAqICogIpAugC2AR2BHQEgQTbBJsEeATbBIEE2wR4BNoEnQQfBd0EfwSeBN0EHwV/BN0EHwUeBX8E2gR2BNgECAXCBMAEcwTYBHQE7ATYBHME7ARzBHIE0gTsBHIE1ATsBNIE0ARwBM8EzwRuBCkFzwRwBG4EwwQIBcAEjgXEBMIEjgXCBAgFxATHBMYExwTEBCcFxAQJBScFCwUnBQkFCwWoBckECwXJBCcFDAXMBM0EDAXNBO8EzQQgBe8EIAXNBN4EqAUPBckEKQUEBMkEJgSNBI4ExgTHBGMEwgTEBMYEYQTDBMIEwwTABMIElwQoBDcENwSNBJcEjQQ3BC8EKASXBCYEJwXrBGMElwSNBCYEJAQmBE8EJgSOBE8EIwQkBEYEJARPBEYEhgRFBEYERQSGBE0EDwUpBckEYwTrBGQEJwVjBMcEyQRkBOsEJwXJBOsEzQTMBNwE3ATMBGYEzQTcBN4EjQPeBNwE3gSNA2gEaATfBN4E4AQ6Bd8EaATgBN8EZATJBDsEBAQ7BMkEBAQpBW4EkwWtBVQFCAXDBKoFjgUIBaoFWgWWBVwFrwVXBZUFVwWvBVoFlAWVBRUFrgVUBa0FVAWuBZQFwwRRBaoFlAUVBVQFkwVUBZIFjQVRBU8FjgVRBY0FTwWbBY0FmwVPBTMFXAVyBRkFXAVXBVoFUQWOBaoFxASOBQkFjgWoBQkFqAULBasFCwUJBasFCQWoBasFkAWSBawFkgUPBawFDwWoBawFqAWQBawFugX7BY0FjQX7BY4FugXoBfsF/AWOBQ0GtQO5A2EDHAXaBBkFEQUpBQ8FEQXPBCkFEgXPBBEFzwQSBdAE0AQVBdIEFQXQBBIFFwXSBBUF0gQYBdQEGAXSBBcFGAVXBewE1AQYBewE7ARXBdgEVwVcBdgEXAUZBdgEGQXaBNgEawRFBE0EHwWdBPAE2wTuBJsEYQTMBMMEzAQMBcMEDAVRBcMETwVRBTMFMwVRBQwFMwUMBe8EDwWSBREFkgVUBRIFEQWSBRIFEgVUBRUFFQUYBRcFVwUYBRUFVwUVBZUFCARBBNIDDwSlA6QDDwSiA6ADogMPBKQDmwMMBKADDARBBAoEQQSbA5oDDASbA0EECQQKBEEEDwQcBKYDCQRBBAgECASYAwYEBgSYAwUEbgSXAwQElwNuBAUEOwSWAz0EBASWAzsEBASXA5YDDwSmA6UDHASoA6YDqQMXBJ0DqwMXBKkD2AMXBKsD9wPYA1oEHASsA6gDHgSsAxwEHgQgBKwDhAQgBB4EIASvA60DlgT4A68DsQNFBAIElAOxAwIEswNFBLEDlANLA7ED+gPzA4EDLAS2A78DagO2AywEBQO/AwEAvwOzA0wDtgOzA78DsQNMA7MDsQNLA0wD9QPHA4IDSgPaAyUDrQPaA0oDrwPaA60D2QMgBK0DrAMgBNkDqAOsA9kDqwMcA9gDtgNGBEUE9AOCA/MD9QOCA/QDOgSFA8cD9QM6BMcD9QNjBDoEYwT2AzoEiQM6BDsEiQM7BD0EOgRkBDsEZAQ6BPYDjAP7A/oDjQP7A4wDzwNoBM0DaATPAwAEPQSWA4kDCQRyBAoEDwR4BBwEdgTaBA8EdAQPBKADdgQPBHQEdASgAwwEcwR0BAwEcwQMBHIEcgQMBAoEeAQPBNoEcgQIBNIECARyBAkE0ATSBAgE0AQGBHAEBgTQBAgEcAQFBG4EBQRwBAYERQRrBAIEqwQXBHsEHgV7BBcEHgUXBH8EfwQXBNgD9wN/BNgDfwT3A54EHAR4BIEEgQQeBBwEhAQeBIEEhASBBJsEhASfBCAEIASWBK8DlgQgBJ8EnwShBJYElgShBPgD8wNhBPQDswO2A0UEtgMjBEYESQQjBLYDIwQmBCQELwQ3BEgENQQvBEgESQQmBCMESQQoBCYESQRKBDcEKARJBDcESQRoA0oESgRoAzcEbANtAywEbgMqBG0DKgQrBG0D1gEHAgYCYQTzA8wE9ANhBMIE9APGBPUDxgT0A8IEYwT1A8YE9gNjBGQE3ARmBPoD+wPcBPoD+gPMBPMDzAT6A2YEjQPcBPsDzQNoBI0DAATgBGgEAgTgBAAEawTgBAIEZgOVAy0EGgQbBEMEGgSLAxgEFAQYBIgDfgQYBBQEFASIA4QDEgQUBIQDEgSEAxAEgwMQBIQDQwSOAxoElQNmAz4DlQM+AzoDNgOVAzoDkQOVAzYDNgM6AzcD3QM0A44DkQM0A90DkQM2AzQD3QOOA0ME3QNDBBsEfgQUBBIEfgSpBJUElQQaBBgEfgSVBBgEgAQbBBoEgAQaBKkEqQQaBJUEgATdAxsEZAA1AJMAlACVAGEAlgBhAJUAmACaAGIAmgBjAGIAXAO7ArkCNgPCAjQDNwPCAjYDNAPCAsECNAPBAjIDMgPBAr4CMgO+ArsCLQO7AlwDMgO7Ai0DwgI6A8QCXAO5ArYCLQO2AiwDLQNcA7YCWQOyAlsDWQO2ArICLAO2AlkDWQNbA7ECmgCbAGMAOgPCAjcDPgPEAjoDrgKDA1kDhANZA4MDhAMsA1kDzAMtAywDhAPMAywDiAMtA4QDhAMtA8wDGAQtA4gDGAQyAy0DGgQyA4sDiwMyAxgEGgSOAzQDGgQ0AzIDbAHnAOMASwEWAZkBSwHcABYBmgHcAEsBmQEWARQBSQEUAXUBSQGZARQBbAEfAegAbAHoAOcAmgEYAdwAHQHjADwBbAHjAB0BPAHjAOIAPAHiAN8AHQHfABsBHQE8Ad8AGQEbAd0AGwHfAN0AmgEZARgBUAEbARkBUAEZAU4BTgEZAZoBnAFrAVABUAFrARsBawEdARsBnAFRAWsBqAEdAVEBUQEdAWsBdwFsAagBqAFsAR0BfAFsAXcBbAF8AR8BeAF8AXcB3QCWANwA4wCcAJsA4wCbAJoA4wCYAOIA4wCaAJgA4gCYAN8A3wCYAJYA3wCWAN0A3ACWAJUA6ACcAOcA3ACUANkA3ACVAJQAuACeAGQAnAC4AJMAuABkAJMAnACTAGMAnABjAJsAWwOyArEC5wCcAOMAnADoALgAkQAPAREBDwE1AREBEQGSAJEAkgARARIBEQE4ARIBOAH5ABIB+QD3ABIBFgHZAPgAFgH4AHUBFgF1ARQBFgHcANkAGQHdANwAGQHcABgBmAGZAUkBnAGoAVEBnQGoAZwB4QGcAVAB4QFQAU4B4QFOAZsBmgGbAU4BmgFLAZkBmQGYAdoBdwGoAZ0BmAFJAZcBpwGXATkB0gGXAacBpwE5AWcB0gFnAZYB0gGnAWcBlgFnAWYBlgFlAZUBpgHKAcwBkwGmAcwBlAHMAfoBzgH6AcwBNQKWAfoBaQhICEcINQL6Ac4BNQI4ApYBOALSAZYB1AGXAdIB1AGYAZcB1AHYAZgB2AHaAZgB2gHcAfwB/AGaAZkBZwE5AfkAZAE1ATQBZAE0AaYBdQH4ALUAOgG1AEcBdQG1ADoBOgH5ADkBOgH3APkAOgFHAfcANgE1AWQBZwH5ADgBOAE2ATcBNgE4AREBNgERATUBRgE1AQ8BNAE1AUYB+ACUALUA2gH8AZkBNwFlATgBZQE3ATYBZQFnATgBZwFlAWYBlwF1ATkBOQF1AToBbghjCGIIkwFkAaYBkwHMAWQBzAGUAWQBlAE2AWQBlQE2AfoB+gE2AZQBNgGVAWUBbghiCGEIuQI7ArYCvgI/ArsCwQI/Ar4CwQLxAj8C8AK7Aj8C8AI/AjsCuwI7ArkCuwLwAjsCtgI7AjkC8QJDAj8CsgK2AjgCtgI5AjgCsgI4AjUCsgI1ArECsAKxAswBsALMATECrgIxAsoBrgKwAjECwQLCAvEC8QLCAkMCwgJFAkMCxAL1AsICwgL1AkUCPgP1AsQCPgPHAvUC9QJMAkoCyQJMAvUCyQL1AscCTALJAgkDCQOUAqoBlAKrAaoBrgJZA7ACWQOxArACcgLcAdoBmwGaAdwB3AGaAfwB3gHhAZsB4QHiAZwB5QGdAZwB5QGcAeIBygExAswBsQLOAcwBsQI1As4BOAI5AtIBOQLUAdIBOQI7AtQBPwLYATsCOwLYAdQBPwLaAdgBfAF4AXoBPwJyAtoBQwLcAT8CPwLcAXICQwKbAdwBRQLeAZsBRQKbAUMC3gFFAuEB4QH1AuIB9QLhAUUC9QJKAuIB4gFMAuUBTALiAUoCTAKdAeUBqgGdAUwCqgFMAgkDwQB7AFwAxABfAF4ApABeAH4AwwBeAKQAxABeAMMAfgCoAKQAqAB+AHsAxADDAMYAewDBAKgAXwDEAMYApgDBAFwApgCoAMEApgBcAFoApgBaAL4ApgC+AKIAogC+AFkAogBZAFgAAwFYAHgAXwDGAMcArADJAMcArADHAMYArACuAMoAygCuAGAAygBgAKwAsAC3AGAAsABgAK4AxwBlAF8AZQDHAMkAZQDJAKwArABgAGUA7ACeAOgA6ACeALgAAwHsAAQBXAA3AFoAewB+ADgAfgA5ADgAXgBFAH4AXgCBAEUAewA4ABgAXAB7ADcAewAYADcAWgA3AEMAfgBFADkAWgA2AL4ANgBaAEMAvgA2AFkAWQA2AFgAeABYACUAWAA2ACUAZAB4ADUA7ACgAJ4AgQBeAF8AgQBGAEUAXwA6AEYAgQBfAEYAaABgAGkAhABfAGUAhACFAF8AXwCFADoAhQCEAGUAYABoAGYAYABmAGcAYABnAGUAoAADAWQAoABkAJ4AogBYAAMBaQFqAXYBBgICAg0CLwIFAgICywEDAgICywH9AQMCywECAgUCxwHJAf8BxwH+Af0BxQHHAf0B/QH+AQMCaAFpAXYBfAEyAR8BaAEyAXwB7ABqAQQBagFKAQQBdgFqAewAaAF2AewAMgHsAOgAxwEIAv4B/gEIAgMCAwIJAgICAgIKAg0CCgICAgkCAwIIAgkC/wELAggCxwH/AQgCCwLbAQgC2wELAv8BCQIIAtsB2wEMAgkCDQIPAgYCDQIKAgkCDQIOAg8CGgEKAcMA7AADAaAABAGiAAMBBAEFAaIABQEEAQcBBwEEAagABAHuAAkBqAAEAQkBFwGkAO4A7gCkAAkBBQGmAKIApgAFAQcBpgAHAagACQGkAKgAFwHwAMMApAAXAcMAeAAlADUAGgHDAPAACgHGAMMAxgAKAQsBCwEKAfIAxgALAfIA9gCsAPIA8gCsAMYA9ACuAPYA9gCuAKwAVgGwAA4BVgEOAfQArgD0AA4BDgGwAK4AHwEyAegAaAHsADIBEgSmBH4ErgToBOME5gTlBEsE5QSABOME5QTmBIAEqQTjBIAEqQSqBOMEpwR+BKYEfgSnBKkE4wToBOUE4ASgBDoF3gTfBDoFjQQvBOUDjQTlA+MDjQSLBI4EjgSIBE8EiASOBIsEjQTjA4sEoATgBE0EoARNBK4ETQToBK4E6ARNBIYETwTlBOgE5QRPBEsE6ASGBE8E7wQgBTYFNgUgBd4ENgXeBDgFOAXeBDoF9AQ7BToFoAT0BDoF9ASgBPMEpwRmBakEZwMIA2YD4wPhA4sE4wOSA+EDkQPhA5ID3QPhA5ED3wPhA90DaQMJAwgDZwNpAwgDZgMIA8cCkgOVA5EDZgPHAj4DCAMJA8kCCAPJAscCeAGqAXoBqgGrAXoBdwGdAXgBnQGqAXgBZgWnBPkE4wMtBJUD4wOVA5ID5QMvBOMD4wMvBC0ELwRmAy0ELwRnA2YDLwRpA2cD5gRLBIAEgARLBN8DgATfA90DTwSIBIsETwSLBEsEhgRGBE8ESwThA98DiwThA0sEngU8BUYFvwV7BcAFewW/BZoFvwW+BZoFvAWaBb4FmgW8BXkFugWbBdcFugWNBZsFeQW6BdcFwgXABXsFRQWeBUYFnwU+BT8FngU/BTwFgAU/BZ4FgQU/BYAFgQWfBT8FPgWfBXwFOwU+BXsFfAXCBXsFgQXCBXwFwwWBBdwF3AWBBYAFAwbCBYEFAwaBBcMFNgBDACUAQwA3AEQAQwBEACYAOAA5AEUARgAZAEUARgA6AIUAhQA9AEYAhQA7AD0AZAADAXgAZgX5BGcFqQRnBaoEZwWpBGYFqgRnBeME+wQkBeME+wTjBGcF+wTzBCQFJAXzBK4EJAWuBOME8wSgBK4ENgUzBe8E9AQ+BTsFPAU/BfMEPgX0BD8FPwX0BPME+QRFBWcFjgX7BQ0GZwVFBUYFRgU8BfsERgX7BGcFPAXzBPsEeQXXBZoF1wWbBZoFmgWbBTMFmgUzBTYFmgU2BTgFOAV7BZoFewU4BToFewU6BTsFgAWeBUUFnwWBBXwFPgV8BXsFZAJgAuQBXwLpAiEC7AFkAmYCZQJmAmQCrwFgAuwBYAJkAuwBHAJfAiECZALkAWUC5AFgArEBZQJoAmYCHwIgArYBHwK1AbMBHwK2AbUBtAGzAbUBsgEeArMBegEeArIBlQIeAnoBqwGVAnoBaAJlAmcCZgJoAvAB8AFnAvQBZwLwAWgCIQLrAiMCIgIhAiMCkwJiAmMC5gGTAmMC8wGTAuYB8wHnAZMC5wEmApMCawImAucBfgJsAmcCZwJsAvUB9AFnAvUBGAKtARkCGwKLAg8CrwEaAl4CGgKvAa4BGQIPAosCDwIZAq0BXQKuAakBGAKuAV0CGAIaAq4BXgJfAq8BrQFdAlwCGAJdAq0BFgKsARcCFgKpAawBqQEWAhUCFgIUAhUCFQJdAqkB6wIoAiMCYAIbArEBGwJgAoUCYAKvAYUCrwFfAoUCXwIcAoUCHAIbAoUCGgKMAl8CXgIaAl8CFwKsAbABFwKwARICFwISAh0CEgJhAh0CEgJiAmECYgISAuYB5gFjAmIC/wK/AU8C1QLIAVICxgHBAcMBwgHBAcYB1AJcAVECXAHUAlICxAFQAlECzwJQAsQBygJPAr8B1QJTAsgBvwH/AsABvgFOAr8BTgLKAr8BTgK+AbwBvQG8Ab4BTQKDAfYCgwFNArwBSAJHAncCUwLNAcgB1gLNAVMC2AJUAs0BzQFUAs8B2ALNAdYCVALQAc8BVALRAdABgQLRAVUCVQLRAVQC0QGBAtMB2gJWAoEC1wGDAtkB1QHXAdkBVwLZAVgCWALZAYMCLQJwAi4CMALnAbcB8gLnATAC8gJrAucBdQK5AboBqwK5AXUCdQK6AfcBLgL3ASwCLgJwAvcB8gImAmsCKwItAi4CLAJsAioCLAL1AWwCLAL3AfUBKwIqAi0CuAG5ATACuAEwArcBFQJcAl0CMAK5ARYDFgO5AaoCqwKqArkBIAKsArsBrAI0AjcCuwGsAjcCNwI+AkACPgI3AjoCQgKzAvYCLQJEAnACcAJHAvcBcAJ3AkcCdwJwAkgC9wFHAnUCRwK8AnUCswHuAbIB7AFmAvAB5AGxAQ4CgAEgAkwBtgEgAoABtQHuAbQB7gG1AbYBtgF/Ae4BswG0Ae4B7wHsAfABfgF6Ae4BegGyAe4BfQF6AX4BfAF6AX0BewHyAe0BrwHsAXkBewHqAekB7QHqAXsB7wHxAewB7wHwAfEB8AHzAfIB8QHwAfIB9gHwAfQB8AH2AfMB9AH1AfYBuAH1AfcB9QG3AfYBtwH1AbgBuQG4AboBugG4AfcBIAK7AU0BTAEgAk0BNwJNAbsBjgGiAYwBkQGSAaUBpQEwAXQBpAGlAXQBowGRAaQBjwGRAaMBkAGPAaIBjgGQAaIBjgGMAY0BpAGRAaUBjwGjAaQBcAGiAY8BbwGiAXABogFuAYwBbgGiAW8BiwFuAaEB+wX8BQ0GTQE3AoEBBAJiATABBAIwAZIBkgEwAaUBYgEEAmMBqQGwAawBrQHoAQ8CrgGvAekBqQGuAekBqQHqAbAB6wGwAeoBqQHpAeoBsQEbAg8CDgKxAQ8CeQF7AekBeQHpAa8BjgHRAZABAALZAQEC1QHZAQACAAIBApEB1QEAApEB1wHVAZABjwHVAZEBkAHVAY8B0QHTAZAB0wHXAZAB0QHPAdABzwHRAY4BzwGOAY0BzQGNAYwBzQHPAY0BzQGMAYsBzQGLAaEBzQH7AcgBkQEEApIBBAKRAQEC3wHjAQQC3wEEAgEC4wFjAQQCsAHrARIC6wHqARIC5gESAu0BEgLqAe0B8gHmAe0B5gHyARMC8gHzARMC8wHmARMC9gG3AfMBtwHnAfMBzwKHAcMBgQE3AoIBQAKCATcCQAJCAoIB9gKDAfkBQgL2AvkB+AFCAvkBvAG9AVUBgwG8AVUBvgFVAb0BVQG+AYQBvgG/AYUBvgGFAYQBvwHAAYUBwAHBAYYBwgGGAcEBWQLXAdMBwwGHAcYBxgGHAVkBzwLEAYcBhwHEAYgBiAHEAVsBWwFRAlwBUQJbAcQBoAFSAokBUgKgAVwBwgHGAYYBhgHGAVkByAGJAVICyAGKAYkByAH7AYoBzQGhAfsBIgIOAwoD6gIRA8oDEQPqApoCKAIPA5sCDwMOA5sCmwIOAyICEAMRA48CEQOaAo8CTwMQA48CYQIQA08D5AINA5gClwINA+QClgIMA5cCDAMNA5cCUAMMA5UCCwMMA1ADCQOVApQCCQNQA5UCEgMQA2ECkwISA2ECDwMoAhQDFAMTAw8D6gJRA6ACUgOlAqACUQNSA6ACoQJ7AxQDoQKjAkADUQMVA1IDhwNTA6UChwOlAhUDFQOlAlIDqgJUAxYDFwMWA1QD2wJZAgQD3gJbAoQChAJaAt0C3QJaAlcCWALcAt0CWAJZAkkD2gJZAlYC2gIEA1kC2wIEA9oCqwJ1At8CSQNZAtsCWALdAlcC2QLaAoEC2AJVAlQC2AKBAlUC2QKBAtgCsgPYAtcCqgIXA1QDdQK8At8CBQOHAhkCBQMZAgYDBgMZAosCZQOKAk4DTgOMAmUDjQIGA4sCBwMGA40CjQKOAgoDkQKMApICkgKMApACkAKMAk4DkgJPA5ECYQJPA5ICCwNQAwkDoQPPAjUD1QKuA9YC1AIRBFIC1AJRAtEC0wLMAjUD0gLMAtMCOQM8A9EC0AKhA9ECoQM5A9ECrgPVAlICzwKhA9ACwAEzA8wCygIwAzMDMAPKAi4DxgIrA8oCKwMuA8oCKwPGAioDKgPGArUCQQOyA9YCQQPWAq4DsgPXAtYCsgNCA9gCQgPZAtgCtQPZAkIDtQNhA9oC2QK1A9oCYQNFA9oCRAPbAtoCRAPaAkUDRANJA9sCSQNHA1gCRwPcAlgCSQNIA0cDhwMaA1MDFwOqAt8C3wKqAqsCmQIYA6wCGAOZApgC0AOsAhgDrALQA60COgLVAz4C1QM6Aq8CswIZA7UCGQOzAj4CQAOjArgCQAO4AhoDGgO4AlMDUwO4AqMCGgMbA0AD1wLYAtYCVgPOAkoDVgNXA78CzgJWA78CIAMdA1gDWAMdA78CIANYA78CIAO/AlcDIgPfArwCIgO8Ah0DIgMdAyMDSgMmA1YDJgNKAyUDVgMmA1cD1wO1AhkD1wOZA7UCkgKQAh0ClwKzAR4ClgKXAh4CDAOWAh4ClQIMAx4ClAKVAqsBYQJiApMCkQJPA4wCYQKSAh0ClwLkArMBkAJOAx0CigIdAk4DHQKKAhcCjwLjAowC4wJfAowCTwOPAowCjgIbAhwCjQIbAo4C5AIfArMBHwLkApgCmAIgAh8CIAKZAqwCmQIgApgCIQKOAhwCjgIhAgoDIgIKAyEC5wLpAl8C4wLnAl8C4wKPAucC5wKaAukCmgLnAo8CIgIjApsCKAKbAiMCWgKEAuMB4AIVAhQChwJMAxQCTAPgAhQChgLgAkwDhgIVAuAChgJcAhUCWwLjAYQCWgLjAd8BiQKHAgAAWgLfAQECVwIBAtkBVwJaAgECWQJYAoMCVgJZAoEC1wFZAoMCWQLTAYEC6gIhAukCAACHAhYCFgKHAhQCiAIAABYCiQLhAocCFwKIAhYCiAIXAooChwLhAhkCGQLhAhgCGALhAhoC4gIaAokCiQIaAuECiQJlA+ICGgLiAowCjALiAmUDjQKLAhsC/AJIAvsC/gK8AU0CtQK8Af4CxgK8AbUC/gJNAvYC/AJHAkgC/AK/AkcC+wLOAvwCzgK/AvwC9gK1Av4C+wIDA84CAwNIAnAC+wJIAgMDHQNHAr8CHQO8AkcCSwIDA0QCAwNwAkQCLQJLAkQCvAHGAk4CygJOAsYCygL/Ak8CMwPAAf8CygIzA/8CwAHMAsEBNQPPAtMC0wLPAsMBzwLQAlAC0ALRAlACUALRAlEC0gLBAcwC0gLTAsEBwQHTAsMB1QLWAlMCLALvAqUC6QKaAuoC6gLrAiECnAISA5MCJgKcApMCnAImAhIDEgMmAqcC7wIoAqACKALvAhQD6wKgAigC6gKgAusCoAKlAu8CFAPvAioCFAMqAisCFAMrAqECLAIqAu8CiwGMAW4BoQIrAi4CoQIuAqMCUwOjAqUCpQKjAi4CpQIuAiwCpwImAvICFgPyAjACFgOnAvICNAKtAjcCrQI0AqwCNwKvAjoCrwI3Aq0CQAKzAkICswJAAj4CtQL2ArMCUQCDAFMAiQBxAC4AiQAuAC0AawCJAC0AhgDMAIcAzABTAIcAUwCIAFEATQBRAFIAUQBNAIAAcABKAHEAgwBRAIAAhgCHAFMAggCGAFMATwCGAIIAUACGAE8AgwB5AFMAggBTAHkATwCCAE4ASgBwAHQASgA/AC4AcQBKAC4ASgCKAD8AigBKAFQAVABVAIoAVQAvAIoAiwAwAC8AVQCLAC8AjAAxADAAiwCMADAAiwBWAIwAjABBADEAVgBCAEEAjABWAEEAcgB0AHUAeQCDAHoAdgB6AHcAegB2AHkAdwBIAHYASAB3AG4AbgBtAEgASABJAHYAdQB0AHAAbgB8AHQAbwByAHAAcgB1AHAAcwB0AHIAbABuAHIAbgBzAHIAcQBmAHAAZgBxAIkA0gBCAFcAcwBuAHQAdwB9AG4AbgB9AHwAfAB/AHQASgB0AEsASwB0AH8AfAB9AH8AdwB6AH0AgAB6AIMAegCAAH0ATAB/AH0ATAB9AE0ATABLAH8AgABNAH0ATgCCAHkATQBSAL0AwgDIANEAzgBTAM0AzgCIAFMAzADNAFMA0QBSAMUAxQBRAMIAxQBSAFEAUgDRAL0AxQDCANEAiADCAFEAnQCGAFAAnQBQAE8AvwCdAMAAwABPAL8AnQBPAMAAvwBPAE4AuwC/AHkAiADOAMIAwgDOAMgAnQCfAP0AywCGAP0A/QCGAJ0AhgDLAMwAywCpAMwA/QChAMsAoQCjAMsAowCpAMsAzQCnAM4AzACpAM0ApQDOAAABqgCnAM0ApwAAAc4AjgCPADMARwD6ALYAtwBHAGAAsABHALcA+gBHALAAXQCQADQAjwA0ADMArQA0AI8AWwA0AK0A+gCXALYAjgCNAI8AjQCtAI8AjQCOADMA0gCNADMA0gAzADIA0gAyAEIAVwBCAFYAbwBwAGYAlwD6AEgAtgCXAEcAmQBJAEgAmQBIAPoASQCZALkAuQCZALoAuQB2AEkAdgC5ALoAugCZALsAugB5AHYAeQC6ALsATAC8AEsAvABMAE0ATQC9ALwAvwBOAHkAEQAKABAAKAAXAAsAJwA3ACgANwAYACgARAAnAAsARAA3ACcAJgBEAAsAEgAKABEAEAAKAAkAJwAoAAsAHgAQAAgAHAAIAA8ACAAcAB4ABwAOAAgADgAPAAgABgAOAAcABQAOAAYADQAOAAUAOAAMABcAOAAXABgAGAAXACgAOABFAAwAGQANAAwAGQAMAEUAGQBGACkARgA9ACkAKQAOAA0AGQApAA0AGgAOAD0APQAOACkAGgAbAA4AHAAPAA4AHAAOABsA/AX7BV4GWwZcBloGXAZbBgUGWgYJBlAGCQZaBlwGTwZQBgkGTwb8BV4GTwYJBvwF+wXoBV4GWwYtBgUGkAVcBgoGXAYFBgoGkgWQBQoGXAaoBQkGXAaQBagFjgX8BagF/AUJBqgFHAAdACoAWgZQBl8GLQZbBmAGWwZhBmAG4gZaBl8G4wYbB9sG2wYcB/4GHAfbBhsHHAcmB/4GHAdAByYHDQAFAAIABgADAAUACAAQAAkADAACAAQAFwAMAAQADAANAAIALwAwACEAagBlAGcAZQBqAIUAMgAkAEIAIwBCACQAQQBCACMAMABBACIAQQAjACIAMAAxAEEAagA8ADsAigAvACEAigAhAEAAPwCKAEAAQAAhAD8ALgA/ACAALQAfAD4ALgAfAC0ALgAgAB8AhQBqADsAZwBrAGoAagBrADwARwBpAGAARwByAGkAcgBHAGwAbQCXAEgAlwBtAGwAlwBsAEcAbQBuAGwAaABvAGYAbwBoAGkAaQByAG8AZwCJAGsAiQBnAGYAIgAjABUAKgAeABwAHQAeACoAHgAfABEAHgARABAAIAASAB8AHwASABEAPwASACAAIQATABIAIQASAD8AIQAUABMAIQArABQAKwAVABQAIQAwACsAMAAiABUAMAAVACsAAgGpAKMAFQAjABYAJAAWACMAJgALACwAJQBDACwAQwAmACwAOwAbABoAPQA7ABoAPAAcABsAOwA8ABsAawAdABwAPABrABwAawAtAB0ALQAeAB0APgAfAB4ALQA+AB4AhgFYASEBXQE+AVwBXAE9AVsBPQFcAT4BhwE9ASQBIwFaASQBWgGHASQBWQFaASMBIQFYASIBWAFZASMBhQGGASEBnwGFASEBVwEhAW0BnwEhAVcBVgEgAdoAVgFtASABVwFtAVYBVAFVAVYBIgFYASMBXQElAT4BXgEmASUBXQFeASUBXwEnAV4BXgEnASYBYAEnAV8BYAEoAScBYQFuAWABYAFuASgBbgEpASgBcAEqASkBcAEpAW8BbwEpAW4BLQFzASsB/gBEAUUBQQEuAe0AKwEuAUEBQwEtAUQBQgEpAUMBLQFFAUQBLQErAUUBKwHvAEUBRAH+AEMBLAEuASsBKAEpAUIBQwH+AEIBQgHpACgB6QBCAf4AQAEoAekAJwEoAUABoQFuAWEBKwFxASwBSAHxAC4BLgHxAO0ASAHWAPEALwFIAS4BLwHzANYASAEvAdYAMQH1AC8BLwH1APMAMQEvATABTAEXARMBEwEXARUBFwFNAU8BTQEXAUwBTwGBARoBHAFSAVMBQgJTAYIBhAGfAVUBVgFVAVcBVAGDAVUBHgH5AVQB+QGDAVQB+QFTAfgBUwH5AR4BggFSARwBVQGfAVcB+AFTAUICggFTAVIBggEaAYEBGgGCARwBTwFNAYEB8QHyAXsB7AHxAXsBgAETAbYBhAGFAZ8BhQHAAYYBWgFZAYcBhwGIAVsBPQGHAVsBXQGgAV4BoAFdAVwBWAGGAVkBoAFfAV4BigFgAYkBiQFgAaABoAFgAV8B+wGhAWAB+wFgAYoBoQFhAWABMAFiAWMBcQErAXMBKQEqAUMBQwFyAS0BKgGPAUMBjwEqAXABQwGPAXIBcwEtAXIBjwGkAXMBcgGPAXMBpAF0AXMBcQEuASwBdAEvAS4BdAEuAXEBdAFxAXMBMAEvAXQBQQHtAOsAYwEzATEBMAFjATEBeQHsAXsBfAF9AWgBfQF+AWkBaAF9AWkBfgHuAWkB7gFqAWkB7gFKAWoB7gF/AZ4BSgHuAZ4BtgETAX8BfwETAZ4BngETAUoBEwGAAUwB5ADlAL8A1wCzANgAswDXALIAswC0ANgA2gCwAFYBsADaAPoA2wD6ANoA+gDbAPsA3gCZANsA2wCZAPsA+wCZAPoA3gDgAJkA4ADhAJkA4QAjAbsAmQDhALsAIwHkALsAsQBdANYAuwDkAL8A5gA/AZ0A5gCdAL8A5gC/AOUA/ACfAJ0APwH8AJ0A/AD9AJ8A/AAmAf0AJgHpAP0A/QDpAKEA6QD+AKEA/wACAaMA/wCjAP4AQQHqACsBAAGnAKoAyADOANEAqQCqAM0ASwBUAEoAzwBVALwAvABVAFQAvABUAEsAzwCLAFUAvADQAM8A0AC8AL0AzwDQAIsAvQBWAIsA0AC9AIsAvQDRAFYA0gBXANEA0QBXAFYAzgDTANEA/gCjAKEA0QDTANIAzgCrANMAqwDOAKUAqwAIAdQAqwCNANIA0wCrANIAqwDUAI0ACAGtAI0ACAGNANQArwDVAK0A1QBbAK0A1QA0AFsA1gBdADQA1QDWADQAsgDXALEAHgHyAFMB2wAhAd4AIQHbAG0B2gAgAdsAIAFtAdsA9ABUAVYBVAH0AB4B8gD0APYAUwHyABwB3gAhAeAAHgH0APIACgEcAfIAGgEcAQoBOwEaAfAATwEaATsBOwHwABcBqQABAaoAPQE+AeUA6gBBAesA7wArAeoAJgFAAekAJgEnAUABJgH8ACUBPgH8AD8BJQH8AD4BPgE/AeYAFwFPATsBPgHmAOUA5QAkAT0B5QAjASQBIwHlAOQA4QAhASMBIQEiASMB4AAhAeEAqgDtAAYBAgHvAOoARQH/AP4A/wBFAQIBCAHtAK0A7QCvAK0AqgDrAO0A7QAIAQYBAAGqAAYBFwHuAAQBpQAGAasABgEIAasAAAEGAaUA6gDrAKoA6gCqAAEBAgHqAAEBAQGpAAIB7wACAUUBFwEEARUBFQEEARMBEwEEAUoB1wDYABABDQGyALEA8wCxANYA8wANAbEA8QDVAAwB8QDWANUA7QAMAa8ADAHVAK8A7QDxAAwB', ao:'AE3o5+fo+Pf3uv/n6Oj//+n///D/8L/o6Ojo6Ono8PDw8PDb6Oijxujo6P/m4ODw8PDw79r/6Ofn6ODg4Ojn5+fw7+fo5+ismZfGuq+vp5mgla+fzM3b2+jo5wjn8OfayRC84//GvLyzsdLgnZCqs7rGpZm6uJKq/5mj56+g56+g542czOGjo5jN4ODo6Ojf04Ri/+eV75vvj/b3/6L4pfis75/ns+eU55SozN7oyui56Of39/ewu/+Pj5S6uOiXoueq5ueq5uCszNefmpGzutO64Mbo3/DX9uelnO//jO+Uj/D/i4uL//+nmr34y+iU7+fD573pyubv9rmijqWsmriUlvfw8LPw2Pbd3effu+Z6wvfo9+/v5+/vzu+/97n/l4eHlIuAoqK1qqCZtJjL5tfg/7RJ5uDf7+b35vePg4ensaWUoZ+59+bv8O/e0e/P7/e3v62Qn42Hh4OLk4OLn6K1eNGX5+fn///w9v+Xr7WgtJ+hv+/4//8A/wD////w37+9sIiUgIyPipuvpa+tmKCy1JDg5+fv6Ojv7/f38JeHp6WqtMeA5v8A//8ARQAAAEzx+PDw5wAAAADXp5mIiIB3d3eMSHdDjkl4TNG176qnn++Z8KBMleio6FrnWufRU+bv0Vf3AABMAAAAAADwAAAAAAAAAAAAt7Xvn+dHSFOo0U5R0UNFSlVOQ1pTSVdRTlwAACpJAAAfSwA+AAD/998AAABLOABSAEM1PgBCAE4ApU1S2OZgz+/w4OhjZtjgzFq74BXfTAAAU+cy97CZiJCTjpKXk5fLtJPRtk5JAAAoAAAANk45NzlFQgAsPkxOAFHnUFIAXwBcWk5VWlNTU06TU5fRAEkzAFkAUABIKgAAAAAA////////AAAAVUtKAABJAEYAVQBOVwAA7/Bd6MHv6MVVxeFaAOhY6ABd5wBi4N9V31ie5k33kFx7OgCEgJB3d46SmaKXk56X0dG0AEIAAAD/SE0ASwAAAFBQTgDo3wBmX+fBX05QRwAAWruIU1VSFYRQPGTv/03w//9LIwAAAE0bAAAA/9gAAAAATFIARgAAQg8AQ1hVta3o6K1XlFrvkOB3399YjN9jkF3fUACnlF6bi12vwZ8XXFDgAAD/AAAAAFcAAACjZO/hYmRaUpNNJ+AA5+e46JmveIeDqKivr7Gz6O9uYHWsODokAAAATU/m8FIAAO9aAOhQWOcAAODmAF/gY11s3mJkpRyfl2CEWIxYWFibTQCUAE1VnhybY5xcnIt1lpSTstHgnGdsabjw6O/3AEoAAABa6FoAX/fnbPf36fDpAF0IAADnquaY54fgrM+xrLjIsXiETQAA4OgAXE9PYgAXAFpY8NvFv1+vZr1wbHCPXG10lHSXnmbimfeg95ycM+ic7+dVj1K3YMG5lZXSseC64JWqjuao1LbDrLjD29vDz89bbs1YnHGxbLjoAHiaAM+ftOCNkmy8eKazs8va2gAAAAAAAAAAEABY6V52x1qXX6WfgLeXcLJ7onh7dKp4m26fokC9zvcA4V3v92MXlJHIrKzUzcO+v6G44OkA8C3DanAXYGAeAGOKGBGflaP38Nfp73CEALYAAAAAAAAAAADg8OHf1qevtGO/XntqtF5sqHunnHZ7rXuE0nzSjODg94T/eHNdAHFmeISo58Pa4MnB6OJ2lOBzgzAnUKOHkLkAAMGox5zH19cA4OffxbW7v3ONqICHra97rYCItaeMooiQiPfnhPBGS3ijobzH4K97r3cAYoSEbXhgAE+cn5J8sm5tfHzFnHyZ5uEAQN/L2ODMubu/tK+3l6WZrbWEtceQz9GQ2pDg9/fmcJ0AAACo57yxySTa1My7+GyQgGNqnKDBI+Z1fNrY37Wg0bW0t6+1ta/F1+CXiO+M5oSIhJCVcYSqaLLWa7+H1r/Kv78k3w+M94iQgIiMkJmbooyPk5+ArNas2DPFQHB1tXyzubK1r7W7t7/Y4O/n79jYudrXz0Xfube5s7TgmZSQkJ6il4faorXFu6qnoqe3t729vc/v5vfa2Ket58/BzreylOeU14BgooyU5qWcoqKioqWqk5+019HPvcGlla23t73D39bg0tjU3r2nmaKioqWyspu5x87W0aWZqre9vb29vcXFxdfP5ub30tPf37XDoqy/va+i6NLJkICX2LmthJCcqrKlt8W1vcHBz9eytcW9zs7Ozs7Ozvb39/DL2LK396KioqKtsLK1v8/JqMO3w87O1+ff39LRmcO8rLbL34vO32yIrbKysrK3v9bWvbzKw8POzM7Ozs7O7+Lfv8PR2L+lsrW1v8fF3cXFu8W1zNfv9/f//9LRv8vedrLD39/f13p2hICirbWyvb29vb3Lx8XFzMzMzM7O3+b3/9uEiYDoz8PDra2vvb3Xxb/WzsXMzs7X1u/39/C/z16Q4N/Pz8ne4N+snK29v7/Uz8/P19bMzt/n78/v79ff98/Dw8ONw73HvcnDz8fPz87Xzv/v4drXw/fXz8vm39jm2M/X3t/u3+fo4eHv3+jw7/Dv9///8ODw3+DXz9GErdbW3e/u7u//8M/P1ujn18/D3tFAz97m5+bm3+/v8Oj39/fw8OfP0dfJ/+jPyRyq5ubm5u/n9/f38PDw8PDn58PJ//fo58/P59HW3ubY2N7o5u/f3+fn5+fw8PDo59LLy9/w8Ojn5+ff1u/v5+fn6Ojp6Ojo5+jh4efg5+fg5+fn8Ojo6Ojo5+fn5+fR0d3e39/m5t/mz92AQh2y5+/v6Ojn5+jo6Ojo6Ojh4eCS5+jo6OHo5+jvqufn7+jo6PDjwefv6Ojo6PDo8Ofm5ubm6OjgqvDw8PDw6MF8zfDw8L/U6PDb29vo6L/p3mLD6Oi46CBYLJjb', at:'///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+/////////////////////////////////////f/////////////////////////////////////////////////////////////////////6//n///3///////////////////////////////////////////////////z////////////////////////////////////////////08fH25////////////////v////////////////////////////////////////////////////////7/6f///9L/3P/M/+7///r8/////////////////////////////////9f///////////////////////////////////////////////////////////////////////////7///7i/+T///+r////v//i//////v///////////////////////////////////////////////////+2///////////////////////////////////////////////////////////////////////////////9///9/f///93//63/i///ev//kaj/z///5v////////////////////////////////////////////////////+XoP////D////////////////////////+///////////////////////////////////////////+//+dbP////5U/2H/ma7//7j////k///////////////////////////////////b/9ul////////////3vT//P//////////////////////////////8/7bnP///1j//y7+0Fr//3qV//yp////////////////////////////////////9f/////////////////////////////////+nPX/7f////////////////9N/1//cv+l/83/////////////////+/H/8f///+Oy/////9j/5f/i//////////////9U/xr/G////yn/Gir/////////9dz/3f/k/////8H/4f//////7//6/////f////////8//9O////9/2D/lP+T//////////////////////+o/+Te/6D/s///rP///f///////////////////wH/MP//////of+l//+N/8PH////////Bf/d//////////9e//////8AAP8HCv///1j//////////////////////4//sXKU/9+9/6v//31N//////////////////+L/0pvi///HP9IWf9q///b////NP///zUf/////wD/Fv///////////////3hb/45A//+b/8b//////////////////0L///81//+5/9X///////////8S//8U/xT/NQ0N/wkO//////8AAf//////////FP8d//////////////////////////8AAP//////////////////////AP8AAP///wAA//////////////8EP/8f/7n3////////AAT//wAD//////////84/0ZWbOz///////////////8A/wD/AAAA/wAA/////////////////////////wD/////AP//of3/////////AP///////////////////////wAA////////AP87////AKF0/wb/////////////////////////////////////////Xbzw/P///////////////////////////////////////wAA////////////AAEA/wAAG2mc/v///////////////////////////////////////yZnlsHY////////////////////////Z/////////////8WkO3//P////////////////////////////////9rx/3/////////////////////////////AP///////wAAAAABmp/Rs+//+f////////////////////8AAAb/////AD5f0vXt/f///////////////////wAA////////////AERnwOX///////////////////////////8AAAAAByo2P21rmr3y///////////////18//y/P8ApsW31+bu9fr2//78//////////////////8AAA0fQ3Glts7///P6df///v343e4AAQEUMURbW6GimMrMzuL////o2uS/+v/u0gAABRFOUVOQl37Hk6fTytXD5ZuqxeXs8rnY2q6u4Fw5MJQAAAAPEy1DTFhrcIerg3phhACCod7Av6mWAAABAQcFCx02LjxfV1ZUWy8AAAIoISpDRFV0gXGlhnSJdY5jVDMXOwgAAABQOHkqmVsTAAAAAAABBQwGHBohNSIlMAAADwwWIDhBNz4AAAAAAAMGBgEHAAEAAggXCBINAxECAAMAG0wWAAAAAAABAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAACwEGAAAA'};

/* The four places on the ear mesh that the ear marks name: top of the
   helix, bottom of the lobe, the most posterior point of the helix, and the
   helix root at the front. Found once from the stored mesh, among vertices
   standing at least 0.03 W off the skin. */
/* A 5 by 5 linear solve, Gaussian elimination with partial pivoting. */

function solveLin5(A, b){
  const n = b.length, M = A.map((r,i) => [...r, b[i]]);
  for (let c=0;c<n;c++){
    let p = c; for (let r=c+1;r<n;r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    if (Math.abs(M[p][c]) < 1e-18) return null;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r=0;r<n;r++){ if (r===c) continue; const f = M[r][c]/M[c][c]; for (let k=c;k<=n;k++) M[r][k] -= f*M[c][k]; }
  }
  return M.map((r,i) => r[n]/r[i]);
}

function earFeatureIdx(){
  const { V, AT } = earMeshData();
  let top=-1, bot=-1, back=-1, front=-1;
  for (let k=0;k<V.length/3;k++){
    const h=V[3*k], up=V[3*k+1], bk=V[3*k+2];
    /* The front mark is the top of the ear's attachment to the head in
       front, the otobasion superius (v36): the highest vertex of the strip
       laid on the skin. It used to be the helix root over the tragus, which
       is hard to see under hair and sat 15 mm lower than where marks on five
       test faces were actually placed. */
    if (AT[k] < 0.3 && h < 0.02 && (front < 0 || up > V[3*front+1])) front = k;
    if (h < 0.03) continue;
    if (top  < 0 || up > V[3*top+1])  top = k;
    if (bot  < 0 || up < V[3*bot+1])  bot = k;
    if (back < 0 || bk > V[3*back+2]) back = k;
  }
  return { Top:top, Bot:bot, Back:back, Front:front };
}

let EAR_MESH_DATA = null;

function earMeshData(){
  if (EAR_MESH_DATA) return EAR_MESH_DATA;
  const dec = s => { const b = atob(s), u = new Uint8Array(b.length);
                     for (let i=0;i<b.length;i++) u[i] = b.charCodeAt(i); return u; };
  const vb = dec(EAR_MESH.v), fb = dec(EAR_MESH.f), ab = dec(EAR_MESH.ao);
  const dv = new DataView(vb.buffer), df = new DataView(fb.buffer);
  const V = new Float32Array(EAR_MESH.n*3);
  for (let i=0;i<V.length;i++) V[i] = dv.getInt16(2*i, true)/EAR_MESH.q;
  const F = new Uint16Array(EAR_MESH.t*3);
  for (let i=0;i<F.length;i++) F[i] = df.getUint16(2*i, true);
  const AO = new Float32Array(EAR_MESH.n), AT = new Float32Array(EAR_MESH.n);
  const tb = EAR_MESH.at ? dec(EAR_MESH.at) : null;
  for (let i=0;i<AO.length;i++){ AO[i] = ab[i]/255; AT[i] = tb ? tb[i]/255 : 1; }
  return (EAR_MESH_DATA = { V, F, AO, AT });
}

function shellRadiusSampler(r, nT, nP){
  return (dx, dy, dz) => {
    let th = Math.atan2(dx, dz); if (th < 0) th += 2*Math.PI;
    const ph = Math.acos(Math.max(-1, Math.min(1, dy)));
    const fi = th/(2*Math.PI)*nT - 0.5;
    const fj = Math.max(0, Math.min(nP-1.001, ph/Math.PI*nP - 0.5));
    const i0 = Math.floor(fi), j0 = Math.floor(fj), ti = fi-i0, tj = fj-j0;
    const I0 = ((i0%nT)+nT)%nT, I1 = (I0+1)%nT;
    const a = r[j0*nT+I0], b = r[j0*nT+I1], c = r[(j0+1)*nT+I0], d = r[(j0+1)*nT+I1];
    return (a*(1-ti)+b*ti)*(1-tj) + (c*(1-ti)+d*ti)*tj;
  };
}

const EAR_PAINT = 'tone';

const EAR_SKIN_MIX = 0.35;

const srgbToLinear = c => c <= 0.04045 ? c/12.92 : Math.pow((c+0.055)/1.055, 2.4);

function earColours(src, pos, AO, mode, AT){
  const n = AO.length, col = new Float32Array(n*3);
  // The fallback, and the base the photograph is read against: the skin tone
  // measured off the front photograph.
  const st = new THREE.Color(skinToneFromFront());      // already linear
  let tint = [st.r, st.g, st.b], per = null, front = null;
  if (src && src.photo && src.photo.img){
    const img = src.photo.img;
    /* Low frequency by construction: the photograph is drawn small enough that
       one pixel is several millimetres of ear. The concha shadow, the helix
       highlight and a stray hair all average into the local colour, which is
       what survives a donor ear whose ridges are not where the patient's are. */
    const sample = Wc => {
      const Hc = Math.max(1, Math.round(Wc*img.naturalHeight/img.naturalWidth));
      const cv = document.createElement('canvas'); cv.width=Wc; cv.height=Hc;
      const g2 = cv.getContext('2d', { willReadFrequently:true });
      g2.drawImage(img, 0, 0, Wc, Hc);
      const px = g2.getImageData(0,0,Wc,Hc).data;
      const v3 = new THREE.Vector3();
      const samp = new Float32Array(n*3), okv = new Uint8Array(n);
      for (let k=0;k<n;k++){
        v3.set(pos[3*k], pos[3*k+1], pos[3*k+2]).project(src.cam);
        const u = v3.x*0.5+0.5, v = 0.5-v3.y*0.5;
        if (!(v3.z < 1 && u >= 0 && u < 1 && v >= 0 && v < 1)) continue;
        const x = Math.min(Wc-1, Math.floor(u*Wc)), y = Math.min(Hc-1, Math.floor(v*Hc));
        const i = 4*(y*Wc+x);
        samp[3*k] = srgbToLinear(px[i]/255); samp[3*k+1] = srgbToLinear(px[i+1]/255);
        samp[3*k+2] = srgbToLinear(px[i+2]/255); okv[k] = 1;
      }
      return { samp, okv };
    };
    const { samp, okv } = sample(mode === 'photo' ? 900 : 72);
    /* The strip where the ear's front is laid onto the cheek is SKIN, and the
       head beside it is painted from these same photographs at about this
       resolution. Taking its colour from the photograph there, and fading to
       the ear's own tone over the attachment falloff, leaves no line where the
       ear mesh stops and the head's texture begins. */
    front = AT ? sample(480) : null;
    // The ear's own colour: the median of what the camera saw on it, with hair
    // and deep shadow (well under the median brightness) left out.
    const lum = k => 0.2126*samp[3*k] + 0.7152*samp[3*k+1] + 0.0722*samp[3*k+2];
    const ls = []; for (let k=0;k<n;k++) if (okv[k]) ls.push(lum(k));
    if (ls.length > n*0.5){
      ls.sort((a,b)=>a-b);
      const lm = ls[ls.length>>1];
      const rs=[], gs=[], bs=[];
      for (let k=0;k<n;k++) if (okv[k] && lum(k) > 0.55*lm && lum(k) < 1.8*lm){
        rs.push(samp[3*k]); gs.push(samp[3*k+1]); bs.push(samp[3*k+2]); }
      const med = a => { a.sort((x,y)=>x-y); return a[a.length>>1]; };
      if (rs.length > 30) tint = [med(rs), med(gs), med(bs)];
      per = { samp, okv, lm };
    }
    /* Pull the ear's tone part of the way to the cheek's. The ear in the
       photograph is pinker and lighter than the skin in front of it, which is
       true of ears, but in the render the cheek carries the photograph's own
       shading and the ear carries the scene's on top of its tone, so the ear
       came out a shade lighter than the eye accepts as the same skin. The
       skin is read where the ear's front lies on the cheek. */
    if (front){
      const rs=[], gs=[], bs=[];
      for (let k=0;k<n;k++) if (front.okv[k] && AT[k] < 0.3){
        rs.push(front.samp[3*k]); gs.push(front.samp[3*k+1]); bs.push(front.samp[3*k+2]); }
      const med = a => { a.sort((x,y)=>x-y); return a[a.length>>1]; };
      if (rs.length > 20){
        const sk = [med(rs), med(gs), med(bs)];
        tint = tint.map((x,q) => (1-EAR_SKIN_MIX)*x + EAR_SKIN_MIX*sk[q]);
      }
    }
  }
  for (let k=0;k<n;k++){
    const ao = Math.pow(Math.max(0, AO[k]), 0.8);
    let c;
    if (mode === 'photo' && per && per.okv[k]){
      c = [per.samp[3*k], per.samp[3*k+1], per.samp[3*k+2]];
      const s = 0.80 + 0.20*ao;
      c = c.map(x => x*s);
    } else {
      // A little of the photograph's own light and shade, never its detail.
      let f = 1;
      if (per && per.okv[k]){
        const l = 0.2126*per.samp[3*k] + 0.7152*per.samp[3*k+1] + 0.0722*per.samp[3*k+2];
        f = Math.max(0.85, Math.min(1.15, l/Math.max(1e-4, per.lm)));
      }
      const s = (0.42 + 0.58*ao) * f;
      c = tint.map(x => x*s);
    }
    if (front && front.okv[k] && AT[k] < 1){
      const t = AT[k]*AT[k]*(3 - 2*AT[k]);
      for (let q=0;q<3;q++) c[q] = t*c[q] + (1-t)*front.samp[3*k+q];
    }
    col[3*k] = c[0]; col[3*k+1] = c[1]; col[3*k+2] = c[2];
  }
  return col;
}

function dropEarMeshes(mesh){
  for (const c of [...mesh.children]) if (c.userData && c.userData.isEarMesh){
    mesh.remove(c); c.geometry.dispose(); c.material.dispose();
  }
}

function buildEarMeshes(ears, rShell, centre, nT, nP, W, H, earSrc){
  const { V, F, AO, AT } = earMeshData();
  const R = shellRadiusSampler(rShell, nT, nP);
  const lateralAt = (y, z, sx) => {
    const dy = y-centre[1], dz = z-centre[2];
    let rho = 0.5*W;
    for (let it=0; it<6; it++){
      const L = Math.hypot(rho, dy, dz) || 1;
      const Rr = R(sx*rho/L, dy/L, dz/L);
      const q = Rr*Rr - dy*dy - dz*dz;
      rho = q > 0 ? Math.sqrt(q) : rho*0.9;
    }
    return centre[0] + sx*rho;
  };
  const out = [];
  for (const side of ['R','L']){
    const e = ears[side]; if (!e) continue;
    const yc = (e.yBot + e.yTop)/2;
    const sUp = e.height/(2*EAR_HALF_H*H);
    /* A helix mark sets depth against the standard outline's reach,
       EAR_BACK_MAX. The donor reaches EAR_MESH.back, so a marked ear is scaled
       to put the donor's own helix on the mark. Unmarked, it keeps its shape. */
    const sBk = e.markedDepth ? e.depth*EAR_BACK_MAX/EAR_MESH.back : 1;
    /* How far the ear stands off the head, as a factor on h. A ¾ or front
       photograph sees it plainly and the image fit reads it; a lateral does
       not, and leaves it at one. */
    const sH  = 0.5*(sUp + sBk) * (isFinite(e.flare) ? e.flare : 1);
    /* The same backward lean earShape gives the standard ear, top posterior,
       plus whatever forward lean the donor's own scan pose left in it. */
    const shear = Math.tan(EAR_TILT + (EAR_MESH.lean||0)*Math.PI/180);
    const n = V.length/3;
    const pos = new Float32Array(n*3), baseX = new Float32Array(n);
    for (let k=0;k<n;k++){
      const h = V[3*k], up = V[3*k+1], bk = V[3*k+2];
      const y = yc + up*H*sUp, z = e.attachZ - bk*W*sBk - (y - yc)*shear;
      baseX[k] = lateralAt(y, z, e.sx);
      pos[3*k]   = baseX[k] + e.sx*h*W*sH;
      pos[3*k+1] = y;
      pos[3*k+2] = z;
    }
    // (h, up, back) to (x, y, z) has determinant of sign -sx, so one side is a
    // mirror image and its winding turns round with it.
    const idx = new Uint16Array(F);
    if (e.sx > 0) for (let t=0;t<idx.length;t+=3){ const s=idx[t+1]; idx[t+1]=idx[t+2]; idx[t+2]=s; }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    g.computeVertexNormals();
    /* Shade the root as skin. Where the ear's front lies on the cheek its own
       normals follow the donor's surface, the head's follow the shell, and the
       two disagree by enough to draw a lighting crease along the join. Across
       the attachment falloff the ear's normal is turned toward the head's,
       found from the slope of the head surface under the vertex. */
    {
      const nrm = g.attributes.normal.array, eps = 0.01*W;
      for (let k=0;k<n;k++){
        const t = AT[k]; if (!(t < 1)) continue;
        const y = pos[3*k+1], z = pos[3*k+2];
        const fy = (lateralAt(y+eps, z, e.sx) - lateralAt(y-eps, z, e.sx))/(2*eps);
        const fz = (lateralAt(y, z+eps, e.sx) - lateralAt(y, z-eps, e.sx))/(2*eps);
        let sx_ = e.sx, sy_ = -e.sx*fy, sz_ = -e.sx*fz;
        const L = Math.hypot(sx_, sy_, sz_) || 1; sx_/=L; sy_/=L; sz_/=L;
        const w = t*t*(3 - 2*t);
        let ax = w*nrm[3*k] + (1-w)*sx_, ay = w*nrm[3*k+1] + (1-w)*sy_, az = w*nrm[3*k+2] + (1-w)*sz_;
        const M = Math.hypot(ax, ay, az) || 1;
        nrm[3*k] = ax/M; nrm[3*k+1] = ay/M; nrm[3*k+2] = az/M;
      }
      g.attributes.normal.needsUpdate = true;
    }
    g.setAttribute('color', new THREE.BufferAttribute(earColours(earSrc && earSrc[side], pos, AO, EAR_PAINT, AT), 3));
    /* Both sides drawn: the scanner never saw the back of an ear, so the mesh
       is one sheet, and culling its back would leave holes in the rim wherever
       the helix curls away from the camera. polygonOffset settles the few
       places the ear lies within a hair of the skin in the ear's favour. */
    const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({
      vertexColors:true, roughness:0.72, metalness:0, side:THREE.DoubleSide,
      polygonOffset:true, polygonOffsetFactor:-1, polygonOffsetUnits:-2 }));
    m.name = 'ear'+side;
    m.userData.isEarMesh = true; m.userData.side = side;
    m.userData.baseX = baseX;             // the head surface under each vertex, for the image fit
    // Everything the image fit needs to predict exactly where a rebuild with
    // new numbers would put each vertex (v36).
    m.userData.place = { lateralAt, sUp, sBk, sH, shear, yc, sx:e.sx, flare: isFinite(e.flare) ? e.flare : 1 };
    /* Both sides only while the camera is on this ear's side of the head, or
       close behind it. With the scalp above the hairline left empty, the ear
       on the FAR side is in plain view through the top of the head, and drawn
       double sided its back came up over the crown as a loose flap of skin.
       From the far side a single sheet facing away is simply not drawn. */
    const cx = centre[0], lim = -0.15*W, v4 = new THREE.Vector3();
    m.onBeforeRender = (r, sc, cam) => {
      v4.setFromMatrixPosition(cam.matrixWorld);
      m.worldToLocal(v4);
      const want = (v4.x - cx)*e.sx > lim ? THREE.DoubleSide : THREE.FrontSide;
      if (m.material.side !== want){ m.material.side = want; m.material.needsUpdate = true; }
    };
    out.push(m);
  }
  return out;
}

function canonicalHeadField(centre, earFit){
  const tR = S.lm3[234], tL = S.lm3[454];
  const W = Math.hypot(tR[0]-tL[0], tR[1]-tL[1], tR[2]-tL[2]) || 1;
  const y10 = S.lm3[10][1], y152 = S.lm3[152][1];
  const H = Math.abs(y10 - y152) || 1;
  const cx = centre[0], cy = centre[1], cz = centre[2];
  // Crown ≈ 30% of visible face height above the upper-forehead landmark —
  // the standard menton-to-vertex proportion.
  const crown = y152 + 1.32*H;
  const neckFloor = y152 - 0.75*H;          // nothing exists below this — see cutY
  // Ear ellipsoids, resolved once — the march tests them, and the shell attach
  // reuses them to find which quads ARE the ear (for the photo projection).
  // The ear, built from the measured tables rather than as an ellipsoid on the
  // cheek. Marked extremes still scale it — see HB_DEFS and earShape.
  const ears = {};
  for (const [t, side] of [[tR,'R'], [tL,'L']]){
    const sx = Math.sign(t[0]-cx) || 1;
    ears[side] = earShape(t, sx, W, H, earFit && earFit[side]);
  }
  /* The head is now one measured radius field rather than five ellipsoids —
     see the note above HEAD_R. Heights are measured from the tragion midpoint,
     which is where the scans were measured from and which sits at a very
     steady y152 + 0.609 H (sd 0.014 over 26 heads).

     The table runs out at the crown, so the last stretch is tapered to a
     rounded close instead of ending in a disc. Everything up there is under
     the hairline mask and renders black, but a silhouette is still a
     silhouette. */
  const earY  = (tR[1]+tL[1])/2;
  const yCrown = (crown - earY)/H;
  const CAP = 0.12;
  const inside = p => {
    if (p[1] < neckFloor) return false;
    const yy = (p[1] - earY)/H;
    if (yy <= yCrown){
      const dx = p[0]-cx, dz = p[2]-cz;
      let R = headRadiusAt(Math.atan2(dx, dz), yy) * W;
      if (yy > yCrown - CAP){
        const u = (yy - (yCrown - CAP))/CAP;
        R *= Math.sqrt(Math.max(0, 1 - u*u));
      }
      if (dx*dx + dz*dz <= R*R) return true;
    }
    // No ears in the head solid any more (v32): they are meshes of their own,
    // set onto this surface afterwards. `ears` stays, for their placement.
    return false;
  };
  const nT = HULL.nTheta, nP = HULL.nPhi;
  const rad = new Float32Array(nT*nP);
  const rMax = Math.max(1.7*H, 1.4*W);
  for (let j=0;j<nP;j++){
    const phi = (j+0.5)/nP*Math.PI, sp = Math.sin(phi), cp = Math.cos(phi);
    for (let i=0;i<nT;i++){
      const th = (i+0.5)/nT*Math.PI*2;
      const dx = sp*Math.sin(th), dy = cp, dz = sp*Math.cos(th);
      let r = 0;
      /* Outermost surface along the ray — walked from outside in, so an ear
         standing proud of the skull is the answer, not the skull behind it.

         Then BISECT. The coarse walk takes rMax/80 per step, which on a real
         head is 3.1 mm of radius, and it returns the first sample that happens
         to land inside rather than the surface itself. Against a 1600-step
         march the field that gave was 1.62 mm RMS out and 3.23 mm at worst,
         and the eighteen blur passes downstream were quietly hiding a
         staircase. Five halvings between the last outside sample and the first
         inside one bring that under a tenth of a millimetre for five extra
         `inside` calls per direction, which is nothing next to the 80 already
         spent. */
      for (let m=HULL.march; m>=1; m--){
        const rr = rMax*m/HULL.march;
        if (inside([cx+dx*rr, cy+dy*rr, cz+dz*rr])){
          let lo = rr, hi = rMax*(m+1)/HULL.march;       // inside, outside
          for (let b=0;b<5;b++){
            const mid = (lo+hi)/2;
            if (inside([cx+dx*mid, cy+dy*mid, cz+dz*mid])) lo = mid; else hi = mid;
          }
          r = lo;
          break;
        }
      }
      rad[j*nT+i] = r;
    }
  }
  return { rad: smoothRadii(rad, nT, nP, 2), W, H, y152, crown, ears };
}

function hairAt(a, y, P){
  if (a > 2.05) return true;                                  // behind the ears
  /* Both coefficient pairs were widened in v26, keeping the middle of each
     slider exactly where it already was. The estimate below measures a real
     hairline off a real photograph, and a range spanning only 1.04 to 1.36
     face-heights clamps a genuinely low hairline against its own stop and then
     reports the stop as the answer. Same value at the default, more room on
     either side of it. */
  const base = P.y152 + (0.98 + 0.42*P.hairH)*P.H;            // frontal hairline
  const dip  = Math.exp(-(((a-1.15)/0.45)**2)) * (0.02 + 0.49*P.temple)*P.H;
  return y > base - dip;
}

function estimateHairline(){
  try {
    const front = S.photos.find(p=>p.id===S.frontId);
    if (!front || !front.img || !S.rawLm || !S.lm3) return null;
    const W = 400, img = front.img;
    const H = Math.max(1, Math.round(W * img.naturalHeight / img.naturalWidth));
    const c = document.createElement('canvas'); c.width=W; c.height=H;
    const g = c.getContext('2d', { willReadFrequently:true });
    g.drawImage(img, 0, 0, W, H);
    const d = g.getImageData(0,0,W,H).data;
    const lum = (x,y) => {
      x = Math.min(W-1, Math.max(0, x|0)); y = Math.min(H-1, Math.max(0, y|0));
      const i = 4*(y*W+x);
      return 0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2];
    };
    // Median of a short horizontal run, so a single dark hair or a highlight
    // does not decide anything.
    const rowLum = (x,y) => {
      const v = [];
      for (let k=-3;k<=3;k++) v.push(lum(x+k, y));
      v.sort((a,b)=>a-b); return v[3];
    };
    /* Walk up from `y0` until the brightness drops and stays down. The
       threshold is relative to this face's own forehead, not absolute, so it
       survives any exposure. */
    const edgeAbove = (x, y0) => {
      const skin = [];
      for (let k=0;k<10;k++) skin.push(rowLum(x, y0 + k*2));
      skin.sort((a,b)=>a-b);
      const ref = skin[5];
      if (!(ref > 20)) return null;                 // forehead is in shadow
      const cut = ref*0.62;
      const limit = Math.max(0, y0 - H*0.35);
      let run = 0;
      for (let y=y0; y>=limit; y--){
        if (rowLum(x,y) < cut){ if (++run >= 4) return y + 3; }
        else run = 0;
      }
      return null;
    };
    const px = i => [S.rawLm[i].x*W, S.rawLm[i].y*H];
    const [x10, y10] = px(10);
    const midY = edgeAbove(x10, y10);
    if (midY === null) return null;
    // Image y to model y, read off two landmarks that span the face.
    const iy10 = S.rawLm[10].y*H, iy152 = S.rawLm[152].y*H;
    const my10 = S.lm3[10][1],    my152 = S.lm3[152][1];
    const den = (iy152 - iy10) || 1;
    const toModelY = iy => my10 + (iy - iy10)*(my152 - my10)/den;
    const faceH = Math.abs(my10 - my152) || 1;
    const base = toModelY(midY);
    let hairH = ((base - my152)/faceH - 0.98)/0.42;
    // The temple, averaged over both sides when both can be read.
    const temples = [];
    for (const id of [21, 251]){
      if (!S.rawLm[id]) continue;
      const [tx, ty] = px(id);
      const e = edgeAbove(tx, ty);
      if (e === null) continue;
      temples.push(((base - toModelY(e))/faceH - 0.02)/0.49);
    }
    const temple = temples.length ? temples.reduce((a,b)=>a+b,0)/temples.length : null;
    const clamp = v => Math.min(1, Math.max(0, v));
    return {
      hairH: clamp(hairH),
      temple: temple === null ? null : clamp(temple),
      raw: { hairH, temple },
      clamped: hairH < 0 || hairH > 1 || (temple !== null && (temple < 0 || temple > 1)),
    };
  } catch (e){ return null; }
}

function skinToneFromFront(){
  try {
    const front = S.photos.find(p=>p.id===S.frontId);
    if (!front || !front.img || !S.rawLm) return 0xc9a189;
    const c = document.createElement('canvas'); c.width=64; c.height=64;
    const g = c.getContext('2d', { willReadFrequently:true });
    g.drawImage(front.img, 0, 0, 64, 64);
    const d = g.getImageData(0,0,64,64).data;
    let r=0,gg=0,b=0,n=0;
    for (const id of [50, 280, 101, 330, 205, 425]){          // mid-cheek landmarks
      const lm = S.rawLm[id]; if (!lm) continue;
      const x = Math.min(63, Math.max(0, Math.round(lm.x*63)));
      const y = Math.min(63, Math.max(0, Math.round(lm.y*63)));
      const i = (y*64+x)*4;
      r+=d[i]; gg+=d[i+1]; b+=d[i+2]; n++;
    }
    if (!n) return 0xc9a189;
    return (Math.round(r/n)<<16) | (Math.round(gg/n)<<8) | Math.round(b/n);
  } catch { return 0xc9a189; }
}

function attachCanonicalShell(opts){
  const mesh = targets[0];
  if (!mesh || !S.lm3) return { ok:false, why:'no photo-built face to extend' };
  if (!S.faceBase) return { ok:false, why:'no pristine face captured' };
  const hairH  = opts && isFinite(opts.hairH)  ? opts.hairH  : CANON.hairH;
  const temple = opts && isFinite(opts.temple) ? opts.temple : CANON.temple;

  const tR = S.lm3[234], tL = S.lm3[454];
  const centre = [ (tR[0]+tL[0])/2, (tR[1]+tL[1])/2, (tR[2]+tL[2])/2 ];
  const field = canonicalHeadField(centre, opts && opts.earFit);
  const nT = HULL.nTheta, nP = HULL.nPhi;

  const fpos = S.faceBase.pos;
  const fidx = S.faceBase.idx;
  const faceR = faceRadiusGrid(fpos, fidx, centre, nT, nP);
  const faceH = Math.abs(S.lm3[10][1] - S.lm3[152][1]) || 1;
  const cutY = S.lm3[152][1] - 0.6*faceH;
  const { pos:spos, idx:sidx, uv:suv, r:rShell } = shellGeometry(field.rad, faceR, nT, nP, centre, cutY, field.ears);
  if (!sidx.length) return { ok:false, why:'the head shape left no surface outside the face' };

  /* The fringe ring is trimmed FROM THE TEXTURE, NOT FROM THE MESH (v25).

     Dropping these triangles outright is what put a black tear down the middle
     of the cheek in the field. It leaves a ring-shaped hole between the face
     patch and the shell, and wherever the canonical shell deviates from a real
     face — which is everywhere on a real face — the hole gapes and you see
     straight into the dark inside of the head. On the synthetic test heads the
     slit is hairline-thin, which is exactly why twenty suites never saw it.

     The original complaint was never the geometry. It was that these boundary
     triangles carry stretched UVs and read as dark spikes. So keep the
     geometry and take away the texture: they go into the SKIN group, plain
     skin-toned — the same buffer this code already insists on around the whole
     face rim to keep the dark scalp off it. A skin-coloured ragged edge is
     invisible at a glance. A hole is not. */
  const edgeUse = new Map();
  for (let t=0; t<fidx.length; t+=3){
    for (const [a,b] of [[fidx[t],fidx[t+1]],[fidx[t+1],fidx[t+2]],[fidx[t+2],fidx[t]]]){
      const k = Math.min(a,b)*100000 + Math.max(a,b);
      edgeUse.set(k, (edgeUse.get(k)||0)+1);
    }
  }
  const rim = new Set();
  for (let t=0; t<fidx.length; t+=3){
    for (const [a,b] of [[fidx[t],fidx[t+1]],[fidx[t+1],fidx[t+2]],[fidx[t+2],fidx[t]]]){
      const k = Math.min(a,b)*100000 + Math.max(a,b);
      if (edgeUse.get(k) === 1){ rim.add(a); rim.add(b); }
    }
  }
  const faceIdx = [], fringeIdx = [];
  for (let t=0; t<fidx.length; t+=3){
    const isRim = rim.has(fidx[t]) || rim.has(fidx[t+1]) || rim.has(fidx[t+2]);
    (isRim ? fringeIdx : faceIdx).push(fidx[t], fidx[t+1], fidx[t+2]);
  }

  const nFace = fpos.length/3;
  const position = new Float32Array(fpos.length + spos.length);
  position.set(fpos, 0); position.set(spos, fpos.length);
  const fuv = S.faceBase.uv;
  const uv = new Float32Array(fuv.length + (spos.length/3)*2);
  uv.set(fuv, 0);

  // Shell triangles, each with the two numbers the hairline needs: |azimuth|
  // from the front and centroid height. Kept so moving a slider only re-sorts
  // triangles between the skin and scalp groups — geometry, buffers, sculpt
  // and markers are untouched.
  // Shell QUADS (shellGeometry emits two consecutive triangles per cell), each
  // with the two numbers the hairline needs. Classifying per quad rather than
  // per triangle halves the staircase along the skin/scalp boundary.
  const sTris = [];
  for (let t=0; t<sidx.length; t+=6){
    const v = [];
    for (let k=0; k<6 && t+k<sidx.length; k++) v.push(sidx[t+k]+nFace);
    let mx=0, my=0, mz=0;
    for (const q of v){ mx+=position[3*q]; my+=position[3*q+1]; mz+=position[3*q+2]; }
    mx = mx/v.length - centre[0]; my /= v.length; mz = mz/v.length - centre[2];
    sTris.push({ v, a:Math.abs(Math.atan2(mx, mz)), y:my, mx, mz });
  }

  /* Cells where the face mesh is present (or adjacent) are always SKIN. The
     face's Delaunay edge is ragged, and a black scalp boundary crossing it
     silhouettes every sawtooth; a guaranteed skin buffer around the whole face
     rim keeps the dark boundary away from it whatever the sliders say. */
  /* Dilate, then SMOOTH, then threshold (v26).

     A plain dilation of the face cells inherits the face's own outline, and
     that outline is the Delaunay edge of a landmark cloud, which is genuinely
     ragged. Since this mask overrides the hairline wherever it is set, the
     boundary between skin and scalp was being cut to the shape of that ragged
     edge — a torn black notch across the temple and the forehead, which is the
     single most artificial thing in a profile view. It is not a hairline that
     is wrong; it is a hairline wearing the face mesh's tatters.

     So blur the mask as a field and take the half contour. Blurring a ragged
     boundary and re-thresholding it is a morphological open and close in one,
     and it costs nothing at this size. */
  const nfRaw = new Float32Array(nT*nP);
  for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
    if (!(faceR[j*nT+i] > 0)) continue;
    for (let dj=-2; dj<=2; dj++){
      const jj = Math.min(nP-1, Math.max(0, j+dj));
      for (let di=-2; di<=2; di++) nfRaw[jj*nT + ((i+di+nT)%nT)] = 1;
    }
  }
  {
    let f = nfRaw;
    for (let p=0;p<6;p++){
      const g = new Float32Array(nT*nP);
      for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
        const j0=Math.max(0,j-1), j1=Math.min(nP-1,j+1);
        const i0=(i-1+nT)%nT, i1=(i+1)%nT;
        g[j*nT+i] = (f[j*nT+i]*2 + f[j*nT+i0] + f[j*nT+i1] + f[j0*nT+i] + f[j1*nT+i])/6;
      }
      f = g;
    }
    for (let k=0;k<nT*nP;k++) nfRaw[k] = f[k];
  }
  const nearFace = new Uint8Array(nT*nP);
  for (let k=0;k<nT*nP;k++) nearFace[k] = nfRaw[k] > 0.45 ? 1 : 0;
  /* ── the keep field (v27) ──

     The clinician asked for a mask: the face, the surface out to the ears, the
     ears, and nothing else. Rather than enumerate what to remove — which is
     how the temple spikes survived three attempts — this enumerates what to
     KEEP, so anything the head field produces outside the mask is gone by
     construction whatever caused it.

     A cell is kept when it is within reach of the face oval OR part of an ear,
     AND below the hairline, AND above the jaw, AND in front of the ear. The
     field is then blurred, so what the texture reads is a soft contour rather
     than a grid of yes and no. */
  const faceBand = (() => {
    const m = new Uint8Array(nT*nP);
    for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
      if (!(faceR[j*nT+i] > 0)) continue;
      for (let dj=-9; dj<=9; dj++){
        const jj = Math.min(nP-1, Math.max(0, j+dj));
        for (let di=-9; di<=9; di++) m[jj*nT + ((i+di+nT)%nT)] = 1;
      }
    }
    return m;
  })();
  /* The ceiling: how high the FACE reaches at each azimuth.

     The last artefact standing after the mask went in was a pair of dark
     wedges at the temples. They were not a bug in the head field; they were
     the collar of skin between the face and the ear, kept on purpose, rising
     above the face's own outline and reading as horns against a black
     background. Nothing photographic supports a surface that stands proud of
     the face there, so the collar is not allowed to: at every azimuth it stops
     at the topmost cell the face itself occupies. The ear is exempt, since an
     ear does reach above the face oval and is the one thing out there worth
     drawing. */
  const jTop = new Int32Array(nT).fill(nP);
  for (let i=0;i<nT;i++)
    for (let j=0;j<nP;j++)
      if (faceR[j*nT+i] > 0){ jTop[i] = j; break; }
  // Carry the ceiling sideways into azimuths the face never reaches, so the
  // collar does not simply stop dead where the face oval ends.
  for (let pass=0; pass<3; pass++){
    const t2 = Int32Array.from(jTop);
    for (let i=0;i<nT;i++){
      const a = jTop[(i-1+nT)%nT], b = jTop[(i+1)%nT];
      t2[i] = Math.min(jTop[i], Math.max(a, b) === nP ? nP : Math.min(a, b) + 1);
    }
    jTop.set(t2);
  }
  const KEEP_AZ = 96*Math.PI/180;
  /* The skin the ear stands on (v32).

     The ear mesh is set onto this surface with its root sunk into it, so the
     patch under the root and a strip in front of it have to stay, or the ear
     hangs over a hole. Behind the root the ear's own back is all that shows,
     the same empty space as the hair. The zone is measured in the ear's frame:
     from 0.05 in front of the attachment line, a strip of preauricular skin
     and no more, since the zone is exempt from the hairline and a wider one
     brings the temple back, to 0.035 of the ear's reach behind it, which is where
     the donor ear's front edge has already been flattened onto the skin, and a
     little past the top and bottom of the ear so the lobe and the helix root
     have skin under them. */
  const earZone = tr => {
    const x = tr.mx + centre[0], z = tr.mz + centre[2];
    for (const side of ['R','L']){
      const e = field.ears[side];
      if (!e || Math.sign(x - centre[0]) !== e.sx) continue;
      const yc = (e.yBot + e.yTop)/2;
      const bk = (e.attachZ - z)/(field.W*e.depth);
      const up = (tr.y - yc)/e.height;
      /* Under the lobe the zone reaches further back. The lobe hangs free and
         its front edge sits about 0.06 behind the attachment line, so a
         0.035 zone left a strip of empty head between lobe and cheek, and
         from the front quarter the ear stood off the face on its own. The
         skin in front of the lobe is cheek, not sideburn, so the strip there
         runs further forward as well. */
      const lob = Math.min(1, Math.max(0, (-0.20 - up)/0.15));
      const bkMax = 0.035 + 0.05*lob*lob*(3 - 2*lob);
      const bkMin = -0.05 - 0.07*lob*lob*(3 - 2*lob);
      if (bk > bkMin && bk < bkMax && up > -0.62 && up < 0.60) return bk < 0 ? 1 : 2;
    }
    return 0;
  };
  const keepField = P2 => {
    const f = new Float32Array(nT*nP);
    const cellY = new Float32Array(nT*nP).fill(NaN);
    for (const tr of sTris){
      const k = cellOf(tr);
      const i = k % nT, j = (k - i)/nT;
      const zone = earZone(tr), nearEar = zone > 0;
      /* The ear is exempt from the azimuth limit as well as the ceiling. Now
         that it sits 0.21 W behind the landmark rather than 0.01 W, its own
         azimuth is past 96 degrees, so the limit that keeps the back of the
         head out was quietly deleting the one thing out there worth drawing. */
      const ok = (faceBand[k] || nearEar) &&
                 /* The ear is exempt from the 96° limit, but not from every
                    limit: without a second cap the exemption carried a pale
                    wedge of shell round behind the ear, which shows edge-on in
                    a profile view. The ear's own helix rim is at about 119°. */
                 (tr.a < KEEP_AZ || (nearEar && tr.a < 124*Math.PI/180)) &&
                 /* Raised from 0.06 H when the keep field stopped eroding
                    itself: the two-cell dilation now carries the boundary
                    about that far further down, and the neck came back. */
                 tr.y > P2.y152 - 0.005*P2.H &&
                 (nearEar || j >= jTop[i]) &&
                 /* In front of the ear the hairline still rules, so the
                    sideburn stays hair; under the ear it does not, so the
                    root always has skin beneath it. */
                 (zone === 2 || !hairAt(tr.a, tr.y, P2));
      if (ok) f[k] = 1;
      // Height of the surface in this cell, for the chin gate below.
      cellY[k] = cellY[k] === cellY[k] ? Math.max(cellY[k], tr.y) : tr.y;
    }
    /* Grow, THEN soften, THEN put the middle back.

       Blurring the raw mask on its own is what left a gap between the cheek
       and the ear. The collar between them is only about nine cells wide, six
       passes of blur pull its middle down to 0.7 and its edges below 0.5, and
       the texture alpha-tests at 0.5 — so a band that was entirely inside the
       mask came out half deleted. The fade has to eat into spare margin rather
       than into the feature it is softening.

       So dilate two cells first, giving the blur something to consume, and
       rescale afterwards so anything that was solidly inside returns to one.
       The contour still crosses 0.5 in roughly the same place; only the
       interior stops being eroded. */
    for (let pass=0; pass<2; pass++){
      const g2 = new Float32Array(f);
      for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
        if (!f[j*nT+i]) continue;
        for (let dj=-1; dj<=1; dj++){
          const jj = j+dj; if (jj<0||jj>=nP) continue;
          for (let di=-1; di<=1; di++) g2[jj*nT + ((i+di+nT)%nT)] = 1;
        }
      }
      f.set(g2);
    }
    for (let pass=0; pass<6; pass++){
      const g2 = new Float32Array(nT*nP);
      for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
        const j0=Math.max(0,j-1), j1=Math.min(nP-1,j+1);
        const i0=(i-1+nT)%nT, i1=(i+1)%nT;
        g2[j*nT+i] = (f[j*nT+i]*2 + f[j*nT+i0] + f[j*nT+i1] + f[j0*nT+i] + f[j1*nT+i])/6;
      }
      f.set(g2);
    }
    for (let k=0;k<nT*nP;k++) f[k] = Math.min(1, f[k]*1.8);
    /* ── the chin, and why it needed a ramp (v31) ──

       The cut under the chin used to be a per-cell yes or no, and that was
       invisible only because the old head was a fat ellipsoid down there: the
       surface ran well outside the face, so whichever cells the threshold took
       were all roughly the same distance out and the edge read as straight.

       The measured head hugs the real jaw — it puts the menton at 0.39 W from
       the tragion axis where the old ellipsoid put it at 0.66 W, and the
       landmarks say 0.390 — so the surface now curves away sharply just below
       the chin. A per-cell threshold across a sharply curving surface takes
       cells that differ a lot in height, and the bottom edge came out deeply
       scalloped.

       Dropping the cut lower does not help; it hangs a grey neck stump under
       the chin, which is the thing the mask exists to remove. So the cut stays
       where it is and stops being binary: alpha ramps from one to zero over
       0.065 H of height, applied AFTER the rescale so the ×1.8 cannot crush
       the ramp back into a step. The blur then has a gradient to soften rather
       than a staircase to hide. */
    const yHi = P2.y152 + 0.010*P2.H, yLo = P2.y152 - 0.055*P2.H;
    for (let k=0;k<nT*nP;k++){
      if (!(f[k] > 0)) continue;
      const y = cellY[k];
      if (!(y === y)) continue;                 // no surface here to gate
      if (y >= yHi) continue;
      if (y <= yLo){ f[k] = 0; continue; }
      const t = (y - yLo)/(yHi - yLo);
      f[k] *= t*t*(3 - 2*t);
    }
    /* The ramp leaves the odd single cell standing above the alpha test with
       nothing beside it, which renders as a thin spike hanging off the jaw.
       One majority pass: a cell whose neighbours have all but gone is gone. */
    {
      const g2 = new Float32Array(f);
      for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
        const k = j*nT+i;
        if (f[k] < 0.5) continue;
        const j0=Math.max(0,j-1), j1=Math.min(nP-1,j+1);
        const i0=(i-1+nT)%nT, i1=(i+1)%nT;
        const nb = (f[j*nT+i0] + f[j*nT+i1] + f[j0*nT+i] + f[j1*nT+i])/4;
        if (nb < 0.35) g2[k] = 0;
      }
      f.set(g2);
    }
    return f;
  };

  const cy0 = centre[1];
  const cellOf = tr => {
    // Recover the (θ,φ) cell from the quad centroid.
    const th = ((Math.atan2(tr.mx, tr.mz) + Math.PI*2) % (Math.PI*2));
    const i = Math.min(nT-1, Math.floor(th/(Math.PI*2)*nT));
    const rr = Math.hypot(tr.mx, tr.y-cy0, tr.mz) || 1;
    const phi = Math.acos(Math.max(-1, Math.min(1, (tr.y-cy0)/rr)));
    const j = Math.min(nP-1, Math.floor(phi/Math.PI*nP));
    return j*nT + i;
  };
  const P = { y152:S.lm3[152][1], H:faceH, hairH, temple };

  /* ── which photograph colours each ear ──

     Each side picks its best profile (then ¾) photo. A hand-solved pose is
     preferred over the fit's automatic one, and an outline-only estimate is a
     last resort. Up to v31 the photograph was projected onto the head grid's
     own ear; the ear is a mesh of its own now (see buildEarMeshes), and the
     photograph only sets its colour. */
  const earSrc = {};
  for (const [side, roles] of [['R', ['r90','r45']], ['L', ['l90','l45']]]){
    for (const role of roles){
      const cands = S.photos.filter(q => q.role===role && q.img && q.pose);
      cands.sort((a,b) => (a.pose.silOnly?2:a.pose.auto?1:0) - (b.pose.silOnly?2:b.pose.auto?1:0));
      const cam = cands.length && projCameraFor(cands[0]);
      if (cam){ earSrc[side] = { photo:cands[0], cam }; break; }
    }
  }
  // No grid quad is an ear any more. The two ear groups stay, empty, so the
  // material slots and every saved group index keep their meaning.
  for (const tr of sTris) tr.ear = null;

  const index = new Uint32Array(faceIdx.length + fringeIdx.length + sidx.length);
  index.set(faceIdx, 0);

  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(position, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(new THREE.BufferAttribute(index, 1));

  /* One sorter for first build, winding flip and hairline slider alike:
     face | fringe | skin | scalp | right ear | left ear. Ear quads never
     re-sort.

     The fringe is its own group rather than the head of the skin group (v26).
     It is made of FACE vertices, and once an atlas exists the face and the
     shell live in different halves of it, so a group that mixes the two would
     read one half's texture through the other half's coordinates. It also
     wants to stay untextured whatever else happens, which a group of its own
     states plainly. */
  const regroup = () => {
    // The fringe is NOT re-wound with the shell below: face and shell windings
    // are established independently, and this ring belongs to the face.
    const skin=[], hair=[], eR=[], eL=[];
    /* The crop plane at the bottom of the neck goes in with the scalp.

       It is a flat disc that no camera ever saw, so the atlas fills it with
       skin tone, and a skin-coloured disc under the chin reads as a slab of
       meat. In the dark group the same disc reads as the shadow under a jaw,
       which is what a viewer expects to find there. The geometry is
       unchanged; this is only which material draws it. */
    const cutBand = P.y152 - 0.42*P.H;
    for (const tr of sTris){
      if (tr.ear==='R'){ eR.push(...tr.v); continue; }
      if (tr.ear==='L'){ eL.push(...tr.v); continue; }
      if (tr.y < cutBand){ hair.push(...tr.v); continue; }
      ((!nearFace[cellOf(tr)] && hairAt(tr.a, tr.y, P)) ? hair : skin).push(...tr.v);
    }
    const o1 = faceIdx.length, o2 = o1+fringeIdx.length, o3 = o2+skin.length,
          o4 = o3+hair.length, o5 = o4+eR.length;
    index.set(fringeIdx, o1); index.set(skin, o2); index.set(hair, o3);
    index.set(eR, o4); index.set(eL, o5);
    g.clearGroups();
    g.addGroup(0,  o1,                0);
    g.addGroup(o1, fringeIdx.length,  1);
    g.addGroup(o2, skin.length,       2);
    g.addGroup(o3, hair.length,       3);
    g.addGroup(o4, eR.length,         4);
    g.addGroup(o5, eL.length,         5);
    g.index.needsUpdate = true;
  };
  regroup();
  g.computeVertexNormals(); g.computeBoundingBox(); g.computeBoundingSphere();

  // Winding, measured not assumed — §3.6.
  const nrm = g.attributes.normal.array;
  let out = 0;
  for (let i=nFace; i<position.length/3; i++){
    const dx = position[3*i]-centre[0], dy = position[3*i+1]-centre[1], dz = position[3*i+2]-centre[2];
    out += nrm[3*i]*dx + nrm[3*i+1]*dy + nrm[3*i+2]*dz;
  }
  if (out < 0){
    for (const tr of sTris){
      for (let k=0; k+2<tr.v.length; k+=3){ const t = tr.v[k+1]; tr.v[k+1] = tr.v[k+2]; tr.v[k+2] = t; }
    }
    regroup();
    g.computeVertexNormals();
  }
  // The face part shaded as its landmark surface (v34, see fixFaceNormals).
  fixFaceNormals(g, S.faceBase && S.faceBase.sub);

  /* ── weld the normals across the join (v26) ──

     The face and the shell are separate vertices that happen to sit on the
     same surface, so `computeVertexNormals` gives each side its own normal and
     the boundary between them is a hard lighting crease. Run that crease along
     the face's ragged Delaunay edge and you get the sawtooth down the cheek
     that made a photo-built head read as a mask laid on a mannequin — and it
     survives every geometric fix, because it is not geometry, it is shading.

     So average the normals of any two vertices that are close enough to be the
     same point. A hash grid at the join's own scale keeps it linear; there are
     ten thousand vertices and this runs once per build.

     Positions are untouched, which matters: the sculpt buffer, the markers and
     every measurement read positions, and none of them read this. */
  {
    const nrmA = g.attributes.normal.array;
    const nv = position.length/3;
    const eps = 0.006 * (Math.abs(S.lm3[10][1] - S.lm3[152][1]) || 1);
    const cell = eps;
    const key = (x,y,z) => `${Math.round(x/cell)},${Math.round(y/cell)},${Math.round(z/cell)}`;
    const bins = new Map();
    for (let i=0;i<nv;i++){
      const k = key(position[3*i], position[3*i+1], position[3*i+2]);
      let b = bins.get(k); if (!b){ b = []; bins.set(k, b); }
      b.push(i);
    }
    const acc = new Float32Array(nv*3);
    const eps2 = eps*eps;
    for (let i=0;i<nv;i++){
      const x=position[3*i], y=position[3*i+1], z=position[3*i+2];
      const ci=Math.round(x/cell), cj=Math.round(y/cell), ck=Math.round(z/cell);
      let ax=0, ay=0, az=0;
      for (let dx=-1;dx<=1;dx++) for (let dy=-1;dy<=1;dy++) for (let dz=-1;dz<=1;dz++){
        const b = bins.get(`${ci+dx},${cj+dy},${ck+dz}`);
        if (!b) continue;
        for (const j of b){
          const ex=position[3*j]-x, ey=position[3*j+1]-y, ez=position[3*j+2]-z;
          if (ex*ex+ey*ey+ez*ez > eps2) continue;
          // Only weld normals that already broadly agree. Two surfaces that
          // genuinely meet at an angle — the crop plane at the neck — should
          // keep their edge rather than be rounded into mush.
          if (nrmA[3*i]*nrmA[3*j] + nrmA[3*i+1]*nrmA[3*j+1] + nrmA[3*i+2]*nrmA[3*j+2] < 0.35) continue;
          ax+=nrmA[3*j]; ay+=nrmA[3*j+1]; az+=nrmA[3*j+2];
        }
      }
      const L = Math.hypot(ax,ay,az);
      if (L > 1e-9){ acc[3*i]=ax/L; acc[3*i+1]=ay/L; acc[3*i+2]=az/L; }
      else { acc[3*i]=nrmA[3*i]; acc[3*i+1]=nrmA[3*i+1]; acc[3*i+2]=nrmA[3*i+2]; }
    }
    nrmA.set(acc);
    g.attributes.normal.needsUpdate = true;
  }

  const faceMat = baseMats[0] ? baseMats[0].mat : mesh.material;
  const skinMat = new THREE.MeshStandardMaterial({
    color: skinToneFromFront(), side:THREE.DoubleSide, roughness:0.72, metalness:0 });
  /* Hair is a flat black mass, not a lit surface (v26).

     The scanner does not reconstruct hair either; it returns it as an unlit
     dark volume whose lower edge follows the real hairline, and that is what
     the clinic is used to reading. A lit material puts a specular sheen and a
     shaded side on it, which says "this is a surface we measured" about the
     one part of the head that was never measured. Basic material, no lighting,
     so it reads as a silhouette and nothing more. The boundary is the fitted
     hairline, which is what carries the actual information. */
  /* Dark and matte, but LIT.

     The first version of this was unlit, on the reasoning that a specular
     sheen on unmeasured geometry reads as a claim. Seen from the front that
     was right. Seen from the side it was badly wrong: in profile the scalp is
     most of the head, and a single flat value across all of it reads as a hole
     punched in the picture rather than as hair. It needs shape, so it is lit,
     with the roughness up and the colour low enough that no detail is being
     claimed — a dark mass with a form, which is what the scanner returns. */
  const hairMat = new THREE.MeshStandardMaterial({
    color: ATLAS_HAIR, side:THREE.DoubleSide, roughness:0.97, metalness:0 });
  const earMatR = skinMat, earMatL = skinMat;
  mesh.geometry.dispose();
  dropEarMeshes(mesh);
  mesh.geometry = g;
  mesh.material = [faceMat, skinMat, skinMat, hairMat, earMatR, earMatL];
  const earMeshes = buildEarMeshes(field.ears, rShell, centre, nT, nP, field.W, field.H, earSrc);
  for (const em of earMeshes) mesh.add(em);
  baseMats = [
    { mat:faceMat, map:faceMat.map }, { mat:skinMat, map:null }, { mat:skinMat, map:null },
    { mat:hairMat, map:null },
    { mat:earMatR, map:earMatR.map||null }, { mat:earMatL, map:earMatL.map||null },
  ];
  /* Which groups the atlas may claim: everything except the hair.

     The fringe is included, which reverses the v25 decision to leave it plain
     skin. That decision was right for projective texturing: the fringe's
     coordinates were front-photo coordinates at a grazing angle, so its
     triangles carried stretched pixels and read as dark spikes, and plain skin
     was the lesser evil. In the atlas the fringe has its own chart coordinates
     like everything else and its colour is baked from whichever camera faces
     it, so the reason is gone — and leaving it untextured now puts a pale
     zigzag between a textured face and a textured shell, which is worse than
     what it was hiding. */
  /* The scalp is in the list too, because the map paints the hairline now and
     a separate material would put a hard quad edge back inside a gradient that
     exists precisely to hide one. */
  S.atlasGroups = [0, 1, 2, 3, 4, 5];
  /* ── pack the shell chart to what survives the mask (v31) ──

     The shell's unwrap is its own (theta, phi) lattice, distortion free and
     needing no packing, and it spends the whole right half of the atlas on the
     whole sphere. The mask then deletes most of that sphere: nothing behind
     124 degrees, nothing above the hairline, nothing below the chin. Roughly
     two thirds of the shell chart is painted and then thrown away, and the
     surface that IS kept gets a third of the texels it could have.

     That is what the sideburn seam is made of. The face chart runs at about
     0.07 mm per texel and the shell at 0.28, so where they meet there is a
     four to one step in sharpness, and the boundary follows the shell's cell
     grid, which is why the step is a staircase rather than a line.

     Fading the face rim further does not help. The mask has already removed
     the shell from behind the rim, so a longer fade opens black holes along
     the join: measured at fade 60 and 110 on the clinician's own photographs.

     So rescale the shell's UV onto the bounding box of the cells the mask
     keeps. Nothing about the geometry or the mask changes, only which part of
     the atlas each cell is painted into. */
  {
    const kf = keepField(P);
    let i0=nT, i1=-1, j0=nP, j1=-1;
    for (let j=0;j<nP;j++) for (let i=0;i<nT;i++){
      if (!(kf[j*nT+i] > 0.02)) continue;
      if (i<i0) i0=i; if (i>i1) i1=i; if (j<j0) j0=j; if (j>j1) j1=j;
    }
    const PAD = 3;                       // room for the dilation and the bleed
    i0=Math.max(0,i0-PAD); i1=Math.min(nT-1,i1+PAD);
    j0=Math.max(0,j0-PAD); j1=Math.min(nP-1,j1+PAD);
    const du=(i1-i0+1)/nT, dv=(j1-j0+1)/nP;
    // Worth doing only if it is a real saving, and never if the mask came back
    // empty or spanning everything.
    if (i1>=i0 && j1>=j0 && du*dv < 0.85 && du > 0.02 && dv > 0.02){
      const u0=i0/nT, v0=1-(j1+1)/nP;
      for (let k=0;k<suv.length;k+=2){
        suv[k]   = Math.min(1, Math.max(0, (suv[k]  -u0)/du));
        suv[k+1] = Math.min(1, Math.max(0, (suv[k+1]-v0)/dv));
      }
      S.shellPack = { u0, v0, du, dv, gain: +(1/Math.sqrt(du*dv)).toFixed(2) };
    } else S.shellPack = null;
  }
  S.shellUV = Float32Array.from(suv);
  atlasState.on = false; atlasState.photoUV = null; atlasState.coverage = 0;
  captureBase(); refreshWireframe();

  return {
    ok: true, canon: true,
    hairH, temple, earFit: (opts && opts.earFit) || null,
    verts: spos.length/3, tris: sidx.length/3, nFace,
    restored: !!(opts && opts.restored),
    earTex: { R: earSrc.R ? earSrc.R.photo.name : null, L: earSrc.L ? earSrc.L.photo.name : null },
    earMesh: { paint: EAR_PAINT, sides: earMeshes.map(m => m.userData.side),
               verts: earMeshes.length ? earMeshes[0].geometry.attributes.position.count : 0 },
    centre: [centre[0], centre[1], centre[2]],
    keep: keepField(P), _keepField: keepField, nT, nP,
    _sTris: sTris, _faceLen: faceIdx.length, _P: P, _geom: g,
    _nearFace: nearFace, _cellOf: cellOf, _regroup: regroup, _ears: field.ears,
  };
}

function updateHairline(){}

function refineShellFromMarks(){
  const si = S.shellInfo;
  if (!si || !si.ok || !si.canon) return { any:false };
  const tR = S.lm3[234], tL = S.lm3[454];
  const H = si._P.H, y152 = si._P.y152;
  const W = Math.hypot(tR[0]-tL[0], tR[1]-tL[1], tR[2]-tL[2]) || 1;
  const cx = (tR[0]+tL[0])/2, cy = (tR[1]+tL[1])/2, cz2 = (tR[2]+tL[2])/2;

  // The standard cranium, same numbers as canonicalHeadField.
  const crown = y152 + 1.32*H;
  const skullYc = (crown + y152 + 0.35*H) / 2;
  const skullRy = crown - skullYc;
  const skull = { c:[cx, skullYc, cz2-0.02*W], r:[0.545*W, skullRy, 0.66*W] };

  // Ray ∩ ellipsoid: near root, or the ray's closest approach if it misses.
  const rayEllipsoid = (o, d, e) => {
    const ox=(o.x-e.c[0])/e.r[0], oy=(o.y-e.c[1])/e.r[1], oz=(o.z-e.c[2])/e.r[2];
    const dx=d.x/e.r[0], dy=d.y/e.r[1], dz=d.z/e.r[2];
    const A=dx*dx+dy*dy+dz*dz, B=2*(ox*dx+oy*dy+oz*dz), C=ox*ox+oy*oy+oz*oz-1;
    const disc = B*B - 4*A*C;
    let t;
    if (disc >= 0){ t = (-B - Math.sqrt(disc)) / (2*A); }
    else          { t = -B / (2*A); }                 // closest approach
    if (!(t > 0)) return null;
    return { x:o.x+d.x*t, y:o.y+d.y*t, z:o.z+d.z*t };
  };
  const hits = {};       // id -> [ {x,y,z}, ... ] across photos
  for (const p of S.photos){
    if (!p.img || !p.landmarks2D || !p.pose) continue;
    if (p.pose.silOnly) continue;             // estimated outline cameras are guesses
    const cam = projCameraFor(p);
    if (!cam) continue;
    for (const h of HB_DEFS){
      const m = p.landmarks2D[h.id];
      if (!m) continue;
      if (h.id.startsWith('hbEar')) continue;      // fitted in the image, below
      const o = cam.position.clone();
      const d = new THREE.Vector3(m[0]*2-1, 1-m[1]*2, 0.5).unproject(cam).sub(o).normalize();
      const side = h.id.endsWith('R') ? 'R' : h.id.endsWith('L') ? 'L' : null;
      /* The front of the ear is where it meets the head, so its ray is
         dropped onto the head's side (the attachment line's x), not onto the
         ear's mid-lateral. On a ¾ view the ray runs mostly along z, and the
         z-plane the other ear marks use would hand back the attachment line
         itself whatever was marked. */
      const q = rayEllipsoid(o, d, skull);
      if (q) (hits[h.id] = hits[h.id] || []).push(q);
    }
  }

  const med1 = a => { const s=[...a].sort((x,y)=>x-y); const m=s.length>>1;
                      return s.length%2 ? s[m] : (s[m-1]+s[m])/2; };
  const med = id => {
    const l = hits[id]; if (!l || !l.length) return null;
    return { x:med1(l.map(q=>q.x)), y:med1(l.map(q=>q.y)), z:med1(l.map(q=>q.z)) };
  };
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  const out = { any:true, hair:false, ears:false, earFit: si.earFit ? JSON.parse(JSON.stringify(si.earFit)) : {} };

  /* Hairline: fit y = base − dip·g(a) through the marked points. Linear in
     (base, dip), so it is two sums and a 2×2 solve. */
  const hp = [];
  for (const id of ['hbHairApex','hbTempR','hbTempL']){
    const q = med(id); if (!q) continue;
    const a = Math.abs(Math.atan2(q.x-cx, q.z-cz2));
    hp.push({ a, y:q.y, g:Math.exp(-(((a-1.15)/0.45)**2)) });
  }
  if (hp.length){
    let Sg=0, Sgg=0, Sy=0, Sgy=0, n=hp.length;
    for (const q of hp){ Sg+=q.g; Sgg+=q.g*q.g; Sy+=q.y; Sgy+=q.g*q.y; }
    let base, dip;
    if (n >= 2 && Math.abs(n*Sgg - Sg*Sg) > 1e-9){
      dip  = -( (n*Sgy - Sg*Sy) / (n*Sgg - Sg*Sg) );
      base = (Sy + dip*Sg) / n;
    } else {
      // One point: move only the parameter it actually constrains.
      dip = (0.02 + 0.49*si.temple)*H;
      base = hp[0].y + dip*hp[0].g;
    }
    // Same coefficients as hairAt. They were widened in v26; if they move
    // again they must move in all three places at once, here, in hairAt and in
    // estimateHairline, or a marked hairline and a measured one disagree.
    const hairH  = clamp(((base - y152)/H - 0.98) / 0.42, 0, 1);
    const temple = clamp((dip/H - 0.02) / 0.49, 0, 1);
    out.hair = true; out.hairH = hairH; out.temple = temple;
  }

  /* ── ears: fitted in the photographs themselves (v35) ──

     Each ear mark names one place on the ear mesh: the top of the helix, the
     bottom of the lobe, the back of the helix, the helix root at the front.
     The ear as it stands now is projected through each photograph's solved
     camera, and the numbers are found that move those four places onto the
     marks. Doing it in the image means a ¾ view needs no guess at
     how far out from the head a mark sits, which is what the older ray to a
     plane had to guess and, on a ¾ view, got wrong: the posterior mark there
     read the ear as shallow as its clamp allowed.

     The lateral axis is fitted as a stand-out factor; the ear is re-seated
     on the head surface when the shell is rebuilt. See below for the
     unknowns and their limits. */
  const m0 = targets[0];
  const earMeshes = m0 ? m0.children.filter(c => c.userData && c.userData.isEarMesh) : [];
  const FI = earMeshes.length ? earFeatureIdx() : null;
  for (const [side, t] of [['R', tR], ['L', tL]]){
    const em = earMeshes.find(c => c.userData.side === side);
    const e = si._ears && si._ears[side];
    if (!em || !e || !FI) continue;
    const P = em.geometry.attributes.position.array;
    const obs = [];                       // { cam, vtx:[x,y,z], mark:[u,v] }
    for (const p of S.photos){
      if (!p.img || !p.landmarks2D || !p.pose || p.pose.silOnly) continue;
      const cam = projCameraFor(p); if (!cam) continue;
      for (const nm of ['Top','Bot','Back','Front']){
        const mk = p.landmarks2D['hbEar'+nm+side];
        if (!mk) continue;
        const k = FI[nm]; if (k < 0) continue;
        obs.push({ cam, ar: p.img.naturalWidth/p.img.naturalHeight, k, nm,
                   vtx:[P[3*k], P[3*k+1], P[3*k+2]], mark:[mk[0]*2-1, 1-mk[1]*2] });
      }
    }
    if (obs.length < 2) continue;
    const yc0 = (e.yBot + e.yTop)/2, zc0 = e.attachZ;
    const v3 = new THREE.Vector3();
    const bx = em.userData.baseX;
    for (const o of obs) o.bx = bx ? bx[o.k] : o.vtx[0];
    /* Outline marks are outline points (v36). The top, the lobe and the back
       of the ear are where its outline is in THIS photograph, and on a ¾ view
       that is not the vertex highest, lowest or furthest back on the head:
       at 30° of yaw the outline of the helix is set as much by how far it
       stands out as by how far back it reaches. A fixed vertex there made
       the fit stretch the ear a third longer than it is, on the donor's own
       head. So each outline mark is matched to whichever vertex of the ear,
       as currently placed, lies furthest in that mark's direction in that
       photograph: up the image for the top, down for the lobe, and toward
       the back of the head for the back. The helix root is a point on the
       surface, not an outline, and keeps its vertex. */
    const outl = [];
    { const { V:VV } = earMeshData();
      for (let k=0;k<VV.length/3;k+=2) if (VV[3*k] >= 0.03) outl.push(k); }
    const OX = outl.map(k => bx ? bx[k] : P[3*k]);
    for (const o of obs){
      if (o.nm === 'Front') continue;
      const a = new THREE.Vector3(o.vtx[0], yc0, zc0).project(o.cam);
      const b = o.nm === 'Back' ? new THREE.Vector3(o.vtx[0], yc0, zc0 - 0.1*W).project(o.cam)
                                : new THREE.Vector3(o.vtx[0], yc0 + (o.nm==='Top'?1:-1)*0.1*W, zc0).project(o.cam);
      const dx = (b.x-a.x)*o.ar, dy = b.y-a.y, L = Math.hypot(dx, dy) || 1;
      o.dir = [dx/L, dy/L];
    }
    /* Five numbers (v36): height scale, reach scale, shift up, shift back,
       stand-out. Height and reach scale apart because the standard ear's
       length for its width is one man's: on five test faces with a uniform
       scale the lobe fell 5 to 15 mm short of the lobe mark every time. A
       light pull keeps the two scales near each other and the stand-out near
       its standard, so a mark set that cannot see one of them leaves it be.
       Solved by damped Gauss-Newton with box limits. */
    // Limits are on the ear's total size and place, not on the step.
    const hs0 = e.height/(0.433*H), rs0 = e.markedDepth ? e.depth*EAR_BACK_MAX/EAR_MESH.back : 1, fl0 = e.flare || 1;
    const LO = [0.7/hs0, 0.7/rs0, -0.15*W, -0.15*W, 0.6/fl0], HI = [1.5/hs0, 1.5/rs0, 0.15*W, 0.15*W, 1.8/fl0];
    const box = q => q.map((v,j) => clamp(v, LO[j], HI[j]));
    const rv = q => {
      const [ku, kb, dy, dz, kf] = box(q), r = [];
      /* The same placement a rebuild would do with these numbers: new
         heights and reach about the ear's centre and attachment line, the
         shear that leans the ear back taken with the height, and the vertex
         set on the head surface where it will now be, lifted by its own
         height scaled for the new size and stand-out. */
      const pl = em.userData.place;
      const sHn = pl ? 0.5*(pl.sUp*ku + pl.sBk*kb)*pl.flare*kf : 0;
      const at = (vx, vy, vz, b0, cam) => {
        if (!pl){
          const y = yc0 + ku*(vy-yc0) + dy, z = zc0 + kb*(vz-zc0) + dz;
          return v3.set(b0 + 0.5*(ku+kb)*kf*(vx-b0), y, z).project(cam);
        }
        const dyc = vy - pl.yc;
        const y = pl.yc + dy + ku*dyc;
        const z = (zc0 + dz) - kb*(zc0 - vz - dyc*pl.shear) - ku*dyc*pl.shear;
        const x = pl.lateralAt(y, z, pl.sx) + (vx - b0)*(sHn/pl.sH);
        return v3.set(x, y, z).project(cam);
      };
      for (const o of obs){
        if (!o.dir){
          at(o.vtx[0], o.vtx[1], o.vtx[2], o.bx, o.cam);
          r.push((v3.x-o.mark[0])*o.ar, v3.y-o.mark[1]); continue;
        }
        let best = -Infinity, bxp = 0, byp = 0;
        for (let i=0;i<outl.length;i++){
          const k = outl[i];
          at(P[3*k], P[3*k+1], P[3*k+2], OX[i], o.cam);
          const d = v3.x*o.ar*o.dir[0] + v3.y*o.dir[1];
          if (d > best){ best = d; bxp = v3.x; byp = v3.y; }
        }
        // An outline mark constrains only how far the ear reaches in its own
        // direction. Where along the outline the extreme falls is the ear's
        // shape, which the standard ear has and the patient's need not.
        r.push(((bxp-o.mark[0])*o.ar)*o.dir[0] + (byp-o.mark[1])*o.dir[1]);
      }
      r.push(0.05*((e.flare||1)*kf-1), 0.05*(ku-kb));
      return r;
    };
    const ss = r => r.reduce((t,v)=>t+v*v, 0);
    // Every number is relative to the ear as it stands, so a second build
    // with the same marks starts at the answer and stays there.
    let q = [1, 1, 0, 0, 1], r0 = rv(q), c0 = ss(r0), lam = 1e-3;
    const hs = [1e-4, 1e-4, 1e-4*W, 1e-4*W, 1e-4];
    for (let it=0; it<60; it++){
      const J = hs.map((h,j) => { const q2 = q.slice(); q2[j] += h; return rv(q2).map((v,i) => (v - r0[i])/h); });
      const A = [0,1,2,3,4].map(i => [0,1,2,3,4].map(k => J[i].reduce((t,v,n)=>t+v*J[k][n], 0)));
      const g = [0,1,2,3,4].map(i => J[i].reduce((t,v,n)=>t+v*r0[n], 0));
      let ok = false;
      for (let tries=0; tries<8 && !ok; tries++){
        const Ad = A.map((row,i) => row.map((v,k) => v + (i===k ? lam*(A[i][i]+1e-12) : 0)));
        const dq = solveLin5(Ad, g.map(v=>-v));
        if (!dq) { lam *= 10; continue; }
        const q2 = box(q.map((v,j) => v + dq[j])), r2 = rv(q2), c2 = ss(r2);
        if (c2 < c0){ q = q2; r0 = r2; ok = c0 - c2 < 1e-12; c0 = c2; lam = Math.max(1e-7, lam/3); ok = true; }
        else lam *= 10;
      }
      if (!ok) break;
    }
    q = box(q);
    // The last fit's residuals, per mark, for the test rig (tests/faces).
    { const rr_ = rv(q); (S._earDbg = S._earDbg || {})[side] = { start: Math.sqrt(ss(rv([1,1,0,0,1])) /Math.max(1,2*obs.length))/2, q: q.slice(), W,
        res: rr_.slice(0, -2).map(v => +(v*0.5).toFixed(4)), names: obs.map(o=>o.nm) }; }
    const rf = rv(q), nRes = rf.length - 2;
    let rr = 0; for (let i=0;i<nRes;i++) rr += rf[i]*rf[i];
    const rmsNdc = Math.sqrt(rr/Math.max(1, nRes));
    const f = out.earFit[side] = {};
    f.flare = clamp((e.flare||1)*q[4], 0.6, 1.8);
    f.yc = yc0 + q[2];
    f.ry = e.height/2 * q[0];
    const sBk0 = e.markedDepth ? e.depth*EAR_BACK_MAX/EAR_MESH.back : 1;
    f.rz = q[1]*sBk0*EAR_MESH.back*W;
    f.attachZ = zc0 + q[3];
    f.fromImage = { height:+q[0].toFixed(3), reach:+q[1].toFixed(3), up:+(q[2]/W).toFixed(3), back:+(-q[3]/W).toFixed(3),
                    flare:+q[4].toFixed(3), n:obs.length,
                    // NDC is 2 across the frame height, so this is a share of the photograph's height.
                    rmsFrac:+(rmsNdc/2).toFixed(4) };
    out.ears = true;
  }
  if (!out.hair && !out.ears) return { any:false };
  return out;
}

function applyShellRefinement(){
  const r = refineShellFromMarks();
  if (!r.any) return false;
  if (r.hair){
    const hlH=$('#hlH'), hlT=$('#hlT');
    if (hlH){ hlH.value = Math.round(r.hairH*100); $('#hlHv').textContent = hlH.value; }
    if (hlT){ hlT.value = Math.round(r.temple*100); $('#hlTv').textContent = hlT.value; }
  }
  if (r.ears){
    S.shellInfo = attachCanonicalShell({
      hairH:  r.hair ? r.hairH : S.shellInfo.hairH,
      temple: r.hair ? r.temple : S.shellInfo.temple,
      earFit: r.earFit,
    });
    bindAllMarkers(); applyDeform(); rebuildOverlays(); redrawAnno(); updateSimUi();
  } else if (r.hair){
    updateHairline(r.hairH, r.temple);
  }
  return true;
}

function addWireframes(){}

function refreshWireframe(){}

function frameCamera(){}

function bindAllMarkers(){}

function applyDeform(){}

function updateSimUi(){}

function kpUiState(){}

function rebuildOverlays(){}

function pick(){}

let down = null;

function redrawAnno(){}

function solveLinear(A,b){
  const n=b.length;
  const M=A.map((row,i)=>[...row,b[i]]);
  for (let c=0;c<n;c++){
    let piv=c;
    for (let r=c+1;r<n;r++) if (Math.abs(M[r][c])>Math.abs(M[piv][c])) piv=r;
    if (Math.abs(M[piv][c])<1e-12) return null;
    [M[c],M[piv]]=[M[piv],M[c]];
    for (let r=0;r<n;r++){
      if (r===c) continue;
      const f=M[r][c]/M[c][c];
      for (let cc=c;cc<=n;cc++) M[r][cc]-=f*M[c][cc];
    }
  }
  return M.map((row,i)=>row[n]/row[i]);
}

let devField = null;     // Float32Array of signed mm per vertex

let devSource = '';

function buildVGrid(){}

const HB_DEFS = [
  { id:'hbHairApex', label:'Hairline: mid forehead',    views:['front','r45','l45'] },
  { id:'hbTempR',    label:'Hairline: right temple',    views:['front','r45','r90'] },
  { id:'hbTempL',    label:'Hairline: left temple',     views:['front','l45','l90'] },
  { id:'hbEarTopR',  label:'Right ear: top',            views:['front','r90','r45'] },
  { id:'hbEarBotR',  label:'Right ear: lobe',           views:['front','r90','r45'] },
  { id:'hbEarBackR', label:'Right ear: most posterior', views:['r90','r45'] },
  { id:'hbEarFrontR', label:'Right ear: front, top of where it joins the head', views:['r90','r45'] },
  { id:'hbEarTopL',  label:'Left ear: top',             views:['front','l90','l45'] },
  { id:'hbEarBotL',  label:'Left ear: lobe',            views:['front','l90','l45'] },
  { id:'hbEarBackL', label:'Left ear: most posterior',  views:['l90','l45'] },
  { id:'hbEarFrontL', label:'Left ear: front, top of where it joins the head', views:['l90','l45'] },
];

const PROF_DEFS = [
  { id:'pfGlabella',  label:'Glabella',             mp:9,   views:['l90','r90'] },
  { id:'pfNasion',    label:'Nasion — nasal root',  mp:168, views:['l90','r90','l45','r45'] },
  { id:'pfRhinion',   label:'Rhinion — bridge',     mp:6,   views:['l90','r90','l45','r45'] },
  { id:'pfPronasale', label:'Pronasale — tip',      mp:4,   views:['l90','r90','l45','r45'] },
  { id:'pfSubnasale', label:'Subnasale',            mp:2,   views:['l90','r90','l45','r45'] },
  { id:'pfLabSup',    label:'Upper lip',            mp:0,   views:['l90','r90','l45','r45'] },
  { id:'pfStomion',   label:'Stomion — lip line',   mp:13,  views:['l90','r90'] },
  { id:'pfLabInf',    label:'Lower lip',            mp:17,  views:['l90','r90','l45','r45'] },
  { id:'pfSulcus',    label:'Mentolabial sulcus',   mp:18,  views:['l90','r90'] },
  { id:'pfPogonion',  label:'Pogonion — chin',      mp:199, views:['l90','r90','l45','r45'] },
  { id:'pfMenton',    label:'Menton — chin base',   mp:152, views:['l90','r90'] },
  // The two that carry the rotation. Every midline point above sits in a
  // near-vertical line, which pins scale and height well and the tilt only
  // weakly; the tragus is far posterior and the canthus far anterior-superior,
  // so they are the lever arm that makes the rotation observable at all.
  { id:'pfTragus',    label:'Tragus',        mpR:234, mpL:454, views:['l90','r90'] },
  { id:'pfCanthus',   label:'Outer canthus', mpR:33,  mpL:263, views:['l90','r90'] },
];

const ALAR_DEFS = [
  { id:'nsAlarR', label:'Alare, right: widest point of the nostril wing', mp:129, views:['front'] },
  { id:'nsAlarL', label:'Alare, left: widest point of the nostril wing',  mp:358, views:['front'] },
];

let ALAR_SIGMA = 0.2;

function applyAlarMarks(lm, photo){
  const marks = photo && photo.landmarks2D;
  if (!lm || !marks) return { lm, moved:[] };
  const ar = photo.img && photo.img.naturalHeight ? photo.img.naturalWidth/photo.img.naturalHeight : 1;
  const use = ALAR_DEFS.filter(d => marks[d.id] && lm[d.mp]);
  if (!use.length) return { lm, moved:[] };
  const aw = Math.hypot((lm[129].x-lm[358].x)*ar, lm[129].y-lm[358].y) || 0.1;
  const sig = ALAR_SIGMA*aw;
  const out = lm.map(p => ({ x:p.x, y:p.y, z:p.z }));
  const moved = [];
  for (const d of use){
    const c = lm[d.mp], m = marks[d.id];
    const dx = m[0] - c.x, dy = m[1] - c.y;
    // A mark more than half an alar width from the landmark is on the wrong
    // feature; say so rather than drag the nose there.
    if (Math.hypot(dx*ar, dy) > 0.5*aw){ moved.push({ id:d.id, rejected:true }); continue; }
    for (let i=0;i<lm.length;i++){
      const r = Math.hypot((lm[i].x-c.x)*ar, lm[i].y-c.y);
      const w = i === d.mp ? 1 : Math.exp(-((r/sig)**2));
      if (w < 1e-3) continue;
      out[i].x += w*dx; out[i].y += w*dy;
    }
    moved.push({ id:d.id, dx:dx*ar/aw, dy:dy/aw });
  }
  return { lm: out, moved };
}

const profVisible = role => PROF_DEFS.filter(d => d.views.includes(role));

const profMp = (d, role) => d.mp !== undefined ? d.mp : (role === 'r90' ? d.mpR : d.mpL);

const PROF_LEVER = ['pfTragus','pfCanthus'];

function solveProfileMap(rows){
  if (rows.length < 4) return null;
  // Normal equations for  Y ≈ b·ξ + a·η + ty.
  let Sxx=0,Sxe=0,Sx1=0,See=0,Se1=0,S11=0, Yx=0,Ye=0,Y1=0;
  for (const r of rows){
    Sxx+=r.xi*r.xi; Sxe+=r.xi*r.eta; Sx1+=r.xi;
    See+=r.eta*r.eta; Se1+=r.eta; S11+=1;
    Yx+=r.Y*r.xi; Ye+=r.Y*r.eta; Y1+=r.Y;
  }
  const M = [[Sxx,Sxe,Sx1],[Sxe,See,Se1],[Sx1,Se1,S11]];
  const sol = solve3(M, [Yx,Ye,Y1]);
  if (!sol) return null;
  const [b, a, ty] = sol;
  const k = Math.hypot(a, b);
  if (!(k > 1e-9)) return null;
  const theta = Math.atan2(b, a);
  // A lateral photograph rotated more than this is not a lateral photograph,
  // or the marks are not where their labels say. Refuse rather than bend the
  // head — the v24 field test is the argument for clamping instead of trusting.
  if (Math.abs(theta) > 25*Math.PI/180) return { bad:'tilt', theta };
  let rss = 0;
  for (const r of rows){ const d = (b*r.xi + a*r.eta + ty) - r.Y; rss += d*d; }
  return { a, b, ty, k, theta, rms: Math.sqrt(rss/rows.length) };
}

function solve3(M, v){
  const A = [[M[0][0],M[0][1],M[0][2],v[0]],
             [M[1][0],M[1][1],M[1][2],v[1]],
             [M[2][0],M[2][1],M[2][2],v[2]]];
  for (let c=0;c<3;c++){
    let piv=c; for (let r=c+1;r<3;r++) if (Math.abs(A[r][c])>Math.abs(A[piv][c])) piv=r;
    if (Math.abs(A[piv][c]) < 1e-12) return null;
    [A[c],A[piv]]=[A[piv],A[c]];
    for (let r=0;r<3;r++){
      if (r===c) continue;
      const f = A[r][c]/A[c][c];
      for (let k2=c;k2<4;k2++) A[r][k2] -= f*A[c][k2];
    }
  }
  return [A[0][3]/A[0][0], A[1][3]/A[1][1], A[2][3]/A[2][2]];
}

function profileAnchors(raw, camZ){
  const out = { any:false, sides:{}, anchors:new Map(), disc:[], notes:[], pitch:0, pitchFrom:'assumed' };
  const frames = [];
  for (const p of (S.photos||[])){
    const role = p.role;
    if (role !== 'l90' && role !== 'r90') continue;
    if (!p.landmarks2D) continue;
    // Square unless the photograph says otherwise, so a synthetic frame with
    // no image behaves exactly as it always did.
    const ar = (p.img && p.img.naturalHeight) ? p.img.naturalWidth/p.img.naturalHeight : 1;
    const rows = [];
    for (const d of profVisible(role)){
      const m = p.landmarks2D[d.id];
      if (!m) continue;
      const idx = profMp(d, role);
      if (idx === undefined || !raw[idx]) continue;
      /* Canonical profile coordinates. Anterior is image-left on a left
         profile and image-right on a right profile, with v running down in
         both.

         The horizontal is multiplied by the photograph's aspect, and leaving
         that out cost a systematic depth error of 1/aspect. Marks are stored
         as fractions of the image, so u is divided by the WIDTH and v by the
         HEIGHT. On a 3:4 portrait one unit of u is 0.75 as many pixels as one
         unit of v, and the similarity below assumes one scale for both axes.
         Every traced profile therefore came out 33% too deep on a portrait
         photograph, which is every photograph a phone takes held upright.

         Measured on a real scanned face: nasal projection read 22.1 mm
         against a truth of 17.2 mm, and 22.1 × 0.75 = 16.6 mm. The synthetic
         marks in test21 carry no image at all, so aspect defaulted to 1 and
         the suite could never see this. */
      rows.push({ id:d.id, idx,
                  xi: (role === 'l90' ? -m[0] : m[0]) * ar,
                  eta: -m[1], Y: 0 });
    }
    /* Which way an off-midline point slides when the head is pitched. The
       lateral camera's vertical axis is (−sin e, cos e, 0) on a left profile
       and (sin e, cos e, 0) on a right one, so a point at X sits −σ·X·sin e
       above where a level camera would put it. That is the entire pitch
       signal, and it lives on the two lever marks. */
    if (rows.length >= 4) frames.push({ photo:p, role, rows, sigma: role === 'l90' ? -1 : 1 });
    else if (rows.length) out.notes.push(`${p.name || role}: only ${rows.length} profile mark${rows.length===1?'':'s'} — at least 4 are needed to fit the photograph to the model.`);
  }
  if (!frames.length) return out;

  /* Fit one photograph at an assumed head pitch.

     Iterate: heights depend on depth (Y = s·py), and depth is what we are
     solving for. The coupling is weak because s sits near 1, but "weak" is
     not "absent" — how many passes it takes scales with how wrong the
     detector's prior was, and on a strongly flattened prior three passes
     still leaves a few tenths of a percent on the table. Run to convergence
     instead of trusting a fixed count; it is thirteen points, so this costs
     nothing worth measuring.

     The pitch enters through what the similarity is fitted AGAINST. A level
     lateral photograph shows the model's own height, so the target is Y. A
     pitched one shows σ·X·sin e + Y·cos e, which is the same thing for a
     midline point and different for a lever mark. Nothing else changes, so
     the linear solve underneath is untouched. */
  const fitFrame = (f, e) => {
    const ce = Math.cos(e), se = Math.sin(e);
    let s = f.rows.map(r => 1 - raw[r.idx][2]/camZ);
    let map = null, Z = null;
    for (let pass=0; pass<12; pass++){
      f.rows.forEach((r,j) => {
        const px = raw[r.idx][0], py = raw[r.idx][1];
        r.Y = s[j]*(f.sigma*px*se + py*ce);
      });
      map = solveProfileMap(f.rows);
      if (!map || map.bad) break;
      // Depth from the fitted similarity, gauge pinned to the mean depth the
      // marked points already have.
      const Zraw = f.rows.map(r => map.a*r.xi - map.b*r.eta);
      const mean0 = f.rows.reduce((t,r)=>t+raw[r.idx][2],0)/f.rows.length;
      const meanR = Zraw.reduce((t,z)=>t+z,0)/Zraw.length;
      const tz = mean0 - meanR;
      Z = Zraw.map(z => z + tz);
      const sNext = Z.map(z => 1 - z/camZ);
      let move = 0;
      for (let j=0;j<sNext.length;j++) move = Math.max(move, Math.abs(sNext[j]-s[j]));
      s = sNext;
      if (move < 1e-10) break;
    }
    return { map, Z };
  };

  /* Solve the pitch shared by both photographs.

     A chin-up head is chin-up in every view, so one number serves both and the
     two lever marks per side become four constraints on it. Only the lever
     marks carry the signal: a midline mark has X near zero, so its target is
     Y·cos e whatever the pitch, and a uniform scale is exactly what the
     similarity absorbs. Without a lever mark the cost is flat and the search
     would be reading noise, so it is skipped and the level assumption stands.

     Measured on a real scanned face, an uncorrected 15° pitch cost 5.3 mm of
     nasal projection out of 17.2 mm, four times what the camera distance is
     worth. It is the one photography error that mattered. */
  const leverRows = frames.reduce(
    (t,f) => t + f.rows.filter(r => PROF_LEVER.includes(r.id)).length, 0);
  const PITCH_MAX = 22*Math.PI/180;
  let bestE = 0;
  if (leverRows >= 2){
    const cost = e => {
      let num = 0, den = 0;
      for (const f of frames){
        const g = fitFrame(f, e);
        if (!g.map || g.map.bad) return Infinity;
        num += g.map.rms*g.map.rms*f.rows.length;
        den += f.rows.length;
      }
      if (!den) return Infinity;
      /* A whisker of regularisation toward level. Four points is thin
         evidence, so a shallow minimum should not be allowed to run away with
         the head; a real pitch clears this easily. */
      return num/den + 4e-4*e*e;
    };
    let best = Infinity;
    for (let deg = -22; deg <= 22; deg++){
      const e = deg*Math.PI/180, c = cost(e);
      if (c < best){ best = c; bestE = e; }
    }
    // Golden refine inside the winning degree, so the answer is not quantised.
    let lo = Math.max(-PITCH_MAX, bestE - Math.PI/180),
        hi = Math.min( PITCH_MAX, bestE + Math.PI/180);
    const gr = (Math.sqrt(5)-1)/2;
    let x1 = hi - gr*(hi-lo), x2 = lo + gr*(hi-lo), c1 = cost(x1), c2 = cost(x2);
    for (let it=0; it<24 && hi-lo > 1e-5; it++){
      if (c1 < c2){ hi = x2; x2 = x1; c2 = c1; x1 = hi - gr*(hi-lo); c1 = cost(x1); }
      else        { lo = x1; x1 = x2; c1 = c2; x2 = lo + gr*(hi-lo); c2 = cost(x2); }
    }
    const xe = (c1 < c2) ? x1 : x2;
    if (isFinite(cost(xe))) bestE = xe;
    out.pitchFrom = 'solved';
  }
  out.pitch = bestE*180/Math.PI;

  for (const f of frames){
    const g = fitFrame(f, bestE);
    const map = g.map;
    f.Z = g.Z;
    f.map = map;
    if (!map){
      out.notes.push(`${f.photo.name || f.role}: the marks do not support a fit — they may be nearly collinear. Add the tragus and the outer canthus, which are what make the tilt measurable.`);
      continue;
    }
    if (map.bad){
      out.notes.push(`${f.photo.name || f.role}: rejected — the fitted tilt is ${(map.theta*180/Math.PI).toFixed(0)}°, past the 25° limit. Either this is not a true lateral or a mark is on the wrong feature.`);
      continue;
    }
    f.ok = true;
    out.sides[f.role] = {
      n: f.rows.length,
      tilt: map.theta*180/Math.PI,
      rms: map.rms,
      lever: PROF_LEVER.filter(id => f.rows.some(r=>r.id===id)),
    };
  }

  // Merge. A landmark marked on both sides is averaged; the gap between the
  // two is a real number worth showing — either this face is asymmetric or one
  // of the photographs is not the lateral it claims to be, and he asked to be
  // told which.
  const per = new Map();
  for (const f of frames){
    if (!f.ok) continue;
    f.rows.forEach((r,j) => {
      /* The tilt marks SHAPE the fit without being anchored BY it.

         The tragus and the outer canthus are here for their lever arm: every
         midline mark sits in a near-vertical line and pins the rotation only
         weakly, so these two are what make it observable. Anchoring their own
         depth as well costs far more than it buys. Measured against a real
         scan, anchoring them threw the tragus from 7 mm of error to 23 mm
         while the midline improved, for two reasons that compound: the tragus
         sits at the very edge of the front photograph where the detector
         places it worst, so the height the similarity is fitted against is
         itself shaky there; and its front-camera ray is steeply angled, so
         forcing a depth on it drags the point sideways as well.

         The midline is what a profile photograph measures well. Anchor that,
         and let the sides be carried by the smoothing. */
      if (PROF_LEVER.includes(r.id)) return;
      if (!per.has(r.idx)) per.set(r.idx, []);
      per.get(r.idx).push({ role:f.role, id:r.id, Z:f.Z[j] });
    });
  }
  for (const [idx, hits] of per){
    const Z = hits.reduce((t,h)=>t+h.Z,0)/hits.length;
    out.anchors.set(idx, Z);
    if (hits.length > 1){
      const spread = Math.max(...hits.map(h=>h.Z)) - Math.min(...hits.map(h=>h.Z));
      out.disc.push({ id:hits[0].id, idx, spread });
    }
  }
  out.any = out.anchors.size > 0;
  return out;
}

function obliqueAnchors(fit, raw, camZ, pos3){
  const out = { anchors:new Map(), hits:[], roles:[] };
  if (!fit || !fit.views) return out;
  const per = new Map();
  for (const v of fit.views.slice(1)){
    if (!(v.role === 'r45' || v.role === 'l45') || !v.solved) continue;
    const p = v.photo, marks = p && p.landmarks2D;
    if (!marks) continue;
    const c = new THREE.PerspectiveCamera(fit.fov, v.aspect, 0.05, 100);
    c.position.set(v.solved.params[0], v.solved.params[1], v.solved.params[2]);
    c.rotation.set(v.solved.params[3], v.solved.params[4], v.solved.params[5]);
    c.updateMatrixWorld(true); c.updateProjectionMatrix();
    const e = new THREE.Matrix4().multiplyMatrices(c.projectionMatrix, c.matrixWorldInverse).elements;
    let used = 0;
    for (const d of PROF_DEFS){
      if (!d.views.includes(v.role) || d.mp === undefined) continue;
      const m = marks[d.id]; if (!m) continue;
      const i = d.mp; if (!raw[i] || !pos3[i]) continue;
      const ox = m[0]*2 - 1, oy = 1 - m[1]*2;
      const err = s => {
        const px = s*raw[i][0], py = s*raw[i][1], pz = camZ*(1-s);
        const cw = e[3]*px + e[7]*py + e[11]*pz + e[15];
        if (cw <= 1e-6) return Infinity;
        const cx = (e[0]*px + e[4]*py + e[8]*pz + e[12])/cw;
        const cy = (e[1]*px + e[5]*py + e[9]*pz + e[13])/cw;
        return ((cx-ox)*v.aspect)**2 + (cy-oy)**2;
      };
      // Search the ray around where the point is now: a coarse sweep, then a
      // golden section on the best bracket. The error along one ray has a
      // single minimum, but the sweep costs nothing and keeps a bad mark from
      // walking the search off to a far bracket.
      const s0 = 1 - pos3[i][2]/camZ;
      let bs = s0, be = err(s0);
      for (let k=-60; k<=60; k++){ const s = s0 + k*0.002, q = err(s); if (q < be){ be = q; bs = s; } }
      let lo = bs-0.002, hi = bs+0.002;
      const gr = (Math.sqrt(5)-1)/2;
      let x1 = hi - gr*(hi-lo), x2 = lo + gr*(hi-lo), c1 = err(x1), c2 = err(x2);
      for (let it=0; it<40; it++){
        if (c1 < c2){ hi = x2; x2 = x1; c2 = c1; x1 = hi - gr*(hi-lo); c1 = err(x1); }
        else        { lo = x1; x1 = x2; c1 = c2; x2 = lo + gr*(hi-lo); c2 = err(x2); }
      }
      const s = c1 < c2 ? x1 : x2;
      if (Math.abs(s - s0) > 0.115) continue;          // off the end of the sweep: a mark on the wrong feature
      const Z = camZ*(1-s);
      if (!per.has(i)) per.set(i, []);
      per.get(i).push({ role:v.role, id:d.id, Z, moved:Z - pos3[i][2] });
      used++;
    }
    if (used) out.roles.push(v.role);
  }
  for (const [i, hs] of per){
    out.anchors.set(i, hs.reduce((t,h)=>t+h.Z,0)/hs.length);
    out.hits.push(...hs.map(h=>({ ...h, idx:i })));
  }
  return out;
}

function applyProfileAnchors(pos3, raw, nb, camZ, anchors){
  const n = raw.length;
  const s = new Float64Array(n);
  for (let i=0;i<n;i++) s[i] = 1 - pos3[i][2]/camZ;
  const d = new Float64Array(n);            // the correction, in s
  const fixed = new Uint8Array(n);
  for (const [idx, Z] of anchors){
    if (idx >= n) continue;
    fixed[idx] = 1;
    d[idx] = (1 - Z/camZ) - s[idx];
  }
  // Laplacian diffusion of the correction over the front topology.
  for (let it=0; it<160; it++){
    for (let i=0;i<n;i++){
      if (fixed[i]) continue;
      const nbi = nb[i];
      if (!nbi || !nbi.length) continue;
      let m=0; for (const j of nbi) m += d[j];
      d[i] = m/nbi.length;
    }
  }
  const out = new Array(n);
  for (let i=0;i<n;i++){
    const si = s[i] + d[i];
    out[i] = [ si*raw[i][0], si*raw[i][1], camZ*(1-si) ];
  }
  return out;
}

const PROJ_SHADOW = 1024;

function projMax(){
  const units = renderer?.capabilities?.maxTextures || 8;
  return Math.max(2, Math.min(6, Math.floor((units - 2) / 2)));
}

const projState = { on:false, targets:[], mat:null, n:0, coverage:0, dropped:[] };

function profileAutoPose(p){
  return (p.role === 'r90' || p.role === 'l90') && p.pose && p.pose.auto;
}

function projPick(photos, max){
  const usable = photos.filter(p => p.pose && p.img && !profileAutoPose(p) &&
                                    !(VIEW_BY_ID[p.role] && !VIEW_BY_ID[p.role].geo));
  if (usable.length <= max) return { chosen:usable, dropped:[] };
  const dirOf = p => {
    const q = p.pose.params, L = Math.hypot(q[0],q[1],q[2]) || 1;
    return [q[0]/L, q[1]/L, q[2]/L];
  };
  const chosen = [];
  const front = usable.find(p => p.id === S.frontId) || usable[0];
  chosen.push(front);
  const pickSpread = pool => {
    while (chosen.length < max && pool.length){
      let best = 0, bestScore = -Infinity;
      for (let i=0;i<pool.length;i++){
        const d = dirOf(pool[i]);
        // Distance from the nearest already-chosen direction: maximise it.
        let near = Infinity;
        for (const c of chosen){
          const e = dirOf(c);
          near = Math.min(near, 1 - (d[0]*e[0] + d[1]*e[1] + d[2]*e[2]));
        }
        if (near > bestScore){ bestScore = near; best = i; }
      }
      chosen.push(pool.splice(best,1)[0]);
    }
    return pool;
  };
  // Landmark-solved cameras first; silhouette-estimated ones fill whatever
  // budget remains. A silhouette camera carries a few degrees of guesswork —
  // fine for painting an ear, worse than a solved view anywhere they overlap.
  const solved = usable.filter(p => p !== front && !p.pose.silOnly);
  const sil    = usable.filter(p => p !== front &&  p.pose.silOnly);
  const dropped = [...pickSpread(solved), ...pickSpread(sil)];
  return { chosen, dropped };
}

function atlasSize(){
  const cap = renderer?.capabilities?.maxTextureSize || 4096;
  const w = cap < 4096 || CFG.atlasW === 2048 ? 2048 : 4096;
  return { w, h: w>>1 };
}

let ATLAS_W = 4096, ATLAS_H = 2048;

const ATLAS_HAIR = 0x1b1c21;

const atlasState = { on:false, tex:null, photoUV:null, coverage:0, names:[] };

function atlasUVArray(geom, nFace, shellUV){
  const pos = geom.attributes.position.array;
  const n = pos.length/3;
  const uv = new Float32Array(n*2);
  const nf = Math.max(0, Math.min(nFace === undefined ? n : nFace, n));
  let x0=Infinity, x1=-Infinity, y0=Infinity, y1=-Infinity;
  for (let i=0;i<nf;i++){
    const x=pos[3*i], y=pos[3*i+1];
    if (x<x0) x0=x; if (x>x1) x1=x; if (y<y0) y0=y; if (y>y1) y1=y;
  }
  const sx=(x1-x0)||1, sy=(y1-y0)||1;
  // The left half is 0.5 wide and 1 tall in uv, but the atlas pixels behind it
  // are square, so the box is 2048 by 2048 and the aspect maths is in texels.
  const k = Math.min((0.5-0.03)*ATLAS_W/sx, (1-0.03)*ATLAS_H/sy);
  const ox = (0.5*ATLAS_W - k*sx)/2, oy = (ATLAS_H - k*sy)/2;
  for (let i=0;i<nf;i++){
    uv[2*i]   = (ox + k*(pos[3*i]  -x0))/ATLAS_W;
    uv[2*i+1] = (oy + k*(pos[3*i+1]-y0))/ATLAS_H;
  }
  for (let i=nf;i<n;i++){
    const j = i-nf;
    const su = shellUV ? shellUV[2*j]   : 0;
    const sv = shellUV ? shellUV[2*j+1] : 0;
    uv[2*i]   = 0.5 + 0.005 + su*0.49;
    uv[2*i+1] = 0.005 + sv*0.99;
  }
  return uv;
}

function atlasShader(n){
  return {
    vertex: `
      varying vec3 vWorld;
      varying vec3 vNrm;
      void main(){
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorld = wp.xyz;
        vNrm = normalize(mat3(modelMatrix) * normal);
        gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
      }`,
    fragment: `
      uniform mat4 projMat[${n}];
      uniform vec3 projPos[${n}];
      uniform sampler2D projTex[${n}];
      uniform sampler2D projDepth[${n}];
      uniform float useDepth;
      uniform float bias;
      uniform float only;
      varying vec3 vWorld;
      varying vec3 vNrm;
      void main(){
        vec3 n = normalize(vNrm);
        vec3 acc = vec3(0.0);
        float wsum = 0.0;
        float wbsum = 0.0;
        float masked = 0.0;
${Array.from({length:n}, (_,i) => projUnit(i)).join('\n')}
        if (only > 0.5 && wsum > 0.0001){
          vec3 c1 = clamp(acc / max(wbsum, 1e-30), 0.0, 1.0);
          vec3 lo1 = c1 * 12.92;
          vec3 hi1 = 1.055 * pow(c1, vec3(1.0/2.4)) - 0.055;
          gl_FragColor = vec4(mix(hi1, lo1, step(c1, vec3(0.0031308))), clamp(wsum, 0.004, 1.0));
        }
        else if (wsum > 0.0001){
          /* Encode to sRGB on the way out.

             Sampling an sRGB-tagged photograph decodes it to linear, which is
             what the live wrap wants because it hands its result straight to a
             renderer that encodes on the way to the screen. A baked map has no
             such step: it is read back as bytes and handed BACK in as an
             sRGB texture, so without an encode here the values are decoded a
             second time and the whole model comes out near black. */
          vec3 c = clamp(acc / max(wbsum, 1e-30), 0.0, 1.0);
          vec3 lo = c * 12.92;
          vec3 hi = 1.055 * pow(c, vec3(1.0/2.4)) - 0.055;
          vec3 s = mix(hi, lo, step(c, vec3(0.0031308)));
          gl_FragColor = vec4(s, 1.0);
        }
        // Seen by a camera, but only through the ear it was told to ignore:
        // half alpha, so the readback can fill it from the skin around it.
        else if (masked > 0.0001) gl_FragColor = vec4(0.0, 0.0, 0.0, 0.5);
        else gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
      }`,
  };
}

function atlasDilate(px, w, h, passes, fill, seen){
  const has = new Uint8Array(w*h);
  for (let i=0;i<w*h;i++) has[i] = px[4*i+3] > 8 ? 1 : 0;
  // Which texels a camera actually reached, before any of them are bled into.
  if (seen) seen.set(has);
  for (let p=0; p<passes; p++){
    const grew = new Uint8Array(has);
    for (let y=0;y<h;y++){
      for (let x=0;x<w;x++){
        const i = y*w+x;
        if (has[i]) continue;
        let r=0,g=0,b=0,c=0;
        for (let dy=-1; dy<=1; dy++){
          const yy=y+dy; if (yy<0||yy>=h) continue;
          for (let dx=-1; dx<=1; dx++){
            const xx=x+dx; if (xx<0||xx>=w) continue;
            const j=yy*w+xx; if (!has[j]) continue;
            r+=px[4*j]; g+=px[4*j+1]; b+=px[4*j+2]; c++;
          }
        }
        if (!c) continue;
        px[4*i]=r/c|0; px[4*i+1]=g/c|0; px[4*i+2]=b/c|0; px[4*i+3]=255;
        grew[i]=1;
      }
    }
    has.set(grew);
  }
  let unseen = 0;
  for (let i=0;i<w*h;i++){
    if (has[i]) continue;
    unseen++;
    px[4*i]=fill[0]; px[4*i+1]=fill[1]; px[4*i+2]=fill[2]; px[4*i+3]=255;
  }
  // Reported for the tests. Coverage the user is shown is measured against the
  // charted surface instead, which is a much smaller and more honest divisor.
  return 1 - unseen/(w*h);
}

function atlasUnsharp(px, w, h, r, amt){
  // Two box blurs weighted by alpha (close to a gaussian), then px += amt * (px - blur) on solid texels.
  const n = w*h, A = new Float32Array(n), C = [new Float32Array(n), new Float32Array(n), new Float32Array(n)];
  for (let i=0;i<n;i++){ const a = px[4*i+3] > 128 ? 1 : 0; A[i]=a; for (let k=0;k<3;k++) C[k][i]=px[4*i+k]*a; }
  const blur = (src) => { const t = new Float32Array(n), o = new Float32Array(n);
    for (let y=0;y<h;y++){ let s=0; const row=y*w; for (let x=-r;x<=r;x++) s += src[row+Math.min(w-1,Math.max(0,x))];
      for (let x=0;x<w;x++){ t[row+x]=s; s += src[row+Math.min(w-1,x+r+1)] - src[row+Math.max(0,x-r)]; } }
    for (let x=0;x<w;x++){ let s=0; for (let y=-r;y<=r;y++) s += t[Math.min(h-1,Math.max(0,y))*w+x];
      for (let y=0;y<h;y++){ o[y*w+x]=s; s += t[Math.min(h-1,y+r+1)*w+x] - t[Math.max(0,y-r)*w+x]; } }
    return o; };
  const BA = blur(blur(A)), B = C.map(c => blur(blur(c)));
  for (let i=0;i<n;i++){ if (!A[i] || BA[i] < 1e-3) continue; for (let k=0;k<3;k++){ const b = B[k][i]/BA[i]; const v = px[4*i+k] + amt*(px[4*i+k]-b); px[4*i+k] = v < 0 ? 0 : v > 255 ? 255 : v; } }
}
function atlasFadeFaceRim(px, charted, w, h, bandTexels){
  const half = w >> 1;
  const FAR = 1e9;
  const d = new Float32Array(half*h);
  for (let y=0;y<h;y++) for (let x=0;x<half;x++)
    d[y*half+x] = charted[4*(y*w+x)+3] > 8 ? FAR : 0;
  const relax = (y,x,dy,dx,cost) => {
    const yy=y+dy, xx=x+dx;
    if (yy<0||yy>=h||xx<0||xx>=half) return;
    const c = d[yy*half+xx] + cost;
    if (c < d[y*half+x]) d[y*half+x] = c;
  };
  for (let y=0;y<h;y++) for (let x=0;x<half;x++){
    relax(y,x,-1,0,1); relax(y,x,0,-1,1); relax(y,x,-1,-1,1.414); relax(y,x,-1,1,1.414);
  }
  for (let y=h-1;y>=0;y--) for (let x=half-1;x>=0;x--){
    relax(y,x,1,0,1); relax(y,x,0,1,1); relax(y,x,1,1,1.414); relax(y,x,1,-1,1.414);
  }
  // The chart's left and right margins are empty, so a texel near the atlas
  // border is not near the FACE's border; the sweep already reports that
  // correctly because the margin itself is un-charted.
  for (let y=0;y<h;y++) for (let x=0;x<half;x++){
    const i = y*w+x;
    if (px[4*i+3] <= 8) continue;
    let t = Math.min(1, d[y*half+x]/bandTexels);
    t = t*t*(3-2*t);
    px[4*i+3] = Math.max(0, Math.min(255, Math.round(px[4*i+3]*t)));
  }
}

function atlasPaintMask(px, w, h, si, seen){
  /* The face's own chart is never masked. It is the photographed half of the
     model by definition. Everything in the right half is shell, and the shell's
     chart IS the (theta, phi) grid the keep field lives on, so a texel's cell
     is read straight back out of its atlas coordinates. No world positions, no
     re-deriving the hairline, and the field can hold whatever the shell build
     decided to keep. */
  const keep = si.keep, nT = si.nT, nP = si.nP;
  if (!keep) return;
  const half = w/2;
  for (let py=0; py<h; py++){
    const v = (py+0.5)/h;
    const sv = (v - 0.005)/0.99;
    if (sv < 0 || sv > 1) continue;
    // Shell chart: u = 0.505 + (i/nT)*0.49, v = 0.005 + (1-(j+0.5)/nP)*0.99.
    const fj = (1-sv)*nP - 0.5;
    const j0 = Math.floor(fj), tj = fj - j0;
    for (let px_ = half; px_ < w; px_++){
      const idx = py*w + px_;
      if (px[4*idx+3] <= 8) continue;
      const u = (px_+0.5)/w;
      const su = (u - 0.505)/0.49;
      if (su < 0 || su > 1){ px[4*idx+3] = 0; continue; }
      const fi = su*nT;
      const i0 = Math.floor(fi), ti = fi - i0;
      const at = (jj, ii) => {
        if (jj < 0 || jj >= nP) return 0;
        return keep[jj*nT + ((ii%nT)+nT)%nT];
      };
      const a = at(j0, i0)*(1-ti) + at(j0, i0+1)*ti;
      const b = at(j0+1, i0)*(1-ti) + at(j0+1, i0+1)*ti;
      let k = a*(1-tj) + b*tj;
      /* And nothing outside the mask survives on the strength of a fill.

         Where no camera reached, the dilation paints skin tone, and on the
         shell that skin tone was showing as a pale flat slab behind the ear —
         the concha, which is deliberately not built, and the strip behind the
         helix. Neither was photographed by anything, so neither is drawn. The
         face's own chart is exempt above, so a nostril or an under-chin that
         the front camera missed still gets its fill. */
      if (seen && !seen[idx]) k = 0;
      px[4*idx+3] = Math.max(0, Math.min(255, Math.round(k*255)));
    }
  }
}

let EAR_MASK_GROW = 0.06;

function buildAtlas(){
  const m = targets[0];
  if (!m) return { error:'Load or build a model first.' };
  if (projState.on) return { error:'Turn the live photo wrap off first — the atlas replaces it.' };
  const { chosen:photos } = projPick(S.photos, projMax());
  if (!photos.length) return { error:'No photograph has a solved camera pose yet.' };

  // Sized for this machine before anything is laid out against it.
  { const a = atlasSize(); ATLAS_W = a.w; ATLAS_H = a.h; }
  const geom = m.geometry;
  const si = S.shellInfo;
  const nFace = (si && si.ok && si.canon) ? si.nFace : geom.attributes.position.count;
  const atlasUV = atlasUVArray(geom, nFace, S.shellUV);
  if (!atlasState.photoUV) atlasState.photoUV = Float32Array.from(geom.attributes.uv.array);
  geom.setAttribute('uv', new THREE.Float32BufferAttribute(atlasUV, 2));

  // Depth maps, exactly as the live wrap builds them, so a nose cannot paint
  // itself onto the cheek behind it.
  const cams = photos.map(projCameraFor);
  const rts = [], deps = [], texs = [], mats = [], poss = [];
  const hide = [annoRoot, gridRoot, dangerRoot, kpRoot, rulerRoot, phiRoot];
  const wasVisible = hide.map(g => g.visible);
  hide.forEach(g => g.visible = false);
  const prevOverride = scene.overrideMaterial;
  scene.overrideMaterial = new THREE.MeshBasicMaterial({ color:0x808080, side:THREE.DoubleSide });
  const prevRT = renderer.getRenderTarget();
  for (let i=0;i<photos.length;i++){
    const rt = new THREE.WebGLRenderTarget(PROJ_SHADOW, PROJ_SHADOW);
    rt.texture.minFilter = THREE.NearestFilter; rt.texture.magFilter = THREE.NearestFilter;
    rt.depthTexture = new THREE.DepthTexture(PROJ_SHADOW, PROJ_SHADOW);
    rt.depthTexture.type = THREE.UnsignedIntType;
    renderer.setRenderTarget(rt); renderer.clear();
    renderer.render(scene, cams[i]);
    rts.push(rt); deps.push(rt.depthTexture);
  }
  scene.overrideMaterial = prevOverride;
  hide.forEach((g,i) => g.visible = wasVisible[i]);

  /* Downscale each photograph before it goes to the GPU (v29).

     A phone camera hands over 2544 by 3392, which is 34 MB of RGBA per
     photograph once uploaded, and the bake was measured costing about 400 ms
     per photograph on a desktop — 2.0 seconds for one view, 3.6 for five. None
     of that resolution reaches the model: the face occupies roughly 1400
     texels of the atlas, so anything past about 1600 pixels on the long side
     is uploaded, sampled once at less than one to one, and thrown away.

     It matters more for memory than for milliseconds. Five full-size textures
     is 170 MB of GPU memory, which is a large fraction of what a mid-range
     Android will give a browser tab, and running out shows up as a lost
     context rather than as a slow bake. */
  const PHOTO_MAX = CFG.photoMax;
  const earMeshes = m.children.filter(c => c.userData && c.userData.isEarMesh);
  for (let i=0;i<photos.length;i++){
    mats.push(new THREE.Matrix4().multiplyMatrices(cams[i].projectionMatrix, cams[i].matrixWorldInverse));
    poss.push(cams[i].position.clone());
    const im = photos[i].img;
    const big = Math.max(im.naturalWidth, im.naturalHeight);
    const k = big > PHOTO_MAX ? PHOTO_MAX/big : 1;
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(im.naturalWidth*k));
    c.height = Math.max(1, Math.round(im.naturalHeight*k));
    const g2 = c.getContext('2d', { willReadFrequently:true });
    g2.drawImage(im, 0, 0, c.width, c.height);
    let src = c;
    /* The photograph's own ear is withheld from the map when EAR_MASK_GROW is
       set: see the note on it. */
    if (EAR_MASK_GROW > 0 && earMeshes.length && CFG.earMask){
      const W2 = c.width, H2 = c.height, mk = document.createElement('canvas');
      mk.width = W2; mk.height = H2;
      const mg = mk.getContext('2d', { willReadFrequently:true });
      mg.fillStyle = '#fff'; mg.strokeStyle = '#fff'; mg.lineJoin = 'round';
      const camL = cams[i].position, v3 = new THREE.Vector3();
      let drew = false;
      for (const em of earMeshes){
        const e = si && si._ears && si._ears[em.userData.side];
        if (!e || (camL.x - si.centre[0])*e.sx < -0.02) continue;
        const P = em.geometry.attributes.position.array, I = em.geometry.index.array;
        const xy = new Float32Array(P.length/3*2);
        let y0 = Infinity, y1 = -Infinity;
        for (let q=0;q<P.length/3;q++){
          v3.set(P[3*q], P[3*q+1], P[3*q+2]).project(cams[i]);
          xy[2*q] = (v3.x*0.5+0.5)*W2; xy[2*q+1] = (0.5-v3.y*0.5)*H2;
          y0 = Math.min(y0, xy[2*q+1]); y1 = Math.max(y1, xy[2*q+1]);
        }
        mg.lineWidth = Math.max(2, 2*EAR_MASK_GROW*(y1-y0));
        mg.beginPath();
        for (let t2=0;t2<I.length;t2+=3){
          const a=I[t2], b=I[t2+1], d=I[t2+2];
          mg.moveTo(xy[2*a],xy[2*a+1]); mg.lineTo(xy[2*b],xy[2*b+1]); mg.lineTo(xy[2*d],xy[2*d+1]); mg.closePath();
        }
        mg.fill(); mg.stroke(); drew = true;
      }
      if (drew){
        const id = g2.getImageData(0,0,W2,H2), md = mg.getImageData(0,0,W2,H2).data;
        for (let q=0;q<W2*H2;q++) if (md[4*q+3] > 0) id.data[4*q+3] = 0;
        src = id;
      }
    }
    const t = new THREE.Texture(src);
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    t.minFilter = THREE.LinearFilter; t.magFilter = THREE.LinearFilter;
    t.needsUpdate = true;
    texs.push(t);
  }

  const src = atlasShader(photos.length);
  const bakeMat = new THREE.ShaderMaterial({
    uniforms: {
      projMat:{value:mats}, projPos:{value:poss}, projTex:{value:texs}, projDepth:{value:deps},
      useDepth:{value: ($('#projOcclude') && $('#projOcclude').checked) ? 1 : 0},
      bias:{value:0.0024}, only:{value:0},
    },
    vertexShader: src.vertex, fragmentShader: src.fragment,
    side: THREE.DoubleSide, transparent: true, depthTest: false, depthWrite: false,
  });

  /* Bake in a scene of its own. The mesh is drawn in UV space, so it has no
     business being in the scene that the user is looking at, and the camera it
     is drawn with is ignored entirely by the vertex shader. */
  const rt = new THREE.WebGLRenderTarget(ATLAS_W, ATLAS_H);
  rt.texture.minFilter = THREE.LinearFilter; rt.texture.magFilter = THREE.LinearFilter;
  const bakeScene = new THREE.Scene();
  const bakeMesh = new THREE.Mesh(geom, bakeMat);
  bakeMesh.matrixAutoUpdate = false;
  bakeMesh.matrix.copy(m.matrixWorld);
  bakeMesh.matrixWorld.copy(m.matrixWorld);
  bakeScene.add(bakeMesh);
  renderer.setRenderTarget(rt);
  renderer.setClearColor(0x000000, 0);
  renderer.clear();
  renderer.render(bakeScene, new THREE.Camera());

  const px = new Uint8Array(ATLAS_W*ATLAS_H*4);
  renderer.readRenderTargetPixels(rt, 0, 0, ATLAS_W, ATLAS_H, px);
  const perCam = [];
  if (CFG.perCamera && photos.length > 1) {
    // No blending: the sample must come back as it is, with the weight in alpha beside it.
    bakeMat.blending = THREE.NoBlending;
    for (let i = 0; i < photos.length; i++) {
      bakeMat.uniforms.only.value = i + 1;
      renderer.setRenderTarget(rt); renderer.clear();
      renderer.render(bakeScene, new THREE.Camera());
      const one = new Uint8Array(ATLAS_W*ATLAS_H*4);
      renderer.readRenderTargetPixels(rt, 0, 0, ATLAS_W, ATLAS_H, one);
      perCam.push(one);
    }
    bakeMat.uniforms.only.value = 0;
    bakeMat.blending = THREE.NormalBlending;
    CFG.perCamera(px, perCam, ATLAS_W, ATLAS_H, photos);
  }

  /* A second pass with no camera test, so coverage can be reported against the
     charted surface rather than against the whole square. Most of the atlas is
     empty margin between the two charts, and calling that "not covered" would
     read as a failure every time. */
  /* The same pass carries the world position, scaled into the byte range over
     the model's own bounding box. Eight bits across a head is a little over a
     millimetre, which is far finer than the band a hairline is painted over,
     and it saves plumbing every hairline parameter into GLSL. Alpha doubles as
     the charted mask. */
  geom.computeBoundingBox();
  const bb = geom.boundingBox;
  const lo = [bb.min.x, bb.min.y, bb.min.z];
  const span = [Math.max(1e-6, bb.max.x-bb.min.x),
                Math.max(1e-6, bb.max.y-bb.min.y),
                Math.max(1e-6, bb.max.z-bb.min.z)];
  const maskMat = new THREE.ShaderMaterial({
    uniforms: { lo:{value:new THREE.Vector3(...lo)}, span:{value:new THREE.Vector3(...span)} },
    vertexShader: src.vertex,
    fragmentShader: `
      uniform vec3 lo; uniform vec3 span;
      varying vec3 vWorld; varying vec3 vNrm;
      void main(){ gl_FragColor = vec4(clamp((vWorld - lo)/span, 0.0, 1.0), 1.0); }`,
    side: THREE.DoubleSide, depthTest:false, depthWrite:false,
  });
  bakeMesh.material = maskMat;
  renderer.setRenderTarget(rt); renderer.clear();
  renderer.render(bakeScene, new THREE.Camera());
  const mask = new Uint8Array(ATLAS_W*ATLAS_H*4);
  renderer.readRenderTargetPixels(rt, 0, 0, ATLAS_W, ATLAS_H, mask);
  maskMat.dispose();
  renderer.setRenderTarget(prevRT);

  let charted = 0, painted = 0;
  for (let i=0;i<ATLAS_W*ATLAS_H;i++){
    if (mask[4*i+3] <= 8) continue;
    charted++;
    if (px[4*i+3] > 8) painted++;
  }
  const coverage = charted ? painted/charted : 0;

  // The tone comes off a canvas, so it is already sRGB bytes. Taking it
  // through THREE.Color would convert it to linear and fill the unseen ear
  // with something far darker than the cheek beside it.
  const tone = skinToneFromFront();
  /* Texels withheld from the ear mask are surface a camera did see, so they
     are filled from the skin round them, bled inward a texel a pass, rather
     than left for the flood fill or cut away with the unseen. */
  const allowed = [];
  for (let i=0;i<ATLAS_W*ATLAS_H;i++){
    const a = px[4*i+3];
    if (a > 64 && a < 192){ allowed.push(i); px[4*i+3] = 0; }
  }
  if (allowed.length){
    let left = allowed;
    for (let pass=0; pass<80 && left.length; pass++){
      const next = [], done = [];
      for (const i of left){
        const x = i % ATLAS_W, y = (i - x)/ATLAS_W;
        let r=0,g=0,b=0,c=0;
        for (let dy=-1; dy<=1; dy++){
          const yy=y+dy; if (yy<0||yy>=ATLAS_H) continue;
          for (let dx=-1; dx<=1; dx++){
            const xx=x+dx; if (xx<0||xx>=ATLAS_W) continue;
            const j=yy*ATLAS_W+xx; if (px[4*j+3] <= 8) continue;
            r+=px[4*j]; g+=px[4*j+1]; b+=px[4*j+2]; c++;
          }
        }
        if (c) done.push([i, r/c|0, g/c|0, b/c|0]); else next.push(i);
      }
      for (const [i,r,g,b] of done){ px[4*i]=r; px[4*i+1]=g; px[4*i+2]=b; px[4*i+3]=255; }
      left = next;
    }
  }
  const seen = new Uint8Array(ATLAS_W*ATLAS_H);
  atlasDilate(px, ATLAS_W, ATLAS_H, 3, [(tone>>16)&255, (tone>>8)&255, tone&255], seen);
  for (const i of allowed) seen[i] = 1;
  atlasState.seen = { seen, w: ATLAS_W, h: ATLAS_H };
  if (si && si.ok && si.canon && si.keep)
    atlasPaintMask(px, ATLAS_W, ATLAS_H, si, seen);
  // 26 texels of a 2048-tall face chart is roughly two millimetres of skin.
  atlasFadeFaceRim(px, mask, ATLAS_W, ATLAS_H, 26);
  if (CFG.usm) atlasUnsharp(px, ATLAS_W, ATLAS_H, CFG.usm.r, CFG.usm.amt);

  // WebGL hands back rows bottom-up; a canvas is top-down. Flip on the way in
  // so the default flipY upload lands v=0 at the bottom, where the bake put it.
  const cv = document.createElement('canvas');
  cv.width = ATLAS_W; cv.height = ATLAS_H;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(ATLAS_W, ATLAS_H);
  const row = ATLAS_W*4;
  for (let y=0;y<ATLAS_H;y++) img.data.set(px.subarray((ATLAS_H-1-y)*row, (ATLAS_H-y)*row), y*row);
  ctx.putImageData(img, 0, 0);

  if (atlasState.tex) atlasState.tex.dispose();
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  tex.needsUpdate = true;

  for (const r of rts){ if (r.depthTexture) r.depthTexture.dispose(); r.dispose(); }
  for (const t of texs) t.dispose();
  bakeMat.dispose(); rt.dispose();

  atlasState.tex = tex;
  atlasState.on = true;
  atlasState.coverage = coverage;
  atlasState.names = photos.map(p => p.name);
  applyAtlasMaterials(tex);
  return { n:photos.length, coverage, names:atlasState.names };
}

function applyAtlasMaterials(tex){
  const m = targets[0];
  if (!m) return;
  const mat = new THREE.MeshStandardMaterial({
    map:tex,
    /* Front faces only, now that the model is a mask (v27).

       With the back of the head cut away you look straight through the shell,
       and a DoubleSide material draws its INSIDE — lit from behind, so it came
       out as two dark horns at the temples and a dark wedge under the jaw.
       Those were not geometry errors; they were the inside of the head. Culled,
       the cut simply shows the background, which is what was asked for. */
    side:THREE.FrontSide, roughness:0.72, metalness:0,
    /* The mask's edge. Alpha-test rather than blending, so nothing has to be
       depth-sorted, and alpha-to-coverage so the contour is antialiased by the
       same multisampling the rest of the scene already uses. The result is a
       smooth edge that dissolves into whatever background is behind it, light
       or dark, instead of a hard rim or a staircase of dropped quads. */
    alphaTest: 0.5, alphaToCoverage: true, transparent: false });
  if (Array.isArray(m.material)){
    const next = m.material.slice();
    for (const g of (S.atlasGroups || [0])) if (next[g]) next[g] = mat;
    m.material = next;
    baseMats = next.map(x => ({ mat:x, map:x.map || null }));
  } else {
    m.material = mat;
    baseMats = [{ mat, map:tex }];
  }
  refreshWireframe();
}

function projCameraFor(photo){
  const q = photo.pose;
  if (!q || !photo.img) return null;
  const cam = new THREE.PerspectiveCamera(q.fov, photo.img.naturalWidth/photo.img.naturalHeight, 0.05, 100);
  cam.position.set(q.params[0], q.params[1], q.params[2]);
  cam.rotation.set(q.params[3], q.params[4], q.params[5]);
  cam.updateMatrixWorld(true);
  cam.updateProjectionMatrix();
  return cam;
}

function projUnit(i){
  return `
        {
          vec4 cp = projMat[${i}] * vec4(vWorld, 1.0);
          if (cp.w > 0.0){
            vec3 ndc = cp.xyz / cp.w;
            if (abs(ndc.x) <= 1.0 && abs(ndc.y) <= 1.0){
              vec3 toCam = normalize(projPos[${i}] - vWorld);
              float facing = dot(n, toCam);
              vec2 uv = ndc.xy * 0.5 + 0.5;
              bool blocked = false;
              if (useDepth > 0.5){
                float dz = texture2D(projDepth[${i}], uv).x;
                blocked = (ndc.z * 0.5 + 0.5 - dz) > bias;
              }
              if (facing > ${CFG.facingMin.toFixed(3)} && !blocked){
                vec2 e = smoothstep(vec2(0.0), vec2(0.07), uv)
                       * (1.0 - smoothstep(vec2(0.93), vec2(1.0), uv));
                float w = pow(facing, 3.0) * e.x * e.y;
                float wb = pow(facing, ${CFG.facePow.toFixed(2)}) * e.x * e.y;
                vec4 tx = texture2D(projTex[${i}], uv);
                if (only > 0.5 && abs(only - ${i + 1}.0) > 0.5) w = 0.0;
                if (w > 0.0001 && tx.a > 0.5){
                  acc += tx.rgb * wb;
                  wbsum += wb;
                  wsum += w;
                } else if (w > 0.0001) masked += w;
              }
            }
          }
        }`;
}

function busy(){}

function classifyCamera(camPos, role, coarse){
  const def = VIEW_BY_ID[role];
  if (!def) return null;
  const L = Math.hypot(camPos[0], camPos[1], camPos[2]) || 1;
  const angTo = d => {
    const l = Math.hypot(d[0],d[1],d[2]) || 1;
    return Math.acos(Math.max(-1, Math.min(1,
      (d[0]*camPos[0] + d[1]*camPos[1] + d[2]*camPos[2]) / (l*L)))) * 180/Math.PI;
  };
  let det = 'other', bestAng = Infinity;
  for (const cand of VIEW_DEFS){
    if (!cand.geo) continue;
    const a = angTo(cand.dir);
    if (a < bestAng){ bestAng = a; det = cand.id; }
  }
  const deg = Math.round(angTo(def.dir));
  const lim = coarse ? [25, 40] : [15, 30];
  // Chin-up and chin-down vary far more between patients than a turn does —
  // 'submental' spans a 30° range of real necks. Do not nag about it.
  if (role==='up' || role==='down'){ lim[0] = Math.round(lim[0]*1.5); lim[1] = Math.round(lim[1]*1.5); }
  return {
    state: deg <= lim[0] ? 'ok' : deg <= lim[1] ? 'warn' : 'bad',
    det, detLabel: (VIEW_BY_ID[det]||{}).label || 'other', deg,
  };
}

// ---------- what the clinic's build script uses ----------
export { THREE, S, CFG, UI, renderer, scene, camera, modelRoot, targets, VIEW_DEFS, VIEW_BY_ID, FIT, HULL, atlasState,
  getLandmarker, detectFor, applyAlarMarks, fitMultiView, lmToRaw, referenceDepthPrior, profileAnchors, obliqueAnchors, frontTopology,
  applyProfileAnchors, installFaceMesh, poseFromFit, classifyCamera, headMask, estimateSilhouettePose, estimateHairline,
  attachCanonicalShell, applyShellRefinement, projPick, projMax, projCameraFor, buildAtlas, applyAtlasMaterials, skinToneFromFront, mm2u, clearModel };
export function fileInto(rec, role) {
  if (role !== 'other') { const held = S.photos.find(p => p.role === role && p.id !== rec.id); if (held) held.role = 'other'; }
  rec.role = role; rec.check = null;
  if (role === 'front') { S.frontId = rec.id; S.refId = rec.id; }
  if (!S.frontId) { const f = S.photos.find(p => p.role === 'front'); if (f) S.frontId = f.id; }
  if (!S.refId) S.refId = rec.id;
}
