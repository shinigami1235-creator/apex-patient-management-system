// Shows a built head: the standard views, turning by drag, picking a point on the
// surface for a mark, and projecting a surface point back to the picture.
import * as THREE from '../../vendor/three.module.min.js';
import { parseMesh, atlasFromFiles } from './head-files.mjs';

// The standard views. az is the camera's turn about the patient: +X is the patient's left,
// so a positive az looks at the patient's left side.
export const STD_VIEWS = [
  { key: 'front', label: 'Front', az: 0 },
  { key: 'right45', label: 'Right 45°', az: -45 },
  { key: 'left45', label: 'Left 45°', az: 45 },
  { key: 'right', label: 'Right side', az: -90 },
  { key: 'left', label: 'Left side', az: 90 },
];
export const THUMB_W = 600, THUMB_H = 800;
const FOV = 32, FILL = 0.78;

export { THREE };

// Geometry and texture from the head's stored files.
export async function loadHeadFiles({ meshUrl, atlasUrl, alphaUrl, maxAtlas = 0 }) {
  const res = await fetch(meshUrl, { credentials: 'same-origin' });
  if (!res.ok) throw new Error('The head file could not be loaded.');
  const { header, pos, nrm, uv, idx } = parseMesh(await res.arrayBuffer());
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(new THREE.BufferAttribute(idx, 1));
  for (const gr of header.groups) g.addGroup(gr.start, gr.count, gr.materialIndex);
  g.computeBoundingBox(); g.computeBoundingSphere();
  const canvas = await atlasFromFiles(atlasUrl, alphaUrl, { max: maxAtlas });
  return { geometry: g, atlas: canvas, lm3: header.lm3 };
}

export function headMaterial(atlasCanvas, renderer) {
  const tex = new THREE.CanvasTexture(atlasCanvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer ? renderer.capabilities.getMaxAnisotropy() : 1;
  tex.needsUpdate = true;
  const mat = new THREE.MeshStandardMaterial({ map: tex, side: THREE.FrontSide, roughness: 0.72, metalness: 0, alphaTest: 0.5, alphaToCoverage: true, transparent: false });
  return [mat, mat, mat];
}

function makeScene(bg) {
  const sc = new THREE.Scene();
  sc.background = new THREE.Color(bg);
  sc.add(new THREE.HemisphereLight(0xd9e6f2, 0x1b1f26, 1.05));
  const k = new THREE.DirectionalLight(0xffffff, 1.5); k.position.set(1.4, 1.6, 3);
  const f = new THREE.DirectionalLight(0xbcd4ea, 0.55); f.position.set(-2.2, 0.4, 1.2);
  const r = new THREE.DirectionalLight(0x9fb6cc, 0.4); r.position.set(0, 1.2, -3);
  sc.add(k, f, r);
  return sc;
}

// The camera distance that fits the head's box at this aspect, the same for every view
// so the standard pictures of one head line up with each other.
function fitDistance(box, aspect) {
  const sz = box.getSize(new THREE.Vector3());
  const vFov = FOV * Math.PI / 180, hFov = 2 * Math.atan(Math.tan(vFov / 2) * aspect);
  const span = Math.max(sz.x, sz.z);
  return Math.max((sz.y / 2) / (FILL * Math.tan(vFov / 2)), (span / 2) / (FILL * Math.tan(hFov / 2))) + span / 2;
}

// A viewer on a canvas. mesh: a THREE.Mesh of the head.
export function makeViewer(canvas, mesh, { bg = 0xffffff, renderer = null } = {}) {
  const R = renderer || new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
  R.outputColorSpace = THREE.SRGBColorSpace;
  const scene = makeScene(bg);
  const camera = new THREE.PerspectiveCamera(FOV, 1, 0.01, 100);
  scene.add(mesh);
  mesh.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(mesh);
  const centre = box.getCenter(new THREE.Vector3());
  const ray = new THREE.Raycaster();
  const V = { az: 0, el: 0, zoom: 1, w: 1, h: 1 };

  function size(w, h) {
    V.w = Math.max(1, Math.round(w)); V.h = Math.max(1, Math.round(h));
    R.setSize(V.w, V.h, false);
    camera.aspect = V.w / V.h; camera.updateProjectionMatrix();
    place();
  }
  function place() {
    const d = fitDistance(box, camera.aspect) / V.zoom;
    const a = V.az * Math.PI / 180, e = Math.max(-88, Math.min(88, V.el)) * Math.PI / 180;
    camera.position.set(centre.x + Math.sin(a) * Math.cos(e) * d, centre.y + Math.sin(e) * d, centre.z + Math.cos(a) * Math.cos(e) * d);
    camera.up.set(0, 1, 0);
    camera.lookAt(centre);
    camera.updateMatrixWorld(true);
  }
  function setAngles(az, el = 0) { V.az = ((az + 180) % 360 + 360) % 360 - 180; V.el = el; place(); }
  function setView(key) { const v = STD_VIEWS.find(x => x.key === key); if (v) setAngles(v.az, 0); }
  function setZoom(z) { V.zoom = Math.max(0.5, Math.min(6, z)); place(); }
  function render() { R.render(scene, camera); }

  // The surface point under a canvas position (fractions of width and height), or null.
  function pick(fx, fy) {
    ray.setFromCamera(new THREE.Vector2(fx * 2 - 1, 1 - fy * 2), camera);
    const hits = ray.intersectObject(mesh, false);
    for (const h of hits) {
      if (!texelSolid(h)) continue;
      const n = h.face.normal.clone().transformDirection(mesh.matrixWorld).normalize();
      const b = bary(h);
      return { tri: h.faceIndex, b: b.map(v => +v.toFixed(4)), p: h.point.toArray().map(v => +v.toFixed(4)), n: n.toArray().map(v => +v.toFixed(3)) };
    }
    return null;
  }
  // The first surface point along a ray in the head's own space, or null. Templates use it
  // to set their points onto the skin.
  function pickRay(origin, dir) {
    ray.set(new THREE.Vector3(...origin), new THREE.Vector3(...dir).normalize());
    for (const h of ray.intersectObject(mesh, false)) {
      if (!texelSolid(h)) continue;
      const n = h.face.normal.clone().transformDirection(mesh.matrixWorld).normalize();
      return { tri: h.faceIndex, b: bary(h).map(v => +v.toFixed(4)), p: h.point.toArray().map(v => +v.toFixed(4)), n: n.toArray().map(v => +v.toFixed(3)) };
    }
    return null;
  }
  // A point's place on the canvas as fractions, with no check that it can be seen.
  function screen(p) {
    const v = new THREE.Vector3(...p).project(camera);
    return { x: v.x * 0.5 + 0.5, y: 0.5 - v.y * 0.5 };
  }
  // A point's place on the canvas as fractions, with whether the surface there faces the
  // camera and is not hidden behind the head.
  function project(p, n) {
    const v = new THREE.Vector3(...p).project(camera);
    const x = v.x * 0.5 + 0.5, y = 0.5 - v.y * 0.5;
    const toCam = camera.position.clone().sub(new THREE.Vector3(...p)).normalize();
    let visible = !n || toCam.dot(new THREE.Vector3(...n)) > 0.08;
    if (visible) {
      ray.set(camera.position, new THREE.Vector3(...p).sub(camera.position).normalize());
      const dist = camera.position.distanceTo(new THREE.Vector3(...p));
      const hits = ray.intersectObject(mesh, false).filter(texelSolid);
      if (hits.length && hits[0].distance < dist - 0.012) visible = false;
    }
    return { x: +x.toFixed(4), y: +y.toFixed(4), visible };
  }
  // A triangle and barycentric weights back to a point on this head.
  function pointAt(tri, b) {
    const g = mesh.geometry, I = g.index.array, P = g.attributes.position;
    const i0 = I[3 * tri], i1 = I[3 * tri + 1], i2 = I[3 * tri + 2];
    const out = [0, 0, 0];
    for (let k = 0; k < 3; k++) out[k] = P.getComponent(i0, k) * b[0] + P.getComponent(i1, k) * b[1] + P.getComponent(i2, k) * b[2];
    return new THREE.Vector3(...out).applyMatrix4(mesh.matrixWorld).toArray();
  }
  function bary(h) {
    const g = mesh.geometry, I = g.index.array, P = g.attributes.position;
    const i = h.faceIndex * 3;
    const a = new THREE.Vector3().fromBufferAttribute(P, I[i]).applyMatrix4(mesh.matrixWorld);
    const b = new THREE.Vector3().fromBufferAttribute(P, I[i + 1]).applyMatrix4(mesh.matrixWorld);
    const c = new THREE.Vector3().fromBufferAttribute(P, I[i + 2]).applyMatrix4(mesh.matrixWorld);
    const out = new THREE.Vector3();
    THREE.Triangle.getBarycoord(h.point, a, b, c, out);
    return out.toArray();
  }
  // The mask is in the texture's alpha, so a hit through a cut-away texel is not a hit.
  function texelSolid(h) {
    const mat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
    const img = mat.map && mat.map.image;
    if (!h.uv || !img || !img.getContext) return true;
    if (!texelSolid.ctx || texelSolid.img !== img) { texelSolid.ctx = img.getContext('2d', { willReadFrequently: true }); texelSolid.img = img; }
    const x = Math.min(img.width - 1, Math.max(0, Math.floor(h.uv.x * img.width)));
    const y = Math.min(img.height - 1, Math.max(0, Math.floor((mat.map.flipY === false ? h.uv.y : 1 - h.uv.y) * img.height)));
    return texelSolid.ctx.getImageData(x, y, 1, 1).data[3] >= 128;
  }
  // The same point in one of the standard pictures (600 by 800), whatever the viewer shows now.
  function projectInView(key, p, n) {
    const sv = STD_VIEWS.find(x => x.key === key);
    const keep = { az: V.az, el: V.el, zoom: V.zoom, aspect: camera.aspect };
    camera.aspect = THUMB_W / THUMB_H; camera.updateProjectionMatrix();
    V.az = sv.az; V.el = 0; V.zoom = 1; place();
    const r = project(p, n);
    camera.aspect = keep.aspect; camera.updateProjectionMatrix();
    V.az = keep.az; V.el = keep.el; V.zoom = keep.zoom; place();
    return r;
  }
  function snapshot(type = 'image/jpeg', q = 0.88) { render(); return new Promise(r => canvas.toBlob(r, type, q)); }
  function dispose() { scene.remove(mesh); if (!renderer) R.dispose(); }

  size(canvas.width || 1, canvas.height || 1);
  return { R, scene, camera, mesh, box, V, size, place, setAngles, setView, setZoom, render, pick, pickRay, screen, project, projectInView, pointAt, snapshot, dispose };
}

// A head mesh from loaded files.
export function headMesh(loaded, renderer) {
  const m = new THREE.Mesh(loaded.geometry, headMaterial(loaded.atlas, renderer));
  m.userData.lm3 = loaded.lm3;
  return m;
}

// The five standard pictures of a head, each as a blob, plus the projections of any
// points given.
export async function standardShots(mesh, { w = THUMB_W, h = THUMB_H, bg = 0xffffff, renderer = null } = {}) {
  const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  const v = makeViewer(canvas, mesh, { bg, renderer });
  v.size(w, h);
  const out = {};
  for (const sv of STD_VIEWS) { v.setView(sv.key); out[sv.key] = await v.snapshot('image/jpeg', 0.88); }
  v.dispose();
  return out;
}
