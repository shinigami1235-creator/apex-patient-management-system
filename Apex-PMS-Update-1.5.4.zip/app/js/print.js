// Printouts. Each builds a page into #print and opens the browser's print dialog,
// where Save as PDF is also offered.

function printHead() {
  const c = S.clinic;
  return `<div class="ph-head"><img src="${c.logo ? fileURL(c.logo) : 'assets/logo.png'}" alt=""><div class="c"><b>${esc(c.name)}</b><span>${esc([c.address, c.phone, c.email].filter(Boolean).join(' · '))}</span></div></div>`;
}
function printFoot() {
  return `<div class="foot">${esc(S.clinic.footer || '')}${S.clinic.footer ? ' · ' : ''}Printed ${fmtStamp(Date.now())} by ${esc(S.me.name)}</div>`;
}
function patientLine(p, date) {
  return `<table><tr><td><b>${esc(p.name)}</b><br>${esc(p.no || '')}</td><td>${p.dob ? `Born ${fmtDate(p.dob)}<br>${ageOf(p.dob, date || todayISO())} years` : ''}</td><td>${esc(p.sex || '')}<br>${esc(p.phone || '')}</td><td>${date ? 'Date<br><b>' + fmtDate(date) + '</b>' : ''}</td></tr></table>`;
}

async function doPrint(html, title, { receipt = false } = {}) {
  let el = document.getElementById('print');
  if (!el) { el = document.createElement('div'); el.id = 'print'; document.body.appendChild(el); }
  el.innerHTML = html;
  await Promise.all([...el.querySelectorAll('img')].map(img => (img.complete ? null : new Promise(r => { img.onload = img.onerror = r; }))));
  const oldTitle = document.title;
  if (title) document.title = title;
  document.body.classList.add('printing');
  document.body.classList.toggle('print-receipt', receipt);
  const done = () => { document.body.classList.remove('printing', 'print-receipt'); document.title = oldTitle; window.removeEventListener('afterprint', done); };
  window.addEventListener('afterprint', done);
  setTimeout(() => window.print(), 50);
}

function alertsText(p) {
  const out = [];
  out.push((p.allergies || []).length ? 'Allergies: ' + p.allergies.map(a => `${a.what}${a.reaction ? ' (' + a.reaction + ')' : ''}`).join('; ') : (p.nka ? 'No known allergies' : 'Allergies not recorded'));
  const sc = SCREEN.filter(s => p.screen && p.screen[s.k]).map(s => s.label);
  if (sc.length) out.push(sc.join('; '));
  return out.map(esc).join('<br>');
}

// The 2D charts of a visit in a row. A 3D head chart gets a sheet of its own, below.
async function chartsPrintHTML(v) {
  const charts = chartsOfVisit(v.id).filter(c => (c.marks || []).length && c.view !== HEAD_CHART.key);
  // the notes written on each area of the chart
  const notes = CHART_GROUPS.map(g => [g.label, String((v.areaNotes || {})[g.key] || '').trim()]).filter(x => x[1]);
  const notesHTML = notes.length ? `<h2>Notes by area</h2><dl class="kv">${notes.map(([l, t]) => `<div><dt>${esc(l)}</dt><dd class="pre">${esc(t)}</dd></div>`).join('')}</dl>` : '';
  if (!charts.length) return notesHTML;
  const order = CHART_VIEWS.map(x => x.key);
  charts.sort((a, b) => order.indexOf(a.view) - order.indexOf(b.view));
  const parts = [];
  for (const c of charts) {
    const url = c.base.type === 'photo' ? fullURL(c.base.photoId) : '';
    parts.push(`<div>${chartSVG(c, url)}<div style="font-size:9pt;text-align:center">${CHART_VIEWS.find(x => x.key === c.view).label}</div></div>`);
  }
  return `<h2>Treatment chart</h2><div class="charts">${parts.join('')}</div>${notesHTML}`;
}

// One A4 sheet of a 3D head chart: the front view large with the 45s and the sides beside
// it, each with its marks, then the treatment lines and who signed.
function signLine(v) {
  const doc = byId('users', v.doctorId);
  return `<div class="sig"><div>${esc(doc ? doc.name : '')}${doc && doc.licence ? ' · ' + esc(doc.licence) : ''}<br>${v.signedAt ? `Signed ${fmtStamp(v.signedAt)} by ${esc(userName(v.signedBy))}` : 'Not signed yet'}</div></div>`;
}
function headChartSheetHTML(c, v, p) {
  const head = c.base && c.base.type === 'head' ? byId('heads', c.base.headId) : null;
  // The standard pictures leave room round the head, so the print shows the middle of each.
  const pic = key => `<div class="hd-pic">${chartSVG({ ...c, shot: key }, head ? headThumbURL(head, key) : '', '', [0.15, 0.09, 0.7, 0.82])}<div class="lab">${HEAD_VIEWS.find(x => x.key === key).label}</div></div>`;
  const lines = linesFromMarks(c.marks || []);
  const table = lines.length ? `<table class="hd-lines"><tr><th>Treatment</th><th>Product</th><th>Lot</th><th class="n">Amount</th><th>Area</th><th>Notes</th></tr>
    ${lines.map(l => `<tr><td>${esc(KINDS[l.kind].label)}</td><td>${esc(l.product)}</td><td>${esc(l.lot || '')}</td><td class="n">${trimNum(l.amount)} ${esc(l.unit)}</td><td>${esc(l.area || '')}</td><td>${esc(l.notes || '')}</td></tr>`).join('')}</table>` : '<p>No treatment marks.</p>';
  return `<div class="hd-sheet"><h1>3D head chart · ${esc(v.type || 'Visit')} <span class="meta">${esc(headLabel(head))}${head ? `, built ${fmtStamp(head.built)}` : ''}</span></h1>${patientLine(p, v.date)}
    <div class="hd-print">${pic('front')}<div class="hd-col">${pic('right45')}${pic('right')}</div><div class="hd-col">${pic('left45')}${pic('left')}</div></div>
    <h2>Treatment</h2>${table}${signLine(v)}</div>`;
}
function headChartsPrintHTML(v, p) {
  return chartsOfVisit(v.id).filter(c => c.view === HEAD_CHART.key && (c.marks || []).length).map(c => `<div class="pagebreak">${printHead()}${headChartSheetHTML(c, v, p)}${printFoot()}</div>`).join('');
}
function printHeadChart(c, v, p) {
  doPrint(`${printHead()}${headChartSheetHTML(c, v, p)}${printFoot()}`, `${p.name} 3D head chart ${v.date}`);
}

function treatTable(v) {
  const t = (v.treatments || []).filter(x => x.source !== 'supply');
  const sup = (v.treatments || []).filter(x => x.source === 'supply');
  return `${t.length ? `<h2>Treatment</h2><table><tr><th>Treatment</th><th>Product</th><th>Lot</th><th class="n">Amount</th><th>Area</th><th>Notes</th></tr>
    ${t.map(x => `<tr><td>${esc(KINDS[x.kind] ? KINDS[x.kind].label : x.kind)}</td><td>${esc(x.product)}</td><td>${esc(x.lot || '')}</td><td class="n">${trimNum(x.amount)} ${esc(x.unit)}</td><td>${esc(x.area || '')}</td><td>${esc(x.notes || '')}</td></tr>`).join('')}</table>` : ''}
    ${sup.length ? `<h2>Consumables used</h2><table><tr><th>Consumable</th><th>Lot</th><th class="n">Amount</th><th>From</th></tr>${sup.map(x => `<tr><td>${esc(x.product)}</td><td>${esc(x.lot || '')}</td><td class="n">${trimNum(x.amount)} ${esc(x.unit)}</td><td>${x.set ? esc(x.notes || 'Set by the service') : 'Added on the visit' + (x.note ? ': ' + esc(x.note) : '')}</td></tr>`).join('')}</table>` : ''}`;
}
// Custom note fields of a visit, for the printouts.
function customNotesPrint(v) { const pairs = customPairs('visits', v.custom, 'notes'); return pairs.length ? pairs.map(([k, t]) => `<p><b>${esc(k)}.</b> <span class="pre">${esc(t)}</span></p>`).join('') : ''; }

async function printVisit(v) {
  const p = patient(v.patientId);
  const doc = byId('users', v.doctorId);
  const notes = [['Complaint', v.complaint], ['Findings', v.findings], ['Assessment', v.assessment], ['Plan', v.plan]].filter(x => x[1]);
  const html = `${printTag(p)}${printHead()}<h1>Visit record · ${esc(v.type || 'Visit')}</h1>${patientLine(p, v.date)}
    <h2>Before treatment</h2><div class="pre">${alertsText(p)}</div>
    ${notes.length || customNotesPrint(v) ? `<h2>Notes</h2>${notes.map(([k, t]) => `<p><b>${k}.</b> <span class="pre">${esc(t)}</span></p>`).join('')}${customNotesPrint(v)}` : ''}
    ${await chartsPrintHTML(v)}
    ${(v.services || []).length ? `<h2>Services</h2><p>${esc(v.services.map(x => (service(x.serviceId) || {}).name || x.name).join(', '))}</p>` : ''}
    ${settingsPrintHTML(v)}
    ${medsPrintHTML(v)}
    ${treatTable(v)}
    ${(v.rx || []).length ? `<h2>Prescription</h2><ol>${v.rx.map(r => `<li>${esc(r.drug)} · ${esc(r.qty)}<br>${esc(r.sig)}</li>`).join('')}</ol>` : ''}
    ${(v.consents || []).length ? `<h2>Consent</h2><ul>${v.consents.map(c => `<li>${esc(c.title)}, signed by ${esc(c.signer)} ${fmtStamp(c.signedAt)}, witness ${esc(c.witness)}</li>`).join('')}</ul>` : ''}
    ${v.followUp ? `<h2>Follow-up</h2><p>${fmtDate(v.followUp)}${v.followReason ? ' · ' + esc(v.followReason) : ''}</p>` : ''}
    ${signLine(v)}
    ${printFoot()}${headChartsPrintHTML(v, p)}`;
  doPrint(html, `${p.name} visit ${v.date}`);
}

function printRx(v) {
  const p = patient(v.patientId);
  const doc = byId('users', v.doctorId) || doctors()[0];
  const html = `${printHead()}${patientLine(p, v.date)}${p.address ? `<p style="font-size:10pt">Address: ${esc(p.address)}</p>` : ''}
    <div class="rx">℞</div>
    <ol style="font-size:12pt;line-height:1.6">${(v.rx || []).map(r => `<li style="margin-bottom:10px"><b>${esc(r.drug)}</b>${r.qty ? ' &nbsp;#' + esc(r.qty) : ''}<br>Sig: ${esc(r.sig)}</li>`).join('')}</ol>
    <div class="sig" style="margin-top:60px;justify-content:flex-end"><div style="flex:0 0 260px">${esc(doc ? doc.name : '')}<br>${doc && doc.licence ? 'Licence ' + esc(doc.licence) : ''}</div></div>
    ${printFoot()}`;
  doPrint(html, `${p.name} prescription ${v.date}`);
}

function printAftercare(v, text) {
  const p = patient(v.patientId);
  const html = `${printHead()}<h1>Aftercare</h1><p>${esc(p.name)} · ${fmtDate(v.date)}</p>
    ${(v.treatments || []).length ? `<p>${esc(v.treatments.map(t => `${t.product || KINDS[t.kind].label} ${trimNum(t.amount)} ${t.unit}${t.area ? ' to ' + t.area : ''}`).join('; '))}</p>` : ''}
    <div class="pre" style="font-size:12pt;line-height:1.6">${esc(text)}</div>
    ${v.followUp ? `<p style="margin-top:14px"><b>Next visit:</b> ${fmtDate(v.followUp)}${v.followReason ? ' · ' + esc(v.followReason) : ''}</p>` : ''}
    <p style="margin-top:14px">Clinic: ${esc(S.clinic.phone || '')}</p>${printFoot()}`;
  doPrint(html, `${p.name} aftercare ${v.date}`);
}

function printConsent(v, c) {
  const p = patient(v.patientId);
  const html = `${printHead()}<h1>${esc(c.title)}</h1>${patientLine(p, v.date)}
    <div class="pre" style="margin-top:12px">${esc(c.text)}</div>
    <div class="sig"><div>${c.signatureId ? `<img src="${fileURL(c.signatureId)}" alt="">` : ''}${esc(c.signer)}<br>Signed ${fmtStamp(c.signedAt)}</div><div>${esc(c.witness)}<br>Witness</div></div>
    ${printFoot()}`;
  doPrint(html, `${p.name} consent ${c.title}`);
}

// The patient's number and QR, repeated on every printed page of their record.
function printTag(p) {
  if (!p || !p.no) return '';
  return `<div class="print-tag">${qrSVG(clinicURL('/p/' + p.no), 60)}<div><b>${esc(p.no)}</b><span>${esc(p.name)}</span></div></div>`;
}

// A wallet-size card with the QR, the record number large and the clinic's details.
function printPatientCard(p) {
  const c = S.clinic;
  const card = `<div class="pcard"><div style="display:flex;flex-direction:column"><div class="clinic">${esc(c.name)}${c.branchName ? ' · ' + esc(c.branchName) : ''}${c.phone ? ' · ' + esc(c.phone) : ''}</div><div class="name">${esc(p.name)}${p.nameTh && p.nameTh !== p.name ? `<br><span style="font-weight:500">${esc(p.nameTh)}</span>` : ''}</div><div class="no">${esc(p.no || '')}${p.hn ? ` <span style="font-size:10pt">HN ${esc(p.hn)}</span>` : ''}</div><div class="foot">Show this card to your doctor at each visit.</div></div><div class="qr">${qrSVG(clinicURL('/p/' + (p.no || '')), 110)}</div></div>`;
  doPrint(`<div class="cards">${card}${card}</div>`, `${p.name} card`);
}

// One visit in full, for the record sheet.
async function visitSheetHTML(v, p) {
  const doc = byId('users', v.doctorId);
  const notes = [['Complaint', v.complaint], ['Findings', v.findings], ['Assessment', v.assessment], ['Plan', v.plan]].filter(x => x[1]);
  const heads = chartsOfVisit(v.id).filter(c => c.view === HEAD_CHART.key && (c.marks || []).length);
  const headPics = heads.map(c => { const head = c.base && c.base.type === 'head' ? byId('heads', c.base.headId) : null; return `<div class="charts">${['front', 'right45', 'left45', 'right', 'left'].map(key => `<div>${chartSVG({ ...c, shot: key }, head ? headThumbURL(head, key) : '', '', [0.15, 0.09, 0.7, 0.82])}<div style="font-size:8pt;text-align:center">3D head · ${HEAD_VIEWS.find(x => x.key === key).label}</div></div>`).join('')}</div>`; }).join('');
  return `<div class="rec-visit"><h2>${fmtDate(v.date)}${v.time ? ' ' + fmtTime(v.time) : ''} · ${esc(v.type || 'Visit')} · ${esc(v.no || '')}${doc ? ' · ' + esc(doc.name) : ''}${v.signedAt ? ` · signed ${fmtStamp(v.signedAt)} by ${esc(userName(v.signedBy))}` : ' · not signed'}</h2>
    ${notes.length ? notes.map(([k, t]) => `<p><b>${k}.</b> <span class="pre">${esc(t)}</span></p>`).join('') : ''}${customNotesPrint(v)}
    ${(v.services || []).length ? `<h3>Treatments</h3><p>${esc(v.services.map(x => (service(x.serviceId) || {}).name || x.name).join(', '))}</p>` : ''}
    ${await chartsPrintHTML(v)}${headPics}
    ${treatTable(v).replace(/<h2>/g, '<h3>').replace(/<\/h2>/g, '</h3>')}
    ${medsPrintHTML(v).replace('<h2>', '<h3>').replace('</h2>', '</h3>')}
    ${settingsPrintHTML(v).replace('<h2>', '<h3>').replace('</h2>', '</h3>')}
    ${(v.rx || []).length ? `<h3>Prescription</h3><ol>${v.rx.map(r => `<li>${esc(r.drug)} · ${esc(r.qty)}<br>${esc(r.sig)}</li>`).join('')}</ol>` : ''}
    ${(v.consents || []).length ? `<h3>Consent</h3><ul>${v.consents.map(c => `<li>${esc(c.title)}, signed by ${esc(c.signer)} ${fmtStamp(c.signedAt)}, witness ${esc(c.witness)}${c.signatureId ? ` <img src="${fileURL(c.signatureId)}" alt="" style="height:28px;vertical-align:middle">` : ''}</li>`).join('')}</ul>` : ''}
    ${v.aftercare ? `<h3>Aftercare given</h3><div class="pre" style="font-size:9.5pt">${esc(v.aftercare)}</div>` : ''}
    ${v.followUp ? `<h3>Follow-up</h3><p>${fmtDate(v.followUp)}${v.followReason ? ' · ' + esc(v.followReason) : ''}</p>` : ''}
</div>`;
}

// The complete record sheet: details, alerts, history, consents and every visit.
async function recordSheetHTML(p) {
  const list = (arr, fmt) => (arr && arr.length ? `<ul>${arr.map(x => `<li>${fmt(x)}</li>`).join('')}</ul>` : '<p>None recorded.</p>');
  const visits = visitsOf(p.id).slice().reverse();
  const consents = visits.flatMap(v => (v.consents || []).map(c => ({ ...c, date: v.date })));
  const parts = [];
  for (const v of visits) parts.push(await visitSheetHTML(v, p));
  return `${printTag(p)}${printHead()}<h1>Patient record</h1>${patientLine(p, '')}
    <dl class="kv" style="margin-top:8px">${[['Apex HN', p.hn], ['Name in Thai', p.nameTh], ['Nationality', p.nationality], [p.idType || 'ID', p.idNo], ['Address', p.address], ['Mobile', p.phone], ['LINE ID', p.line], ['Email', p.email], ['Occupation', p.occupation], ['Skin type', p.skin ? 'Fitzpatrick ' + p.skin : ''], ['Found Apex through', p.source], ['Referred by', p.referredBy], ['On record since', p.created ? fmtDate(isoOf(new Date(p.created))) : ''], ['Clinical photos', p.photoConsent === 'yes' ? 'Agreed' : p.photoConsent === 'no' ? 'Declined' : 'Not recorded'], ['Photos in marketing', p.marketingConsent === 'yes' ? 'Agreed' : p.marketingConsent === 'no' ? 'Declined' : 'Not recorded'], ['Tags', (p.tags || []).join(', ')]].filter(x => x[1]).map(([k, v]) => `<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
    <h2>Alerts and allergies</h2><div class="pre">${alertsText(p)}</div>${(p.allergies || []).length ? `<ul>${p.allergies.map(a => `<li>${esc(a.what)}${a.reaction ? ': ' + esc(a.reaction) : ''}${a.severity ? ' (' + esc(a.severity) + ')' : ''}</li>`).join('')}</ul>` : ''}
    <h2>Medicines</h2>${list(p.meds, m => `${esc(m.name)} ${esc(m.dose || '')} ${esc(m.freq || '')}${m.reason ? ' for ' + esc(m.reason) : ''}`)}
    <h2>Conditions</h2>${list(p.conditions, c => `${esc(c.name)}${c.year ? ' since ' + esc(c.year) : ''}${c.notes ? ', ' + esc(c.notes) : ''}`)}
    <h2>Surgeries and past treatments</h2>${list(p.surgeries, s => `${esc(s.what)}${s.year ? ', ' + esc(s.year) : ''}${s.where ? ', ' + esc(s.where) : ''}`)}
    ${customPairs('patients', p.custom, 'details').length ? `<dl class="kv">${customPairs('patients', p.custom, 'details').map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>` : ''}
    ${customPairs('patients', p.custom, 'medical').length ? `<h2>Medical history</h2><dl class="kv">${customPairs('patients', p.custom, 'medical').map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>` : ''}
    ${p.smoking || p.alcohol || p.sun || customPairs('patients', p.custom, 'lifestyle').length ? `<h2>Lifestyle</h2><p>${[p.smoking && 'Smoking: ' + p.smoking, p.alcohol && 'Alcohol: ' + p.alcohol, p.sun && 'Sun: ' + p.sun, ...customPairs('patients', p.custom, 'lifestyle').map(([k, v]) => `${k}: ${v}`)].filter(Boolean).map(esc).join('. ')}</p>` : ''}
    ${customPairs('patients', p.custom, 'aesthetic').length ? `<h2>Aesthetic profile</h2><dl class="kv">${customPairs('patients', p.custom, 'aesthetic').map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>` : ''}
    ${customSections('patients', p.custom).filter(sec => customPairs('patients', p.custom, sec).length).map(sec => `<h2>${esc(sec)}</h2><dl class="kv">${customPairs('patients', p.custom, sec).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`).join('')}
    <h2>Emergency contacts</h2>${list(p.contacts, c => `${esc(c.name)}${c.relation ? ', ' + esc(c.relation) : ''} ${esc(c.phone || '')}`)}
    ${p.notes ? `<h2>Notes</h2><div class="pre">${esc(p.notes)}</div>` : ''}
    ${(() => { const inc = (S.incidents || []).filter(x => x.patientId === p.id).sort((a, b) => (a.date || '').localeCompare(b.date || '')); return inc.length ? `<h2>Complications</h2><table><tr><th>Date</th><th>What happened</th><th>What was done</th><th>Outcome</th></tr>${inc.map(x => `<tr><td>${fmtDate(x.date)}</td><td>${esc(x.type)}, ${esc(x.severity.toLowerCase())}${x.area ? ', ' + esc(x.area) : ''}${x.what ? `<br><small>${esc(x.what)}</small>` : ''}</td><td>${esc(x.given || '')}</td><td>${esc(x.outcome)}${x.resolvedOn ? ' ' + fmtDate(x.resolvedOn) : ''}${x.outcomeNote ? `<br><small>${esc(x.outcomeNote)}</small>` : ''}</td></tr>`).join('')}</table>` : ''; })()}
    <h2>Consent forms signed</h2>${consents.length ? `<table><tr><th>Date</th><th>Form</th><th>Signed by</th><th>Witness</th></tr>${consents.map(c => `<tr><td>${fmtDate(c.date)}</td><td>${esc(c.title)}</td><td>${esc(c.signer)}</td><td>${esc(c.witness)}</td></tr>`).join('')}</table>` : '<p>None.</p>'}
    <h2>Visits</h2>${visits.length ? `<table><tr><th>Date</th><th>Type</th><th>Treatment</th><th>Doctor</th></tr>${visits.map(v => `<tr><td>${fmtDate(v.date)}</td><td>${esc(v.type || '')}</td><td>${esc(visitSummary(v))}</td><td>${esc(userName(v.doctorId))}</td></tr>`).join('')}</table>` : '<p>No visits.</p>'}
    ${parts.join('')}
    ${printFoot()}`;
}

// The visit summary for Apex's EMR on paper.
function printEmrSummary(v, p) {
  markSeen(p.id, 'print');
  doPrint(`${printHead()}<h1>Visit summary for Apex's EMR</h1><pre style="font:10.5pt/1.5 'LINE Seed Sans TH', system-ui, sans-serif;white-space:pre-wrap" translate="no">${esc(emrSummaryText(v, p))}</pre>${printFoot()}`, `${p.name} ${v.date} summary`);
}

async function printRecord(p) {
  markSeen(p.id, 'print');
  doPrint(await recordSheetHTML(p), `${p.name} record`);
}
