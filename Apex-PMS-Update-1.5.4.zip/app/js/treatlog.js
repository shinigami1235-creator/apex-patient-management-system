// Settings used on lasers, devices and peels, and the medicines given in the clinic.
// A settings entry keeps its own copy of the field names and units, so editing a
// sheet in Settings later never changes what an old visit says.

const sheetsList = () => S.templates.sheets || [];
const sheetOf = id => sheetsList().find(x => x.id === id);
const numOf = x => (x === '' || x === null || x === undefined || isNaN(+String(x).replace(',', '.')) ? null : +String(x).replace(',', '.'));

// Every earlier entry of one sheet for a patient, newest first. With a visit given,
// only sessions before that visit count.
function settingsHistory(patientId, sheetId, before) {
  const key = v => (v.date || '') + (v.time || '') + String(v.created || '').padStart(15, '0');
  const out = [];
  for (const v of visitsOf(patientId)) {
    if (before && (v.id === before.id || key(v) > key(before))) continue;
    for (const e of [...(v.settings || [])].reverse()) if (e.sheetId === sheetId) out.push({ v, e });
  }
  return out.sort((a, b) => key(b.v).localeCompare(key(a.v)));
}
// The session to start from: the same area if it was done before, else the latest.
function lastSetting(patientId, sheetId, before, area) {
  const h = settingsHistory(patientId, sheetId, before);
  if (!h.length) return null;
  const a = String(area || '').trim().toLowerCase();
  return (a && h.find(x => String(x.e.area || '').trim().toLowerCase() === a)) || h[0];
}
function prevValue(prev, label) {
  if (!prev) return undefined;
  const x = (prev.e.values || []).find(y => y.label === label);
  return x ? x.value : undefined;
}
function deltaHTML(value, was) {
  const a = numOf(value), b = numOf(was);
  if (a === null || b === null || a === b) return was !== undefined && was !== '' && String(was) !== String(value) ? `<span class="delta">was ${esc(was)}</span>` : '';
  return `<span class="delta ${a > b ? 'up' : 'down'}">${a > b ? '↑' : '↓'} from ${esc(trimNum(b))}</span>`;
}
function valuesLine(e) {
  return (e.values || []).filter(x => x.value !== '' && x.value !== undefined).map(x => `${x.label} ${x.value}${x.unit ? ' ' + x.unit : ''}`).join(' · ');
}
function nextLine(e) {
  return e.next || e.nextNote ? `${e.next || ''}${e.next && e.nextNote ? '. ' : ''}${e.nextNote || ''}` : '';
}
// Sheets the visit's services point to that have no entry yet.
function sheetsWanted(v) {
  const done = new Set((v.settings || []).map(e => e.sheetId));
  const ids = [];
  for (const s of v.services || []) { const sv = service(s.serviceId); if (sv && sv.sheetId && sheetOf(sv.sheetId) && !done.has(sv.sheetId) && !ids.includes(sv.sheetId)) ids.push(sv.sheetId); }
  return ids;
}
function sheetsForAppt(a) {
  const ids = [];
  for (const id of a.serviceIds || []) { const sv = service(id); if (sv && sv.sheetId && sheetOf(sv.sheetId) && !ids.includes(sv.sheetId)) ids.push(sv.sheetId); }
  return ids;
}

// ---------- visit: settings used ----------
function settingsCard(v, p, locked) {
  const list = v.settings || [];
  const want = locked ? [] : sheetsWanted(v);
  const lastBox = want.map(id => {
    const sh = sheetOf(id), last = lastSetting(v.patientId, id, v);
    return `<div class="set-last"><div class="grow"><b>${esc(sh.name)}</b>${last ? `<div class="meta">Last session ${fmtDate(last.v.date)}${last.e.area ? ', ' + esc(last.e.area) : ''}: ${esc(valuesLine(last.e))}</div>${nextLine(last.e) ? `<div class="meta-line"><span class="meta">Planned</span> ${esc(nextLine(last.e))}</div>` : ''}` : '<div class="meta">First session on this patient.</div>'}</div>
      <button class="btn secondary small" data-set-add="${id}">Record settings</button></div>`;
  }).join('');
  return `<div class="card" id="vsettings"><div class="card-head"><h2>Settings used</h2>${locked ? '' : `<button class="btn secondary small" data-set-add="">${I.plus}Add settings</button>`}</div>
    ${p.skin ? `<p class="meta" style="margin:0 0 8px">Skin type Fitzpatrick ${esc(p.skin)}</p>` : ''}
    ${lastBox}
    ${list.length ? list.map(e => settingEntryHTML(v, e, locked)).join('') : (want.length ? '' : `<p class="muted">${locked ? 'No settings recorded.' : 'Record the laser, device or peel settings here. The next session starts from them.'}</p>`)}</div>`;
}
function settingEntryHTML(v, e, locked) {
  const prev = lastSetting(v.patientId, e.sheetId, v, e.area);
  return `<div class="set-entry"><div class="set-head"><div class="grow"><b>${esc(e.name)}</b>${e.area ? ` · ${esc(e.area)}` : ''}<div class="meta">${esc(userName(e.by))}${e.at ? ' · ' + fmtTime(timeOfStamp(e.at)) : ''}${prev ? ` · compared with ${fmtDate(prev.v.date)}` : ''}</div></div>
      ${locked ? '' : `<button class="btn quiet small" data-set-edit="${e.id}">Edit</button>`}</div>
    <div class="set-vals">${(e.values || []).filter(x => x.value !== '' && x.value !== undefined).map(x => `<div><span class="meta">${esc(x.label)}</span><b>${esc(x.value)}${x.unit ? ` <small>${esc(x.unit)}</small>` : ''}</b>${deltaHTML(x.value, prevValue(prev, x.label))}</div>`).join('')}</div>
    ${e.area ? entryPhotosHTML(v, e, locked) : ''}
    ${e.response || e.responseNote ? `<p class="meta-line"><span class="meta">Since last time</span> ${e.response ? `<b>${esc(e.response)}</b>` : ''}${e.response && e.responseNote ? '. ' : ''}${esc(e.responseNote || '')}</p>` : ''}
    ${e.reaction ? `<p class="meta-line"><span class="meta">Skin today</span> ${esc(e.reaction)}</p>` : ''}
    ${nextLine(e) ? `<p class="meta-line"><span class="meta">Next session</span> ${e.next ? `<b>${esc(e.next)}</b>` : ''}${e.next && e.nextNote ? '. ' : ''}${esc(e.nextNote || '')}</p>` : ''}</div>`;
}
// The baseline and today's photos of the area the settings were used on.
function entryPhotosHTML(v, e, locked) {
  const base = baselineOf(v.patientId, e.area);
  const today = S.photos.filter(x => x.visitId === v.id && areaKey(x.area) === areaKey(e.area)).sort((a, b) => (a.created || 0) - (b.created || 0));
  const isBaseVisit = base.length && base[0].visitId === v.id;
  const tiles = [...(isBaseVisit ? [] : base.slice(0, 2).map(ph => ['Baseline ' + fmtDay(ph.date), ph, true])), ...today.map(ph => [isBaseVisit ? 'Baseline' : 'Today', ph, false])];
  if (!tiles.length && locked) return '';
  return `<div class="entry-photos">${tiles.length ? `<div class="area-strip">${tiles.map(([label, ph, ref]) => `<div class="ph ${ref ? 'ref' : ''}"><img loading="lazy" src="${thumbURL(ph.id)}" alt="${esc(label)}" data-view-photo="${ph.id}"><div class="cap"><span>${esc(label)}</span></div></div>`).join('')}</div>` : ''}
    ${locked ? '' : `<label class="btn quiet small">${I.plus}${today.length ? 'More photos of' : 'Add photos of'} ${esc(e.area.toLowerCase())}<input type="file" class="file-hidden" accept="image/*" multiple data-add-photo data-area="${esc(e.area)}"></label>`}</div>`;
}
const timeOfStamp = t => { const d = new Date(t); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };

async function settingSheet(v, entry, sheetId0) {
  const p = patient(v.patientId) || {};
  const sheets = sheetsList();
  if (!sheets.length && !entry) return toast('Add a machine or peel under Settings, Treatment settings first.');
  let sid = entry ? entry.sheetId : sheetId0 || sheetsWanted(v)[0] || (sheets[0] || {}).id;
  const first = entry ? null : lastSetting(v.patientId, sid, v);
  const areaDefault = entry ? entry.area || '' : (first && first.e.area) || '';
  const f = await sheet({
    title: entry ? entry.name : 'Record settings', wide: true, submit: 'Save settings',
    extra: entry ? '<button type="button" class="btn danger" data-del>Delete</button>' : '',
    body: `<div class="grid2">${entry ? `<div class="field"><span class="label">Machine or treatment</span><b style="padding:10px 0">${esc(entry.name)}</b></div>`
        : field('Machine or treatment', 'sheetId', sid, { type: 'select', blank: false, options: groupedSheetOptions() })}
      ${field('Area', 'area', areaDefault, { ph: 'Underarms', attrs: 'list="set-area-dl"' })}</div>${datalist('set-area-dl', ['Full face', 'Forehead', 'Cheeks', 'Upper lip', 'Chin', 'Neck', 'Underarms', 'Arms', 'Legs', 'Bikini', 'Back', 'Chest', 'Hands'])}
      <div data-last></div><div data-fields></div>
      <div data-resp></div>
      ${field('Skin today', 'reaction', entry ? entry.reaction : '', { ph: 'Even redness and swelling at the follicles. Settled in 20 minutes.' })}
      <div class="grid2">${field('Next session', 'next', entry ? entry.next : '', { type: 'select', options: NEXT_STEPS, blank: 'Not decided' })}${field('Note for next session', 'nextNote', entry ? entry.nextNote : '', { ph: 'Go up to 14 J/cm² if there are no blisters.' })}</div>`,
    onOpen: form => {
      const del = form.querySelector('[data-del]');
      if (del) del.onclick = async () => {
        if (!(await confirmDanger('Delete these settings?', ''))) return;
        form.close(null);
        try { await pullFrom('visits', v.id, 'settings', [entry.id], 'Settings deleted: ' + entry.name); renderVisit(v.id); } catch (e) { fail(e); }
      };
      const draw = () => {
        const sh = entry ? null : sheetOf(sid);
        const defs = entry ? entry.values : (sh ? sh.fields : []);
        const prev = lastSetting(v.patientId, sid, v, form.querySelector('[name=area]').value || areaDefault);
        form.querySelector('[data-last]').innerHTML = prev
          ? `<div class="banner info"><div>Filled from ${fmtDate(prev.v.date)}${prev.e.area ? ', ' + esc(prev.e.area) : ''}. Change what you adjusted today.${nextLine(prev.e) ? `<br>Planned then: <b>${esc(nextLine(prev.e))}</b>` : ''}${prev.e.reaction ? `<br>Skin that day: ${esc(prev.e.reaction)}` : ''}</div></div>`
          : (entry ? '' : '<p class="meta">No earlier session on this patient.</p>');
        form.querySelector('[data-fields]').innerHTML = `<div class="grid4">${defs.map((d, i) => {
          const was = prevValue(prev, d.label);
          const value = entry ? d.value : (was !== undefined ? was : '');
          return field(d.label + (d.unit ? ` (${d.unit})` : ''), 'f_' + i, value, { type: d.type === 'number' ? 'number' : 'text', ph: d.ph || '', hint: was !== undefined && was !== '' ? `Last time ${was}${d.unit ? ' ' + d.unit : ''}` : '' });
        }).join('')}</div>`;
        const showResp = prev || (entry && (entry.response || entry.responseNote));
        form.querySelector('[data-resp]').innerHTML = showResp ? `<div class="grid2">${field('How the last session went', 'response', entry ? entry.response : '', { type: 'select', options: RESPONSES, blank: 'Not asked' })}${field('What the patient noticed', 'responseNote', entry ? entry.responseNote : '', { ph: 'Hair thinner on the legs, little change on the underarms.' })}</div>` : '';
      };
      const sel = form.querySelector('[name=sheetId]');
      if (sel) sel.onchange = () => { sid = sel.value; draw(); };
      draw();
    },
    validate: form => {
      const defs = entry ? entry.values : ((sheetOf(sid) || {}).fields || []);
      return defs.some((d, i) => val(form, 'f_' + i) !== '') ? '' : 'Fill in at least one setting.';
    },
  });
  if (!f) return;
  const sh = sheetOf(sid);
  const defs = entry ? entry.values : sh.fields;
  const rec = {
    ...(entry || { id: uid(), by: S.me.id, at: Date.now() }),
    sheetId: sid, name: entry ? entry.name : sh.name, group: entry ? entry.group : sh.group, area: val(f, 'area'),
    values: defs.map((d, i) => ({ label: d.label, unit: d.unit || '', type: d.type || 'text', value: val(f, 'f_' + i) })),
    response: val(f, 'response'), responseNote: val(f, 'responseNote'), reaction: val(f, 'reaction'), next: val(f, 'next'), nextNote: val(f, 'nextNote'),
  };
  if (entry) { rec.editedBy = S.me.id; rec.editedAt = Date.now(); }
  try { await pushTo('visits', v.id, 'settings', [rec], (entry ? 'Settings edited: ' : 'Settings recorded: ') + rec.name); renderVisit(v.id); }
  catch (e) { fail(e); }
}
function groupedSheetOptions() {
  return SHEET_GROUPS.flatMap(g => sheetsList().filter(s => (s.group || 'Other') === g).map(s => [s.id, `${s.name} (${g.toLowerCase()})`]));
}

// ---------- visit: medicines given ----------
function allergyHits(p, drug) {
  const d = String(drug || '').toLowerCase();
  if (!d) return [];
  return (p.allergies || []).filter(a => {
    const w = String(a.what || '').toLowerCase().trim();
    if (!w) return false;
    return d.includes(w) || w.includes(d) || w.split(/[^a-z0-9]+/).some(t => t.length >= 4 && d.includes(t));
  });
}
function medsCard(v, p, locked) {
  const list = [...(v.meds || [])].sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  return `<div class="card" id="vmeds"><div class="card-head"><h2>Medicines given</h2>${locked ? '' : `<button class="btn secondary small" data-act="add-med">${I.plus}Add medicine</button>`}</div>
    ${list.length ? `<div class="scroll-x"><table class="t"><tr><th>Time</th><th>Medicine</th><th class="n">Dose</th><th>Route and site</th><th>Lot</th><th>Given by</th><th></th></tr>
      ${list.map(m => `<tr><td>${m.time ? fmtTime(m.time) : ''}</td><td><b>${esc(m.drug)}</b>${m.reaction ? `<div class="meta">${esc(m.reaction)}</div>` : ''}${m.allergyOk ? `<div class="meta bad-text">Given despite a recorded allergy</div>` : ''}</td>
        <td class="n">${esc(trimNum(m.dose))} ${esc(m.unit || '')}</td><td>${esc([m.route, m.site].filter(Boolean).join(', '))}</td><td>${esc(m.lot || '')}</td>
        <td>${esc(userName(m.givenBy))}</td><td class="n">${locked ? '' : `<button class="btn quiet small" data-med="${m.id}">Edit</button>`}</td></tr>`).join('')}</table></div>`
      : `<p class="muted">${locked ? 'No medicines given.' : 'Record anaesthetic, drips, injections and tablets given here. The prescription below is for medicines taken home.'}</p>`}</div>`;
}
function medLotOptions(selected) {
  const lots = lotsForKind('medicine');
  return [['', 'Not in the product list'], ...lots.map(l => [l.id, lotOptionLabel(l)])].map(([i, l]) => `<option value="${i}" ${i === selected ? 'selected' : ''}>${esc(l)}</option>`).join('');
}
async function medSheet(v, m) {
  const p = patient(v.patientId) || {};
  const givers = activeUsers().filter(u => ROLES[u.role].clinical);
  const f = await sheet({
    title: m ? 'Medicine given' : 'Add medicine given', wide: true,
    extra: m ? '<button type="button" class="btn danger" data-del>Delete</button>' : '',
    body: `<div data-allergy></div>
      <div class="grid4">${field('Medicine', 'drug', m ? m.drug : '', { ph: 'Tranexamic acid', attrs: 'list="med-dl" autocomplete="off"', cls: 'span2' })}${field('Dose', 'dose', m ? m.dose : '', { type: 'number', ph: '500' })}${field('Unit', 'unit', m ? m.unit : 'mg', { type: 'select', options: MED_UNITS, blank: false })}</div>
      ${datalist('med-dl', [...new Set([...MED_HINTS, ...S.products.filter(x => x.kind === 'medicine').map(x => x.name)])])}
      <div class="grid4">${field('Route', 'route', m ? m.route : 'IV', { type: 'select', options: MED_ROUTES, blank: false })}${field('Site', 'site', m ? m.site : '', { ph: 'Left antecubital' })}${field('Time', 'time', m ? m.time : nowTime(), { type: 'time' })}${field('Given by', 'givenBy', m ? m.givenBy : S.me.id, { type: 'select', blank: false, options: givers.map(u => [u.id, u.name]) })}</div>
      <div class="grid2"><label class="field"><span class="label">Product and lot</span><select name="lotId">${medLotOptions(m ? m.lotId : '')}</select></label>${field('Lot number', 'lotNo', m && !m.lotId ? m.lot || '' : '', { ph: 'Typed when the medicine is not in the list' })}</div>
      ${field('Reaction or notes', 'reaction', m ? m.reaction : '', { ph: 'Diluted in 100 ml saline over 15 minutes. No reaction.' })}`,
    onOpen: form => {
      const drug = form.querySelector('[name=drug]'), sel = form.querySelector('[name=lotId]'), box = form.querySelector('[data-allergy]');
      const check = () => {
        const hits = allergyHits(p, drug.value);
        box.innerHTML = hits.length ? `<div class="banner bad"><div>Recorded allergy: ${hits.map(a => `${esc(a.what)}${a.reaction ? ' (' + esc(a.reaction) + ')' : ''}${a.severity ? ', ' + esc(a.severity.toLowerCase()) : ''}`).join('; ')}.${field('Give it anyway', 'allergyOk', m && m.allergyOk, { type: 'check' })}</div></div>` : '';
      };
      drug.oninput = check; check();
      sel.onchange = () => { const l = lot(sel.value), pr = l ? product(l.productId) : null; if (pr && !drug.value.trim()) { drug.value = pr.name; check(); } };
      const del = form.querySelector('[data-del]');
      if (del) del.onclick = async () => {
        if (!(await confirmDanger('Delete this medicine?', ''))) return;
        form.close(null);
        try { await pullFrom('visits', v.id, 'meds', [m.id], 'Medicine deleted: ' + m.drug); renderVisit(v.id); } catch (e) { fail(e); }
      };
    },
    validate: form => (!val(form, 'drug') ? 'Enter the medicine.' : nval(form, 'dose') <= 0 ? 'Enter the dose.' : allergyHits(p, val(form, 'drug')).length && !val(form, 'allergyOk') ? 'The patient has a recorded allergy to this. Tick Give it anyway to record it.' : ''),
  });
  if (!f) return;
  const l = lot(val(f, 'lotId')), pr = l ? product(l.productId) : null;
  const rec = {
    ...(m || { id: uid(), at: Date.now() }),
    drug: val(f, 'drug'), dose: nval(f, 'dose'), unit: val(f, 'unit'), route: val(f, 'route'), site: val(f, 'site'), time: val(f, 'time'), givenBy: val(f, 'givenBy'),
    lotId: l ? l.id : '', productId: pr ? pr.id : '', lot: l ? l.lot || '' : val(f, 'lotNo'), reaction: val(f, 'reaction'),
    allergyOk: !!(allergyHits(p, val(f, 'drug')).length && val(f, 'allergyOk')),
  };
  try {
    await pushTo('visits', v.id, 'meds', [rec], (m ? 'Medicine edited: ' : 'Medicine given: ') + `${rec.drug} ${trimNum(rec.dose)} ${rec.unit} ${rec.route}`);
    renderVisit(v.id);
  } catch (e) { fail(e); }
}

function wireTreatLog(v) {
  const cur = () => visit(v.id);
  document.querySelectorAll('[data-set-add]').forEach(b => b.onclick = () => settingSheet(cur(), null, b.dataset.setAdd));
  document.querySelectorAll('[data-set-edit]').forEach(b => b.onclick = () => settingSheet(cur(), (cur().settings || []).find(e => e.id === b.dataset.setEdit)));
  const am = document.querySelector('[data-act="add-med"]'); if (am) am.onclick = () => medSheet(cur(), null);
  document.querySelectorAll('[data-med]').forEach(b => b.onclick = () => medSheet(cur(), (cur().meds || []).find(m => m.id === b.dataset.med)));
}

// ---------- patient record tabs ----------
function patientSettingsLog(p) {
  const rows = [];
  for (const v of visitsOf(p.id)) for (const e of v.settings || []) rows.push({ v, e });
  if (!rows.length) return empty('No settings recorded yet.', 'Laser, device and peel settings recorded on visits show here, one table per machine.');
  const groups = groupBy(rows, x => x.e.sheetId + '|' + x.e.name);
  return [...groups.values()].map(list => {
    const labels = [];
    for (const { e } of [...list].reverse()) for (const x of e.values || []) if (!labels.includes(x.label)) labels.push(x.label);
    const unit = l => { for (const { e } of list) { const x = (e.values || []).find(y => y.label === l); if (x && x.unit) return x.unit; } return ''; };
    const used = labels.filter(l => list.some(({ e }) => (e.values || []).some(x => x.label === l && x.value !== '')));
    return `<h3 class="section-title">${esc(list[0].e.name)} · ${plural(list.length, 'session')}</h3>
      <div class="card flush scroll-x"><table class="t set-log"><tr><th>Date</th><th>Area</th>${used.map(l => `<th class="n">${esc(l)}${unit(l) ? `<div class="meta">${esc(unit(l))}</div>` : ''}</th>`).join('')}<th>Since last time</th><th>Skin that day</th><th>Next session</th></tr>
      ${list.map(({ v, e }, i) => {
        const older = list.slice(i + 1).find(x => !e.area || !x.e.area || x.e.area === e.area) || list[i + 1];
        return `<tr><td><a href="#/visit/${v.id}">${fmtDate(v.date)}</a></td><td>${esc(e.area || '')}</td>
          ${used.map(l => { const x = (e.values || []).find(y => y.label === l); const was = older ? prevValue(older, l) : undefined; return `<td class="n">${x ? esc(x.value) : ''}${x && x.value !== '' ? deltaHTML(x.value, was) : ''}</td>`; }).join('')}
          <td>${esc([e.response, e.responseNote].filter(Boolean).join('. '))}</td><td>${esc(e.reaction || '')}</td><td>${e.next ? `<b>${esc(e.next)}</b>` : ''}${e.next && e.nextNote ? '. ' : ''}${esc(e.nextNote || '')}</td></tr>`;
      }).join('')}</table></div>`;
  }).join('');
}
function patientMedsLog(p) {
  const rows = [];
  for (const v of visitsOf(p.id)) for (const m of [...(v.meds || [])].sort((a, b) => (b.time || '').localeCompare(a.time || ''))) rows.push({ v, m });
  if (!rows.length) return empty('No medicines given yet.', 'Medicines given on visits show here with the dose, route and lot.');
  return `<div class="card flush scroll-x"><table class="t"><tr><th>Date</th><th>Medicine</th><th class="n">Dose</th><th>Route and site</th><th>Lot</th><th>Given by</th><th>Reaction or notes</th></tr>
    ${rows.map(({ v, m }) => `<tr><td><a href="#/visit/${v.id}">${fmtDate(v.date)}</a>${m.time ? `<div class="meta">${fmtTime(m.time)}</div>` : ''}</td><td><b>${esc(m.drug)}</b></td><td class="n">${esc(trimNum(m.dose))} ${esc(m.unit || '')}</td>
      <td>${esc([m.route, m.site].filter(Boolean).join(', '))}</td><td>${esc(m.lot || '')}</td><td>${esc(userName(m.givenBy))}</td><td>${esc(m.reaction || '')}${m.allergyOk ? '<div class="meta bad-text">Given despite a recorded allergy</div>' : ''}</td></tr>`).join('')}</table></div>`;
}

// ---------- printing ----------
function settingsPrintHTML(v) {
  const list = v.settings || [];
  if (!list.length) return '';
  return `<h2>Settings used</h2>${list.map(e => `<p><b>${esc(e.name)}</b>${e.area ? ', ' + esc(e.area) : ''}: ${esc(valuesLine(e))}${e.response || e.responseNote ? `<br>Since last time: ${esc([e.response, e.responseNote].filter(Boolean).join('. '))}` : ''}${e.reaction ? `<br>Skin: ${esc(e.reaction)}` : ''}${nextLine(e) ? `<br>Next session: ${esc(nextLine(e))}` : ''}</p>`).join('')}`;
}
function medsPrintHTML(v) {
  const list = v.meds || [];
  if (!list.length) return '';
  return `<h2>Medicines given</h2><table><tr><th>Time</th><th>Medicine</th><th>Dose</th><th>Route and site</th><th>Lot</th><th>Given by</th></tr>${list.map(m => `<tr><td>${m.time ? fmtTime(m.time) : ''}</td><td>${esc(m.drug)}${m.reaction ? `<br><i>${esc(m.reaction)}</i>` : ''}</td><td>${esc(trimNum(m.dose))} ${esc(m.unit || '')}</td><td>${esc([m.route, m.site].filter(Boolean).join(', '))}</td><td>${esc(m.lot || '')}</td><td>${esc(userName(m.givenBy))}</td></tr>`).join('')}</table>`;
}
// One line per machine the booking needs, for the day sheet.
function lastSettingsLines(a) {
  return sheetsForAppt(a).map(id => {
    const sh = sheetOf(id), last = lastSetting(a.patientId, id, null);
    return last ? { name: sh.name, date: last.v.date, visitId: last.v.id, text: valuesLine(last.e), next: nextLine(last.e), area: last.e.area || '' } : { name: sh.name, first: true };
  });
}

// ---------- settings page: treatment settings ----------
function sheetsTab() {
  const list = sheetsList();
  const usedBy = id => S.services.filter(s => s.sheetId === id && s.active !== false).map(s => s.name);
  return `<div class="row end gap-b"><button class="btn primary" data-act="add-sheet">${I.plus}Add machine or peel</button></div>
    <p class="meta" style="margin-top:0">Each one lists the settings written down on a visit. Link it to a service under Services and the visit asks for it, filled in from the patient's last session.</p>
    ${SHEET_GROUPS.filter(g => list.some(s => (s.group || 'Other') === g)).map(g => `<h3 class="section-title">${esc(g)}</h3><div class="card flush"><div class="list flat">${list.filter(s => (s.group || 'Other') === g).map(s => `<div class="li"><div class="grow"><div class="t medium">${esc(s.name)}</div><div class="m">${esc((s.fields || []).map(x => x.label + (x.unit ? ' (' + x.unit + ')' : '')).join(', '))}</div>${usedBy(s.id).length ? `<div class="m">Services: ${esc(usedBy(s.id).join(', '))}</div>` : ''}</div><button class="btn secondary small" data-sheet="${s.id}">Edit</button></div>`).join('')}</div></div>`).join('')}
    ${list.length ? '' : empty('No machines or peels yet.', '')}`;
}
function wireSheets() {
  document.querySelector('[data-act="add-sheet"]').onclick = () => sheetEditSheet(null);
  document.querySelectorAll('[data-sheet]').forEach(b => b.onclick = () => sheetEditSheet(sheetOf(b.dataset.sheet)));
}
async function sheetEditSheet(sh) {
  const f = await sheet({
    title: sh ? sh.name : 'Add machine or peel', wide: true,
    extra: sh ? '<button type="button" class="btn danger" data-del>Delete</button>' : '',
    body: `<div class="grid2">${field('Name', 'name', sh ? sh.name : '', { ph: 'Diode laser hair removal' })}${field('Group', 'group', sh ? sh.group : 'Laser', { type: 'select', options: SHEET_GROUPS, blank: false })}</div>
      <div class="field"><span class="label">Settings to write down</span>${rowsBlock('fields', [{ k: 'label', label: 'Setting', ph: 'Fluence', w: '1.4fr' }, { k: 'unit', label: 'Unit', ph: 'J/cm²', w: '0.7fr' }, { k: 'type', label: 'Kind', type: 'select', options: [['number', 'Number'], ['text', 'Words']], w: '0.7fr' }, { k: 'ph', label: 'Example', ph: 'Contact, 5°C', w: '1fr' }], sh ? sh.fields : [{ type: 'number' }], 'Add setting')}</div>
      <p class="meta">Numbers show an arrow on the visit when they go up or down from the last session.${sh ? ' Visits already recorded keep the names they were saved with.' : ''}</p>`,
    onOpen: form => {
      wireRows(form);
      const del = form.querySelector('[data-del]');
      if (del) del.onclick = async () => {
        if (!(await confirmDanger(`Delete ${sh.name}?`, 'Visits that used it keep their settings.'))) return;
        form.close(null);
        try { await setMeta('templates', { ...S.templates, sheets: sheetsList().filter(x => x.id !== sh.id) }); render(); } catch (e) { fail(e); }
      };
    },
    validate: form => (!val(form, 'name') ? 'Enter the name.' : !readRows(form, 'fields').some(r => r.label) ? 'Add at least one setting.' : ''),
  });
  if (!f) return;
  const fields = readRows(f, 'fields').filter(r => r.label).map(r => ({ label: r.label, unit: r.unit || '', type: r.type || 'number', ph: r.ph || '' }));
  const rec = { id: sh ? sh.id : 'sheet-' + uid().slice(0, 8), name: val(f, 'name'), group: val(f, 'group'), fields };
  const list = sh ? sheetsList().map(x => (x.id === sh.id ? rec : x)) : [...sheetsList(), rec];
  try { await setMeta('templates', { ...S.templates, sheets: list }); toast('Saved.'); render(); } catch (e) { fail(e); }
}
