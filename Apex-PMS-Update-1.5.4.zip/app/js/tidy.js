// Loose ends, and saving a before and after as one picture.

// ---------- loose ends ----------
// What a busy day leaves undone in the last 30 days: visits not signed and consent still
// missing. Today's visits join the list once they are more than 2 hours old.
function looseEnds() {
  const today = todayISO(), from = addDays(today, -30);
  const inRange = v => v.date >= from && (v.date < today || Date.now() - (v.created || 0) > 2 * 3600000);
  const out = [];
  const pname = id => (patient(id) || {}).name || 'Unknown patient';
  for (const v of S.visits) {
    if (!inRange(v)) continue;
    const worked = (v.services || []).length || (v.treatments || []).length || v.complaint || v.assessment;
    if (!worked) continue;
    if (can('sign') && !v.signedAt && (isOwner() || v.doctorId === S.me.id)) out.push({ kind: 'sign', href: `#/visit/${v.id}`, who: pname(v.patientId), what: `Visit ${fmtDate(v.date)} not signed`, date: v.date });
    if (can('clinical') && !v.signedAt) {
      const p = patient(v.patientId);
      const miss = p ? [...consentsWanted(v, p)].filter(k => S.templates.consent[k] && !(v.consents || []).some(c => c.key === k)) : [];
      if (miss.length) out.push({ kind: 'consent', href: `#/visit/${v.id}`, who: pname(v.patientId), what: `Consent missing: ${miss.map(k => consentTitle(k)).join(', ')}`, date: v.date });
    }
  }
  return out.sort((a, b) => a.date.localeCompare(b.date));
}
const LOOSE_LABEL = { sign: 'Not signed', consent: 'Consent' };
function todayLooseEndsCard() {
  const list = looseEnds();
  if (!list.length) return '';
  return `<div class="card" id="loose"><div class="card-head"><h2>Loose ends</h2><span class="meta">${plural(list.length, 'thing')} to finish</span></div>
    <div class="list flat">${list.slice(0, 12).map(x => `<a class="li" href="${x.href}"><div class="grow"><div class="t medium">${esc(x.who)}</div><div class="m">${esc(x.what)}</div></div>${chip(LOOSE_LABEL[x.kind], 'bad')}</a>`).join('')}</div>
    ${list.length > 12 ? `<p class="meta">And ${list.length - 12} more from earlier.</p>` : ''}</div>`;
}

// ---------- before and after: save ----------
// The comparison on the Photos tab as one picture, with the dates under each side and the
// clinic name, for the patient to keep.
async function compareImage(idA, idB) {
  const load = id => new Promise((res, rej) => { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => res(im); im.onerror = () => rej(new Error('A photo could not be loaded.')); im.src = fullURL(id); });
  const [a, b] = await Promise.all([load(idA), load(idB)]);
  const H = 1200, wa = Math.round(a.width * H / a.height), wb = Math.round(b.width * H / b.height), gap = 16, band = 90;
  const c = document.createElement('canvas'); c.width = wa + wb + gap; c.height = H + band;
  const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
  g.drawImage(a, 0, 0, wa, H); g.drawImage(b, wa + gap, 0, wb, H);
  const pa = photoMeta(idA), pb = photoMeta(idB);
  g.fillStyle = '#1B222C'; g.font = '600 34px system-ui, sans-serif'; g.textBaseline = 'middle';
  g.fillText(`Before · ${fmtDate(photoVisitDate(pa))}`, 20, H + 34);
  g.fillText(`After · ${fmtDate(photoVisitDate(pb))}`, wa + gap + 20, H + 34);
  g.fillStyle = '#6B7686'; g.font = '500 24px system-ui, sans-serif';
  g.fillText(S.clinic.name || '', 20, H + 70);
  return new Promise(r => c.toBlob(r, 'image/jpeg', 0.9));
}
async function saveCompare(p, idA, idB) {
  try {
    const blob = await compareImage(idA, idB);
    const name = `${safeName(p.name)} before and after ${todayISO()}.jpg`;
    const file = new File([blob], name, { type: 'image/jpeg' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; } }
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  } catch (e) { fail(e); }
}
function compareActionsHTML(p) {
  return `<div class="row end" style="margin-top:8px"><button type="button" class="btn secondary small" data-act="cmp-save">Save the pair as one picture</button><button type="button" class="btn primary small" data-act="cmp-collage">Before and after picture</button></div>`;
}
function wireCompareActions(p) {
  const pick = () => [document.querySelector('[data-cmp="a"]').value, document.querySelector('[data-cmp="b"]').value];
  const sv = document.querySelector('[data-act="cmp-save"]');
  if (sv) sv.onclick = () => { const [a, b] = pick(); saveCompare(p, a, b); };
  const co = document.querySelector('[data-act="cmp-collage"]');
  if (co) co.onclick = () => openCollage(p.id, { pick: pick() });
}

