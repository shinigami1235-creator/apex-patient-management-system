// Tablets and phones: the laptop's hotspot, the Connect screen with its two QR codes, the
// list of signed-in devices, and sending a screen from one device to another.

const onClinicPC = () => ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
const DEVICE_NAME_KEY = 'apex_device_name';
function deviceName() { try { return localStorage.getItem(DEVICE_NAME_KEY) || ''; } catch (e) { return ''; } }
function setDeviceName(n) { try { if (n) localStorage.setItem(DEVICE_NAME_KEY, n); else localStorage.removeItem(DEVICE_NAME_KEY); } catch (e) { /* kept for this sign-in only */ } }
const HOTSPOT_BAND = { TwoPointFourGigahertz: '2.4 GHz', FiveGigahertz: '5 GHz', SixGigahertz: '6 GHz', Auto: 'any band' };

// The address a tablet opens: the secure one, on the hotspot when it is on.
function tabletIP(h) { return h && h.ok && h.state === 'On' ? h.ip : ((S.lan || []).find(x => x !== '192.168.137.1') || (S.lan || [])[0]); }
function tabletURL(h) {
  const ip = tabletIP(h);
  if (!ip) return '';
  const port = (h && h.securePort) || S.securePort;
  return port ? `https://${ip}:${port}/` : `http://${ip}:${(h && h.port) || S.port}/`;
}
// The set-up page a new tablet opens first, over plain http since it does not trust the PC yet.
function tabletSetupURL(h) { const ip = tabletIP(h); return ip ? `http://${ip}:${(h && h.port) || S.port}/tablet.html` : ''; }
function deviceTitle(d) { return d.name || d.kind; }

// ---------- the Connect screen ----------
let connectTimer = null;
function openConnect() {
  document.querySelectorAll('.connect-ov').forEach(x => x.remove());
  const el = document.createElement('div');
  el.className = 'connect-ov';
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Connect a tablet or phone');
  el.innerHTML = '<div class="cx-top"><b>Connect a tablet or phone</b><button class="btn quiet small" data-cx-close>Close</button></div><div class="cx-body"><p class="meta">Checking the hotspot.</p></div>';
  document.body.appendChild(el);
  document.body.classList.add('ov-open');
  const close = () => { clearInterval(connectTimer); connectTimer = null; el.remove(); document.body.classList.remove('ov-open'); document.removeEventListener('keydown', onKey); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  el.querySelector('[data-cx-close]').onclick = close;
  let h = null, busy = false, devs = [], helpOpen = false;
  const paint = () => {
    const body = el.querySelector('.cx-body');
    const on = h && h.ok && h.state === 'On';
    const url = tabletURL(h);
    const hotspotCard = !h ? '' : !h.supported ? `<div class="card cx-hs"><h2 class="card-title">Clinic wifi</h2><p class="muted">${esc(h.error)}</p></div>` : `
      <div class="card cx-hs">
        <div class="card-head"><h2>Laptop hotspot</h2><span class="chip ${on ? 'ok' : ''}">${on ? `On · ${plural(h.clients || 0, 'device')} joined` : h.ok ? 'Off' : 'Not available'}</span></div>
        ${h.ok ? `<p class="muted">${on ? `Tablets and phones join the laptop's own wifi, so the branch works with no router. ${h.sharing === 'internet' ? `Devices that join also get the laptop's internet from ${esc(h.network || 'its connection')}.` : 'The laptop has no internet now, so devices on the hotspot have none either.'}` : 'Turn it on and the laptop makes its own wifi for the branch\'s tablets and phones, with no router needed.'}</p>` : `<p class="bad-text">${esc(h.error)}</p>`}
        <div class="row wrap">${h.ok ? `<button class="btn ${on ? 'secondary' : 'primary'}" data-cx="${on ? 'off' : 'on'}" ${busy ? 'disabled' : ''}>${busy ? 'Switching' : on ? 'Turn off' : 'Turn on the hotspot'}</button>` : '<button class="btn secondary" data-cx="retry">Try again</button>'}
          <label class="check"><input type="checkbox" data-cx="auto" ${h.auto ? 'checked' : ''}> Turn on when the system starts</label></div>
      </div>`;
    const step1 = on ? `<div class="cx-step"><span class="cx-n">1</span><h3>Join the wifi</h3><div class="qr" data-qr-raw="${esc(h.wifi)}"></div>
        <dl class="cx-wifi"><dt>Name</dt><dd>${esc(h.ssid)}</dd><dt>Password</dt><dd>${esc(h.passphrase)}</dd></dl>
        <p class="meta">Point the camera at the code and tap Join.${h.band && HOTSPOT_BAND[h.band] ? ` ${esc(HOTSPOT_BAND[h.band])}.` : ''}</p></div>`
      : `<div class="cx-step"><span class="cx-n">1</span><h3>Join the branch wifi</h3><p class="muted">${h && h.supported && h.ok ? 'Turn on the hotspot above for a code to scan, or join the branch router\'s wifi.' : 'Join the same wifi as this PC.'}</p></div>`;
    const setup = tabletSetupURL(h);
    const step2 = `<div class="cx-step"><span class="cx-n">2</span><h3>Set up the tablet</h3>${setup ? `<div class="qr" data-qr-raw="${esc(setup)}"></div><b class="cx-url">${esc(setup)}</b>
        <p class="meta">Once per tablet. The page installs the branch PC's certificate on an iPad or an Android tablet, so the camera and microphone work with no warning.</p>` : '<p class="bad-text">This PC is not on any network yet.</p>'}</div>`;
    const step3 = `<div class="cx-step"><span class="cx-n">3</span><h3>Open the app and sign in</h3>${url ? `<div class="qr" data-qr-raw="${esc(url)}"></div><b class="cx-url">${esc(url)}</b>` : ''}<p class="muted">Sign in with your own PIN. Add it to the home screen so it opens like an app next time.</p></div>`;
    const live = devs.filter(d => d.live && !d.self);
    body.innerHTML = `${hotspotCard}
      <div class="cx-steps">${step1}${step2}${step3}</div>
      <div class="card"><div class="card-head"><h2>Connected now</h2><a href="#/settings/devices" data-cx-all>All signed-in devices</a></div>
        ${live.length ? `<div class="list">${live.map(d => `<div class="li"><div class="grow"><div class="t">${esc(deviceTitle(d))}</div><div class="m">${esc(d.user)}${d.ip ? ' · ' + esc(d.ip) : ''}</div></div><span class="chip ok">Live</span></div>`).join('')}</div>` : '<p class="muted">No tablet or phone is signed in yet.</p>'}</div>
      ${h && h.supported ? `<details class="cx-help" ${helpOpen ? 'open' : ''}><summary>The tablet joined but the page will not open</summary>
        <p class="muted">Windows Firewall may be blocking tablets on the hotspot. Allow the branch PC's ports ${esc(String(h.port))} and ${esc(String(h.securePort || h.port + 1))} through it. Windows asks for permission first. This adds one firewall rule for these two ports only. Nothing else changes.</p>
        <button class="btn secondary" data-cx="firewall">Allow tablets through the firewall</button></details>
        <p class="meta">The hotspot name and password are set in Windows. <a href="#" data-cx="settings">Open the hotspot settings</a></p>` : ''}`;
    body.querySelectorAll('[data-qr-raw]').forEach(q => { q.innerHTML = qrSVG(q.dataset.qrRaw, 230); });
    const act = sel => body.querySelector(`[data-cx="${sel}"]`);
    const sw = async payload => { busy = true; paint(); try { h = await api('/api/hotspot', payload); } catch (e) { fail(e); } busy = false; paint(); };
    if (act('on')) act('on').onclick = () => sw({ on: true });
    if (act('off')) act('off').onclick = async () => { if (h.clients && !(await ask({ title: 'Turn off the hotspot?', body: `${plural(h.clients, 'device')} on it lose the connection. Their saves wait on them until they are back.`, buttons: [{ label: 'Cancel', value: null }, { label: 'Turn off', value: true, kind: 'primary' }] }))) return; sw({ on: false }); };
    if (act('retry')) act('retry').onclick = () => load(true);
    if (act('auto')) act('auto').onchange = e => sw({ auto: e.target.checked });
    if (act('settings')) act('settings').onclick = e => { e.preventDefault(); api('/api/hotspot/settings', {}).catch(fail); };
    if (act('firewall')) act('firewall').onclick = async () => { try { await api('/api/hotspot/firewall', {}); toast('Tablets are allowed through the firewall.'); } catch (e) { fail(e); } };
    const all = body.querySelector('[data-cx-all]'); if (all) all.onclick = () => close();
    const help = body.querySelector('.cx-help'); if (help) help.ontoggle = () => { helpOpen = help.open; };
  };
  const load = async fresh => {
    try { h = onClinicPC() || S.me.role === 'owner' ? await api('/api/hotspot' + (fresh ? '?fresh=1' : '')) : { supported: false, error: 'The hotspot is switched on at the branch PC.' }; } catch (e) { h = { supported: false, error: e.message }; }
    try { devs = await api('/api/devices'); } catch (e) { devs = []; }
    if (!busy && document.body.contains(el)) paint();
  };
  load(true);
  connectTimer = setInterval(() => load(false), 5000);
}

// ---------- Settings, Devices ----------
function devicesTabHTML() {
  return `${S.me.role === 'owner' || onClinicPC() ? `<div class="card"><div class="card-head"><h2>Connect a tablet or phone</h2>${onClinicPC() ? '<button class="btn primary" data-act="connect">Show the codes</button>' : ''}</div>
      <p class="muted">${onClinicPC() ? 'Shows the codes a new tablet scans: the wifi, the one-time set-up page and the app.' : 'Open this page on the branch PC to show the codes for joining the wifi, setting up a tablet and opening the app.'}</p>
      ${!onClinicPC() && tabletURL(null) ? `<p class="meta">This branch's address: ${esc(tabletURL(null))} · Tablet set-up: ${esc(tabletSetupURL(null))}</p>` : ''}</div>` : ''}
    <form class="card" id="thisdevice"><h2 class="card-title">This device</h2>
      <div class="grid2">${field('Name', 'name', deviceName(), { ph: 'Treatment room iPad', hint: 'Shown when someone sends a screen to a tablet, and in the list below.' })}<div class="field"><span class="label">&nbsp;</span><button class="btn secondary">Save name</button></div></div></form>
    <div class="card"><div class="card-head"><h2>Signed-in devices</h2></div><div id="devlist"><p class="meta">Loading.</p></div>
      <p class="meta">${S.me.role === 'owner' ? 'Sign out a lost or replaced tablet here. Whoever has it needs a PIN to get back in.' : 'The tablets, phones and computers you are signed in on. Sign one out here if it is lost.'}</p></div>
`;
}
async function wireDevicesTab() {
  const c = document.querySelector('[data-act="connect"]'); if (c) c.onclick = openConnect;
  const f = document.getElementById('thisdevice');
  f.onsubmit = async e => { e.preventDefault(); const n = val(f, 'name'); setDeviceName(n); try { await api('/api/devices/name', { name: n }); toast(n ? `This device is ${n}.` : 'Name cleared.'); paintDevList(); } catch (ex) { fail(ex); } };
  paintDevList();
}
async function paintDevList() {
  const box = document.getElementById('devlist'); if (!box) return;
  let list = [];
  try { list = await api('/api/devices'); } catch (e) { box.innerHTML = `<p class="bad-text">${esc(e.message)}</p>`; return; }
  // everyone but the admin sees only their own devices
  if (S.me.role !== 'owner') list = list.filter(d => d.self || d.userId === S.me.id);
  box.innerHTML = list.length ? `<div class="list">${list.map(d => `<div class="li"><div class="grow"><div class="t">${esc(deviceTitle(d))}${d.self ? ' <span class="meta">(this one)</span>' : ''}</div>
      <div class="m">${esc(d.user)}${d.name ? ' · ' + esc(d.kind) : ''}${d.ip ? ' · ' + esc(d.ip) : ''}${d.seen ? ' · last used ' + esc(fmtStamp(d.seen)) : ''}</div></div>
      ${d.live ? '<span class="chip ok">Live</span>' : ''}${d.self || !(S.me.role === 'owner' || d.userId === S.me.id) ? '' : `<button class="btn quiet small" data-signout="${esc(d.id)}">Sign out</button>`}</div>`).join('')}</div>` : '<p class="muted">Only this device.</p>';
  box.querySelectorAll('[data-signout]').forEach(b => b.onclick = async () => {
    const d = list.find(x => x.id === b.dataset.signout);
    if (!(await ask({ title: `Sign out ${deviceTitle(d)}?`, body: `${d.user} needs their PIN to use it again. Saves still waiting on it go over when they sign back in.`, buttons: [{ label: 'Cancel', value: null }, { label: 'Sign out', value: true, kind: 'primary' }] }))) return;
    try { await api('/api/devices/signout', { id: d.id }); toast('Signed out.'); paintDevList(); } catch (e) { fail(e); }
  });
}

// ---------- sending a screen to another device ----------
function sendButtonHTML(hash, what) {
  // On a tablet or phone the screen is already in hand, so the button shows on the PC and laptops only.
  if (window.matchMedia && matchMedia('(pointer: coarse)').matches && !matchMedia('(any-pointer: fine)').matches) return '';
  return `<button class="btn secondary" data-send="${esc(hash)}" data-send-what="${esc(what)}" title="Open this on a tablet or phone that is signed in">${I.send}Send to tablet</button>`;
}
async function sendToDevice(hash, what) {
  let list = [];
  try { list = (await api('/api/devices')).filter(d => d.live && !d.self); } catch (e) { return fail(e); }
  if (!list.length) return ask({ title: 'No tablet is connected', body: `<p class="muted">Sign in on the tablet first. It shows here while the app is open on it.</p>${onClinicPC() ? '<p class="meta">Connect a tablet from the wifi button in the top bar.</p>' : ''}`, buttons: [{ label: 'OK', value: null, kind: 'primary' }] });
  const id = list.length === 1 ? list[0].id : await ask({ title: `Send ${what}`, body: '<p class="muted">Opens on the device straight away.</p>', buttons: [{ label: 'Cancel', value: null }, ...list.map(d => ({ label: `${deviceTitle(d)} · ${d.user}`, value: d.id }))] });
  if (!id) return;
  try { await api('/api/devices/send', { id, hash, what }); const d = list.find(x => x.id === id); toast(`Sent to ${deviceTitle(d)}.`); } catch (e) { fail(e); }
}
// Another device sent a screen here.
function onRemoteGoto(m) {
  if (!S.me) return;
  if (document.querySelector('.checkin, .pview')) { S.pendingGoto = m.goto; return toast(`${m.from} sent ${m.what || 'a screen'}. It opens when the patient hands the tablet back.`, 6000); }
  document.querySelectorAll('.scrim').forEach(x => x.remove());
  go(m.goto);
  toast(`${m.from} sent ${m.what || 'this screen'}.`, 4000);
}

document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-send]');
  if (b) { e.preventDefault(); sendToDevice(b.dataset.send, b.dataset.sendWhat || 'this screen'); }
  const c = e.target.closest && e.target.closest('[data-act="connect-top"]');
  if (c) { e.preventDefault(); openConnect(); }
});
