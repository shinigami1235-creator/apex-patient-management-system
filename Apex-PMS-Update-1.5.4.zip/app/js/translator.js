// Real Time Translator, the separate program that listens to a speaker and shows the English
// a few seconds behind. It runs on a computer with an NVIDIA card on the branch wifi. The
// doctor opens its live page from the visit, and saves the transcript on the visit when the
// talk is done. English only: the translator turns Thai, Chinese and other speech into English.

const translatorURL = () => {
  let u = String((S.translator || {}).url || '').trim();
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
  try { return new URL(u).origin; } catch (e) { return ''; }
};

// ---------- settings ----------
function translatorTab() {
  const t = S.translator || {};
  return `<form class="card" id="trset"><h2 class="card-title">Translator</h2>
    <p class="muted">Real Time Translator runs on its own computer, best one with an NVIDIA card, on this branch's wifi. It listens to the patient or an interpreter and shows the English a few seconds behind. Doctors open it from a visit and save the transcript on the visit.</p>
    <div class="grid2">${field('Translator address', 'url', t.url || '', { ph: 'http://192.168.1.20:8000', hint: 'Shown under the QR on the translator\'s host panel.' })}${field('Note for doctors', 'note', t.note || '', { ph: 'Translator laptop in consult room 2' })}</div>
    <div data-trstatus></div>
    <ol class="steps muted"><li>On the translator computer, double-click start.bat and keep the black window open.</li>
      <li>On its host panel, pick the microphone, set the speaker's language if you know it, and leave "Let viewers download the transcript" ticked.</li>
      <li>Copy the address under the QR code into the box above and press Save.</li></ol>
    <div class="row end"><button type="button" class="btn secondary" data-trtest>Test</button><button class="btn primary">Save</button></div></form>`;
}
function wireTranslatorTab() {
  const f = document.getElementById('trset');
  const box = f.querySelector('[data-trstatus]');
  const test = async () => {
    box.innerHTML = '<p class="meta">Checking.</p>';
    try {
      const st = await api('/api/translator/status');
      box.innerHTML = !st.set ? '<p class="meta">No address set.</p>'
        : st.ok ? `<p class="ok-text">The translator answered. Its transcript has ${plural(st.lines, 'line')} so far.</p>`
        : `<p class="bad-text">${esc(st.error || 'The address is not on the branch wifi.')}</p>`;
    } catch (e) { box.innerHTML = `<p class="bad-text">${esc(e.message)}</p>`; }
  };
  f.querySelector('[data-trtest]').onclick = test;
  f.onsubmit = async e => {
    e.preventDefault();
    try { await setMeta('translator', { url: val(f, 'url'), note: val(f, 'note') }); delete f.dataset.dirty; toast('Translator saved.'); test(); } catch (ex) { fail(ex); }
  };
  if ((S.translator || {}).url) test();
}

// ---------- on the visit ----------
function transcriptsOf(visitId) { return S.transcripts.filter(t => t.visitId === visitId).sort((a, b) => (a.created || 0) - (b.created || 0)); }
function translatorCard(v, p, locked) {
  const url = translatorURL(), list = transcriptsOf(v.id);
  if (!url && !list.length) return '';
  const canSave = (ACCESS.transcripts[S.me.role] || '').includes('w');
  return `<div class="card" id="vtrans"><div class="card-head"><h2>Translator</h2>${url ? `<div class="row">
      <a class="btn secondary small" href="${esc(url)}/" target="_blank" rel="noopener">Open the live English</a>
      ${canSave && !locked ? '<button class="btn primary small" data-act="tr-save">Save transcript on this visit</button>' : ''}</div>` : ''}</div>
    ${url ? `<p class="muted">Start the translator on its computer first.${S.translator.note ? ' ' + esc(S.translator.note) + '.' : ''} The English is machine-made, so check doses, times and names with the patient.</p>` : ''}
    ${list.length ? `<div class="list flat">${list.map(t => `<button type="button" class="li" data-tr="${t.id}"><div class="grow"><div class="t medium">${esc(t.title || 'Transcript')}</div><div class="m">${esc(fmtTime(new Date(t.created).toTimeString().slice(0, 5)))} · ${plural(t.lines || 0, 'line')}${t.by ? ' · ' + esc(userName(t.by)) : ''}</div></div></button>`).join('')}</div>` : ''}</div>`;
}
function wireTranslatorCard(v, p) {
  const card = document.getElementById('vtrans');
  if (!card) return;
  const b = card.querySelector('[data-act="tr-save"]');
  if (b) b.onclick = async () => {
    b.disabled = true;
    try {
      const { text } = await api('/api/translator/pull', {});
      const rows = text.split('\n');
      const lines = rows.filter(l => /^\[/.test(l)).length;
      if (!lines) { toast('The translator has no lines yet.'); return; }
      const title = (rows[0] || '').trim();
      // the same talk saved twice keeps the longer copy
      const same = transcriptsOf(v.id).find(t => t.title === title && text.startsWith((t.text || '').split('\n').slice(0, 4).join('\n')));
      const doc = same ? { ...same, text, lines } : { id: uid(), patientId: p.id, visitId: v.id, date: v.date, title, text, lines, by: S.me.id };
      await save('transcripts', doc, { action: same ? 'Transcript updated' : 'Transcript saved' });
      toast(same ? 'Transcript updated on this visit.' : 'Transcript saved on this visit.');
      render();
    } catch (ex) { fail(ex); } finally { b.disabled = false; }
  };
  card.querySelectorAll('[data-tr]').forEach(x => x.onclick = () => {
    const t = byId('transcripts', x.dataset.tr);
    if (!t) return;
    ask({ title: t.title || 'Transcript', body: `<pre class="emr-text" translate="no">${esc(t.text || '')}</pre>`, buttons: [{ label: 'Copy', value: 'copy' }, { label: 'Close', value: null, kind: 'primary' }] })
      .then(r => { if (r === 'copy') copyText(t.text || ''); });
  });
}
