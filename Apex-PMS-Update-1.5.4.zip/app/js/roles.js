// Roles and what each one can open. The server enforces the same table, so a
// screen hidden here is also refused by the server.
// The keys stay as they were in Cygnus Clinic: owner is the Admin, nurse is the Assistant.

const ROLES = {
  owner: { label: 'Admin', desc: 'Everything, including settings, the doctors and assistants, backups and the change log.', clinical: true, sign: true, admin: true, edit: true },
  doctor: { label: 'Doctor', desc: 'Patient records, notes, charts, photos and the clinical tools. Signs visits.', clinical: true, sign: true, admin: false, edit: true },
  rn: { label: 'Nurse', desc: 'Records the care they give on the visit, such as an IV drip or a dressing, with photos and consent. Doctors sign the visits.', clinical: true, sign: false, admin: false, edit: true },
  nurse: { label: 'Assistant', desc: 'Patient records, photos, consent forms and check-in. Doctors sign the visits.', clinical: true, sign: false, admin: false, edit: true },
  // Reception: books patients, sends the reminders, and looks up patients and visits.
  staff: { label: 'Staff', desc: 'Books patients and sends the reminders. Opens patients, visits and photos, and changes no clinical record.', clinical: true, sign: false, admin: false, edit: false },
};

// read: 'all' | 'own' (rows where userId is theirs) | 'filter' (server trims rows or fields) | false
// write: true | 'limited' (only the listed fields) | false
const ACCESS = {
  //                 admin          doctor         assistant      staff
  users:      { owner: 'rw', doctor: 'r', rn: 'r', nurse: 'r', staff: 'r' },
  // The staff add a new patient from a booking and change only the contact details.
  patients:   { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'rl' },
  visits:     { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  charts:     { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  heads:      { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  photos:     { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  // The treatments the branch does, with the consent forms, aftercare and device settings each one needs.
  services:   { owner: 'rw', doctor: 'r', rn: 'r', nurse: 'r', staff: 'r' },
  // The products used on patients, with brand and unit. Stock is counted in Apex's own system.
  products:   { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  // Lot numbers and expiry dates of each product, for the chart and for a recall.
  lots:       { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  // Sync conflicts: the admin sees every one, everyone else sees their own.
  conflicts:  { owner: 'rw', doctor: 'ow', rn: 'ow', nurse: 'ow', staff: 'ow' },
  // Patient tags and custom fields are the admin's to define. Everyone reads the list.
  tags:       { owner: 'rw', doctor: 'r', rn: 'r', nurse: 'r', staff: 'r' },
  fields:     { owner: 'rw', doctor: 'r', rn: 'r', nurse: 'r', staff: 'r' },
  // The complication log.
  incidents:  { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  // Treatment presets: services, chart marks and forms put on a visit in one go.
  presets:    { owner: 'rw', doctor: 'rw', rn: 'r', nurse: 'r', staff: 'r' },
  // Skin analysis results, one per scan.
  analyses:   { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'r' },
  // Lip, chin and nose previews saved to the patient file.
  previews:   { owner: 'rw', doctor: 'rw', rn: 'r', nurse: 'r', staff: 'r' },
  // Live translator transcripts saved to a visit.
  transcripts: { owner: 'rw', doctor: 'rw', rn: 'r', nurse: 'r', staff: 'r' },
  // Appointments. The staff do most of the booking.
  bookings:   { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'rw' },
  // Reminders sent on LINE, and the ones to send by hand. The PC writes them.
  messages:   { owner: 'rw', doctor: 'rw', rn: 'rw', nurse: 'rw', staff: 'rw' },
};

// The areas the admin sets for each role under Settings, People: no access, view, or edit.
// Each area covers the record types listed, and the admin's choice replaces the table above
// for them. The admin always has everything, and only doctors sign visits.
const ACCESS_AREAS = [
  ['patients', 'Patient records', ['patients']],
  ['visits', 'Visits, notes and treatments', ['visits', 'transcripts']],
  ['charts', 'Charts and photos', ['charts', 'photos', 'heads']],
  ['bookings', 'Bookings and reminders', ['bookings', 'messages']],
  ['incidents', 'Complications', ['incidents']],
  ['products', 'Products and lots', ['products', 'lots']],
  ['presets', 'Treatment presets', ['presets']],
];
const ACCESS_LEVELS = [['rw', 'Edit'], ['rl', 'Contact details only'], ['r', 'View'], ['', 'No access']];
// The rule for one record type: the admin's choice for its area when there is one, else the table.
function accessRule(store, role, custom) {
  if (role === 'owner') return (ACCESS[store] && ACCESS[store].owner) || '';
  const area = ACCESS_AREAS.find(a => a[2].includes(store));
  const set = custom && area && custom[role] && Object.prototype.hasOwnProperty.call(custom[role], area[0]) ? custom[role][area[0]] : undefined;
  if (set !== undefined && ACCESS_LEVELS.some(l => l[0] === set) && (set !== 'rl' || area[0] === 'patients')) return set;
  return (ACCESS[store] && ACCESS[store][role]) || '';
}

// Fields a 'limited' writer may change. Anything else in their save is dropped.
const LIMITED_FIELDS = { patients: ['phone', 'line', 'plang', 'lineCode', 'cardPhoto'] };
// And the fields they may fill in on a new record.
const LIMITED_NEW = { patients: ['name', 'nameTh', 'created'] };
// Which roles may see a custom field: the roles ticked on it.
function fieldVisible(f, role) {
  if (!f) return false;
  if (role === 'owner') return true;
  return (f.roles || []).includes(role);
}

if (typeof module !== 'undefined') module.exports = { ROLES, ACCESS, ACCESS_AREAS, ACCESS_LEVELS, accessRule, LIMITED_FIELDS, LIMITED_NEW, fieldVisible };
