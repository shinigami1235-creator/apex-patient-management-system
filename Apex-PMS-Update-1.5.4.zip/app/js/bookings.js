// Bookings: the appointment book by doctor and day, with the follow-ups still to book and the
// reminders. A booking turns into the visit when the patient arrives. Confirmations and
// reminders go out on LINE from the branch PC (server/line.js); a patient not on LINE is on
// the Reminders list to message or call by hand.

const BOOK_STATUS = { booked: 'Booked', confirmed: 'Confirmed', arrived: 'Arrived', done: 'Done', noshow: 'No-show', cancelled: 'Cancelled' };
const BOOK_LIVE = b => !['cancelled', 'noshow'].includes(b.status);
const bookingsOn = d => S.bookings.filter(b => b.date === d).sort((a, b) => a.time.localeCompare(b.time));
const bookName = b => { const p = b.patientId ? patient(b.patientId) : null; return p ? p.name : (b.name || 'Unknown'); };
const bookWhat = b => { const sv = b.serviceId ? service(b.serviceId) : null; return [sv ? sv.name : '', b.what || ''].filter(Boolean).join(', '); };
// The same on the page, with the note as typed: notes stay out of the Thai.
const bookWhatHTML = b => { const sv = b.serviceId ? service(b.serviceId) : null; return [sv ? esc(sv.name) : '', b.what ? `<span translate="no">${esc(b.what)}</span>` : ''].filter(Boolean).join(', '); };
const minsOf = t => { const [h, m] = String(t || '0:0').split(':').map(Number); return h * 60 + m; };
const bookHours = () => [minsOf(S.clinic.opens || '09:00'), minsOf(S.clinic.closes || '20:00')];
const canBook = () => accessOf('bookings').includes('w');
// Patients whose follow-up date is near and who have nothing booked from today on.
function followUpsToBook(days = 30) {
  const today = todayISO(), until = addDays(today, days), from = addDays(today, -14);
  const booked = new Set(S.bookings.filter(b => b.date >= today && BOOK_LIVE(b)).map(b => b.patientId));
  const seen = new Set();
  return S.visits.filter(v => v.followUp && v.followUp >= from && v.followUp <= until && !booked.has(v.patientId))
    .sort((a, b) => a.followUp.localeCompare(b.followUp))
    .filter(v => (seen.has(v.patientId) ? false : seen.add(v.patientId)));
}

function renderBookings(q = {}) {
  const view = ['day', 'week', 'reminders'].includes(q.v) ? q.v : 'day';
  const d = /^\d{4}-\d{2}-\d{2}$/.test(q.d || '') ? q.d : todayISO();
  const nav = (days) => `#/book?v=${view}&d=${addDays(d, days)}`;
  const step = view === 'week' ? 7 : 1;
  const todo = S.messages.filter(m => m.status === 'todo' || m.status === 'failed').length;
  const tabs = [['day', 'Day'], ['week', 'Week'], ['reminders', 'Reminders', todo || '']];
  const head = `<div class="page-head"><div><h1>Bookings</h1><p class="meta">${view === 'week' ? `${fmtDate(weekStart(d))} to ${fmtDate(addDays(weekStart(d), 6))}` : view === 'day' ? `${esc(weekday(d))} ${fmtDate(d)}` : 'Confirmations, reminders and follow-ups'}</p></div>
    <div class="row wrap-end">${view !== 'reminders' ? `<a class="btn secondary small" href="${nav(-step)}" aria-label="Back">‹</a><a class="btn secondary small" href="#/book?v=${view}">Today</a><a class="btn secondary small" href="${nav(step)}" aria-label="Next">›</a><input type="date" class="book-date" value="${d}" aria-label="Go to a date">` : ''}${canBook() ? `<button class="btn primary" data-book-new>${I.plus}New booking</button>` : ''}</div></div>
    <nav class="tabs" aria-label="Sections">${tabs.map(([k, l, n]) => `<a href="#/book?v=${k}&d=${d}" ${k === view ? 'aria-current="page"' : ''}>${l}${n ? ` <span class="count">${n}</span>` : ''}</a>`).join('')}</nav>`;
  const body = view === 'day' ? bookDayHTML(d) : view === 'week' ? bookWeekHTML(d) : remindersHTML();
  $app.innerHTML = shell('book', head + body, { wide: view !== 'reminders' });
  wireShell();
  wireBookings(d, view);
}

// ---------- day ----------
// A column for each doctor, with the time down the side. Tap a free time to book it.
function bookDayHTML(d) {
  const list = bookingsOn(d);
  const docs = doctors();
  const cols = [...docs.map(u => ({ id: u.id, name: u.name })), ...(list.some(b => !b.doctorId || !docs.some(u => u.id === b.doctorId)) ? [{ id: '', name: 'Any doctor' }] : [])];
  const [open, close] = bookHours();
  const first = Math.min(open, ...list.map(b => minsOf(b.time))), last = Math.max(close, ...list.map(b => minsOf(b.time) + (b.mins || 30)));
  const top = Math.floor(first / 30) * 30, rows = Math.ceil((last - top) / 30), H = 52;
  const block = b => {
    const y = (minsOf(b.time) - top) / 30 * H, h = Math.max(H - 4, (b.mins || 30) / 30 * H - 4);
    return `<button class="bk st-${esc(b.status)}" data-book="${b.id}" style="top:${y}px;height:${h}px" ><b>${esc(b.time)} ${esc(bookName(b))}</b><span>${[b.status !== 'booked' ? esc(BOOK_STATUS[b.status]) : '', bookWhatHTML(b)].filter(Boolean).join(' · ')}</span></button>`;
  };
  const fu = followUpsToBook();
  return `<div class="book-wrap"><div class="book-day" style="--cols:${cols.length}">
      <div class="bd-times">${Array.from({ length: rows }, (_, i) => `<span style="height:${H}px">${i % 2 === 0 ? timeOf(top + i * 30) : ''}</span>`).join('')}</div>
      ${cols.map(c => `<div class="bd-col"><div class="bd-head">${esc(c.name)}</div><div class="bd-slots" data-col="${c.id}" data-top="${top}" style="height:${rows * H}px">
        ${Array.from({ length: rows }, (_, i) => `<span class="bd-slot" data-time="${timeOf(top + i * 30)}" style="top:${i * H}px;height:${H}px"></span>`).join('')}
        ${list.filter(b => (b.doctorId || '') === c.id || (!c.id && b.doctorId && !docs.some(u => u.id === b.doctorId))).map(block).join('')}</div></div>`).join('')}
    </div>
    <aside class="card book-side"><h2 class="card-title">Follow-ups to book</h2>${fu.length ? `<div class="list flat">${fu.slice(0, 20).map(v => { const p = patient(v.patientId) || { name: 'Unknown patient' }; return `<div class="li"><div class="grow"><div class="t medium">${esc(p.name)}</div><div class="m">${fmtDate(v.followUp)} · ${esc(v.followReason || 'Follow-up')}</div></div>${canBook() ? `<button class="btn secondary small" data-book-fu="${v.id}">Book</button>` : ''}</div>`; }).join('')}</div>` : '<p class="muted">Everyone with a follow-up due has a booking.</p>'}</aside></div>`;
}

// ---------- week ----------
function bookWeekHTML(d) {
  const start = weekStart(d), today = todayISO();
  return `<div class="book-week">${Array.from({ length: 7 }, (_, i) => addDays(start, i)).map(day => {
    const list = bookingsOn(day);
    return `<div class="bw-day ${day === today ? 'today' : ''}"><a class="bw-head" href="#/book?v=day&d=${day}"><b>${esc(weekday(day))}</b><span>${fmtDate(day)}</span></a>
      ${list.length ? list.map(b => `<button class="bw-item st-${esc(b.status)}" data-book="${b.id}"><b>${esc(b.time)}</b> ${esc(bookName(b))}<span>${[bookWhatHTML(b), esc(userName(b.doctorId))].filter(Boolean).join(' · ')}</span></button>`).join('') : '<p class="meta">Nothing booked.</p>'}
      ${canBook() ? `<button class="bw-add" data-book-day="${day}">${I.plus}Book</button>` : ''}</div>`;
  }).join('')}</div>`;
}

// ---------- reminders ----------
function remindersHTML() {
  const li = S.lineInfo || {};
  const todo = S.messages.filter(m => m.status === 'todo').sort((a, b) => (a.created || 0) - (b.created || 0));
  const failed = S.messages.filter(m => m.status === 'failed');
  const sent = S.messages.filter(m => m.status === 'sent' || m.status === 'done').sort((a, b) => (b.sentAt || b.updated || 0) - (a.sentAt || a.updated || 0)).slice(0, 40);
  const KIND = { confirm: 'Confirmation', remind: 'Reminder for tomorrow', soon: 'Reminder today', followup: 'Follow-up due' };
  const row = (m, acts) => { const p = patient(m.patientId) || { name: 'Unknown patient' }; return `<div class="li msg"><div class="grow"><div class="t medium">${esc(p.name)} <span class="meta">${esc(KIND[m.kind] || m.kind)}</span></div>
    <div class="msg-text" translate="no">${esc(m.text)}</div><div class="m">${p.phone ? `${esc(p.phone)} · ` : ''}${m.status === 'sent' ? 'Sent on LINE ' + fmtStamp(m.sentAt) : m.status === 'done' ? 'Sent by hand ' + fmtStamp(m.doneAt) : m.status === 'failed' ? 'LINE did not take it: ' + esc(m.error || '') : 'Not on LINE'}</div></div>${acts}</div>`; };
  const handActs = m => `<div class="row"><button class="btn secondary small" data-msg-copy="${m.id}">Copy</button>${canBook() ? `<button class="btn primary small" data-msg-done="${m.id}">Sent</button>` : ''}</div>`;
  return `${li.on ? '' : `<div class="banner info">LINE is not set up, so every reminder is on the list to send by hand.${isOwner() ? ' <a href="#/settings/line">Set up LINE</a>' : ''}</div>`}
    ${canBook() ? '<div class="row" style="margin-bottom:12px"><button class="btn secondary small" data-run-reminders>Check for reminders now</button><span class="meta">The PC checks every minute by itself.</span></div>' : ''}
    <section class="card"><div class="card-head"><h2>To send by hand</h2><span class="meta">${plural(todo.length, 'message')}</span></div>${todo.length ? `<div class="list flat">${todo.map(m => row(m, handActs(m))).join('')}</div><p class="meta">These patients have not linked LINE. Copy the message into the clinic's LINE chat or call them, then press Sent.</p>` : '<p class="muted">Nothing to send by hand.</p>'}</section>
    ${failed.length ? `<section class="card"><div class="card-head"><h2>LINE did not send</h2></div><div class="list flat">${failed.map(m => row(m, handActs(m))).join('')}</div></section>` : ''}
    <section class="card"><div class="card-head"><h2>Sent</h2></div>${sent.length ? `<div class="list flat">${sent.map(m => row(m, '')).join('')}</div>` : '<p class="muted">Nothing sent yet.</p>'}</section>`;
}

function wireBookings(d, view) {
  const on = (sel, fn) => document.querySelectorAll(sel).forEach(b => b.onclick = e => { e.preventDefault(); fn(b); });
  const dt = document.querySelector('.book-date');
  if (dt) dt.onchange = () => go(`#/book?v=${view}&d=${dt.value}`);
  on('[data-book-new]', () => bookingSheet({ date: d }));
  on('[data-book]', b => bookingSheet(byId('bookings', b.dataset.book)));
  on('[data-book-day]', b => bookingSheet({ date: b.dataset.bookDay }));
  on('[data-book-fu]', b => { const v = visit(b.dataset.bookFu); bookingSheet({ patientId: v.patientId, date: v.followUp >= todayISO() ? v.followUp : todayISO(), doctorId: v.doctorId, what: v.followReason || 'Follow-up', source: 'followup' }); });
  if (canBook()) document.querySelectorAll('.bd-slot').forEach(s => s.onclick = () => bookingSheet({ date: d, time: s.dataset.time, doctorId: s.closest('[data-col]').dataset.col }));
  on('[data-msg-copy]', async b => { const m = byId('messages', b.dataset.msgCopy); try { await navigator.clipboard.writeText(m.text); toast('Copied.'); } catch (e) { toast('Copy did not work here. Select the text and copy it.'); } });
  on('[data-msg-done]', async b => { try { await save('messages', { ...byId('messages', b.dataset.msgDone), status: 'done', doneAt: Date.now(), doneBy: S.me.id }, { action: 'Reminder sent by hand' }); renderBookings({ v: 'reminders' }); } catch (e) { fail(e); } });
  on('[data-run-reminders]', async () => { try { const r = await api('/api/line/run', {}); toast(r.sent ? `${plural(r.sent, 'reminder')} added.` : 'Nothing is due.'); await loadAll(); renderBookings({ v: 'reminders' }); } catch (e) { fail(e); } });
}

// ---------- the booking sheet ----------
function patientChoices() {
  return S.patients.filter(p => !p.archived).map(p => ({ id: p.id, label: [p.name, p.hn ? 'HN ' + p.hn : '', p.phone || ''].filter(Boolean).join(' · ') }));
}
async function bookingSheet(b0 = {}) {
  const editing = !!b0.id, ro = !canBook();
  const b = { date: todayISO(), time: '', mins: 30, doctorId: '', status: 'booked', remind: true, ...b0 };
  const p0 = b.patientId ? patient(b.patientId) : null;
  const choices = patientChoices();
  const [open, close] = bookHours();
  const times = []; for (let m = Math.floor(Math.min(open, minsOf(b.time || '09:00')) / 15) * 15; m <= Math.max(close, minsOf(b.time || '00:00')); m += 15) times.push(timeOf(m));
  const docs = doctors();
  const active = S.services.filter(s => s.active !== false);
  const li = S.lineInfo || {};
  const statusBtns = editing && !ro ? `<div class="field"><span class="label">Status</span><div class="seg wrap" role="group">${Object.entries(BOOK_STATUS).map(([k, l]) => `<button type="button" data-status="${k}" aria-pressed="${b.status === k}">${l}</button>`).join('')}</div></div>` : '';
  const f = await sheet({
    title: editing ? `${bookName(b)} · ${fmtDate(b.date)}` : 'New booking',
    submit: ro ? null : editing ? 'Save' : 'Book',
    extra: editing && !ro ? `<button type="button" class="btn danger" data-del>Delete</button>${b.visitId ? `<a class="btn secondary" href="#/visit/${b.visitId}">Open the visit</a>` : b.patientId && b.status !== 'done' && (b.status !== 'arrived' || can('edit')) ? `<button type="button" class="btn secondary" data-arrive>${arriveLabel(b)}</button>` : ''}` : '',
    body: `<label class="field"><span class="label">Patient</span><input type="text" name="who" list="bk-patients" value="${esc(p0 ? choices.find(c => c.id === p0.id).label : b.name || '')}" placeholder="Name, HN or mobile" autocomplete="off" ${editing && b.patientId ? 'readonly' : ''}>
        <span class="hint" data-who-hint>${p0 ? '' : 'Pick a patient from the list, or type a new name and their mobile below.'}</span></label>
      ${datalist('bk-patients', choices.map(c => c.label))}
      <div class="grid2" data-newp ${p0 ? 'hidden' : ''}>${field('Mobile', 'phone', b.phone || '', { type: 'tel', ph: '081 234 5678' })}${field('LINE ID', 'line', b.line || '', { ph: 'kwan.cp' })}</div>
      <div class="grid3">${field('Date', 'date', b.date, { type: 'date' })}
        <label class="field"><span class="label">Time</span><select name="time">${times.map(t => `<option ${t === b.time ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        ${field('Length', 'mins', String(b.mins || 30), { type: 'select', options: [15, 30, 45, 60, 90, 120].map(m => [String(m), m < 60 ? `${m} minutes` : m === 60 ? '1 hour' : `${m / 60} hours`]), blank: false })}</div>
      <div class="grid2">${field('Doctor', 'doctorId', b.doctorId || '', { type: 'select', options: [['', 'Any doctor'], ...docs.map(d => [d.id, d.name])], blank: false })}
        <label class="field"><span class="label">Treatment</span><select name="serviceId"><option value="">Not set</option>${active.map(s => `<option value="${s.id}" ${s.id === b.serviceId ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></label></div>
      ${field('Note', 'what', b.what || '', { ph: 'Follow-up after lip filler' })}
      <label class="check"><input type="checkbox" name="remind" ${b.remind !== false ? 'checked' : ''}> Send the confirmation and reminder${li.on ? ' on LINE' : ''}</label>
      ${statusBtns}`,
    onOpen: form => {
      const who = form.querySelector('[name=who]'), np = form.querySelector('[data-newp]'), hint = form.querySelector('[data-who-hint]');
      const sync = () => { const hit = choices.find(c => c.label === who.value); np.hidden = !!hit; hint.textContent = hit ? '' : who.value ? 'A new patient. Their record is made with the booking.' : 'Pick a patient from the list, or type a new name and their mobile below.'; };
      who.addEventListener('input', sync);
      form.querySelectorAll('[data-status]').forEach(x => x.onclick = () => { form.querySelectorAll('[data-status]').forEach(y => y.setAttribute('aria-pressed', y === x)); form.dataset.status = x.dataset.status; });
      const del = form.querySelector('[data-del]');
      if (del) del.onclick = async () => { form.close(null); const ok = await ask({ title: 'Delete this booking?', body: `${esc(bookName(b))}, ${fmtDate(b.date)} ${esc(b.time)}.`, buttons: [{ label: 'Cancel', value: null }, { label: 'Delete', value: true, kind: 'danger' }] }); if (!ok) return; try { await remove('bookings', b.id); render(); } catch (e) { fail(e); } };
      const arr = form.querySelector('[data-arrive]');
      if (arr) arr.onclick = () => { form.close(null); bookingArrived(byId('bookings', b.id)); };
    },
    validate: form => {
      const who = val(form, 'who');
      if (!who) return 'Pick the patient or type a name.';
      if (!val(form, 'date')) return 'Pick the date.';
      return '';
    },
  });
  if (!f || ro) return;
  let patientId = b.patientId || '';
  const hit = choices.find(c => c.label === val(f, 'who'));
  if (hit) patientId = hit.id;
  try {
    if (!patientId) {
      const np = await save('patients', { id: uid(), name: val(f, 'who'), phone: val(f, 'phone'), line: val(f, 'line'), plang: 'th', created: Date.now() }, { action: 'Record made with a booking' });
      patientId = np.id;
    }
    const doc = { ...b, patientId, name: '', date: val(f, 'date'), time: val(f, 'time'), mins: +val(f, 'mins') || 30, doctorId: val(f, 'doctorId'), serviceId: val(f, 'serviceId'), what: val(f, 'what'), remind: f.querySelector('[name=remind]').checked, status: f.dataset.status || b.status || 'booked', source: b.source || 'staff' };
    if (!editing) doc.id = uid();
    const clash = S.bookings.find(x => x.id !== doc.id && BOOK_LIVE(x) && x.date === doc.date && doc.doctorId && x.doctorId === doc.doctorId && minsOf(x.time) < minsOf(doc.time) + doc.mins && minsOf(doc.time) < minsOf(x.time) + (x.mins || 30));
    if (clash && !(await ask({ title: 'This time is taken', body: `${esc(userName(doc.doctorId))} has ${esc(bookName(clash))} at ${esc(clash.time)}. Book anyway?`, buttons: [{ label: 'Change it', value: null }, { label: 'Book anyway', value: true, kind: 'primary' }] }))) return bookingSheet({ ...doc, id: editing ? doc.id : undefined });
    await save('bookings', doc, { action: editing ? 'Booking changed' : 'Booked' });
    toast(editing ? 'Booking saved.' : `Booked for ${fmtDate(doc.date)} at ${doc.time}.`);
    render();
  } catch (e) { fail(e); }
}

// The patient is here: the booking becomes today's visit, with its doctor and treatment. The
// staff mark them arrived, and the doctor or assistant starts the visit from Today.
const arriveLabel = b => (!can('edit') ? 'Arrived' : b.status === 'arrived' ? 'Start the visit' : 'Arrived, start the visit');
async function bookingArrived(b) {
  if (!b || !b.patientId) return;
  if (!can('edit')) {
    try { await save('bookings', { ...b, status: 'arrived', arrivedAt: Date.now() }, { action: 'Arrived' }); toast('Marked arrived. The doctor or assistant starts the visit from Today.'); render(); }
    catch (e) { fail(e); }
    return;
  }
  const sv = b.serviceId ? service(b.serviceId) : null;
  const v = { id: uid(), patientId: b.patientId, date: todayISO(), time: nowTime(), type: sv ? 'Treatment' : 'Consultation', complaint: b.what || '', doctorId: b.doctorId || defaultDoctorId(),
    services: sv ? [{ id: uid(), serviceId: sv.id, name: sv.name }] : [], findings: '', assessment: '', plan: '', treatments: [], consents: [], rx: [], aftercare: null, followUp: '', followReason: '', bookingId: b.id };
  try {
    const saved = await save('visits', v, { action: 'Visit started from a booking' });
    await save('bookings', { ...b, status: 'arrived', visitId: saved.id, arrivedAt: b.arrivedAt || Date.now() }, { action: b.status === 'arrived' ? 'Visit started' : 'Arrived' });
    go('#/visit/' + saved.id);
  } catch (e) { fail(e); }
}

// ---------- on the patient, Today and the visit ----------
function patientBookingsHTML(p) {
  const today = todayISO();
  const up = S.bookings.filter(b => b.patientId === p.id && b.date >= today && BOOK_LIVE(b) && b.status !== 'done').sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  const li = S.lineInfo || {};
  const lineChip = p.lineUserId ? chip('LINE linked', 'ok') : li.on && li.basicId && canBook() ? `<button class="btn quiet small" data-line-link="${p.id}">Link LINE</button>` : '';
  return `<section class="card sum-book"><div class="card-head"><h2>Bookings</h2><div class="row">${lineChip}${canBook() ? `<button class="btn secondary small" data-book-patient="${p.id}">${I.plus}Book</button>` : ''}</div></div>
    ${up.length ? `<div class="list flat">${up.map(b => `<button class="li" data-book="${b.id}"><div class="date-col"><b>${fmtDate(b.date)}</b><div class="m">${esc(b.time)}</div></div><div class="grow"><div class="t medium">${bookWhatHTML(b) || 'Appointment'}</div><div class="m">${esc(userName(b.doctorId) || 'Any doctor')}</div></div>${chip(BOOK_STATUS[b.status], b.status === 'confirmed' ? 'ok' : '')}</button>`).join('')}</div>` : '<p class="muted">Nothing booked.</p>'}</section>`;
}
function todayBookingsCard() {
  const list = bookingsOn(todayISO()).filter(BOOK_LIVE);
  if (!list.length) return '';
  return `<section class="card"><div class="card-head"><h2>Booked today</h2><a class="btn quiet small" href="#/book">Bookings</a></div><div class="list flat">${list.map(b => { const p = b.patientId ? patient(b.patientId) : null; return `<div class="li">${p ? avatar(p) : ''}<div class="grow"><div class="t">${esc(bookName(b))}</div><div class="m">${esc(b.time)} · ${[bookWhatHTML(b), esc(userName(b.doctorId))].filter(Boolean).join(' · ') || 'Appointment'}</div></div>${b.visitId ? `<a class="btn secondary small" href="#/visit/${b.visitId}">Visit</a>` : b.status === 'arrived' && can('edit') && b.patientId ? `<button class="btn primary small" data-arrived="${b.id}">Start the visit</button>` : canBook() && b.patientId && !['arrived', 'done'].includes(b.status) ? `<button class="btn primary small" data-arrived="${b.id}">Arrived</button>` : chip(BOOK_STATUS[b.status], b.status === 'arrived' ? 'ok' : '')}</div>`; }).join('')}</div></section>`;
}
// Clicks for the booking buttons that sit on other pages.
document.addEventListener('click', e => {
  const t = e.target.closest && e.target.closest('[data-book-patient], [data-arrived], [data-line-link], [data-book-visit], .sum-book [data-book]');
  if (!t) return;
  e.preventDefault();
  if (t.dataset.bookPatient) bookingSheet({ patientId: t.dataset.bookPatient });
  else if (t.dataset.arrived) bookingArrived(byId('bookings', t.dataset.arrived));
  else if (t.dataset.lineLink) lineLinkSheet(patient(t.dataset.lineLink));
  else if (t.dataset.bookVisit) { const v = visit(t.dataset.bookVisit); bookingSheet({ patientId: v.patientId, date: v.followUp && v.followUp >= todayISO() ? v.followUp : todayISO(), doctorId: v.doctorId, what: v.followReason || 'Follow-up', source: 'followup' }); }
  else if (t.dataset.book) bookingSheet(byId('bookings', t.dataset.book));
});

// ---------- linking a patient's LINE ----------
// The patient scans this with their phone. LINE opens a chat with the clinic with the link
// code typed in, and sending it ties their LINE to the record (server/line.js).
async function lineLinkSheet(p) {
  const li = S.lineInfo || {};
  if (!p || !li.basicId) return;
  let code = p.lineCode;
  if (!code) {
    const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    code = Array.from(crypto.getRandomValues(new Uint8Array(6)), x => A[x % A.length]).join('');
    try { await save('patients', { ...p, lineCode: code }, { action: 'LINE link code made' }); } catch (e) { return fail(e); }
  }
  const url = `https://line.me/R/oaMessage/${encodeURIComponent(li.basicId)}/?${encodeURIComponent('APEX-' + code)}`;
  await ask({ title: 'Link LINE', body: `<div class="line-link" data-ui-lang="${esc(p.plang || 'th')}"><div class="qr">${qrSVG(url, 220)}</div>
      <p class="lead">Scan with your phone camera, then press Send in LINE.</p><p class="meta">Appointment confirmations and reminders will come to you on LINE.</p></div>`, buttons: [{ label: 'Done', value: true, kind: 'primary' }] });
}
