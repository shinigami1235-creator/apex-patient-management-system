// Today: find a patient, the visits of the day, what is left to finish, follow-ups coming
// up and open complications.

const RECENT_KEY = 'apex_recent';
function recentPatients() {
  let ids = [];
  try { ids = JSON.parse(localStorage.getItem(RECENT_KEY + ':' + S.me.id) || '[]'); } catch (e) { ids = []; }
  return ids.map(patient).filter(Boolean);
}
function markRecent(pid) {
  if (!S.me || !pid) return;
  try {
    const k = RECENT_KEY + ':' + S.me.id;
    const ids = [pid, ...JSON.parse(localStorage.getItem(k) || '[]').filter(x => x !== pid)].slice(0, 12);
    localStorage.setItem(k, JSON.stringify(ids));
  } catch (e) { /* kept for this page only */ }
}

function renderToday() {
  const today = todayISO();
  const mine = v => v.doctorId === S.me.id;
  const todays = S.visits.filter(v => v.date === today).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  const myOpen = S.visits.filter(v => !v.signedAt && v.date < today && (mine(v) || isOwner())).sort((a, b) => b.date.localeCompare(a.date));
  const week = addDays(today, 7);
  const follows = S.visits.filter(v => v.followUp && v.followUp >= today && v.followUp <= week).sort((a, b) => a.followUp.localeCompare(b.followUp));
  const openInc = S.incidents.filter(incidentOpen).sort((a, b) => (a.checkOn || a.date || '').localeCompare(b.checkOn || b.date || ''));
  const recent = recentPatients();
  const first = (S.me.name || '').replace(/^(Dr\.?|Dra\.?)\s+/i, '').split(' ')[0];
  const vrow = v => { const p = patient(v.patientId) || { name: 'Unknown patient' }; return `<a class="li" href="#/visit/${v.id}">${avatar(p)}<div class="grow"><div class="t">${esc(p.name)}${p.hn ? ` <span class="meta">HN ${esc(p.hn)}</span>` : ''}</div><div class="m">${v.time ? fmtTime(v.time) + ' · ' : ''}${esc(v.type || 'Visit')} · ${visitSummaryHTML(v)}${v.doctorId ? ' · ' + esc(userName(v.doctorId)) : ''}</div></div>${v.signedAt ? chip('Signed', 'ok') : chip('Not signed')}</a>`; };
  $app.innerHTML = shell('today', `${updateBannerHTML()}
    <div class="today-head">
      <div><p class="eyebrow">${esc(weekday(today))} ${esc(fmtDate(today))}</p><h1>${first ? `Good to see you, ${esc(first)}` : 'Today'}</h1></div>
      <div class="find">
        <div class="search big">${I.search}<input type="search" id="tq" placeholder="Name, HN, patient number, ID or mobile" aria-label="Find a patient" autocomplete="off"></div>
        <div class="row"><button class="btn secondary" data-act="scan">${I.qr}Scan a patient card</button><a class="btn primary" href="#/patient/new">${I.plus}New patient</a></div>
        <div class="find-hits" id="hits" hidden></div>
      </div>
    </div>
    <div class="today-grid">
      <section class="card today-visits"><div class="card-head"><h2>Visits today</h2><span class="meta">${plural(todays.length, 'visit')}</span></div>
        ${todays.length ? `<div class="list flat">${todays.map(vrow).join('')}</div>` : '<p class="muted">No visits started today. Open a patient and press New visit.</p>'}</section>
      ${typeof todayBookingsCard === 'function' ? todayBookingsCard() : ''}
      ${todayLooseEndsCard()}
      ${myOpen.length ? `<section class="card"><div class="card-head"><h2>Open visits from earlier days</h2><span class="meta">${plural(myOpen.length, 'visit')}</span></div><div class="list flat">${myOpen.slice(0, 10).map(vrow).join('')}</div></section>` : ''}
      ${follows.length ? `<section class="card"><div class="card-head"><h2>Follow-ups this week</h2></div><div class="list flat">${follows.map(v => { const p = patient(v.patientId) || { name: 'Unknown patient' }; return `<a class="li" href="#/patient/${v.patientId}"><div class="date-col"><b>${esc(fmtDay(v.followUp))}</b><div class="m">${esc(weekday(v.followUp))}</div></div><div class="grow"><div class="t medium">${esc(p.name)}</div><div class="m">${esc(v.followReason || 'Follow-up')} · ${esc(userName(v.doctorId))}</div></div>${S.bookings.some(b => b.patientId === v.patientId && b.date >= today && BOOK_LIVE(b)) ? chip('Booked', 'ok') : canBook() ? `<button class="btn secondary small" data-book-visit="${v.id}">Book</button>` : ''}</a>`; }).join('')}</div></section>` : ''}
      ${openInc.length ? `<section class="card"><div class="card-head"><h2>Open complications</h2><a class="btn quiet small" href="#/complications">All</a></div><div class="list flat">${openInc.slice(0, 8).map(x => incidentRow(x, { showPatient: true })).join('')}</div></section>` : ''}
      ${recent.length ? `<section class="card"><div class="card-head"><h2>Opened lately on this device</h2></div><div class="list flat">${recent.slice(0, 8).map(p => `<a class="li" href="#/patient/${p.id}">${avatar(p)}<div class="grow"><div class="t">${esc(p.name)}</div><div class="m">${esc(patientSummary(p))}</div></div></a>`).join('')}</div></section>` : ''}
    </div>`);
  wireShell();
  wireIncidents();
  document.querySelector('[data-act="scan"]').onclick = () => scanPatientCard();
  const q = document.getElementById('tq'), hits = document.getElementById('hits');
  const find = () => {
    const term = q.value.trim().toLowerCase();
    if (term.length < 2) { hits.hidden = true; hits.innerHTML = ''; return; }
    const exact = findPatientByNo(q.value);
    const digits = term.replace(/\D/g, '');
    const list = S.patients.filter(p => [p.name, p.nameTh, p.goesBy, p.no, p.hn, p.idNo, p.line].some(x => String(x || '').toLowerCase().includes(term)) || (digits.length > 3 && String(p.phone || '').replace(/\D/g, '').includes(digits)));
    const shown = [...new Set([exact, ...list].filter(Boolean))].slice(0, 8);
    hits.hidden = false;
    hits.innerHTML = shown.length ? shown.map(p => `<a class="li" href="#/patient/${p.id}">${avatar(p, 'sm')}<div class="grow"><div class="t">${esc(p.name)}${p.nameTh && p.nameTh !== p.name ? ` <span class="meta" lang="th">${esc(p.nameTh)}</span>` : ''}</div><div class="m">${esc(patientSummary(p))}</div></div></a>`).join('') + (list.length > 8 ? `<a class="li more" href="#/patients?q=${encodeURIComponent(q.value)}">See all ${list.length}</a>` : '')
      : `<div class="li"><div class="grow"><div class="t medium">No patient matches.</div></div><a class="btn secondary small" href="#/patient/new?name=${encodeURIComponent(q.value)}">New patient</a></div>`;
  };
  q.oninput = debounce(find, 150);
  q.onkeydown = e => { if (e.key === 'Enter') { const p = findPatientByNo(q.value) || (hits.querySelector('a.li') && null); if (p) go('#/patient/' + p.id); else { const a = hits.querySelector('a.li'); if (a) location.hash = a.getAttribute('href'); } } };
}
