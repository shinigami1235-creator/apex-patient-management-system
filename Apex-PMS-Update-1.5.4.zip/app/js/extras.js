// Outcome scores on the Global Aesthetic Improvement Scale.

// ---------- outcome scores ----------
// At a later visit the doctor scores how the last treatment came out on the Global
// Aesthetic Improvement Scale, with the patient's own rating out of 5. It is kept on the
// visit the treatment was done on, so the doctor sees how each treatment came out.
const GAIS = [[1, 'Very much improved'], [2, 'Much improved'], [3, 'Improved'], [4, 'No change'], [5, 'Worse']];
// The treatment visit before this one, in the last 4 months, still without a score.
function outcomeDueFor(v) {
  return S.visits.filter(x => x.patientId === v.patientId && x.id !== v.id && x.date < v.date && x.date >= addDays(v.date, -120) && (x.services || []).length && !x.outcome).sort((a, b) => b.date.localeCompare(a.date))[0] || null;
}
function outcomeCard(v) {
  const prev = outcomeDueFor(v), scored = S.visits.filter(x => x.outcome && x.outcome.onVisitId === v.id);
  if (!prev && !scored.length) return '';
  return `<div class="card" id="voutcome"><div class="card-head"><h2>How the last treatment came out</h2></div>
    ${scored.map(x => `<p>${esc(visitSummary(x) || 'Treatment')} on ${fmtDate(x.date)}: <b>${esc((GAIS.find(g => g[0] === x.outcome.gais) || [])[1] || '')}</b>${x.outcome.rating ? ` · patient gave ${x.outcome.rating} of 5` : ''}${x.outcome.note ? ` · ${esc(x.outcome.note)}` : ''}</p>`).join('')}
    ${prev ? `<form id="outcomef"><p class="meta">${esc(visitSummary(prev) || 'Treatment')} on ${fmtDate(prev.date)}, by ${esc(userName(prev.doctorId))}.</p>
      <div class="grid3">${field('Result', 'gais', '', { type: 'select', options: GAIS.map(([k, l]) => [k, l]), blank: 'Pick one' })}${field('Patient rating', 'rating', '', { type: 'select', options: [[5, '5, very happy'], [4, '4'], [3, '3'], [2, '2'], [1, '1, unhappy']], blank: 'Not asked' })}${field('Note', 'note', '', { ph: 'Slight asymmetry on the left brow' })}</div>
      <div class="row end"><button class="btn secondary small">Save the result</button></div></form>` : ''}</div>`;
}
function wireOutcome(v) {
  const f = document.getElementById('outcomef');
  if (!f) return;
  f.onsubmit = async e => {
    e.preventDefault();
    const prev = outcomeDueFor(v);
    if (!prev || !val(f, 'gais')) return toast('Pick the result.');
    try { await save('visits', { ...visit(prev.id), outcome: { gais: nval(f, 'gais'), rating: val(f, 'rating') ? nval(f, 'rating') : 0, note: val(f, 'note'), by: S.me.id, at: Date.now(), onVisitId: v.id } }, { action: 'Result of the treatment recorded' }); delete f.dataset.dirty; toast('Saved.'); renderVisit(v.id); } catch (ex) { fail(ex); }
  };
}
