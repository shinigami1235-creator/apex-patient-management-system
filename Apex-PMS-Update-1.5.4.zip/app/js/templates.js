// Treatment templates, taken from the face planner. One tap puts every point of an area on
// the chart: on the front face drawing, a front photo or the 3D head. Each point is an
// ordinary mark afterwards, so the doctor drags it to where it belongs or deletes it.
//
// Each point is a key point plus an offset in millimetres, as the face planner has them:
//   a  - key point; brow, canthOut, canthIn, mouth and jaw have a right and a left one
//   dx - mm away from the midline, dy - mm down the face
//   sym - a pair, one on each side
//   arrow - filler threaded along a line: len mm long, ang degrees from straight up
//           towards the side, drawn from where the needle goes in to where it stops
// The amounts are the planner's conservative starting doses, not dosing advice.

const TEMPLATE_GROUPS = ['Botox, upper face', 'Botox, lower face', 'Filler', 'Skin booster'];
const TEMPLATE_AREAS = [
  { id: 'frontalis', group: 'Botox, upper face', name: 'Forehead', kind: 'toxin', pts: [
    { a: 'nasion', dy: -45, amt: 2 },
    { a: 'brow', dx: 0, dy: -26, sym: true, amt: 2 },
    { a: 'brow', dx: 20, dy: -21, sym: true, amt: 2 }] },
  { id: 'glabella', group: 'Botox, upper face', name: 'Glabella', kind: 'toxin', pts: [
    { a: 'nasion', dy: -4, amt: 4 },
    { a: 'canthIn', dx: 0, dy: -20, sym: true, amt: 4 },
    { a: 'brow', dx: 6, dy: -3, sym: true, amt: 3 }] },
  { id: 'crowsfeet', group: 'Botox, upper face', name: 'Crow\'s feet', kind: 'toxin', pts: [
    { a: 'canthOut', dx: 12, dy: -8, sym: true, amt: 3 },
    { a: 'canthOut', dx: 14, dy: 2, sym: true, amt: 3 },
    { a: 'canthOut', dx: 12, dy: 12, sym: true, amt: 2 }] },
  { id: 'browlift', group: 'Botox, upper face', name: 'Brow lift', kind: 'toxin', pts: [
    { a: 'brow', dx: 16, dy: -2, sym: true, amt: 2 }] },
  { id: 'bunny', group: 'Botox, upper face', name: 'Bunny lines', kind: 'toxin', pts: [
    { a: 'nasion', dx: 7, dy: 12, sym: true, amt: 2 },
    { a: 'nasion', dx: 6, dy: 22, sym: true, amt: 1 }] },
  { id: 'gummy', group: 'Botox, lower face', name: 'Gummy smile', kind: 'toxin', pts: [
    { a: 'subnasale', dx: 10, dy: -8, sym: true, amt: 2 }] },
  { id: 'lipflip', group: 'Botox, lower face', name: 'Lip flip', kind: 'toxin', pts: [
    { a: 'stomion', dx: 5, dy: -8, sym: true, amt: 1 },
    { a: 'stomion', dx: 13, dy: -6, sym: true, amt: 1 }] },
  { id: 'dao', group: 'Botox, lower face', name: 'DAO', kind: 'toxin', pts: [
    { a: 'stomion', dx: 27, dy: 11, sym: true, amt: 3 }] },
  { id: 'mentalis', group: 'Botox, lower face', name: 'Chin dimpling', kind: 'toxin', pts: [
    { a: 'chin', dx: 6, dy: -10, sym: true, amt: 3 }] },
  { id: 'masseter', group: 'Botox, lower face', name: 'Masseter', kind: 'toxin', pts: [
    { a: 'jaw', dx: -8, dy: -13, sym: true, amt: 8 },
    { a: 'jaw', dx: -3, dy: -23, sym: true, amt: 8 },
    { a: 'jaw', dx: -17, dy: -18, sym: true, amt: 8 }] },
  { id: 'parotid', group: 'Botox, lower face', name: 'Parotid', kind: 'toxin', pts: [
    { a: 'jaw', dx: 5, dy: -24, sym: true, amt: 5 },
    { a: 'jaw', dx: 7, dy: -12, sym: true, amt: 5 }] },
  { id: 'cheek', group: 'Filler', name: 'Cheeks', kind: 'filler', depth: 'Supraperiosteal', pts: [
    { a: 'canthOut', dx: 2, dy: 20, sym: true, amt: 0.3 },
    { a: 'canthOut', dx: 18, dy: 6, sym: true, amt: 0.2, arrow: true, len: 20, ang: 78 },
    { a: 'canthIn', dx: 11, dy: 28, sym: true, amt: 0.2 }] },
  { id: 'temple', group: 'Filler', name: 'Temples', kind: 'filler', depth: 'Supraperiosteal', pts: [
    { a: 'canthOut', dx: 16, dy: -20, sym: true, amt: 0.3 }] },
  { id: 'teartrough', group: 'Filler', name: 'Tear troughs', kind: 'filler', depth: 'Supraperiosteal', pts: [
    { a: 'canthIn', dx: 6, dy: 11, sym: true, amt: 0.1, arrow: true, len: 10, ang: 80 },
    { a: 'canthOut', dx: -10, dy: 12, sym: true, amt: 0.1, arrow: true, len: 12, ang: 80 }] },
  { id: 'piriform', group: 'Filler', name: 'Piriform', kind: 'filler', depth: 'Supraperiosteal', pts: [
    { a: 'subnasale', dx: 9, dy: 1, sym: true, amt: 0.15 }] },
  { id: 'nasolabial', group: 'Filler', name: 'Nasolabial folds', kind: 'filler', depth: 'Subcutaneous', pts: [
    { a: 'subnasale', dx: 19, dy: 7, sym: true, amt: 0.15, arrow: true, len: 16, ang: 22 },
    { a: 'stomion', dx: 28, dy: -3, sym: true, amt: 0.15, arrow: true, len: 16, ang: 22 }] },
  { id: 'lips', group: 'Filler', name: 'Lips', kind: 'filler', depth: 'Submucosal', pts: [
    { a: 'stomion', dx: 5, dy: -8, sym: true, amt: 0.1, arrow: true, len: 8, ang: 90 },
    { a: 'stomion', dx: 14, dy: -6, sym: true, amt: 0.1, arrow: true, len: 10, ang: 90 },
    { a: 'stomion', dx: 9, dy: 8, sym: true, amt: 0.1, arrow: true, len: 12, ang: 90 }] },
  { id: 'jawline', group: 'Filler', name: 'Jawline', kind: 'filler', depth: 'Supraperiosteal', pts: [
    { a: 'jaw', dx: 0, dy: 0, sym: true, amt: 0.4 },
    { a: 'jaw', dx: -18, dy: 6, sym: true, amt: 0.3, arrow: true, len: 24, ang: 82 },
    { a: 'chin', dx: 22, dy: -6, sym: true, amt: 0.2, arrow: true, len: 12, ang: 75 },
    { a: 'chin', dx: 0, dy: -2, amt: 0.3 }] },
  { id: 'chinproj', group: 'Filler', name: 'Chin', kind: 'filler', depth: 'Supraperiosteal', pts: [
    { a: 'chin', dy: -8, amt: 0.4 }] },
  { id: 'booster', group: 'Skin booster', name: 'Cheek grid', kind: 'booster', depth: 'Superficial dermis', pts: [
    { a: 'canthIn', dx: 8, dy: 22, sym: true, amt: 0.05 },
    { a: 'canthOut', dx: -4, dy: 20, sym: true, amt: 0.05 },
    { a: 'canthIn', dx: 12, dy: 42, sym: true, amt: 0.05 },
    { a: 'canthOut', dx: -6, dy: 40, sym: true, amt: 0.05 },
    { a: 'mouth', dx: 12, dy: -8, sym: true, amt: 0.05 }] },
];

// Key points as MediaPipe face mesh points. R and L are the patient's right and left.
const TPL_MP = { nasion: 168, subnasale: 2, chin: 152, browR: 105, browL: 334, canthOutR: 33, canthInR: 133, canthInL: 362, canthOutL: 263, mouthR: 61, mouthL: 291, jawR: 172, jawL: 397, stomion: [13, 14], irisR: [469, 471], irisL: [474, 476] };
const TPL_SIDED = ['brow', 'canthOut', 'canthIn', 'mouth', 'jaw'];


const vAdd = (a, b) => a.map((v, i) => v + b[i]);
const vSub = (a, b) => a.map((v, i) => v - b[i]);
const vMul = (a, k) => a.map(v => v * k);
const vLen = a => Math.hypot(...a);
const vUnit = a => vMul(a, 1 / (vLen(a) || 1));
const vDot = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0);

// Every point of an area in the frame F: F.kp(id) gives a key point, F.right is the unit
// vector towards the patient's left, F.down the unit vector down the face, F.mm one millimetre.
function templatePlace(area, F) {
  const out = [], cal = ((S.spots || {})[area.id]) || [];
  for (const [k, q0] of area.pts.entries()) {
    // The clinic's own spots, saved from a chart, stand in for the planner's.
    const q = { ...q0, ...(cal[k] || {}) };
    for (const side of q.sym ? ['R', 'L'] : ['R']) {
      const A = F.kp(TPL_SIDED.includes(q.a) ? q.a + side : q.a);
      if (!A) continue;
      const lat = vMul(F.right, side === 'R' ? -1 : 1);
      const at = vAdd(vAdd(A, vMul(lat, (q.dx || 0) * F.mm)), vMul(F.down, (q.dy || 0) * F.mm));
      if (!q.arrow) { out.push({ q, k, side, at }); continue; }
      const a = (q.ang || 0) * Math.PI / 180;
      const dir = vAdd(vMul(lat, Math.sin(a)), vMul(F.down, -Math.cos(a)));
      const half = vMul(dir, (q.len || 14) * F.mm / 2);
      out.push({ q, k, side, at, line: [vSub(at, half), vAdd(at, half)] });
    }
  }
  return out;
}

// What a template point becomes on the chart: product and lot from the tool's settings,
// the planner's dose, and the area's name.
function templateMark(area, q, k, side) {
  const s = (E.tools && E.tools[area.kind]) || {};
  const l = s.lotId ? lot(s.lotId) : null, p = l ? product(l.productId) : null;
  const m = { t: area.kind, lotId: s.lotId || '', productId: p ? p.id : '', product: p ? p.name : (s.product || ''), unit: p ? p.unit : KINDS[area.kind].unit, amount: q.amt, area: area.name };
  if (area.kind !== 'toxin') m.depth = area.depth || '';
  if (q.arrow) m.technique = 'arrow';
  m.tpl = { a: area.id, k, side };
  return m;
}

// ---------- on a picture: a drawing or a photo, from any of the five views ----------
// The face mesh gives every landmark a depth as well as its place in the picture. Each
// landmark is put in the face's own frame (across and down, in millimetres from the nasion),
// so a template point given in that frame is found in the picture from the landmarks around
// it, whichever way the face is turned. Points on the far side of a turned face are left out.
const TPL_LM = new Map(); // photo id, or the drawing's view -> { lm, flip }
const MIRROR_VIEW = { left45: 'right45', right45: 'left45', left: 'right', right: 'left', front: 'front' };
async function detectOn(canvas) {
  const M = await import('/features/face/mesh.js');
  return M.detect(new URL('vendor/face_mesh/', document.baseURI).href, canvas);
}
async function drawingCanvas(view) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${FACE_W} ${FACE_H}" width="${FACE_W * 2}" height="${FACE_H * 2}"><rect width="${FACE_W}" height="${FACE_H}" fill="#fff"/>${faceArt(view)}</svg>`;
  const im = new Image(); im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); await im.decode();
  const cv = document.createElement('canvas'); cv.width = FACE_W * 2; cv.height = FACE_H * 2; cv.getContext('2d').drawImage(im, 0, 0);
  return cv;
}
async function templateLandmarks2D(c = E.chart, img = E.img) {
  const key = c.base.type === 'photo' ? c.base.photoId : 'draw:' + c.view;
  if (TPL_LM.has(key)) return TPL_LM.get(key);
  let got = null;
  if (c.base.type === 'photo') {
    toast('Finding the face on the photo.');
    const M = await import('/features/face/mesh.js');
    const im = await M.loadImage(img);
    const k = Math.min(1, 1400 / Math.max(im.naturalWidth, im.naturalHeight));
    const cv = document.createElement('canvas'); cv.width = Math.round(im.naturalWidth * k); cv.height = Math.round(im.naturalHeight * k);
    cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
    const lm = await detectOn(cv);
    if (lm) got = { lm, flip: false };
  } else {
    // The face mesh finds some drawings only one way round; the mirrored drawing then stands in.
    let lm = await detectOn(await drawingCanvas(c.view));
    if (lm) got = { lm, flip: false };
    else if ((lm = await detectOn(await drawingCanvas(MIRROR_VIEW[c.view])))) got = { lm, flip: true };
  }
  TPL_LM.set(key, got);
  return got;
}
// Weighted least squares of value = a + b*u + c*v over the nearest landmarks.
function localAffine(near, val) {
  const A = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], B = [0, 0, 0];
  for (const n of near) {
    const r = [1, n.u, n.v], y = val(n);
    for (let i = 0; i < 3; i++) { B[i] += n.w * r[i] * y; for (let j = 0; j < 3; j++) A[i][j] += n.w * r[i] * r[j]; }
  }
  const det = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
  const D = det(A);
  if (Math.abs(D) < 1e-9) return null;
  return [0, 1, 2].map(k => det(A.map((row, i) => row.map((x, j) => (j === k ? B[i] : x)))) / D);
}
// The face's frame on a picture: key points across and down in picture pixels from the
// nasion, the millimetre, and the way from that frame to the picture and back.
async function frame2D(c = E.chart, img = E.img) {
  const W = c.w, H = c.h;
  const got = await templateLandmarks2D(c, img);
  if (!got) return null;
  const P = got.lm.slice(0, 468).map(q => [q.x * W, q.y * H, q.z * W]);
  const L = i => Array.isArray(i) ? vMul(vAdd(P[i[0]], P[i[1]]), 0.5) : P[i];
  const O = L(TPL_MP.nasion);
  const right = vUnit(vSub(L(TPL_MP.canthOutL), L(TPL_MP.canthOutR)));
  let down = vSub(L(TPL_MP.chin), O);
  down = vUnit(vSub(down, vMul(right, vDot(down, right))));
  const uv = p => [vDot(vSub(p, O), right), vDot(vSub(p, O), down)];
  // The iris is 11.7 mm across on almost everyone. Its height is used, since a turned face
  // narrows the iris but leaves its height.
  const iris = [[470, 472], [475, 477]].map(([a, b]) => (got.lm[a] && got.lm[b] ? Math.hypot((got.lm[a].x - got.lm[b].x) * W, (got.lm[a].y - got.lm[b].y) * H) : 0)).filter(Boolean);
  const mm = iris.length ? iris.reduce((s, v) => s + v, 0) / iris.length / 11.7 : vLen(vSub(L(TPL_MP.canthOutL), L(TPL_MP.canthOutR))) / 94;
  const pts = P.map(p => { const [u, v] = uv(p); return { u, v, p }; });
  const fit = (u, v) => {
    const near = pts.map(n => ({ ...n, d: Math.hypot(n.u - u, n.v - v) })).sort((a, b) => a.d - b.d).slice(0, 10);
    if (near[0].d > 40 * mm) return null;
    near.forEach(n => { n.w = 1 / (n.d * n.d + 4 * mm * mm); });
    const fx = localAffine(near, n => n.p[0]), fy = localAffine(near, n => n.p[1]), fz = localAffine(near, n => n.p[2]);
    return fx && fy && fz ? { fx, fy, fz } : null;
  };
  // A frame point to the picture, as fractions, or null where the face turns away from the camera.
  const at = ([u, v]) => {
    const f = fit(u, v);
    if (!f) return null;
    const { fx, fy, fz } = f;
    // The surface faces the camera when its normal points out of the picture (the mesh's -z).
    const du = [fx[1], fy[1], fz[1]], dv = [fx[2], fy[2], fz[2]];
    const n = [dv[1] * du[2] - dv[2] * du[1], dv[2] * du[0] - dv[0] * du[2], dv[0] * du[1] - dv[1] * du[0]];
    if (-n[2] / (vLen(n) || 1) < 0.2) return null;
    const x = fx[0] + fx[1] * u + fx[2] * v, y = fy[0] + fy[1] * u + fy[2] * v;
    return [Math.min(1, Math.max(0, got.flip ? 1 - x / W : x / W)), Math.min(1, Math.max(0, y / H))].map(t => +t.toFixed(4));
  };
  // A picture point (fractions) back to the frame: start at the nearest landmark and refine.
  const back = ([fxn, fyn]) => {
    const x = (got.flip ? 1 - fxn : fxn) * W, y = fyn * H;
    let best = pts[0], bd = Infinity;
    for (const n of pts) { const d = Math.hypot(n.p[0] - x, n.p[1] - y); if (d < bd) { bd = d; best = n; } }
    let u = best.u, v = best.v;
    for (let i = 0; i < 4; i++) {
      const f = fit(u, v);
      if (!f) break;
      const { fx, fy } = f, det = fx[1] * fy[2] - fx[2] * fy[1];
      if (Math.abs(det) < 1e-9) break;
      const rx = x - fx[0], ry = y - fy[0];
      u = (rx * fy[2] - fx[2] * ry) / det; v = (fx[1] * ry - rx * fy[1]) / det;
    }
    return [u, v];
  };
  const kp = id => (TPL_MP[id] !== undefined ? uv(L(TPL_MP[id])) : null);
  return { kp, right: [1, 0], down: [0, 1], mm, at, back };
}
async function templateMarks2D(area, c = E.chart, img = E.img) {
  const F = await frame2D(c, img);
  if (!F) { toast(c.base.type === 'photo' ? 'No face found on this photo. Use the 3D head or place the marks by hand.' : 'The face could not be read on this drawing. Use the 3D head or place the marks by hand.'); return null; }
  const marks = [];
  marks.missed = 0;
  for (const { q, k, side, at: target, line } of templatePlace(area, F)) {
    const m = templateMark(area, q, k, side);
    if (line) {
      const ends = line.map(F.at);
      if (!ends[0] || !ends[1]) { marks.missed++; continue; }
      m.pts = ends;
    } else {
      const xy = F.at(target);
      if (!xy) { marks.missed++; continue; }
      [m.x, m.y] = xy;
    }
    marks.push(m);
  }
  return marks;
}

// ---------- on the 3D head ----------
// Points are placed in the face's own frame from the head's landmarks, then set onto the skin.
function frame3D(vw = E.viewer, HV = E.HV) {
  const mesh = vw.mesh, L0 = mesh.userData.lm3;
  if (!L0) return null;
  const THREE = HV.THREE;
  const L = i => new THREE.Vector3(...L0[i]).applyMatrix4(mesh.matrixWorld).toArray();
  const at = i => Array.isArray(i) ? vMul(vAdd(L(i[0]), L(i[1])), 0.5) : L(i);
  const kp = id => (TPL_MP[id] !== undefined ? at(TPL_MP[id]) : null);
  const right = vUnit(vSub(kp('canthOutL'), kp('canthOutR')));
  let down = vSub(kp('chin'), kp('nasion'));
  down = vUnit(vSub(down, vMul(right, vDot(down, right))));
  const iris = L0.length > 476 ? (vLen(vSub(L(469), L(471))) + vLen(vSub(L(474), L(476)))) / 2 : 0;
  const mm = iris ? iris / 11.7 : vLen(vSub(kp('canthOutL'), kp('canthOutR'))) / 94;
  return { kp, right, down, mm, uvOf: p => [vDot(vSub(p, kp('nasion')), right), vDot(vSub(p, kp('nasion')), down)] };
}
function templateMarks3D(area, vw = E.viewer, HV = E.HV) {
  const F = frame3D(vw, HV);
  if (!F) { toast('This head has no landmarks. Rebuild it to use templates.'); return null; }
  const { kp, right, down, mm } = F, THREE = HV.THREE;
  const c = vw.box.getCenter(new THREE.Vector3()).toArray(), size = vw.box.getSize(new THREE.Vector3()).length();
  // Straight back along the face's own forward line first, as the face planner seats its
  // points, so a point keeps its place across and down the face and reads back the same when
  // the clinic saves its spots. Where that misses, beyond the edge of the face as seen from the
  // front, a ray from the side towards the middle of the head finds the skin.
  const fwd = [down[1] * right[2] - down[2] * right[1], down[2] * right[0] - down[0] * right[2], down[0] * right[1] - down[1] * right[0]];
  const onSkin = p => {
    const hit = vw.pickRay(vAdd(p, vMul(fwd, size)), vMul(fwd, -1));
    if (hit && vDot(hit.n, fwd) > 0.15) return hit;
    let out = vSub(p, c); out[1] = 0;
    out = vLen(out) > 1e-6 ? vUnit(out) : fwd;
    return vw.pickRay(vAdd(p, vMul(out, size)), vMul(out, -1)) || hit;
  };
  const marks = [], all = templatePlace(area, F);
  marks.missed = 0;
  // A point past the edge of the head, such as high on a forehead the head stops short of, is
  // pulled back towards its key point until it lands on the skin.
  const pull = (p, A) => { for (const t of [1, 0.9, 0.8, 0.7, 0.6, 0.5]) { const hit = onSkin(vAdd(A, vMul(vSub(p, A), t))); if (hit) { if (t < 1) marks.pulled++; return hit; } } return null; };
  marks.pulled = 0;
  for (const { q, k, side, at: p, line } of all) {
    const A = kp(TPL_SIDED.includes(q.a) ? q.a + side : q.a);
    const m = templateMark(area, q, k, side);
    if (line) {
      const anchors = [0, 0.25, 0.5, 0.75, 1].map(t => onSkin(vAdd(line[0], vMul(vSub(line[1], line[0]), t)))).filter(Boolean);
      if (anchors.length < 2) { marks.missed++; continue; }
      m.anchors = anchors;
    } else {
      const a = pull(p, A);
      if (!a) { marks.missed++; continue; }
      m.anchor = a;
    }
    marks.push(hdProjectMark(m, vw));
  }
  return marks;
}

// ---------- the side panel and the tap ----------
function templatesPanelHTML() {
  // the templates are points on the face
  if (E.readOnly || (E.kind !== 'head' && groupOfView(E.chart.view) !== 'face')) return '';
  return `<details class="tpl" ${E.tplOpen ? 'open' : ''} ontoggle="E.tplOpen = this.open"><summary>Templates</summary><p class="meta">Tap an area to put all its points on the ${E.kind === 'head' ? 'head' : 'face'}, then drag any that need moving.</p>
    ${tplTwinHTML()}
    ${TEMPLATE_GROUPS.map(g => `<div class="tpl-group"><span class="label">${esc(g)}</span><div class="tpl-chips">${TEMPLATE_AREAS.filter(a => a.group === g).map(a => `<button type="button" class="tpl-chip" data-ed="tpl" data-id="${a.id}"><span class="dot" style="background:${KINDS[a.kind].color}"></span>${esc(a.name)}</button>`).join('')}</div></div>`).join('')}${tplSpotsHTML()}</details>`;
}
async function applyTemplate(id) {
  const area = TEMPLATE_AREAS.find(a => a.id === id);
  if (!area || E.readOnly) return;
  E.tplOpen = true;
  let marks;
  try { marks = E.kind === 'head' ? templateMarks3D(area) : await templateMarks2D(area); } catch (e) { return fail(e); }
  if (!marks) return;
  const off = marks.missed ? (E.kind === 'head' ? 'Some points fell off the head.' : 'Points this view cannot see were left out.') : marks.pulled ? 'Points past the edge of the head were moved in to it.' : '';
  if (!marks.length) return toast(E.kind === 'head' ? `${area.name}: every point fell off the head.` : `${area.name}: none of its points can be seen from this view.`);
  edPush();
  E.chart.marks.push(...marks);
  E.tool = 'select'; E.sel = -1;
  (E.render || edRender)();
  let twin = '';
  const t = TPL_TWIN ? tplTwin() : null;
  if (t) {
    try { const n = t.kind === 'head' ? await twinOnHead(area, t) : await twinOnPicture(area, t); twin = n ? (t.kind === 'head' ? 'Also put on the 3D head.' : `Also put on the ${t.viewLabel} chart.`) : ''; }
    catch (e) { console.error(e); twin = 'It could not go on the other chart.'; }
  }
  if (typeof BESIDE !== 'undefined') BESIDE.draw();
  // Each sentence is translated on its own, since the message is put together from up to three.
  toast([`${area.name} placed. Drag any point to adjust.`, off, twin].filter(Boolean).map(x => tr(x)).join(' '));
}

// ---------- the same area on the other picture ----------
// "Also on the 3D head" puts the area on the head too when it is placed on a picture, and
// from the head, "Also on this view's picture" puts it on the picture the head is turned to.
// Those marks are copies: they show where the points go, and their dose stays out of the
// treatment record, so it is counted once.
let TPL_TWIN = true; // ticked by default, and kept between charts
function tplTwin() {
  if (!USE_3D) return null;
  if (E.kind === 'head') {
    const view = (E.viewer && hdViewKey(E.viewer.V.az, E.viewer.V.el)) || 'front';
    return { kind: 'picture', view, viewLabel: CHART_VIEWS.find(x => x.key === view).label };
  }
  const hc = S.charts.find(c => c.visitId === E.v.id && c.view === HEAD_CHART.key);
  const head = hc ? byId('heads', hc.base.headId) : latestHead(E.p.id);
  return head ? { kind: 'head', head, chart: hc } : null;
}
function tplTwinHTML() {
  const t = tplTwin();
  if (!t) return '';
  const label = t.kind === 'head' ? 'Also on the 3D head' : 'Also on the picture of the view the head is turned to';
  return `<label class="check tpl-twin"><input type="checkbox" ${TPL_TWIN ? 'checked' : ''} onchange="TPL_TWIN = this.checked"> ${label}</label>`;
}
async function twinOnHead(area, t) {
  const HV = await headView();
  const loaded = await HV.loadHeadFiles({ meshUrl: fileURL(t.head.files.mesh), atlasUrl: fileURL(t.head.files.atlas), alphaUrl: fileURL(t.head.files.alpha), maxAtlas: headAtlasMax() });
  const mesh = HV.headMesh(loaded);
  const cv = document.createElement('canvas'); cv.width = 600; cv.height = 800;
  const vw = HV.makeViewer(cv, mesh, { bg: 0xffffff });
  try {
    const marks = (templateMarks3D(area, vw, HV) || []).map(m => ({ ...m, copy: true }));
    if (!marks.length) return 0;
    const fresh = S.charts.find(c => c.visitId === E.v.id && c.view === HEAD_CHART.key);
    const chart = fresh ? JSON.parse(JSON.stringify(fresh)) : { id: uid(), patientId: E.p.id, visitId: E.v.id, view: HEAD_CHART.key, base: { type: 'head', headId: t.head.id }, shot: 'front', marks: [], dilution: { units: 100, ml: 2.5 }, w: 600, h: 800 };
    chart.marks = [...(chart.marks || []), ...marks];
    await save('charts', chart, { action: `${area.name} copied to the 3D head` });
    return marks.length;
  } finally { vw.dispose(); }
}
async function twinOnPicture(area, t) {
  const want = CHART_VIEWS.find(x => x.key === t.view).photo;
  const fresh = S.charts.find(c => c.visitId === E.v.id && c.view === t.view);
  let chart;
  if (fresh) chart = JSON.parse(JSON.stringify(fresh));
  else {
    const ph = E.p.photoConsent !== 'no' ? S.photos.find(x => x.visitId === E.v.id && x.view === want && x.fileId) : null;
    chart = { id: uid(), patientId: E.p.id, visitId: E.v.id, view: t.view, base: ph ? { type: 'photo', photoId: ph.id } : { type: 'drawing' }, marks: [], dilution: { units: 100, ml: 2.5 } };
  }
  const meta = chart.base.type === 'photo' ? photoMeta(chart.base.photoId) : null;
  if (chart.base.type === 'photo' && !meta) chart.base = { type: 'drawing' };
  chart.w = meta ? meta.w : FACE_W; chart.h = meta ? meta.h : FACE_H;
  const marks = ((await templateMarks2D(area, chart, meta ? fullURL(chart.base.photoId) : '')) || []).map(m => ({ ...m, copy: true }));
  if (!marks.length) return 0;
  chart.marks = [...(chart.marks || []), ...marks];
  await save('charts', chart, { action: `${area.name} copied to the ${t.viewLabel} chart` });
  return marks.length;
}

// ---------- the clinic's own spots ----------
// The planner's offsets are a starting point. After a template is placed and its points
// dragged to where this clinic puts them, Save spots reads each point's distance from its key
// point back off the chart, and every template placed after that, on any patient, goes there.
// The two sides of a pair are averaged, so the pair stays even.
function tplOnChart() { return E.chart.marks.filter(m => m.tpl && !m.copy && TEMPLATE_AREAS.some(a => a.id === m.tpl.a)); }
function tplSpotsHTML() {
  const mine = Object.keys(S.spots || {}).length, here = can('sign') && tplOnChart().length;
  if (!mine && !here) return '';
  return `<div class="tpl-spots">${here ? '<button type="button" class="btn secondary small" data-ed="tpl-save">Save these spots for the clinic</button>' : ''}${mine && can('sign') ? '<button type="button" class="btn quiet small" data-ed="tpl-reset">Use the face planner\'s spots again</button>' : ''}
    ${mine ? `<p class="meta">Templates use this clinic's spots for ${esc(TEMPLATE_AREAS.filter(a => (S.spots || {})[a.id]).map(a => a.name).join(', '))}.</p>` : ''}</div>`;
}
async function saveTemplateSpots() {
  const marks = tplOnChart();
  if (!marks.length) return;
  const F = E.kind === 'head' ? frame3D() : await frame2D();
  if (!F) return toast('The face could not be read on this chart, so the spots were not saved.');
  const uvOf = E.kind === 'head' ? F.uvOf : p => p;
  const ends = m => (E.kind === 'head' ? (m.anchors ? [m.anchors[0].p, m.anchors[m.anchors.length - 1].p] : [m.anchor.p]).map(F.uvOf) : (m.pts ? [m.pts[0], m.pts[m.pts.length - 1]] : [[m.x, m.y]]).map(F.back));
  const sum = {};
  for (const m of marks) {
    const area = TEMPLATE_AREAS.find(a => a.id === m.tpl.a), q = area.pts[m.tpl.k];
    if (!q) continue;
    const A = uvOf(F.kp(TPL_SIDED.includes(q.a) ? q.a + m.tpl.side : q.a));
    const e = ends(m), sg = m.tpl.side === 'R' ? -1 : 1;
    const mid = e.length > 1 ? [(e[0][0] + e[1][0]) / 2, (e[0][1] + e[1][1]) / 2] : e[0];
    const o = { dx: sg * (mid[0] - A[0]) / F.mm, dy: (mid[1] - A[1]) / F.mm };
    if (q.arrow && e.length > 1) {
      const du = sg * (e[1][0] - e[0][0]), dv = e[1][1] - e[0][1];
      o.len = Math.hypot(du, dv) / F.mm; o.ang = Math.atan2(du, -dv) * 180 / Math.PI;
    }
    const key = area.id + '|' + m.tpl.k, t = sum[key] || (sum[key] = { a: area.id, k: m.tpl.k, n: 0, dx: 0, dy: 0, len: 0, ang: 0, arrow: !!o.len });
    t.n++; t.dx += o.dx; t.dy += o.dy; if (o.len) { t.len += o.len; t.ang += o.ang; }
  }
  const spots = JSON.parse(JSON.stringify(S.spots || {}));
  const r1 = x => Math.round(x * 10) / 10;
  for (const t of Object.values(sum)) {
    const list = spots[t.a] || (spots[t.a] = []);
    while (list.length <= t.k) list.push(null);
    list[t.k] = { dx: r1(t.dx / t.n), dy: r1(t.dy / t.n), ...(t.arrow ? { len: r1(t.len / t.n), ang: Math.round(t.ang / t.n) } : {}) };
  }
  try { await setMeta('spots', spots); } catch (e) { return fail(e); }
  const names = [...new Set(Object.values(sum).map(t => TEMPLATE_AREAS.find(a => a.id === t.a).name))];
  toast(`${names.join(', ')}: saved as this clinic's spots.`);
  (E.sideRefresh || (() => { edSideHTML(); edWireSide(); }))();
}
async function resetTemplateSpots() {
  const r = await ask({ title: 'Use the face planner\'s spots again?', body: 'Templates go back to the face planner\'s spots for every area. Marks already on charts stay where they are.', buttons: [{ label: 'Cancel', value: null }, { label: 'Use the planner\'s', value: true, kind: 'primary' }] });
  if (!r) return;
  try { await setMeta('spots', {}); } catch (e) { return fail(e); }
  (E.sideRefresh || (() => { edSideHTML(); edWireSide(); }))();
}
