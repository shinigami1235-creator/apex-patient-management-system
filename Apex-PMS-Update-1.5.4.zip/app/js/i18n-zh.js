// Simplified Chinese for the screens the patient holds: check-in, consent and the patient view.
// Staff screens stay in Thai or English.
Object.assign(I18N.zh, {
"1. Your details": "1. 您的资料",
"2. Your health": "2. 您的健康",
"3. Forms to sign": "3. 需签署的表格",
"4. Done": "4. 完成",
"Add allergy": "添加过敏",
"Add illness": "添加疾病",
"Add medicine": "添加药物",
"Add one": "添加",
"Add someone": "添加联系人",
"Add your allergies, or tick that you have none that you know of.": "请填写过敏情况，或勾选没有已知的过敏。",
"Address": "地址",
"After": "治疗后",
"Aftercare": "术后护理",
"Alcohol": "饮酒",
"Allergic to": "过敏物",
"Allergies": "过敏史",
"Autoimmune disease": "自身免疫性疾病",
"Back": "返回",
"Back to the patient": "返回患者页面",
"Before": "治疗前",
"Before and after": "治疗前后对比",
"Bleeding or clotting disorder": "出血或凝血障碍",
"Botox, forehead and frown lines": "肉毒素，额头纹和眉间纹",
"Botox, frown lines": "肉毒素，眉间纹",
"Botox, jaw slimming": "肉毒素，瘦脸",
"Brow": "眉部",
"Brow lift": "提眉",
"Bunny lines": "鼻背纹",
"Cancel": "取消",
"Check-in closed.": "登记已关闭。",
"Cheek": "面颊",
"Cheek filler": "面颊填充",
"Chin": "下巴",
"Chin and jawline filler": "下巴和下颌线填充",
"Clear": "清除",
"Close": "关闭",
"Close-up": "特写",
"Cold sores": "唇疱疹",
"Consultation": "咨询",
"Crow's feet": "鱼尾纹",
"DAO": "降口角肌",
"Date of birth": "出生日期",
"Done": "完成",
"Dose": "剂量",
"Email": "电子邮箱",
"Enter who is signing.": "请填写签名人姓名。",
"Enter your mobile number so we can reach you.": "请填写手机号码，方便我们联系您。",
"Everything is signed.": "全部已签署。",
"Female": "女",
"Finish": "完成",
"Forehead": "额头",
"Forms to sign": "需签署的表格",
"Fri": "周五",
"Front": "正面",
"Full face": "全脸",
"Glabella": "眉间",
"Gummy smile": "露龈笑",
"HIFU full face": "全脸HIFU",
"Hands": "手部",
"Hives and lip swelling": "荨麻疹、嘴唇肿胀",
"How often": "频率",
"Husband": "丈夫",
"I have no allergies that I know of": "我没有已知的过敏",
"Illness": "疾病",
"Illnesses, operations and past treatments": "疾病、手术和既往治疗",
"Improved": "有所改善",
"Isotretinoin in the last 6 months": "近6个月内服用过异维A酸",
"Jawline": "下颌线",
"Keloid or raised scars": "瘢痕疙瘩或增生性疤痕",
"Language": "语言",
"Left 45°": "左侧45°",
"Left side": "左侧",
"Lidocaine, latex, a food": "利多卡因、乳胶、某种食物",
"Lip filler": "唇部填充",
"Lip flip": "翻唇",
"Lips": "嘴唇",
"Looking after your skin": "皮肤护理",
"Losartan": "氯沙坦",
"Male": "男",
"Marionette": "木偶纹",
"Masseter": "咬肌",
"Medicines to take at home": "回家服用的药物",
"Medicines, vitamins and supplements": "药物、维生素和保健品",
"Midface": "中面部",
"Mobile": "手机",
"Mon": "周一",
"Much improved": "明显改善",
"Myasthenia gravis or other nerve and muscle disease": "重症肌无力或其他神经肌肉疾病",
"Name": "姓名",
"Nasolabial fold": "法令纹",
"Neck": "颈部",
"Next": "下一步",
"No": "否",
"No change": "无变化",
"No forms are needed today.": "今天无需签署表格。",
"No photos yet.": "暂无照片。",
"No visits yet.": "暂无就诊记录。",
"No, or how much": "不吸，或吸多少",
"No, or how often": "不喝，或多久一次",
"Nose": "鼻子",
"Nose implant": "隆鼻假体",
"Once a day": "每天一次",
"One photo of this view so far. The next visit adds the after.": "此角度目前只有一张照片，下次就诊会补充治疗后照片。",
"Operation or aesthetic treatment": "手术或医美治疗",
"Pacemaker or metal implant": "心脏起搏器或金属植入物",
"Patient check-in": "患者登记",
"Patient or guardian name": "患者或监护人姓名",
"Patient view": "患者页面",
"Periorbital": "眼周",
"Permanent filler or implant in the face": "面部有永久性填充物或假体",
"Phone": "电话",
"Platysma": "颈阔肌",
"Please check your details and fix anything that has changed.": "请核对您的资料，如有变动请修改。",
"Please read each form and sign it on the screen. Ask us about anything that is not clear.": "请阅读每份表格并在屏幕上签名。如有不清楚的地方，请随时问我们。",
"Post-op check": "术后复查",
"Pre-jowl": "下颌前沟",
"Pregnant or breastfeeding": "怀孕或哺乳期",
"Read and sign": "阅读并签署",
"Relation": "关系",
"Remove": "删除",
"Result:": "效果：",
"Review": "复诊",
"Right 45°": "右侧45°",
"Right side": "右侧",
"Sat": "周六",
"Save signed form": "保存已签署的表格",
"Sex": "性别",
"Show patient": "给患者看",
"Show what was done": "显示治疗部位",
"Side by side": "并排对比",
"Sign later": "稍后签署",
"Sign with a finger or stylus.": "请用手指或触控笔签名。",
"Signature": "签名",
"Signed": "已签署",
"Signed. Thank you.": "已签署，谢谢",
"Since": "起始年份",
"Skin booster": "水光针",
"Skin infection or open wound at the site": "治疗部位有皮肤感染或开放伤口",
"Slide": "滑动对比",
"Slide between before and after": "滑动对比治疗前后",
"Smoking": "吸烟",
"Staff": "工作人员",
"Staff PIN to close check-in": "工作人员输入PIN关闭登记",
"Staff PIN to close the patient view": "工作人员输入PIN关闭患者页面",
"Submental": "下巴下方",
"Sun": "周日",
"Takes blood thinners, aspirin, fish oil or vitamin E": "正在服用抗凝血药、阿司匹林、鱼油或维生素E",
"Teacher": "教师",
"Tear trough": "泪沟",
"Temple": "太阳穴",
"The form needs a signature.": "表格需要签名。",
"These keep your treatment safe. Tell us everything, even if it seems small.": "这些信息关系到您的治疗安全。请如实告诉我们，小事也不要遗漏。",
"Thread lift": "线雕提升",
"Thu": "周四",
"Thyroid problem": "甲状腺问题",
"Tick everything that is true for you": "请勾选所有符合您的情况",
"Treatment": "治疗",
"Tue": "周二",
"Turn the tablet to the patient: their photos, visits, plan and aftercare only": "将平板转给患者查看：仅显示其照片、就诊、方案和术后护理",
"Under eye": "眼下",
"Under-eye filler": "眼下填充",
"Underarm": "腋下",
"Updated by the patient at check-in": "患者登记时更新",
"Very much improved": "显著改善",
"Visit": "就诊",
"Wed": "周三",
"What happens": "过敏反应",
"What we call you": "我们怎么称呼您",
"Who we call in an emergency": "紧急联系人",
"Work": "职业",
"Worse": "变差",
"Year": "年份",
"Yes": "是",
"You are all set. Please hand the tablet back to the front desk.": "登记完成。请将平板交还前台。",
"Your details": "您的资料",
"Your health": "您的健康",
"Your next visit": "下次就诊",
"Your plan": "您的方案",
"Your visits": "您的就诊"
});
addRules('zh', [
[
"Questions, or anything that worries you: call or text {1}.",
"如有疑问或任何担心，请致电或发短信至{1}。"
],
[
"From your visit on {1}",
"来自您{1}的就诊"
],
[
", you rated it {1} of 5",
"，您的评分为{1}/5"
],
[
"{1}'s treatments",
"{1}的治疗"
],
[
"Thank you, {1}",
"谢谢您，{1}"
],
[
"Witness: {1}",
"见证人：{1}"
],
[
"{1} months",
"{1}个月"
],
[
"Before · {1}",
"治疗前 · {1}"
],
[
"{1} weeks",
"{1}周"
],
[
"{1} month",
"{1}个月"
],
[
"After · {1}",
"治疗后 · {1}"
],
[
"{1} apart",
"间隔{1}"
],
[
"{1} days",
"{1}天"
],
[
"{1} week",
"{1}周"
],
[
"{1} day",
"{1}天"
],
[
"{1} Jan {2}",
"{2}年1月{1}日"
],
[
"{1} Feb {2}",
"{2}年2月{1}日"
],
[
"{1} Mar {2}",
"{2}年3月{1}日"
],
[
"{1} Apr {2}",
"{2}年4月{1}日"
],
[
"{1} May {2}",
"{2}年5月{1}日"
],
[
"{1} Jun {2}",
"{2}年6月{1}日"
],
[
"{1} Jul {2}",
"{2}年7月{1}日"
],
[
"{1} Aug {2}",
"{2}年8月{1}日"
],
[
"{1} Sep {2}",
"{2}年9月{1}日"
],
[
"{1} Oct {2}",
"{2}年10月{1}日"
],
[
"{1} Nov {2}",
"{2}年11月{1}日"
],
[
"{1} Dec {2}",
"{2}年12月{1}日"
],
[
"Hi {1}",
"您好，{1}"
],
[
"{1}: {2}",
"{1}：{2}"
],
[
"{1}, {2}",
"{1}，{2}"
],
[
"{1} · {2}",
"{1} · {2}"
]
]);
