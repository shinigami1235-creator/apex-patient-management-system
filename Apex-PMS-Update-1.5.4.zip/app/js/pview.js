// Patient view: the doctor's tablet turned to the patient. Their own before and after
// photos with a slider, what was done at each visit drawn on their face, their plan to
// sign, and their aftercare. Nothing else in the clinic shows: no notes, no other
// patients, no menus. Like check-in, only a staff PIN closes it.

const PVIEW_KEY = 'cc_pview';
const PV_TABS = [['photos', 'Before and after'], ['visits', 'Your visits'], ['plan', 'Your plan'], ['care', 'Aftercare']];
const pviewFlag = () => { try { return JSON.parse(sessionStorage.getItem(PVIEW_KEY) || 'null'); } catch (e) { return null; } };
const setPviewFlag = x => { try { if (x) sessionStorage.setItem(PVIEW_KEY, JSON.stringify(x)); else sessionStorage.removeItem(PVIEW_KEY); } catch (e) { /* this browser keeps nothing */ } };

function resumePatientView() {
  const f = pviewFlag();
  if (!f || document.querySelector('.pview')) return;
  if (!patient(f.pid) || !can('clinical')) return setPviewFlag(null);
  openPatientView(f.pid, f);
}
function showPatientButtonHTML(pid, visitId = '') {
  return `<button class="btn secondary" data-pview="${esc(pid)}" data-pview-visit="${esc(visitId)}" title="Turn the tablet to the patient: their photos, visits, plan and aftercare only">${I.eye}Show patient</button>`;
}
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-pview]');
  if (b) { e.preventDefault(); openPatientView(b.dataset.pview, { visitId: b.dataset.pviewVisit || '' }); }
});

// What the patient sees about their visits: signed visits, and today's.
function pvVisits(pid) { return visitsOf(pid).filter(v => v.signedAt || v.date === todayISO()); }
function pvPhotoGroups(pid) {
  const views = new Map();
  for (const ph of S.photos.filter(x => x.patientId === pid && x.fileId && x.view && x.view !== 'Other')) {
    if (!views.has(ph.view)) views.set(ph.view, []);
    views.get(ph.view).push(ph);
  }
  for (const list of views.values()) list.sort((a, b) => photoVisitDate(a).localeCompare(photoVisitDate(b)) || (a.created || 0) - (b.created || 0));
  return [...views.entries()].sort((a, b) => PHOTO_VIEWS.indexOf(a[0]) - PHOTO_VIEWS.indexOf(b[0]));
}
function pvTreatLines(v) {
  const lines = chartLines(v.id).map(l => `${l.product}: ${trimNum(l.amount)} ${l.unit}${l.area ? ', ' + l.area : ''}`);
  for (const t of (v.treatments || []).filter(x => x.source !== 'chart' && x.source !== 'supply' && x.source !== 'med')) lines.push(`${t.product}${t.amount ? ': ' + trimNum(t.amount) + ' ' + (t.unit || '') : ''}${t.area ? ', ' + t.area : ''}`);
  return lines;
}
const pvWeeks = (a, b) => { const d = Math.round((new Date(b) - new Date(a)) / 86400000); return d < 14 ? plural(d, 'day') : d < 120 ? plural(Math.round(d / 7), 'week') : plural(Math.round(d / 30.4), 'month'); };

function openPatientView(pid, { visitId = '', tab, view, a, b, mode } = {}) {
  const p = patient(pid);
  if (!p) return;
  document.querySelectorAll('.pview').forEach(x => x.remove());
  const el = document.createElement('div');
  el.className = 'pview';
  el.dataset.uiLang = p.plang || 'th';
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Patient view');
  document.body.appendChild(el);
  document.body.classList.add('ov-open');
  const first = esc(p.goesBy || p.name.split(' ')[0]);
  const groups = pvPhotoGroups(pid);
  const careVisit = pvVisits(pid).find(v => v.aftercare || (v.rx || []).length);
  const tabs = PV_TABS.filter(([k]) => k !== 'plan').filter(([k]) => k !== 'care' || careVisit).filter(([k]) => k !== 'photos' || groups.length);
  const st = { tab: tab && tabs.some(t => t[0] === tab) ? tab : tabs[0] ? tabs[0][0] : 'visits', view: view || (groups.find(g => g[0] === 'Front') ? 'Front' : groups[0] && groups[0][0]), a, b, mode: mode || 'slide', marks: false, cut: 50 };
  const keep = () => setPviewFlag({ pid, visitId, tab: st.tab, view: st.view, a: st.a, b: st.b, mode: st.mode });

  const photosTab = () => {
    const list = (groups.find(g => g[0] === st.view) || [null, []])[1];
    if (!list.length) return '<p class="lead">No photos yet.</p>';
    if (!list.some(x => x.id === st.a)) st.a = list[0].id;
    if (!list.some(x => x.id === st.b)) st.b = list[list.length - 1].id;
    const A = byId('photos', st.a), B = byId('photos', st.b);
    const marks = S.charts.filter(c => c.base && c.base.type === 'photo' && c.base.photoId === A.id).flatMap(c => c.marks || []);
    const w = A.w || 1200, h = A.h || 1600;
    const overlay = st.marks && marks.length ? `<svg class="pv-marks" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid meet">${marksSVG(marks, w, h)}</svg>` : '';
    const one = A.id === B.id;
    const strip = (slot, cur) => `<div class="pv-strip" role="group" aria-label="${slot === 'a' ? 'Before' : 'After'}"><span class="pv-strip-l">${slot === 'a' ? 'Before' : 'After'}</span>${list.map(x => `<button type="button" class="pv-th ${x.id === cur ? 'on' : ''}" data-pv-pick="${slot}" data-id="${x.id}" aria-pressed="${x.id === cur}"><img src="${thumbURL(x.id)}" alt=""><span>${esc(fmtDate(photoVisitDate(x)))}</span></button>`).join('')}</div>`;
    return `<div class="pv-views">${groups.map(([v]) => `<button type="button" class="pv-chip ${v === st.view ? 'on' : ''}" data-pv-view="${esc(v)}">${esc(v)}</button>`).join('')}</div>
      <div class="pv-compare ${st.mode} ${one ? 'one' : ''}" style="--ar:${w}/${h};--cut:${st.cut}%">
        ${one ? `<div class="pv-pane"><img src="${fullURL(A.id)}" alt="">${overlay}<span class="pv-tag">${esc(fmtDate(photoVisitDate(A)))}</span></div>`
          : st.mode === 'slide' ? `<div class="pv-pane pv-after"><img src="${fullURL(B.id)}" alt=""><span class="pv-tag r">After · ${esc(fmtDate(photoVisitDate(B)))}</span></div>
            <div class="pv-pane pv-before"><img src="${fullURL(A.id)}" alt="">${overlay}<span class="pv-tag">Before · ${esc(fmtDate(photoVisitDate(A)))}</span></div>
            <div class="pv-handle" role="slider" tabindex="0" aria-label="Slide between before and after" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${st.cut}"><span></span></div>`
          : `<div class="pv-pane"><img src="${fullURL(A.id)}" alt="">${overlay}<span class="pv-tag">Before · ${esc(fmtDate(photoVisitDate(A)))}</span></div><div class="pv-pane"><img src="${fullURL(B.id)}" alt=""><span class="pv-tag">After · ${esc(fmtDate(photoVisitDate(B)))}</span></div>`}
      </div>
      <div class="pv-under">
        <span class="lead">${one ? 'One photo of this view so far. The next visit adds the after.' : `${pvWeeks(photoVisitDate(A), photoVisitDate(B))} apart`}</span>
        <div class="row">${one ? '' : `<div class="seg" role="group"><button type="button" data-pv-mode="slide" aria-pressed="${st.mode === 'slide'}">Slide</button><button type="button" data-pv-mode="side" aria-pressed="${st.mode === 'side'}">Side by side</button></div>`}
          ${marks.length ? `<label class="check pv-mk"><input type="checkbox" data-pv-marks ${st.marks ? 'checked' : ''}> Show what was done</label>` : ''}</div></div>
      ${one ? '' : strip('a', st.a) + strip('b', st.b)}`;
  };
  const visitsTab = () => {
    const list = pvVisits(pid);
    const fu = followUpOf(pid);
    return `${fu ? `<div class="pv-next"><b>Your next visit</b> ${esc(weekday(fu))}, ${esc(fmtDate(fu))}</div>` : ''}
      ${list.length ? list.map(v => {
        const charts = chartsOfVisit(v.id).filter(c => (c.marks || []).length);
        const lines = pvTreatLines(v), doc = byId('users', v.doctorId);
        const g = v.outcome ? (GAIS.find(x => x[0] === num(v.outcome.gais)) || [])[1] : '';
        return `<div class="pv-visit"><div class="pv-vh"><b>${esc(fmtDate(v.date))}</b><span class="meta">${doc ? esc(doc.name) : ''}</span></div>
          <div class="pv-vb">${charts.length ? `<div class="pv-charts">${charts.map(c => `<button type="button" class="pv-chart" data-pv-chart="${c.id}">${chartSVG(c, c.base && c.base.type === 'photo' ? fullURL(c.base.photoId) : chartImageFor(c))}</button>`).join('')}</div>` : ''}
            <div class="grow"><h3>${esc((v.services || []).map(s => s.name).join(', ') || v.type || 'Visit')}</h3>
              ${lines.length ? `<ul class="pv-lines">${lines.map(l => `<li>${esc(l)}</li>`).join('')}</ul>` : ''}
              ${g ? `<p class="pv-result">Result: <b>${esc(g)}</b>${v.outcome.rating ? `, you rated it ${esc(String(v.outcome.rating))} of 5` : ''}</p>` : ''}</div></div></div>`;
      }).join('') : '<p class="lead">No visits yet.</p>'}`;
  };
  const careTab = () => {
    const v = careVisit;
    return `<p class="meta">From your visit on ${esc(fmtDate(v.date))}</p>
      ${(v.rx || []).length ? `<div class="card"><h2 class="card-title">Medicines to take at home</h2><table class="t">${v.rx.map(r => `<tr><td><b>${esc(r.drug)}</b><div class="m">${esc(r.sig || '')}</div></td><td class="n">${esc(String(r.qty || ''))}</td></tr>`).join('')}</table></div>` : ''}
      ${v.aftercare ? `<div class="card"><h2 class="card-title">Looking after your skin</h2><div class="pre pv-care">${esc(v.aftercare)}</div></div>` : ''}
      ${S.clinic.phone ? `<p class="lead">Questions, or anything that worries you: call or text ${esc(S.clinic.phone)}.</p>` : ''}`;
  };

  const show = () => {
    keep();
    const body = { photos: photosTab, visits: visitsTab, care: careTab }[st.tab]();
    el.innerHTML = `<div class="ck-top"><button class="btn small ck-back" data-pv-staff data-ui-lang="${curLang()}">${I.back}Back</button><b>${esc(S.clinic.name || '')}</b>${plangSwitchHTML(el.dataset.uiLang)}</div>
      <div class="pv-body"><h1>${first}'s treatments</h1>
        ${tabs.length > 1 ? `<div class="pv-tabs" role="tablist">${tabs.map(([k, l]) => `<button type="button" role="tab" aria-selected="${k === st.tab}" data-pv-tab="${k}">${esc(l)}</button>`).join('')}</div>` : ''}
        <div class="pv-content">${body}</div></div>`;
    wirePlangSwitch(el);
    el.querySelector('[data-pv-staff]').onclick = () => pviewExit(el, pid);
    el.querySelectorAll('[data-pv-tab]').forEach(x => x.onclick = () => { st.tab = x.dataset.pvTab; show(); el.scrollTop = 0; });
    el.querySelectorAll('[data-pv-view]').forEach(x => x.onclick = () => { st.view = x.dataset.pvView; st.a = st.b = null; show(); });
    el.querySelectorAll('[data-pv-pick]').forEach(x => x.onclick = () => { st[x.dataset.pvPick] = x.dataset.id; show(); });
    el.querySelectorAll('[data-pv-mode]').forEach(x => x.onclick = () => { st.mode = x.dataset.pvMode; show(); });
    const mk = el.querySelector('[data-pv-marks]'); if (mk) mk.onchange = () => { st.marks = mk.checked; show(); };
    el.querySelectorAll('[data-pv-chart]').forEach(x => x.onclick = () => pvZoom(x.innerHTML));
    wireSlider();
  };
  // Drag anywhere on the picture, or the handle, to move the cut between before and after.
  const wireSlider = () => {
    const box = el.querySelector('.pv-compare.slide:not(.one)');
    if (!box) return;
    const set = x => { const r = box.getBoundingClientRect(); st.cut = Math.max(0, Math.min(100, ((x - r.left) / r.width) * 100)); box.style.setProperty('--cut', st.cut + '%'); const hd = box.querySelector('.pv-handle'); hd.setAttribute('aria-valuenow', Math.round(st.cut)); };
    let drag = false;
    box.onpointerdown = e => { drag = true; box.setPointerCapture(e.pointerId); set(e.clientX); };
    box.onpointermove = e => { if (drag) set(e.clientX); };
    box.onpointerup = box.onpointercancel = () => { drag = false; };
    const hd = box.querySelector('.pv-handle');
    hd.onkeydown = e => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); st.cut = Math.max(0, Math.min(100, st.cut + (e.key === 'ArrowLeft' ? -5 : 5))); box.style.setProperty('--cut', st.cut + '%'); } };
  };
  const pvZoom = svg => {
    const z = document.createElement('div');
    z.className = 'pv-zoom'; z.innerHTML = `<div class="pv-zoom-in">${svg}</div><button class="btn secondary" data-close>Close</button>`;
    z.onclick = () => z.remove();
    el.appendChild(z);
  };
  show();
}
// The picture under a chart on a 3D head or the drawing: the drawing needs none.
function chartImageFor(c) { return c.base && c.base.type === 'head' && typeof headThumbURL === 'function' ? headThumbURL(byId('heads', c.base.headId), c.shot || 'front') : ''; }

// On a tablet the patient may be holding it, so the way back asks for the PIN. A computer
// with a mouse stays with the doctor, so it goes straight back.
const handheld = () => /iPad|iPhone|iPod|Android|Mobile/i.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
function pviewExit(pv, pid) {
  const done = () => {
    setPviewFlag(null);
    pv.remove(); document.body.classList.remove('ov-open');
    if (S.pendingGoto) { const g = S.pendingGoto; S.pendingGoto = null; go(g); }
    else if (location.hash.startsWith('#/patient/' + pid) || location.hash.startsWith('#/visit/') || location.hash.startsWith('#/chart/')) render(); else go('#/patient/' + pid);
  };
  // The PIN is for a tablet or phone handed to the patient. A laptop or PC, touchscreen or not, goes straight back.
  if (!handheld()) return done();
  const el = document.createElement('div');
  el.className = 'lock';
  document.body.appendChild(el);
  pinPad(el, S.me, {
    title: 'Staff PIN to close the patient view',
    onPin: async pin => {
      await api('/api/login', { userId: S.me.id, pin });
      stopEvents(); startEvents(); lastActive = Date.now();
      el.remove(); done();
    },
    extra: '<button class="ghost" data-kiosk>Back to the patient</button>',
    onExtra: () => el.remove(),
  });
}
