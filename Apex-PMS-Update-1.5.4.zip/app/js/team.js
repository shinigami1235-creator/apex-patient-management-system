// People: the doctors and assistants who sign in, and each person's own page with their
// language and PIN.

function renderTeam(b) {
  const owner = isOwner();
  const tabs = owner ? [['people', 'People'], ['access', 'What each role can do'], ['me', 'Me']] : [['me', 'Me']];
  if (!b || !tabs.some(t => t[0] === b)) b = tabs[0][0];
  const body = { people: teamPeople, access: teamAccess, me: teamMe }[b]();
  $app.innerHTML = shell('team', `<div class="page-head"><div><h1>${owner ? 'People' : 'Me'}</h1></div></div>${tabs.length > 1 ? tabsNav(tabs, b, '#/team/') : ''}<div id="team">${body}</div>`);
  wireShell();
  ({ people: wirePeople, access: wireAccess, me: wireMe }[b])();
}

// ---------- what each role can do ----------
// The admin picks, for each role and each part of the program, no access, view or edit.
// The branch PC enforces it, so a role that may only view can't change a record from any device.
// Visits combine: a doctor's treatment lines and a nurse's IV drip on the same visit both stay,
// and only when two people change the same box at once does the admin see it under Conflicts.
const ACCESS_ROLES = Object.keys(ROLES).filter(r => r !== 'owner');
function teamAccess() {
  const rows = ACCESS_AREAS.map(([k, label, stores]) => `<tr><th scope="row">${esc(label)}</th>${ACCESS_ROLES.map(r => {
    const now = accessRule(stores[0], r, S.access || {});
    const opts = ACCESS_LEVELS.filter(([l]) => l !== 'rl' || k === 'patients');
    return `<td><select data-acc-role="${r}" data-acc-area="${k}" aria-label="${esc(ROLES[r].label)}: ${esc(label)}">${opts.map(([l, t]) => `<option value="${l}" ${now === l ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></td>`;
  }).join('')}</tr>`).join('');
  return `<div class="card"><h2 class="card-title">What each role can do</h2>
    <p class="muted">The admin has everything, and only doctors sign visits. When a doctor and a nurse both work on the same visit, such as a surgical procedure and an IV drip on the same day, each one's treatment lines and notes are kept. Only two changes to the same box at the same time go to the admin under Conflicts.</p>
    <div class="table-wrap"><table class="t access-t"><tr><th></th>${ACCESS_ROLES.map(r => `<th>${esc(ROLES[r].label)}</th>`).join('')}</tr>${rows}</table></div>
    <div class="row end" style="margin-top:12px"><button class="btn quiet" data-acc-reset>Use the starting rules</button><button class="btn primary" data-acc-save>Save</button></div>
    <p class="meta">People signed in on other devices see the change straight away; their screens load again.</p></div>`;
}
function wireAccess() {
  const read = () => { const out = {}; document.querySelectorAll('[data-acc-role]').forEach(sel => { (out[sel.dataset.accRole] = out[sel.dataset.accRole] || {})[sel.dataset.accArea] = sel.value; }); return out; };
  document.querySelector('[data-acc-save]').onclick = async () => { try { await setMeta('access', read()); toast('Saved.'); render(); } catch (e) { fail(e); } };
  document.querySelector('[data-acc-reset]').onclick = async () => { try { await setMeta('access', {}); toast('Back to the starting rules.'); render(); } catch (e) { fail(e); } };
}

// ---------- people ----------
function teamPeople() {
  const list = [...S.users].sort((a, b) => (a.archived ? 1 : 0) - (b.archived ? 1 : 0) || a.name.localeCompare(b.name));
  return `<div class="row end gap-b"><button class="btn secondary" data-act="staff-print">${I.print}Print the list</button><button class="btn primary" data-act="add">${I.plus}Add a doctor or assistant</button></div>
    <div class="list">${list.map(u => `<button class="li ${u.archived ? 'dim' : ''}" data-user="${u.id}">${avatar(u)}<div class="grow"><div class="t">${esc(u.name)}${u.nameTh ? ` <span class="meta" lang="th">${esc(u.nameTh)}</span>` : ''}${u.id === S.me.id ? ' <span class="meta">(you)</span>' : ''}</div><div class="m">${esc(u.title || ROLES[u.role].label)}${u.licence ? ` · ${esc(u.licence)}` : ''}</div></div>${u.archived ? chip('Left') : chip(ROLES[u.role].label)}</button>`).join('')}</div>
    <p class="meta" style="margin-top:10px">${Object.values(ROLES).map(r => `<b>${r.label}.</b> ${esc(r.desc)}`).join(' ')}</p>`;
}
function wirePeople() {
  document.querySelector('[data-act="add"]').onclick = () => personSheet(null);
  document.querySelector('[data-act="staff-print"]').onclick = () => printStaff([...S.users].filter(u => !u.archived).sort((a, b) => a.name.localeCompare(b.name)));
  document.querySelectorAll('[data-user]').forEach(b => b.onclick = () => personSheet(byId('users', b.dataset.user)));
}

async function personSheet(u) {
  let photo = u ? u.photo : '';
  const f = await sheet({
    title: u ? u.name : 'Add a doctor or assistant', wide: true,
    extra: `${u && u.id !== S.me.id ? `<button type="button" class="btn ${u.archived ? 'secondary' : 'danger'}" data-arch>${u.archived ? 'Bring back' : 'Mark as left'}</button>` : ''}`,
    body: `<div class="grid2">${field('Name in English', 'name', u ? u.name : '', { ph: 'Dr. Nantapat Srisuk' })}${field('Name in Thai', 'nameTh', u ? u.nameTh : '', { ph: 'นพ. นันทพัทธ์ ศรีสุข' })}</div>
      <div class="grid3">${field('Role', 'role', u ? u.role : 'doctor', { type: 'select', options: Object.entries(ROLES).map(([k, r]) => [k, r.label]), blank: false })}${field('Position', 'title', u ? u.title : '', { ph: 'Plastic surgeon' })}${field('Medical licence number', 'licence', u ? u.licence : '', { ph: 'ว. 12345', hint: 'Printed on prescriptions and signed visits.' })}</div>
      <div class="grid3">${field('Treats patients', 'clinicalRole', u ? u.clinicalRole || '' : 'doctor', { type: 'select', options: [['doctor', 'As a doctor']], blank: 'No', hint: 'For an admin who also sees patients.' })}${field('Mobile', 'phone', u ? u.phone : '', { type: 'tel', ph: '081 234 5678' })}${field('Email', 'email', u ? u.email : '', { type: 'email' })}</div>
      <div class="grid3">${field('Screen language', 'lang', u ? u.lang || 'th' : 'th', { type: 'select', options: [['th', 'ไทย'], ['en', 'English']], blank: false })}${field(u ? 'New PIN' : 'PIN', 'pin', '', { type: 'password', hint: u ? 'Blank keeps the current PIN.' : '4 to 8 digits.', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}${field('PIN again', 'pin2', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}</div>
      <div class="row"><span class="avatar lg" data-ph>${photo ? `<img src="${fileURL(photo)}" alt="">` : esc(initials(u ? u.name : '?'))}</span><label class="btn secondary small">Photo<input type="file" class="file-hidden" accept="image/*" data-photo></label></div>
      ${fieldsFor('users', { retired: true }).length ? `${customFieldsHTML('users', u ? u.custom : {}, 'staff')}${customSections('users', u ? u.custom : {}).map(sec => `<h3 class="sub-head">${esc(sec)}</h3>${customFieldsHTML('users', u ? u.custom : {}, sec)}`).join('')}` : ''}`,
    onOpen: form => {
      form.querySelector('[data-photo]').onchange = async e => { const file = e.target.files[0]; if (!file) return; try { const r = await resizeImage(file, 400, 0.85); photo = await uploadFile(r.blob); form.querySelector('[data-ph]').innerHTML = `<img src="${fileURL(photo)}" alt="">`; } catch (ex) { form.err(ex.message); } };
      const ar = form.querySelector('[data-arch]');
      if (ar) ar.onclick = async () => { form.close(null); try { await save('users', { ...u, archived: !u.archived }, { action: u.archived ? 'Brought back' : 'Marked as left' }); render(); } catch (e) { fail(e); } };
    },
    validate: form => {
      const pin = val(form, 'pin');
      if (!val(form, 'name')) return 'Enter the name in English.';
      if ((!u || pin) && !/^\d{4,8}$/.test(pin)) return 'The PIN needs 4 to 8 digits.';
      if (pin && pin !== val(form, 'pin2')) return 'The two PINs are different.';
      return customMissing(form, 'users');
    },
  });
  if (!f) return;
  const rec = { ...(u || { id: uid() }), photo };
  for (const k of ['name', 'nameTh', 'title', 'role', 'licence', 'clinicalRole', 'phone', 'email', 'lang']) rec[k] = val(f, k);
  rec.custom = readCustomFields(f, 'users', u ? u.custom : {});
  try {
    await save('users', rec, { action: u ? 'Person edited' : 'Person added', pin: val(f, 'pin') || undefined });
    hello = await api('/api/hello').catch(() => hello);
    if (u && u.id === S.me.id) setLang(rec.lang);
    render();
  } catch (e) { fail(e); }
}

function printStaff(list) {
  doPrint(`${printHead()}<h1>Doctors and assistants</h1><table><tr><th>Name</th><th>Role</th><th>Position</th><th>Licence</th><th>Mobile</th></tr>
    ${list.map(u => `<tr><td>${esc(u.name)}${u.nameTh ? `<br>${esc(u.nameTh)}` : ''}</td><td>${esc((ROLES[u.role] || {}).label)}</td><td>${esc(u.title || '')}</td><td>${esc(u.licence || '')}</td><td>${esc(u.phone || '')}</td></tr>`).join('')}</table>${printFoot()}`, 'Doctors and assistants');
}

// ---------- me ----------
function teamMe() {
  const u = S.me;
  return `<div class="cols">
    <div class="card"><div class="phead">${avatar(u, 'lg')}<div class="grow"><h2>${esc(u.name)}</h2>${u.nameTh ? `<div lang="th">${esc(u.nameTh)}</div>` : ''}<div class="meta">${esc(u.title || ROLES[u.role].label)}${u.licence ? ` · ${esc(u.licence)}` : ''}</div></div></div>
      ${['staff', ...customSections('users', u.custom)].map(sec => { const pairs = customPairs('users', u.custom, sec); return pairs.length ? `<h3 class="sub-head">${esc(SECTION_LABEL('users', sec))}</h3>${customKV(pairs)}` : ''; }).join('')}
      <h3 class="sub-head">Screen language</h3>
      <div class="seg" role="group" aria-label="Screen language">${[['th', 'ไทย'], ['en', 'English']].map(([k, l]) => `<button type="button" data-pick-lang="${k}" class="${curLang() === k ? 'on' : ''}" translate="no">${l}</button>`).join('')}</div></div>
    <form class="card" id="mypin"><h2 class="card-title">Change my PIN</h2>
      <div class="grid3">${field('Current PIN', 'old', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="current-password"' })}${field('New PIN', 'pin', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}${field('New PIN again', 'pin2', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="new-password"' })}</div>
      <p class="form-err" data-err></p><div class="row end"><button class="btn primary">Change PIN</button></div></form>
    ${u.role === 'owner' ? `<div class="card" id="totp">${totpCard(u)}</div>` : ''}
  </div>`;
}
// Two-step sign-in for the admin: a code from an authenticator app after the PIN, asked once
// on each device every 30 days.
function totpCard(u, setup) {
  if (setup) return `<h2 class="card-title">Two-step sign-in</h2>
    <ol class="steps"><li>Install Google Authenticator or Microsoft Authenticator on your phone.</li><li>In the app, add an account and scan this QR code.</li><li>Type the 6-digit code the app shows.</li></ol>
    <div class="qr-box">${qrSVG(setup.uri, 200)}</div><p class="meta">Can't scan? Type this key in the app: <code translate="no">${esc(setup.secret.replace(/(.{4})/g, '$1 ').trim())}</code></p>
    <form id="totp-on">${field('Code from the app', 'code', '', { attrs: 'inputmode="numeric" maxlength="6" autocomplete="one-time-code"' })}
    <p class="form-err" data-err></p><div class="row end"><button type="button" class="btn" data-totp-cancel>Cancel</button><button class="btn primary">Turn on</button></div></form>`;
  if (u.totpOn) return `<h2 class="card-title">Two-step sign-in</h2><p>On. Each device asks for the code from your authenticator app once every 30 days.</p>
    <form id="totp-off">${field('Your PIN', 'pin', '', { type: 'password', attrs: 'inputmode="numeric" maxlength="8" autocomplete="current-password"' })}
    <p class="form-err" data-err></p><div class="row end"><button class="btn danger">Turn off</button></div></form>`;
  return `<h2 class="card-title">Two-step sign-in</h2><p>Off. Turn it on to ask for a code from an authenticator app on your phone after your PIN, once on each device every 30 days.</p>
    <p class="form-err" data-err></p><div class="row end"><button class="btn primary" data-totp-start>Set up</button></div>`;
}
function wireTotp() {
  const box = document.getElementById('totp');
  if (!box) return;
  const err = m => { const e = box.querySelector('[data-err]'); if (e) e.textContent = tr(m); };
  const start = box.querySelector('[data-totp-start]');
  if (start) start.onclick = async () => {
    try { const setup = await api('/api/me/totp/start', {}); box.innerHTML = totpCard(S.me, setup); wireTotp(); box.querySelector('[name=code]').focus(); }
    catch (e) { err(e.message); }
  };
  const cancel = box.querySelector('[data-totp-cancel]');
  if (cancel) cancel.onclick = () => { box.innerHTML = totpCard(S.me); wireTotp(); };
  const on = document.getElementById('totp-on');
  if (on) on.onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/me/totp/confirm', { code: val(on, 'code').replace(/\D/g, '') }); S.me.totpOn = true; toast('Two-step sign-in is on.'); box.innerHTML = totpCard(S.me); wireTotp(); }
    catch (ex) { err(ex.message); }
  };
  const off = document.getElementById('totp-off');
  if (off) off.onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/me/totp/off', { pin: val(off, 'pin') }); S.me.totpOn = false; toast('Two-step sign-in is off.'); box.innerHTML = totpCard(S.me); wireTotp(); }
    catch (ex) { err(ex.message); }
  };
}
function wireMe() {
  wireTotp();
  document.querySelectorAll('[data-pick-lang]').forEach(b => b.onclick = async () => {
    const lang = b.dataset.pickLang;
    setLang(lang);
    try { await api('/api/me/lang', { lang }); S.me.lang = lang; } catch (e) { /* the device keeps the choice */ }
    render();
  });
  const f = document.getElementById('mypin');
  f.onsubmit = async e => {
    e.preventDefault();
    const err = m => { f.querySelector('[data-err]').textContent = tr(m); };
    const pin = val(f, 'pin');
    if (!/^\d{4,8}$/.test(pin)) return err('The PIN needs 4 to 8 digits.');
    if (pin !== val(f, 'pin2')) return err('The two PINs are different.');
    try { await api('/api/me/pin', { old: val(f, 'old'), pin }); S.me.pinLen = pin.length; delete f.dataset.dirty; hello = await api('/api/hello').catch(() => hello); toast('PIN changed.'); render(); }
    catch (ex) { err(ex.message); }
  };
}
