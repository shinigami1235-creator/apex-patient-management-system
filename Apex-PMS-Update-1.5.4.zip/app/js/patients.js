// Patient list, patient record and its tabs, and the Medical Info Sheet import.

function patientSummary(p) {
  return [p.no, p.hn ? 'HN ' + p.hn : '', p.sex, p.dob ? `${ageOf(p.dob)} y` : '', p.nationality && p.nationality !== 'Thai' ? p.nationality : '', p.phone].filter(Boolean).join(' · ');
}
function lastVisitOf(pid) { const v = visitsOf(pid)[0]; return v ? v.date : ''; }
// The follow-up date set on the patient's latest visit, when it is still to come.
function followUpOf(pid) { const v = visitsOf(pid).find(x => x.followUp); return v && v.followUp >= todayISO() ? v.followUp : ''; }

// The patient a typed or scanned code points at: this app's number such as SQ-00012, the
// Apex HN, or the address on the patient card's QR.
function findPatientByNo(text) {
  let t = String(text || '').trim().toUpperCase();
  const m0 = t.match(/#\/P\/([^/?#\s]+)/i);
  if (m0) t = decodeURIComponent(m0[1]).toUpperCase();
  if (!t) return null;
  const exact = S.patients.find(p => String(p.no || '').toUpperCase() === t || String(p.hn || '').toUpperCase() === t || String(p.hn || '').toUpperCase() === t.replace(/^HN[\s:-]*/, ''));
  if (exact) return exact;
  const m = t.match(/^([A-Z0-9]{1,4})-?0*(\d+)$/);
  if (m) return S.patients.find(p => { const pm = String(p.no || '').toUpperCase().match(/^([A-Z0-9]{1,4})-0*(\d+)$/); return pm && pm[1] === m[1] && +pm[2] === +m[2]; }) || null;
  return null;
}
const PATIENT_LANGS = [['th', 'ไทย'], ['en', 'English'], ['zh', '中文']];
// The language switch on the screens the patient holds: check-in, consent and the patient view.
function plangSwitchHTML(cur) {
  return `<div class="seg plang" role="group" aria-label="Language" translate="no">${PATIENT_LANGS.map(([l, n]) => `<button type="button" data-plang="${l}" aria-pressed="${l === cur}">${esc(n)}</button>`).join('')}</div>`;
}
function wirePlangSwitch(box) {
  box.querySelectorAll('[data-plang]').forEach(b => b.onclick = () => {
    box.dataset.uiLang = b.dataset.plang;
    box.querySelectorAll('[data-plang]').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    retranslate(box);
  });
}
const SOURCES = ['LINE', 'Facebook', 'Instagram', 'TikTok', 'Google', 'Website', 'Walk-in', 'Doctor referral', 'Friend or family', 'Returning patient', 'Other'];

// ---------- list ----------
function renderPatients(q) {
  const term = (q.q || '').toLowerCase().trim();
  const digits = term.replace(/\D/g, '');
  const tag = q.tag || '';
  const textFields = fieldsFor('patients', { role: S.me.role }).filter(f => ['text', 'long', 'choice', 'multi'].includes(f.type));
  let list = S.patients.filter(p => !term || [p.name, p.nameTh, p.goesBy, p.no, p.hn, p.idNo, p.email, p.line, ...textFields.map(f => customValueText(f, (p.custom || {})[f.id]))].some(x => String(x || '').toLowerCase().includes(term)) || (digits.length > 3 && String(p.phone || '').replace(/\D/g, '').includes(digits)));
  if (tag) list = list.filter(p => (p.tags || []).includes(tag));
  // A filter on one yes/no or choice field: f=<fieldId>&fv=<value>
  const filterFields = fieldsFor('patients', { role: S.me.role }).filter(f => ['yesno', 'choice', 'multi'].includes(f.type));
  const ff = q.f && filterFields.find(f => f.id === q.f);
  if (ff && q.fv !== undefined && q.fv !== '') list = list.filter(p => { const v = (p.custom || {})[ff.id]; return ff.type === 'yesno' ? String(v === true ? 'yes' : v === false ? 'no' : '') === q.fv : ff.type === 'multi' ? (Array.isArray(v) && v.includes(q.fv)) : String(v ?? '') === q.fv; });
  const sort = q.sort || 'recent';
  const lastMap = new Map(S.patients.map(p => [p.id, lastVisitOf(p.id)]));
  if (sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
  else if (sort === 'new') list.sort((a, b) => (b.created || 0) - (a.created || 0));
  else list.sort((a, b) => (lastMap.get(b.id) || '').localeCompare(lastMap.get(a.id) || '') || (b.created || 0) - (a.created || 0));
  const shown = list.slice(0, 300);
  const tags = [...new Set([...tagList().map(t => t.name), ...S.patients.flatMap(p => p.tags || [])])].sort();
  $app.innerHTML = shell('patients', `
    <div class="page-head"><div><h1>Patients</h1><div class="meta sub">${S.patients.length} on record</div></div>
      <div class="row"><button class="btn secondary" data-act="scan">${I.qr}Scan a patient card</button><button class="btn secondary" data-act="print-seen">${I.print}Print records seen</button>${isOwner() ? `<button class="btn secondary" data-act="export-csv">Export for Excel</button>` : ''}<a class="btn primary" href="#/patient/new">${I.plus}New patient</a></div></div>
    <div class="toolbar">
      <div class="search">${I.search}<input type="search" id="q" placeholder="Name, HN, patient number, ID or mobile" value="${esc(q.q || '')}" aria-label="Search patients"></div>
      <select id="tag" aria-label="Tag"><option value="">All tags</option>${tags.map(t => `<option ${t === tag ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>
      <select id="sort" aria-label="Sort"><option value="recent" ${sort === 'recent' ? 'selected' : ''}>Last visit</option><option value="name" ${sort === 'name' ? 'selected' : ''}>Name</option><option value="new" ${sort === 'new' ? 'selected' : ''}>Newest record</option></select>
      ${filterFields.length ? `<select id="ff" aria-label="Field"><option value="">Any field</option>${filterFields.map(f => `<option value="${f.id}" ${ff && ff.id === f.id ? 'selected' : ''}>${esc(f.label)}</option>`).join('')}</select>${ff ? `<select id="fv" aria-label="Value"><option value="">Any value</option>${(ff.type === 'yesno' ? [['yes', 'Yes'], ['no', 'No']] : (ff.options || []).map(o => [o, o])).map(([v, l]) => `<option value="${esc(v)}" ${q.fv === v ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>` : ''}` : ''}
    </div>
    ${shown.length ? `<div class="list">${shown.map(p => { const fu = followUpOf(p.id); const last = lastMap.get(p.id);
      return `<a class="li" href="#/patient/${p.id}">${avatar(p)}<div class="grow"><div class="t">${esc(p.name)}${p.nameTh && p.nameTh !== p.name ? ` <span class="meta" lang="th">${esc(p.nameTh)}</span>` : ''}${(p.tags || []).map(t => ' ' + tagChip(t)).join('')}</div><div class="m">${esc(patientSummary(p))}</div></div>
        <div class="end"><div class="meta">${last ? 'Last visit ' + fmtDate(last) : 'No visits yet'}</div>${fu ? `<div class="meta ok-text">Follow-up ${fmtDate(fu)}</div>` : ''}</div></a>`; }).join('')}</div>
      ${list.length > shown.length ? `<p class="meta center">Showing ${shown.length} of ${list.length}. Search to narrow the list.</p>` : ''}`
      : empty(term || tag || (ff && q.fv) ? 'No patient matches.' : 'No patients yet.', 'Add a new patient, or scan a patient card.')}`);
  wireShell();
  const qi = document.getElementById('q');
  const upd = debounce(() => {
    const hit = qi.value.trim().length > 3 && findPatientByNo(qi.value);
    if (hit && /^[A-Z0-9]{1,4}-\d|#\/p\//i.test(qi.value.trim())) return go('#/patient/' + hit.id);
    const fsel = document.getElementById('ff'), vsel = document.getElementById('fv');
    setQuery({ q: qi.value, tag: document.getElementById('tag').value, sort: document.getElementById('sort').value, f: fsel ? fsel.value : '', fv: vsel && fsel && fsel.value === (ff ? ff.id : '') ? vsel.value : '' }); renderPatients(route().q); const n = document.getElementById('q'); n.focus(); n.setSelectionRange(n.value.length, n.value.length);
  }, 220);
  qi.oninput = upd;
  const fsel = document.getElementById('ff'); if (fsel) fsel.onchange = upd;
  const vsel = document.getElementById('fv'); if (vsel) vsel.onchange = upd;
  qi.onkeydown = e => { if (e.key !== 'Enter') return; const p = findPatientByNo(qi.value); if (p) { e.preventDefault(); go('#/patient/' + p.id); } };
  document.getElementById('tag').onchange = upd;
  document.getElementById('sort').onchange = upd;
  document.querySelector('[data-act="scan"]').onclick = () => scanPatientCard();
  const ps = document.querySelector('[data-act="print-seen"]');
  if (ps) ps.onclick = () => printRecordsSeen();
  const ex = document.querySelector('[data-act="export-csv"]');
  if (ex) ex.onclick = () => exportPatientsCSV();
}

// Paper backup in batches: every patient with a visit in the date range, one record each.
async function printRecordsSeen() {
  const f = await sheet({ title: 'Print records seen', submit: 'Print', body: `<p class="muted">Every patient with a visit in these dates prints as a full record, one after the other, for filing.</p><div class="grid2">${field('From', 'from', todayISO(), { type: 'date' })}${field('To', 'to', todayISO(), { type: 'date' })}</div>`, validate: x => (!val(x, 'from') || !val(x, 'to') ? 'Pick both dates.' : val(x, 'to') < val(x, 'from') ? 'The end date is before the start.' : '') });
  if (!f) return;
  const from = val(f, 'from'), to = val(f, 'to');
  const ids = [...new Set(S.visits.filter(v => v.date >= from && v.date <= to).map(v => v.patientId))];
  const list = ids.map(patient).filter(Boolean).sort((a, b) => a.name.localeCompare(b.name));
  if (!list.length) return toast(`No visits between ${fmtDate(from)} and ${fmtDate(to)}.`, 5000);
  const parts = [];
  for (const p of list) parts.push(`<div class="page">${await recordSheetHTML(p)}</div>`);
  doPrint(parts.join(''), `Records seen ${from} to ${to}`);
}

// Every patient on one sheet for Excel: contact details, consents and visits.
function exportPatientsCSV() {
  const cf = fieldsFor('patients', { role: S.me.role });
  const rows = [['Patient number', 'Apex HN', 'Name', 'Name in Thai', 'Nickname', 'Date of birth', 'Sex', 'Nationality', 'ID or passport', 'Mobile', 'LINE', 'Email', 'Address', 'Tags', 'Came from', 'Allergies', 'PDPA notice signed', 'Photos', 'Marketing photos', 'First visit', 'Last visit', 'Visits', 'Follow-up', ...cf.map(f => f.label)]];
  for (const p of [...S.patients].sort((a, b) => (a.no || '').localeCompare(b.no || ''))) {
    const vs = visitsOf(p.id);
    rows.push([p.no, p.hn, p.name, p.nameTh, p.goesBy, p.dob, p.sex, p.nationality, p.idNo, p.phone, p.line, p.email, p.address, (p.tags || []).join('; '), p.source, (p.allergies || []).map(a => a.what).join('; ') || (p.nka ? 'None known' : ''), p.privacyConsentAt ? isoOf(new Date(p.privacyConsentAt)) : '', p.photoConsent === 'yes' ? 'Agreed' : p.photoConsent === 'no' ? 'Declined' : '', p.marketingConsent === 'yes' ? 'Agreed' : '',
      vs.length ? vs[vs.length - 1].date : '', vs.length ? vs[0].date : '', vs.length, followUpOf(p.id), ...cf.map(f => customValueText(f, (p.custom || {})[f.id]))]);
  }
  saveCSV(rows, `Patients ${todayISO()}.csv`);
}
// One patient's treatments for Excel: a row for each product used, or for the visit.
function exportPatientCSV(p) {
  const rows = [['Date', 'Visit', 'Type', 'Doctor', 'Services', 'Product', 'Amount', 'Unit', 'Lot', 'Area', 'Medicines given', 'Complications']];
  for (const v of [...visitsOf(p.id)].reverse()) {
    const base = [v.date, v.no, v.type, userName(v.doctorId), (v.services || []).map(s => (service(s.serviceId) || {}).name || s.name).join('; ')];
    const meds = (v.meds || []).map(m => [m.drug, m.dose, m.unit, m.route].filter(Boolean).join(' ')).join('; ');
    const inc = (S.incidents || []).filter(x => x.visitId === v.id).map(x => `${x.type} (${x.outcome})`).join('; ');
    const tr = v.treatments || [];
    if (!tr.length) rows.push([...base, '', '', '', '', '', meds, inc]);
    tr.forEach((t, i) => rows.push([...base, t.product, t.amount, t.unit, t.lot || (t.lotId && lot(t.lotId) ? lot(t.lotId).lot : ''), t.area || '', i ? '' : meds, i ? '' : inc]));
  }
  saveCSV(rows, `${safeName(p.no || '')} ${safeName(p.name)} treatments.csv`);
}
// The patient's whole record as a file, for a backup outside the branch PC.
function exportPatientJSON(p) {
  const visits = visitsOf(p.id);
  const vids = new Set(visits.map(v => v.id));
  const data = { app: 'apex-pms', version: S.version || APP_VERSION, exported: new Date().toISOString(), by: S.me.name, clinic: S.clinic.name, branch: S.clinic.branchName || '', branchCode: S.clinic.branchCode || '',
    patient: p, customFields: fieldsFor('patients', { retired: true }).filter(f => p.custom && p.custom[f.id] !== undefined).map(f => ({ id: f.id, label: f.label, section: f.section, type: f.type, unit: f.unit || '', value: p.custom[f.id] })), visits, charts: S.charts.filter(c => vids.has(c.visitId)), photos: S.photos.filter(x => x.patientId === p.id).map(x => ({ ...x, file: fileURL(x.fileId) })),
    skinAnalyses: S.analyses.filter(x => x.patientId === p.id), previews: S.previews.filter(x => x.patientId === p.id), transcripts: S.transcripts.filter(x => x.patientId === p.id), complications: S.incidents.filter(x => x.patientId === p.id) };
  saveBlob(new Blob([JSON.stringify(data, null, 1)], { type: 'application/json' }), `${safeName(p.no || '')} ${safeName(p.name)}.json`);
}

// ---------- form ----------
function renderPatientForm(id, q = {}) {
  const p = id ? patient(id) : { name: q.name || '', screen: {}, allergies: [], meds: [], conditions: [], surgeries: [], contacts: [], tags: [], custom: {} };
  if (id && !p) return go('#/patients');
  const clin = can('clinical');
  const sc = p.screen || {};
  const cf = section => customFieldsHTML('patients', p.custom, section);
  const extraSections = customSections('patients', p.custom);
  $app.innerHTML = shell('patients', `
    <a class="crumb" href="${id ? '#/patient/' + id : '#/patients'}">${I.back}${id ? esc(p.name) : 'Patients'}</a>
    <div class="page-head"><h1>${id ? 'Edit record' : 'New patient'}</h1></div>
    <form id="pf" novalidate>
      <div class="card"><h2 class="card-title">Patient</h2>
        <div class="grid3">${field('Name as on ID or passport', 'name', p.name, { ph: 'Pimchanok Wongsawat' })}${field('Name in Thai', 'nameTh', p.nameTh, { ph: 'พิมพ์ชนก วงศ์สวัสดิ์' })}${field('Nickname', 'goesBy', p.goesBy, { ph: 'Pim' })}</div>
        <div class="grid4">${field('Apex HN', 'hn', p.hn, { ph: '6512345', hint: 'The number in Apex\'s own EMR.' })}${field('Date of birth', 'dob', p.dob, { type: 'date' })}${field('Sex', 'sex', p.sex, { type: 'select', options: ['Female', 'Male'] })}${field('Skin type', 'skin', p.skin, { type: 'select', options: ['I', 'II', 'III', 'IV', 'V', 'VI'].map(x => [x, 'Fitzpatrick ' + x]) })}</div>
        <div class="grid4">${field('Nationality', 'nationality', p.nationality || (id ? '' : 'Thai'), { ph: 'Thai', attrs: 'list="dl-nat"' })}${field('ID', 'idType', p.idType || (id ? '' : 'Thai ID card'), { type: 'select', options: ['Thai ID card', 'Passport', 'Other'] })}${field('ID or passport number', 'idNo', p.idNo, { ph: '1 1037 01234 56 7' })}${field('Language on the tablet', 'plang', p.plang || 'th', { type: 'select', options: PATIENT_LANGS, blank: false, hint: 'For check-in, consent forms and the patient view.' })}</div>
        <datalist id="dl-nat">${['Thai', 'Chinese', 'Japanese', 'Korean', 'American', 'British', 'Australian', 'Myanmar', 'Lao', 'Cambodian', 'Vietnamese', 'Indian', 'Filipino', 'Russian', 'German', 'French', 'Emirati', 'Saudi'].map(n => `<option value="${n}">`).join('')}</datalist>
        <div class="grid4">${field('Mobile', 'phone', p.phone, { type: 'tel', ph: '081 234 5678' })}${field('LINE ID', 'line', p.line, { ph: 'pim.w' })}${field('Email', 'email', p.email, { type: 'email', ph: 'pim.w@gmail.com' })}${field('Occupation', 'occupation', p.occupation, { ph: 'Flight attendant' })}</div>
        ${field('Address', 'address', p.address, { ph: '99/12 Sukhumvit 24, Khlong Tan, Khlong Toei, Bangkok 10110' })}
        <div class="grid2">${field('Found Apex through', 'source', p.source, { type: 'select', options: SOURCES })}${field('Referred by', 'referredBy', p.referredBy, { ph: 'Dr. Somchai at Siam branch' })}</div>
        <div class="field"><span class="label">Tags</span><div class="checks tight">${[...new Set([...(S.tags.length ? tagList().map(t => t.name) : STARTER_TAGS.map(t => t[0])), ...(p.tags || [])])].map(t => `<label class="check"><input type="checkbox" name="tag_${esc(t)}" data-tag="${esc(t)}" ${(p.tags || []).includes(t) ? 'checked' : ''}><span><span class="tag-dot" style="background:${esc(tagColor(t) || '#B2AFA7')}"></span>${esc(t)}${tagList().some(x => x.name === t) || !S.tags.length ? '' : ' <span class="meta">(retired)</span>'}</span></label>`).join('')}</div></div>
        ${cf('details')}
        ${clin ? `<div class="grid2">${field('Clinical photos', 'photoConsent', p.photoConsent, { type: 'select', options: [['yes', 'Agreed to photos'], ['no', 'Declined photos']], hint: 'Charts use the face drawing when photos are declined.' })}${field('Photos in marketing', 'marketingConsent', p.marketingConsent, { type: 'select', options: [['yes', 'Agreed'], ['no', 'Declined']], hint: 'Signing the marketing consent form sets this.' })}</div>` : ''}
      </div>
      <div class="card"><h2 class="card-title">Emergency contacts</h2>
        ${rowsBlock('contacts', [{ k: 'name', label: 'Name', ph: 'Somsak Wongsawat' }, { k: 'relation', label: 'Relation', ph: 'Husband', w: '0.7fr' }, { k: 'phone', label: 'Phone', ph: '089 876 5432', type: 'tel' }], p.contacts, 'Add contact')}
      </div>
      ${clin ? `
      <div class="card"><h2 class="card-title">Allergies</h2>
        ${rowsBlock('allergies', [{ k: 'what', label: 'Allergic to', ph: 'Lidocaine' }, { k: 'reaction', label: 'Reaction', ph: 'Hives and lip swelling' }, { k: 'severity', label: 'Severity', type: 'select', options: ['Mild', 'Moderate', 'Severe', 'Anaphylaxis'], w: '0.6fr' }], p.allergies, 'Add allergy')}
        ${field('No known allergies', 'nka', p.nka, { type: 'check' })}
      </div>
      <div class="card"><h2 class="card-title">Medicines and supplements</h2>
        ${rowsBlock('meds', [{ k: 'name', label: 'Medicine', ph: 'Losartan' }, { k: 'dose', label: 'Dose', ph: '50 mg', w: '0.6fr' }, { k: 'freq', label: 'How often', ph: 'Once a day' }, { k: 'reason', label: 'Taken for', ph: 'High blood pressure' }], p.meds, 'Add medicine')}
      </div>
      <div class="card"><h2 class="card-title">Conditions, surgeries and past treatments</h2>
        ${rowsBlock('conditions', [{ k: 'name', label: 'Condition', ph: 'Hypothyroidism' }, { k: 'year', label: 'Since', ph: '2019', w: '0.4fr' }, { k: 'notes', label: 'Notes', ph: 'On levothyroxine' }], p.conditions, 'Add condition')}
        <div style="height:12px"></div>
        ${rowsBlock('surgeries', [{ k: 'what', label: 'Surgery or aesthetic treatment', ph: 'Rhinoplasty with silicone implant' }, { k: 'year', label: 'Year', ph: '2021', w: '0.4fr' }, { k: 'where', label: 'Where', ph: 'Bangkok' }], p.surgeries, 'Add surgery or treatment')}
        ${cf('medical') ? `<div style="height:12px"></div>${cf('medical')}` : ''}
      </div>
      <div class="card"><h2 class="card-title">Before treatment</h2><p class="meta">Tick everything that applies. Ticked items show on the patient's page, every visit and the day sheet.</p>
        <div class="checks">${SCREEN.map(s => `<label class="check"><input type="checkbox" name="sc_${s.k}" ${sc[s.k] ? 'checked' : ''}><span>${esc(s.label)}</span></label>`).join('')}</div>
        <div class="grid3" style="margin-top:8px">${field('Smoking', 'smoking', p.smoking, { ph: '5 sticks a day' })}${field('Alcohol', 'alcohol', p.alcohol, { ph: 'Weekends only' })}${field('Sun exposure', 'sun', p.sun, { ph: 'Outdoor work, uses SPF daily' })}</div>
        ${cf('lifestyle')}
      </div>
      ${cf('aesthetic') ? `<div class="card"><h2 class="card-title">Aesthetic profile</h2>${cf('aesthetic')}</div>` : ''}
      <div class="card">${field('Notes', 'notes', p.notes, { type: 'textarea', ph: 'Prefers afternoon appointments. Anxious with needles.' })}</div>` : ''}
      ${extraSections.map(sec => `<div class="card"><h2 class="card-title">${esc(sec)}</h2>${cf(sec)}</div>`).join('')}
      <p class="form-err" data-err></p>
      <div class="row end sticky-actions"><a class="btn secondary" href="${id ? '#/patient/' + id : '#/patients'}">Cancel</a><button class="btn primary">${id ? 'Save' : 'Add patient'}</button></div>
    </form>`);
  wireShell();
  const form = document.getElementById('pf');
  wireRows(form);
  form.onsubmit = async e => {
    e.preventDefault();
    const err = m => { form.querySelector('[data-err]').textContent = m; };
    if (!val(form, 'name')) { err("Enter the patient's name."); form.querySelector('[name=name]').focus(); return; }
    const hn = val(form, 'hn').toUpperCase();
    if (hn && S.patients.some(x => String(x.hn || '').toUpperCase() === hn && x.id !== p.id)) return err(`HN ${hn} belongs to another patient.`);
    const dupe = !id && S.patients.find(x => x.name.trim().toLowerCase() === val(form, 'name').toLowerCase() && (!val(form, 'dob') || !x.dob || x.dob === val(form, 'dob')));
    if (dupe && form.dataset.dupeOk !== '1') { form.dataset.dupeOk = '1'; return err(`${dupe.name} (${dupe.no}) is already on record. Press Add patient again to add a second record anyway.`); }
    const miss = customMissing(form, 'patients'); if (miss) { err(miss); return; }
    const rec = { ...p, id: p.id || uid() };
    for (const k of ['name', 'nameTh', 'goesBy', 'hn', 'dob', 'sex', 'skin', 'nationality', 'idType', 'idNo', 'plang', 'phone', 'line', 'email', 'occupation', 'address', 'source', 'referredBy']) rec[k] = val(form, k);
    rec.hn = hn;
    rec.tags = [...form.querySelectorAll('[data-tag]')].filter(x => x.checked).map(x => x.dataset.tag);
    rec.custom = readCustomFields(form, 'patients', p.custom);
    rec.contacts = readRows(form, 'contacts');
    if (clin) {
      rec.allergies = readRows(form, 'allergies');
      rec.nka = val(form, 'nka') && !rec.allergies.length;
      rec.photoConsent = val(form, 'photoConsent'); rec.marketingConsent = val(form, 'marketingConsent');
      rec.meds = readRows(form, 'meds');
      rec.conditions = readRows(form, 'conditions');
      rec.surgeries = readRows(form, 'surgeries');
      rec.screen = Object.fromEntries(SCREEN.map(s => [s.k, val(form, 'sc_' + s.k)]).filter(x => x[1]));
      for (const k of ['smoking', 'alcohol', 'sun', 'notes']) rec[k] = val(form, k);
    }
    try {
      const saved = await save('patients', rec, { action: id ? 'Record edited' : 'Patient added' });
      delete form.dataset.dirty;
      go(q.back ? decodeURIComponent(q.back) : '#/patient/' + saved.id);
    } catch (ex) { err(ex.message); }
  };
}

// ---------- record ----------
// Who opened this record, newest first. Every doctor sees it, since they cover each other's patients.
const SEEN_WHAT = { record: 'Opened the record', visit: 'Opened a visit', chart: 'Opened a chart', photos: 'Looked at the photos', print: 'Printed the record' };
function accessHTML(rows) {
  const people = [...groupBy(rows, r => r.byName || r.by).entries()].map(([n, l]) => `${esc(n)} ${l.length}`).join(' · ');
  return `<h3 class="section-title">Opened by</h3><p class="meta">${rows.length ? people : 'Nobody yet.'}</p>${rows.length ? `<div class="card flush scroll-x"><table class="t"><tr><th>When</th><th>Who</th><th>What</th><th class="ph-hide">Device</th></tr>${rows.slice(0, 100).map(r => `<tr><td>${fmtStamp(r.at)}</td><td>${esc(r.byName)} <span class="meta">${esc((ROLES[r.role] || {}).label || '')}</span></td><td>${esc(SEEN_WHAT[r.what] || r.what)}</td><td class="meta ph-hide">${esc(r.device || '')}</td></tr>`).join('')}</table></div>${rows.length > 100 ? `<p class="meta">The last 100 of ${rows.length}.</p>` : ''}` : ''}`;
}
// The doctor who saw the patient most. Any doctor can open the record when that one is away,
// and the History tab shows who did.
function usualDoctor(visits) {
  const n = new Map();
  for (const v of visits) if (v.doctorId) n.set(v.doctorId, (n.get(v.doctorId) || 0) + 1);
  const top = [...n.entries()].sort((a, b) => b[1] - a[1])[0];
  return top ? userName(top[0]) : '';
}
function alertChips(p) {
  const out = [];
  for (const a of p.allergies || []) out.push(`<span class="chip bad">${I.alert}Allergy: ${esc(a.what)}${a.severity ? ' (' + esc(a.severity.toLowerCase()) + ')' : ''}</span>`);
  if (!(p.allergies || []).length) out.push(p.nka ? chip('No known allergies', 'ok') : chip('Allergies not recorded', 'warn'));
  for (const s of SCREEN) if (p.screen && p.screen[s.k]) out.push(chip(s.label, 'warn'));
  const openInc = (S.incidents || []).filter(x => x.patientId === p.id && x.outcome !== 'Resolved');
  if (openInc.length) out.push(`<span class="chip bad">${I.alert}Open complication: ${esc(openInc[0].type.toLowerCase())}</span>`);
  if (can('clinical') && !p.privacyConsentAt) out.push(chip('PDPA notice not signed', 'warn'));
  if (p.photoConsent === 'no') out.push(chip('Declined photos'));
  if (p.marketingConsent === 'yes') out.push(chip('Marketing photos allowed', 'info'));
  return `<div class="chips alerts">${out.join('')}</div>`;
}

function renderPatient(id, tab) {
  const p = patient(id);
  if (!p) return go('#/patients');
  const clin = can('clinical');
  const visits = visitsOf(id);
  const tabs = clin ? [['summary', 'Summary'], ['record', 'Details']] : [['record', 'Record']];
  if (clin) tabs.push(['visits', 'Visits', visits.length || ''], ['photos', 'Photos', S.photos.filter(x => x.patientId === id).length || ''], ...(USE_3D ? [['head', '3D head', headsOf(id).length || '']] : []),
    ['settings', 'Settings log', sum(visits, v => (v.settings || []).length) || ''], ['meds', 'Medicines given', sum(visits, v => (v.meds || []).length) || '']);
  if (clin) tabs.push(['history', 'History']);
  if (!tabs.some(t => t[0] === tab)) tab = tabs[0][0];
  let body = '';
  if (tab === 'summary') body = patientSummaryTab(p, visits);
  else if (tab === 'record') body = patientRecord(p, clin);
  else if (tab === 'visits') body = visits.length ? `<div class="list">${visits.map(v => visitRow(v)).join('')}</div>` : empty('No visits yet.', 'Start a visit to record notes, photos and treatment.');
  else if (tab === 'photos') body = patientPhotos(p);
  else if (tab === 'head') body = patientHeadTab(p);
  else if (tab === 'settings') body = patientSettingsLog(p);
  else if (tab === 'meds') body = patientMedsLog(p);
  else if (tab === 'history') body = `<div id="hist"><p class="meta">Loading.</p></div>`;

  const fu = followUpOf(id);
  $app.innerHTML = shell('patients', `
    <a class="crumb" href="#/patients">${I.back}Patients</a>
    <div class="phead">${avatar(p, 'lg')}<div class="grow"><h1>${esc(p.name)}${p.goesBy ? ` <span class="meta">(${esc(p.goesBy)})</span>` : ''}${pendingChip(p) ? ' ' + pendingChip(p) : ''}</h1>${p.nameTh && p.nameTh !== p.name ? `<div lang="th">${esc(p.nameTh)}</div>` : ''}<div class="meta">${esc(patientSummary(p))}${(p.tags || []).map(t => ' ' + tagChip(t)).join('')}</div></div>
      ${p.no ? `<div class="pno" title="Scan to open this record"><span class="qr">${qrSVG(clinicURL('/p/' + p.no), 64)}</span><b>${esc(p.no)}</b></div>` : '<span class="meta">Number on sync</span>'}
      <div class="row wrap-end">
        <a class="btn secondary" href="#/patient/${id}/edit">Edit record</a>
        <button class="btn secondary" data-act="pcard">Patient card</button>
        <button class="btn secondary" data-act="print">${I.print}Print</button>
        ${clin ? showPatientButtonHTML(id) + sendButtonHTML('#/patient/' + id, p.name + '\'s record') : ''}
        ${clin ? `<button class="btn primary" data-act="visit">${I.plus}New visit</button>` : ''}</div></div>
    ${alertChips(p)}
    <div class="facts">
      <div><span class="meta">Apex HN</span><b>${p.hn ? esc(p.hn) : 'Not entered'}</b></div>
      <div><span class="meta">Last visit</span><b>${visits[0] ? fmtDate(visits[0].date) : 'None'}</b></div>
      <div><span class="meta">Visits</span><b>${visits.length}</b></div>
      <div><span class="meta">Usual doctor</span><b>${esc(usualDoctor(visits) || 'None yet')}</b></div>
      <div><span class="meta">Follow-up</span><b>${fu ? fmtDate(fu) : 'None set'}</b></div>
    </div>
    ${tabsNav(tabs, tab, `#/patient/${id}/`)}
    ${body}`);
  wireShell();
  const on = (sel, fn) => document.querySelectorAll(sel).forEach(b => b.onclick = fn);
  on('[data-act="visit"]', () => newVisit(id));
  on('[data-act="pcard"]', () => patientCardSheet(patient(id)));
  on('[data-act="print"]', async () => {
    const buttons = clin ? [{ label: 'Full record', value: 'record', kind: 'primary' }, { label: 'Treatments for Excel', value: 'csv' }, { label: 'Export as a file', value: 'json' }] : [{ label: 'Full record', value: 'record', kind: 'primary' }];
    const r = await ask({ title: 'Print', body: 'The full record has every visit, chart and consent, with the patient QR on each page.', buttons: [{ label: 'Cancel', value: null }, ...buttons] });
    if (r === 'record') printRecord(p); else if (r === 'json') exportPatientJSON(p); else if (r === 'csv') { markSeen(p.id, 'print'); exportPatientCSV(p); }
  });
  wireIncidents();
  markSeen(p.id, tab === 'photos' ? 'photos' : 'record');
  markRecent(p.id);
  if (tab === 'photos') wirePatientPhotos(p);
  if (tab === 'head') wirePatientHeadTab(p);
  if (tab === 'history') historyFor(id).then(async rows => {
    const el = document.getElementById('hist'); if (!el) return;
    let opened = null;
    if (can('clinical')) { try { opened = await api('/api/access?patientId=' + encodeURIComponent(id)); } catch (e) { opened = null; } }
    el.innerHTML = (opened ? accessHTML(opened) : '') + `<h3 class="section-title">Changes</h3>` + historyHTML(rows);
  }).catch(fail);
}

function patientRecord(p, clin) {
  const list = (arr, fmt, emptyText) => (arr && arr.length ? `<ul class="plain">${arr.map(x => `<li>${fmt(x)}</li>`).join('')}</ul>` : `<span class="muted">${emptyText}</span>`);
  const kv = pairs => `<dl class="kv">${pairs.filter(x => x[1]).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`;
  const lastV = visitsOf(p.id)[0];
  const cp = section => customPairs('patients', p.custom, section);
  const extraSections = customSections('patients', p.custom);
  return `<div class="cols">
    <div class="card"><h2 class="card-title">Details</h2>${kv([['Patient number', p.no], ['Apex HN', p.hn], ['Name in Thai', p.nameTh], ['PDPA notice', p.privacyConsentAt ? 'Signed ' + fmtStamp(p.privacyConsentAt) : ''], ['Date of birth', p.dob ? `${fmtDate(p.dob)} (${ageOf(p.dob)} years)` : ''], ['Sex', p.sex], ['Nationality', p.nationality], [p.idType || 'ID', p.idNo], ['Language on the tablet', (PATIENT_LANGS.find(x => x[0] === p.plang) || [])[1] || ''], ['Skin type', p.skin ? 'Fitzpatrick ' + p.skin : ''], ['Mobile', p.phone], ['LINE ID', p.line], ['Email', p.email], ['Address', p.address], ['Occupation', p.occupation], ['Found Apex through', p.source], ['Referred by', p.referredBy], ['On record since', p.created ? fmtDate(isoOf(new Date(p.created))) : ''], ...cp('details')])}</div>
    <div class="card"><h2 class="card-title">Emergency contacts</h2>${list(p.contacts, c => `${esc(c.name)}${c.relation ? ', ' + esc(c.relation) : ''}${c.phone ? ` · <a href="tel:${esc(c.phone)}">${esc(c.phone)}</a>` : ''}`, 'None recorded.')}
      ${p.notes ? `<h3 class="sub-head">Notes</h3><p class="pre">${esc(p.notes)}</p>` : ''}</div>
    ${clin ? `
    ${lastV ? `<div class="card"><h2 class="card-title">Last treatment</h2><p><a href="#/visit/${lastV.id}">${fmtDate(lastV.date)} · ${esc(lastV.type || 'Visit')}</a></p><p>${visitSummaryHTML(lastV)}</p></div>` : ''}
    <div class="card"><h2 class="card-title">Medicines</h2>${list(p.meds, m => `<b>${esc(m.name)}</b> ${esc(m.dose || '')}${m.freq ? ', ' + esc(m.freq) : ''}${m.reason ? ` <span class="meta">for ${esc(m.reason)}</span>` : ''}`, 'None recorded.')}</div>
    <div class="card"><h2 class="card-title">Conditions</h2>${list(p.conditions, c => `${esc(c.name)}${c.year ? ` <span class="meta">since ${esc(c.year)}</span>` : ''}${c.notes ? ', ' + esc(c.notes) : ''}`, 'None recorded.')}${cp('medical').length ? `<h3 class="sub-head">Medical history</h3>${customKV(cp('medical'))}` : ''}</div>
    <div class="card"><h2 class="card-title">Surgeries and past treatments</h2>${list(p.surgeries, s => `${esc(s.what)}${s.year ? ' · ' + esc(s.year) : ''}${s.where ? ' · ' + esc(s.where) : ''}`, 'None recorded.')}</div>
    <div class="card"><h2 class="card-title">Lifestyle</h2>${p.smoking || p.alcohol || p.sun || cp('lifestyle').length ? kv([['Smoking', p.smoking], ['Alcohol', p.alcohol], ['Sun exposure', p.sun], ...cp('lifestyle')]) : '<span class="muted">None recorded.</span>'}${p.importedFrom ? `<p class="meta" style="margin-top:10px">${esc(p.importedFrom)}</p>` : ''}</div>
    ${cp('aesthetic').length ? `<div class="card"><h2 class="card-title">Aesthetic profile</h2>${customKV(cp('aesthetic'))}</div>` : ''}
    ${patientIncidentsCard(p)}` : ''}
    ${extraSections.filter(sec => cp(sec).length).map(sec => `<div class="card"><h2 class="card-title">${esc(sec)}</h2>${customKV(cp(sec))}</div>`).join('')}
  </div>`;
}

function visitSummary(v) {
  const lines = (v.treatments || []).filter(t => t.source !== 'supply' && t.source !== 'med').map(t => matText(t, t.product || (KINDS[t.kind] || {}).short || ''));
  const sv = (v.services || []).map(x => (service(x.serviceId) || {}).name || x.name).filter(Boolean);
  return [...sv, ...lines].join(', ') || v.complaint || 'No treatment recorded';
}
// On the page: what was done, as written. The complaint and product names stay in English.
function visitSummaryHTML(v) {
  const t = visitSummary(v);
  return t === 'No treatment recorded' ? t : `<span translate="no">${esc(t)}</span>`;
}
// ---------- summary tab ----------
// Every recent visit on one screen, in short: what was done, what was used, the note, and
// the chart and photos, so a doctor sees the patient's story before opening anything.
function patientSummaryTab(p, visits) {
  const up = typeof patientBookingsHTML === 'function' ? patientBookingsHTML(p) : '';
  if (!visits.length) return up + empty('No visits yet.', 'Start a visit to record notes, photos and treatment.');
  const shown = visits.slice(0, 12);
  return `${up}<div class="sum-list">${shown.map(summaryRow).join('')}</div>${visits.length > shown.length ? `<p><a href="#/patient/${p.id}/visits">All ${visits.length} visits</a></p>` : ''}`;
}
function summaryRow(v) {
  const done = (v.services || []).map(s => (service(s.serviceId) || s).name).filter(Boolean).join(', ');
  const used = typeof materialsLine === 'function' ? materialsLine(v) : '';
  const note = [v.assessment, v.plan, v.complaint].find(x => x && x.trim()) || '';
  const short = note.length > 160 ? note.slice(0, 157).replace(/\s+\S*$/, '') + '…' : note;
  const c = chartsOfVisit(v.id).find(x => (x.marks || []).length);
  const img = !c ? '' : c.base.type === 'photo' ? thumbURL(c.base.photoId) : c.base.type === 'head' ? chartImageFor(c) : '';
  const photos = S.photos.filter(x => x.visitId === v.id && x.fileId).slice(0, 2);
  return `<a class="sum-row" href="#/visit/${v.id}">
    <div class="sum-when"><b>${fmtDate(v.date)}</b><span class="m">${esc(v.type || '')}</span><span class="m">${esc(userName(v.doctorId || v.createdBy))}</span>${v.signedAt ? chip('Signed', 'ok') : chip('Not signed')}</div>
    <div class="sum-what">
      ${done ? `<div><span class="k">Done</span> ${esc(done)}</div>` : ''}
      ${used ? `<div><span class="k">Used</span> <b>${esc(used)}</b></div>` : ''}
      ${short ? `<div class="sum-note" translate="no">${esc(short)}</div>` : ''}
      ${v.followUp ? `<div class="m">Follow-up ${fmtDate(v.followUp)}${v.followReason ? ' · ' + esc(v.followReason) : ''}</div>` : ''}
      ${!done && !used && !short ? '<div class="m">Nothing written yet.</div>' : ''}
    </div>
    <div class="sum-pics">${c ? chartSVG(c, img, 'class="sum-chart"') : ''}${photos.map(ph => `<img src="${thumbURL(ph.id)}" alt="${esc(ph.view || '')}">`).join('')}</div></a>`;
}

function visitRow(v) {
  return `<a class="li" href="#/visit/${v.id}"><div class="date-col"><b>${fmtDate(v.date)}</b><div class="m">${esc(v.type || '')}</div></div>
    <div class="grow"><div class="t medium">${visitSummaryHTML(v)}</div><div class="m">${esc(userName(v.doctorId || v.createdBy))}</div></div>
    <div class="chips">${v.signedAt ? chip('Signed', 'ok') : chip('Not signed')}</div></a>`;
}

// ---------- photos tab ----------
function patientPhotos(p) {
  const all = photosOf(p.id);
  if (!all.length) return empty('No photos yet.', 'Photos are added on a visit page.');
  const byVisit = new Map();
  for (const ph of all) { const k = ph.visitId || ''; if (!byVisit.has(k)) byVisit.set(k, []); byVisit.get(k).push(ph); }
  for (const list of byVisit.values()) list.sort((a, b) => PHOTO_STAGES.indexOf(a.stage) - PHOTO_STAGES.indexOf(b.stage) || PHOTO_VIEWS.indexOf(a.view) - PHOTO_VIEWS.indexOf(b.view));
  const opts = all.map(ph => `<option value="${ph.id}">${fmtDate(ph.date)} · ${ph.area ? esc(ph.area) + ' · ' : ''}${esc(ph.view)} · ${esc(ph.stage || '')}</option>`).join('');
  const fronts = all.filter(x => x.view === 'Front');
  let a = (fronts[fronts.length - 1] || all[all.length - 1]).id, b = (fronts[0] || all[0]).id;
  // Treated areas, each from its baseline to the latest follow-up.
  const byArea = groupBy(all.filter(x => x.area), x => areaKey(x.area));
  const areaRows = [...byArea.values()].map(list => {
    list.sort((x, y) => photoVisitDate(x).localeCompare(photoVisitDate(y)) || (x.created || 0) - (y.created || 0));
    const visitsOrder = [...new Set(list.map(x => x.visitId))];
    return { name: list[0].area, list, visitsOrder, base: list[0], latest: list[list.length - 1], last: photoVisitDate(list[list.length - 1]) };
  }).sort((x, y) => y.last.localeCompare(x.last));
  if (areaRows.length && areaRows[0].visitsOrder.length > 1) { a = areaRows[0].base.id; b = areaRows[0].latest.id; }
  const areaHTML = areaRows.length ? `<div class="card gap-b"><h2 class="card-title">Treated areas</h2>${areaRows.map(r => `<div class="area-row">
      <div class="row between"><b>${esc(r.name)}</b><span class="meta">${r.visitsOrder.length > 1 ? `Baseline ${fmtDate(photoVisitDate(r.base))} · ${plural(r.visitsOrder.length - 1, 'follow-up')}` : `Baseline ${fmtDate(photoVisitDate(r.base))}`}</span>${r.visitsOrder.length > 1 ? `<button type="button" class="btn secondary small" data-cmp-area="${r.base.id}|${r.latest.id}">Compare baseline and latest</button>` : ''}</div>
      <div class="area-strip">${r.list.map(ph => { const n = r.visitsOrder.indexOf(ph.visitId); return `<div class="ph"><img loading="lazy" src="${thumbURL(ph.id)}" alt="" data-view-photo="${ph.id}"><div class="cap"><span>${n ? 'Follow-up ' + n : 'Baseline'}</span><span class="meta">${fmtDay(photoVisitDate(ph))}</span></div></div>`; }).join('')}</div></div>`).join('')}</div>` : '';
  return `${areaHTML}<div class="card gap-b"><div class="card-head"><h2>Compare</h2><div class="seg" role="group"><button data-cmode="side" aria-pressed="true">Side by side</button><button data-cmode="slider" aria-pressed="false">Slider</button></div></div>
      <div class="grid2"><label class="field"><span class="label">Before or baseline</span><select data-cmp="a">${opts}</select></label><label class="field"><span class="label">After</span><select data-cmp="b">${opts}</select></label></div>
      <div class="compare" data-cmpbox><img data-cmp-img="a" alt="" src="${fullURL(a)}"><img data-cmp-img="b" alt="" src="${fullURL(b)}"></div>
      ${compareActionsHTML(p)}
      <span hidden data-cmp-default="${a}|${b}"></span></div>
    ${[...byVisit.entries()].map(([vid, list]) => { const v = visit(vid); return `<h3 class="section-title">${v ? `<a href="#/visit/${v.id}">${fmtDate(v.date)} · ${esc(v.type || 'Visit')}</a>` : 'No visit'}</h3>
      <div class="photo-grid">${list.map(ph => `<div class="ph"><img loading="lazy" src="${thumbURL(ph.id)}" alt="" data-view-photo="${ph.id}"><div class="cap"><span>${esc(ph.area || ph.view)}</span><span class="meta">${esc(ph.stage || '')}</span></div></div>`).join('')}</div>`; }).join('')}`;
}
function wirePatientPhotos(p) {
  const ids = photosOf(p.id).map(x => x.id);
  document.querySelectorAll('[data-view-photo]').forEach(img => img.onclick = () => photoViewer(ids, img.dataset.viewPhoto));
  const def = document.querySelector('[data-cmp-default]');
  if (!def) return;
  const [a, b] = def.dataset.cmpDefault.split('|');
  const sa = document.querySelector('[data-cmp="a"]'), sb = document.querySelector('[data-cmp="b"]');
  sa.value = a; sb.value = b;
  const box = document.querySelector('[data-cmpbox]');
  let mode = 'side';
  const draw = () => {
    const ua = fullURL(sa.value), ub = fullURL(sb.value);
    if (mode === 'side') box.className = 'compare', box.innerHTML = `<img alt="Before" src="${ua}"><img alt="After" src="${ub}">`;
    else {
      box.className = 'compare-slider';
      box.innerHTML = `<img alt="Before" src="${ua}"><div class="after" style="clip-path:inset(0 0 0 50%)"><img alt="After" src="${ub}"></div><input type="range" min="0" max="100" value="50" aria-label="Divider">`;
      const r = box.querySelector('input'), af = box.querySelector('.after');
      r.oninput = () => { af.style.clipPath = `inset(0 0 0 ${r.value}%)`; };
    }
  };
  sa.onchange = draw; sb.onchange = draw;
  wireCompareActions(p);
  document.querySelectorAll('[data-cmp-area]').forEach(btn => btn.onclick = () => { const [x, y] = btn.dataset.cmpArea.split('|'); sa.value = x; sb.value = y; draw(); box.closest('.card').scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  document.querySelectorAll('[data-cmode]').forEach(btn => btn.onclick = () => { mode = btn.dataset.cmode; document.querySelectorAll('[data-cmode]').forEach(x => x.setAttribute('aria-pressed', x === btn)); draw(); });
}

function photoViewer(ids, start) {
  let i = Math.max(0, ids.indexOf(start));
  const el = document.createElement('div');
  el.className = 'viewer';
  const key = e => {
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowRight' && ids.length > 1) { i = (i + 1) % ids.length; show(); }
    if (e.key === 'ArrowLeft' && ids.length > 1) { i = (i - 1 + ids.length) % ids.length; show(); }
  };
  const close = () => { el.remove(); document.removeEventListener('keydown', key); };
  const show = () => {
    const ph = photoMeta(ids[i]);
    el.innerHTML = `<div class="vbar"><span>${esc(ph.view)} · ${esc(ph.stage || '')} · ${fmtDate(ph.date)}</span><span class="spacer"></span>
      ${ids.length > 1 ? `<button data-v="prev" aria-label="Previous">‹</button><span>${i + 1} of ${ids.length}</span><button data-v="next" aria-label="Next">›</button>` : ''}
      <button data-v="close">Close</button></div><div class="stage"><img src="${fullURL(ph.id)}" alt=""></div>`;
    el.querySelectorAll('[data-v]').forEach(b => b.onclick = () => {
      if (b.dataset.v === 'close') close();
      else { i = (i + (b.dataset.v === 'next' ? 1 : -1) + ids.length) % ids.length; show(); }
    });
  };
  document.addEventListener('keydown', key);
  document.body.appendChild(el);
  show();
}

// ---------- patient card scanner ----------
// Reads the QR on a patient card, or the Apex HN barcode, with the tablet camera, and
// opens that patient. Needs the secure address on a tablet, since the camera does.
async function scanPatientCard() {
  let stream = null, stop = false, detector = null;
  if ('BarcodeDetector' in window) { try { detector = new BarcodeDetector({ formats: ['qr_code', 'code_128', 'code_39', 'ean_13'] }); } catch (e) { detector = null; } }
  await sheet({
    title: 'Scan a patient card', submit: '',
    body: `${secureNote('The camera')}<div class="scanner"><video playsinline muted></video></div><p class="muted" data-status style="margin-top:8px">Point the camera at the QR on the patient card.</p>`,
    onOpen: async form => {
      const video = form.querySelector('video');
      const status = form.querySelector('[data-status]');
      try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); }
      catch (e) { status.textContent = tr('The camera could not open. Type the patient number or HN in the search instead.'); return; }
      video.srcObject = stream; await video.play();
      const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d', { willReadFrequently: true });
      const read = async () => {
        if (!video.videoWidth) return '';
        if (detector) { const r = await detector.detect(video); return r[0] ? r[0].rawValue : ''; }
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const r = window.jsQR ? jsQR(img.data, img.width, img.height) : null;
        return r ? r.data : '';
      };
      while (!stop && document.body.contains(form)) {
        let text = '';
        try { text = await read(); } catch (e) { /* frame not ready */ }
        if (text) {
          const p = findPatientByNo(text);
          if (p) { stop = true; form.close(null); if (stream) stream.getTracks().forEach(t => t.stop()); go('#/patient/' + p.id); break; }
          status.textContent = tr('No patient with this code at this branch.');
        }
        await new Promise(r => setTimeout(r, 150));
      }
    },
  });
  stop = true;
  if (stream) stream.getTracks().forEach(t => t.stop());
}
