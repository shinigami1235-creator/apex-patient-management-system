// Shared pieces of the interface: icons, the page frame, dialogs, form fields.

const $app = document.getElementById('app');
const ic = (d, w = 22) => `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const I = {
  mic: ic('<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'),
  today: ic('<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),
  calendar: ic('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>'),
  patients: ic('<circle cx="9" cy="8" r="4"/><path d="M2 21c0-4 3-7 7-7s7 3 7 7M17 4a4 4 0 0 1 0 8M22 21c0-3-2-6-5-7"/>'),
  team: ic('<circle cx="12" cy="7" r="4"/><path d="M5 21v-2a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v2"/>'),
  settings: ic('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
  more: ic('<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'),
  power: ic('<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>', 16),
  lock: ic('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', 16),
  back: ic('<path d="M15 18l-6-6 6-6"/>', 16),
  next: ic('<path d="M9 18l6-6-6-6"/>', 16),
  plus: ic('<path d="M12 5v14M5 12h14"/>', 18),
  print: ic('<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>', 18),
  check: ic('<path d="M20 6L9 17l-5-5"/>', 18),
  clock: ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 18),
  search: ic('<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>', 18),
  wifi: ic('<path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M2 9a15 15 0 0 1 20 0"/><circle cx="12" cy="19.5" r="1"/>', 18),
  send: ic('<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>', 16),
  eye: ic('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>', 16),
  edit: ic('<path d="M4 20l4-1 11-11-3-3L5 16z"/>', 16),
  alert: ic('<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>', 16),
  qr: ic('<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 17h4v4h-4"/>', 18),
  incident: ic('<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>'),
  book: ic('<path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4zM20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8z"/>', 16),
};

function toast(msg, ms = 3200) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const t = document.createElement('div');
  t.className = 'toast'; t.setAttribute('role', 'status'); t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), ms);
}
const hideToast = () => document.querySelectorAll('.toast').forEach(t => t.remove());
function fail(e) { console.error(e); toast(e && e.message ? e.message : String(e), 6000); }

// Returns the value of the pressed button, or null when dismissed.
function ask({ title, body = '', buttons }) {
  return new Promise(resolve => {
    const scrim = document.createElement('div');
    scrim.className = 'scrim';
    scrim.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><h2>${esc(title)}</h2>${body ? `<div class="muted">${body}</div>` : ''}
      <div class="actions">${buttons.map((b, i) => `<button class="btn ${b.kind || 'secondary'}" data-i="${i}">${esc(b.label)}</button>`).join('')}</div></div>`;
    const close = v => { scrim.remove(); document.removeEventListener('keydown', onKey); resolve(v); };
    const onKey = e => { if (e.key === 'Escape') close(null); };
    scrim.addEventListener('click', e => {
      if (e.target === scrim) return close(null);
      const b = e.target.closest('[data-i]');
      if (b) close(buttons[+b.dataset.i].value);
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(scrim);
    scrim.querySelector('.btn:last-child').focus();
  });
}
const confirmDanger = (title, body, label = 'Delete') => ask({ title, body, buttons: [{ label: 'Cancel', value: null }, { label, value: true, kind: 'danger solid' }] });

// Opens a form in a sheet. Resolves with the form on submit, or null.
// validate(form) returns an error message to keep it open. onOpen(form) wires extras.
function sheet({ title, body, submit = 'Save', wide = false, onOpen, validate, extra = '', cancel = 'Cancel' }) {
  return new Promise(resolve => {
    const scrim = document.createElement('div');
    scrim.className = 'scrim';
    scrim.innerHTML = `<form class="sheet ${wide === 'xl' ? 'xl' : wide ? 'wide' : ''}" role="dialog" aria-modal="true" novalidate><h2>${esc(title)}</h2>${body}
      <p class="form-err" data-err></p>
      <div class="actions">${extra}<span class="spacer"></span>${cancel ? `<button type="button" class="btn secondary" data-cancel>${esc(cancel)}</button>` : ''}${submit ? `<button class="btn primary" data-submit>${esc(submit)}</button>` : ''}</div></form>`;
    const form = scrim.querySelector('form');
    const close = v => { scrim.remove(); document.removeEventListener('keydown', onKey); resolve(v); };
    const onKey = e => { if (e.key === 'Escape' && document.querySelectorAll('.scrim').length && document.querySelectorAll('.scrim')[document.querySelectorAll('.scrim').length - 1] === scrim) close(null); };
    const c = form.querySelector('[data-cancel]');
    if (c) c.onclick = () => close(null);
    scrim.addEventListener('mousedown', e => { if (e.target === scrim) close(null); });
    form.onsubmit = async e => {
      e.preventDefault();
      const btn = form.querySelector('[data-submit]');
      if (btn) btn.disabled = true;
      try {
        const msg = validate ? await validate(form) : '';
        if (msg) { form.querySelector('[data-err]').textContent = msg; return; }
        close(form);
      } catch (err) { form.querySelector('[data-err]').textContent = err.message; }
      finally { if (btn) btn.disabled = false; }
    };
    form.close = close;
    form.err = msg => { form.querySelector('[data-err]').textContent = msg; };
    document.addEventListener('keydown', onKey);
    document.body.appendChild(scrim);
    if (onOpen) onOpen(form);
    const first = form.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea');
    if (first && matchMedia('(pointer: fine)').matches && !first.closest('[data-nofocus]')) first.focus();
  });
}

const val = (root, name) => { const el = root.querySelector(`[name="${name}"]`); return el ? (el.type === 'checkbox' ? el.checked : el.value.trim()) : ''; };
const nval = (root, name) => num(val(root, name));

function field(label, name, value = '', { type = 'text', hint = '', ph = '', attrs = '', options = null, blank = true, cls = '' } = {}) {
  let input;
  if (type === 'textarea') input = `<textarea name="${name}" placeholder="${esc(ph)}" ${attrs}>${esc(value ?? '')}</textarea>`;
  else if (type === 'select') input = `<select name="${name}" ${attrs}>${blank ? `<option value="">${typeof blank === 'string' ? esc(blank) : ''}</option>` : ''}${options.map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(v)}" ${String(v) === String(value ?? '') ? 'selected' : ''}>${esc(l)}</option>`; }).join('')}</select>`;
  else if (type === 'check') return `<label class="check ${cls}"><input type="checkbox" name="${name}" ${value ? 'checked' : ''} ${attrs}><span>${esc(label)}${hint ? `<span class="meta block">${esc(hint)}</span>` : ''}</span></label>`;
  else input = `<input type="${type}" name="${name}" value="${esc(value ?? '')}" placeholder="${esc(ph)}" ${type === 'number' ? 'step="any" inputmode="decimal"' : ''} ${attrs}>`;
  return `<label class="field ${cls}"><span class="label">${esc(label)}</span>${input}${hint ? `<span class="hint">${esc(hint)}</span>` : ''}</label>`;
}
const datalist = (id, items) => `<datalist id="${id}">${items.map(x => `<option value="${esc(x)}">`).join('')}</datalist>`;

// Repeating rows inside a form: cols = [{k, label, ph, type, options, w, list}]
function rowsBlock(key, cols, items, addLabel) {
  const tmpl = cols.map(c => c.w || '1fr').join(' ') + ' 36px';
  const cell = (c, it) => c.type === 'select'
    ? `<select data-k="${c.k}" aria-label="${esc(c.label)}"><option value=""></option>${c.options.map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(v)}" ${String(it[c.k] ?? '') === String(v) ? 'selected' : ''}>${esc(l)}</option>`; }).join('')}</select>`
    : `<input type="${c.type || 'text'}" data-k="${c.k}" value="${esc(it[c.k] ?? '')}" placeholder="${esc(c.ph || c.label || '')}" aria-label="${esc(c.label)}" ${c.type === 'number' ? 'step="any" inputmode="decimal"' : ''} ${c.list ? `list="${c.list}"` : ''}>`;
  const row = (it = {}) => `<div class="r" style="grid-template-columns:${tmpl}">${cols.map(c => cell(c, it)).join('')}<button type="button" class="x" data-rm aria-label="Remove">×</button></div>`;
  return `<div class="rows" data-rows="${key}">
    <div class="head" style="grid-template-columns:${tmpl}">${cols.map(c => `<span>${esc(c.label)}</span>`).join('')}<span></span></div>
    <div data-body>${(items && items.length ? items : [{}]).map(row).join('')}</div>
    <button type="button" class="btn quiet small" data-add>${I.plus}${esc(addLabel)}</button></div>`;
}
function wireRows(root) {
  root.querySelectorAll('[data-rows]').forEach(block => {
    if (block.dataset.wired) return;
    block.dataset.wired = '1';
    block.querySelector('[data-add]').onclick = () => {
      const body = block.querySelector('[data-body]');
      const clone = body.querySelector('.r').cloneNode(true);
      clone.querySelectorAll('input').forEach(i => i.value = '');
      clone.querySelectorAll('select').forEach(s => s.selectedIndex = 0);
      body.appendChild(clone);
      clone.querySelector('input,select').focus();
    };
    block.addEventListener('click', e => {
      const rm = e.target.closest('[data-rm]');
      if (!rm) return;
      const body = block.querySelector('[data-body]');
      const r = rm.closest('.r');
      if (body.querySelectorAll('.r').length > 1) r.remove();
      else { r.querySelectorAll('input').forEach(i => i.value = ''); r.querySelectorAll('select').forEach(s => s.selectedIndex = 0); }
    });
  });
}
function readRows(root, key) {
  const block = root.querySelector(`[data-rows="${key}"]`);
  if (!block) return [];
  return [...block.querySelectorAll('[data-body] .r')].map(r => {
    const o = {};
    r.querySelectorAll('[data-k]').forEach(el => { o[el.dataset.k] = el.value.trim(); });
    return o;
  }).filter(o => Object.values(o).some(Boolean));
}

function initials(name) { return String(name || '?').replace(/^(Dr\.?|Dra\.?)\s+/i, '').split(/\s+/).filter(Boolean).slice(0, 2).map(s => s[0].toUpperCase()).join(''); }
function avatar(p, size = '') {
  const ph = p && p.photoId;
  return `<span class="avatar ${size}">${ph ? `<img src="${fileURL(ph)}" alt="">` : esc(initials(p ? p.name : '?'))}</span>`;
}
function chip(text, cls = '') { return `<span class="chip ${cls}">${esc(text)}</span>`; }
// Shown on a record saved while the branch PC was away.
function pendingChip(doc) { return isPending(doc) ? chip('Waiting to sync', 'warn') : ''; }
function empty(title, body = '', action = '') { return `<div class="empty card"><h2>${esc(title)}</h2>${body ? `<p>${body}</p>` : ''}${action}</div>`; }
function tabsNav(items, current, base) { return `<nav class="tabs" aria-label="Sections">${items.map(([k, l, n]) => `<a href="${base}${k}" ${k === current ? 'aria-current="page"' : ''}>${esc(l)}${n ? ` <span class="count">${n}</span>` : ''}</a>`).join('')}</nav>`; }

// ---------- navigation ----------
function go(hash) { if (location.hash === hash) render(); else location.hash = hash; }
function route() {
  const h = location.hash.replace(/^#\/?/, '');
  const [p, qs] = h.split('?');
  return { parts: p.split('/').filter(Boolean).map(decodeURIComponent), q: Object.fromEntries(new URLSearchParams(qs || '')) };
}
function setQuery(q) {
  const { parts } = route();
  const qs = new URLSearchParams(Object.entries(q).filter(([, v]) => v !== '' && v !== undefined && v !== null)).toString();
  history.replaceState(null, '', '#/' + parts.map(encodeURIComponent).join('/') + (qs ? '?' + qs : ''));
}

function navItems() {
  const items = [['today', 'Today', I.today], ['patients', 'Patients', I.patients], ['book', 'Bookings', I.calendar], ['complications', 'Complications', I.incident]];
  items.push(isOwner() ? ['team', 'People', I.team] : ['me', 'Me', I.team]);
  if (isOwner()) items.push(['settings', 'Settings', I.settings]);
  else items.push(['settings', 'Devices', I.settings]);
  return items;
}

function shell(active, inner, { wide = false } = {}) {
  const items = navItems();
  const phone = items.slice(0, 4);
  const more = items.slice(4);
  const branchName = S.clinic.branchName ? `${S.clinic.name || ''} · ${S.clinic.branchName}` : (S.clinic.name || '');
  const lan = S.lan && S.lan[0] ? `${S.lan[0]}:${S.port}` : '';
  document.body.classList.toggle('wide', !!wide);
  return `
  <header class="top">
    <img class="mark" src="assets/apex-mark.png" alt="">
    <span class="name">Apex <b>Patient Management</b></span>
    <span class="clinic">${esc(branchName)}</span>
    <button class="stale" id="stale" hidden>New changes · Refresh</button>
    <a class="stale settle" id="conflicts-btn" href="#/conflicts" hidden></a>
    <span class="offline" id="offline" hidden></span>
    <div class="who">${typeof onClinicPC === 'function' && onClinicPC() ? `<button data-act="connect-top" title="Connect a tablet or phone">${I.wifi}<span>Connect</span></button>` : ''}${typeof micButtonHTML === 'function' ? micButtonHTML() : ''}<button class="lang-btn" data-act="lang" title="ภาษา / Language" translate="no">${curLang() === 'th' ? 'EN' : 'ไทย'}</button><button class="me" data-act="me" title="${esc(S.me.name)}">${avatar(S.me, 'sm')}<span>${esc(S.me.name)}</span></button><button data-act="lock" aria-label="Lock">${I.lock}<span>Lock</span></button>${typeof canClose === 'function' && canClose() ? `<button data-act="close-pms" class="close-pms${updateReady() ? ' has-update' : ''}" title="${updateReady() ? 'Close for the day and install the update' : 'Close the program for the day'}">${I.power}<span>Close</span></button>` : ''}</div>
  </header>
  <nav class="nav" aria-label="Main">
    ${items.map(([k, label, icon]) => `<a href="#/${k}" class="${phone.some(x => x[0] === k) ? 'nv-ph' : 'wide-only'}" ${active === k ? 'aria-current="page"' : ''}>${icon}<span>${label}</span></a>`).join('')}
    ${more.length ? `<button class="nv-ph more-btn ${more.some(x => x[0] === active) ? 'on' : ''}" data-act="more">${I.more}<span>More</span></button>` : ''}
    <div class="brand">${lan ? (typeof onClinicPC === 'function' && onClinicPC() ? `<button class="lan" data-act="connect-top" title="Connect a tablet or phone">${I.wifi}${esc(lan)}</button>` : `<span class="lan" title="This clinic's address">${I.wifi}${esc(lan)}</span>`) : ''}<span class="made">Apex Medical Center</span></div>
  </nav>
  <main id="main"><div class="offline-note" id="offline-banner" hidden>Not connected to the branch PC. Do not reload this page. Saves wait here until it is back.</div>
  ${S.pendingOthers && S.pendingOthers.length ? `<div class="banner">${plural(S.pending, 'save')} made by ${esc(S.pendingOthers.join(', '))} on this device ${S.pendingOthers.length > 1 ? 'are' : 'is'} waiting. They go to the branch PC when ${S.pendingOthers.length > 1 ? 'they sign' : 'that person signs'} in here.</div>` : ''}${inner}</main>`;
}

function wireShell() {
  paintConnection();
  const on = (sel, fn) => { const el = document.querySelector(sel); if (el) el.onclick = fn; };
  on('[data-act="lock"]', () => lockNow());
  on('[data-act="close-pms"]', () => closeProgram());
  on('[data-act="me"]', () => go('#/me'));
  on('[data-act="lang"]', async () => { const lang = curLang() === 'th' ? 'en' : 'th'; setLang(lang); try { await api('/api/me/lang', { lang }); S.me.lang = lang; } catch (e) { /* this device keeps it */ } render(); });
  on('#stale', () => render());
  on('[data-act="more"]', async () => {
    const items = navItems().slice(4);
    const r = await ask({ title: 'More', body: '', buttons: items.map(([k, l]) => ({ label: l, value: k })) });
    if (r) go('#/' + r);
  });
  document.getElementById('stale').hidden = !S.stale;
}

// Another device changed something. Redraw the screen unless someone is typing.
const remoteChanged = debounce((store) => {
  if (!S.me) return;
  if (typeof onRemote === 'function' && onRemote(store)) return;
  const busy = document.querySelector('.scrim, #editor, .lock, .kiosk') || (document.activeElement && document.activeElement.closest && document.activeElement.closest('#main') && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) || document.querySelector('#main [data-dirty]');
  if (busy) { S.stale = true; const b = document.getElementById('stale'); if (b) b.hidden = false; return; }
  const y = window.scrollY;
  render();
  window.scrollTo(0, y);
}, 350);
// Marks forms as being edited so live updates do not redraw under the cursor.
document.addEventListener('input', e => { const f = e.target.closest && e.target.closest('#main form'); if (f) f.dataset.dirty = '1'; });

// ---------- pickers ----------
// A searchable patient field. Returns markup; read the choice with pickedPatient(form).
function patientPicker(selectedId, { name = 'pname', label = 'Patient', allowNew = true } = {}) {
  const sel = selectedId ? patient(selectedId) : null;
  const opts = [...S.patients].sort((a, b) => a.name.localeCompare(b.name));
  return `<label class="field"><span class="label">${esc(label)}</span>
    <input type="text" name="${name}" list="${name}-list" value="${sel ? esc(`${sel.name} · ${sel.no || ''}`) : ''}" placeholder="Type a name, record number or mobile" autocomplete="off">
    <datalist id="${name}-list">${opts.map(p => `<option value="${esc(`${p.name} · ${p.no || ''}`)}">${esc(p.phone || '')}</option>`).join('')}</datalist>
    ${allowNew ? '<span class="hint">A name not on record adds a new patient.</span>' : ''}</label>`;
}
function pickedPatient(form, name = 'pname') {
  const v = val(form, name);
  if (!v) return null;
  return S.patients.find(p => `${p.name} · ${p.no || ''}` === v) || S.patients.find(p => p.no && v.endsWith(p.no)) || S.patients.find(p => p.phone && p.phone.replace(/\D/g, '') === v.replace(/\D/g, '') && v.replace(/\D/g, '').length > 6) || null;
}
async function patientFromPicker(form, name = 'pname', action = 'Patient added') {
  const p = pickedPatient(form, name);
  if (p) return p;
  const raw = val(form, name).replace(/\s·\s.*$/, '').trim();
  if (!raw) return null;
  return save('patients', { id: uid(), name: raw, screen: {}, allergies: [], meds: [], conditions: [], surgeries: [], contacts: [] }, { action });
}

const FIELD_NAMES = { name: 'Name', nameTh: 'Name in Thai', hn: 'Apex HN', nationality: 'Nationality', idNo: 'ID or passport number', idType: 'ID', line: 'LINE ID', plang: 'Language on the tablet', meds_given: 'Medicines given', dob: 'Date of birth', sex: 'Sex', phone: 'Mobile', email: 'Email', address: 'Address', allergies: 'Allergies', meds: 'Medicines', conditions: 'Conditions', surgeries: 'Surgeries', screen: 'Before treatment', contacts: 'Emergency contacts', notes: 'Notes',
  complaint: 'Complaint', findings: 'Findings', assessment: 'Assessment', plan: 'Plan', treatments: 'Treatment record', marks: 'Chart marks', base: 'Chart base', consents: 'Consent', rx: 'Prescription', aftercare: 'Aftercare', charges: 'Charges', payments: 'Payments', discount: 'Discount', followUp: 'Follow-up date', signedAt: 'Signed', date: 'Date', time: 'Time', status: 'Status', view: 'View', stage: 'Stage', reason: 'Reason', lines: 'Lines', total: 'Total', qty: 'Quantity', price: 'Price', role: 'Role', in: 'Time in', out: 'Time out', services: 'Services', doctorId: 'Doctor', roomId: 'Room', mins: 'Length', custom: 'Custom fields', tags: 'Tags', referrerId: 'Referred by', vipOff: 'VIP discount off', level: 'Level', supplies: 'Consumables used' };
const STORE_LABELS = { patients: 'Record', visits: 'Visit', charts: 'Chart', heads: '3D head', photos: 'Photo', lots: 'Lot', products: 'Product', users: 'Doctors and assistants', settings: 'Settings', services: 'Treatment', tags: 'Tag', fields: 'Custom field', incidents: 'Complication', conflicts: 'Sync conflict', presets: 'Preset', analyses: 'Skin analysis', previews: 'Preview', transcripts: 'Transcript' };
function historyHTML(rows) {
  if (!rows.length) return '<p class="muted">No changes recorded.</p>';
  return `<div class="list">${rows.map(r => `<div class="li at-top"><div style="width:150px;flex:none" class="m">${fmtStamp(r.at)}</div>
    <div class="grow"><div class="t medium">${esc(STORE_LABELS[r.store] || r.store)}: ${esc(r.action)}</div><div class="m">${esc(r.byName || '')}</div>
    ${r.changes && r.changes.length ? `<details><summary class="meta link">${plural(r.changes.length, 'field')} changed</summary><div class="scroll-x"><table class="t" style="margin-top:6px"><tr><th>Field</th><th>Before</th><th>After</th></tr>${r.changes.map(c => `<tr><td>${esc(FIELD_NAMES[c.f] || (String(c.f).startsWith('custom.') ? (fieldDef(c.f.slice(7)) || {}).label || 'Custom field' : c.f))}</td><td class="meta wrap">${esc(c.from)}</td><td class="wrap">${esc(c.to)}</td></tr>`).join('')}</table></div></details>` : ''}</div></div>`).join('')}</div>`;
}

// Small inline bar chart, used on Today and in reports.
function sparkBars(values, { h = 40, color = 'var(--p400)' } = {}) {
  const max = Math.max(1, ...values);
  const w = values.length * 8;
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">${values.map((v, i) => `<rect x="${i * 8 + 1}" y="${h - (v / max) * h}" width="6" height="${(v / max) * h}" rx="1.5" fill="${color}"/>`).join('')}</svg>`;
}

// ---------- custom fields ----------
// The owner defines fields under Settings, Custom fields. The same engine draws them on
// the patient form, the visit notes and the service sheet, reads them back and shows them.
const SECTION_LABEL = (target, key) => { const s = (FIELD_SECTIONS[target] || []).find(x => x[0] === key); return s ? s[1] : key; };
function customFieldInput(f, v) {
  const name = 'cf_' + f.id, label = f.label + (f.required ? ' *' : '') + (f.type === 'number' && f.unit ? ` (${f.unit})` : '');
  const ro = f.retired ? 'disabled' : '';
  if (f.type === 'long') return field(label, name, v ?? '', { type: 'textarea', hint: f.hint, attrs: ro, cls: 'wide' });
  if (f.type === 'number') return field(label, name, v ?? '', { type: 'number', hint: f.hint, attrs: ro });
  if (f.type === 'date') return field(label, name, v ?? '', { type: 'date', hint: f.hint, attrs: ro });
  if (f.type === 'yesno') return field(label, name, v === true ? 'yes' : v === false ? 'no' : '', { type: 'select', options: [['yes', 'Yes'], ['no', 'No']], hint: f.hint, attrs: ro });
  if (f.type === 'choice') return field(label, name, v ?? '', { type: 'select', options: f.options || [], hint: f.hint, attrs: ro });
  if (f.type === 'multi') return `<div class="field wide"><span class="label">${esc(label)}</span><div class="checks tight">${(f.options || []).map(o => `<label class="check"><input type="checkbox" name="${name}" value="${esc(o)}" ${(Array.isArray(v) ? v : []).includes(o) ? 'checked' : ''} ${ro}><span>${esc(o)}</span></label>`).join('')}</div>${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
  return field(label, name, v ?? '', { hint: f.hint, attrs: ro });
}
// The fields of one section, for the role signed in. A retired field shows only while the
// record still holds a value for it, and cannot be changed.
function customFieldsHTML(target, values, section, role = S.me.role) {
  const vals = values || {};
  const list = fieldsFor(target, { retired: true, role }).filter(f => (f.section || '') === section && (!f.retired || (vals[f.id] !== undefined && vals[f.id] !== '')));
  return list.length ? `<div class="cf-grid" data-cf="${esc(section)}">${list.map(f => customFieldInput(f, vals[f.id])).join('')}</div>` : '';
}
// Section keys that have at least one field to draw, beyond the fixed ones.
function customSections(target, values, role = S.me.role) {
  const fixed = (FIELD_SECTIONS[target] || []).map(x => x[0]);
  const vals = values || {};
  return [...new Set(fieldsFor(target, { retired: true, role }).filter(f => !fixed.includes(f.section) && (!f.retired || (vals[f.id] !== undefined && vals[f.id] !== ''))).map(f => f.section))];
}
// Reads every custom field on a form back into values. Fields not on the form keep what
// the record held.
function readCustomFields(form, target, existing, role = S.me.role) {
  const out = { ...(existing || {}) };
  for (const f of fieldsFor(target, { retired: true, role })) {
    const els = form.querySelectorAll(`[name="cf_${f.id}"]`);
    if (!els.length || f.retired) continue;
    let v;
    if (f.type === 'multi') v = [...els].filter(e => e.checked).map(e => e.value);
    else if (f.type === 'yesno') v = els[0].value === 'yes' ? true : els[0].value === 'no' ? false : '';
    else if (f.type === 'number') v = els[0].value.trim() === '' ? '' : num(els[0].value);
    else v = els[0].value.trim();
    if (v === '' || (Array.isArray(v) && !v.length)) delete out[f.id]; else out[f.id] = v;
  }
  return out;
}
// The first required field left empty, or ''.
function customMissing(form, target, role = S.me.role) {
  const vals = readCustomFields(form, target, {}, role);
  const f = fieldsFor(target, { role }).find(x => x.required && (vals[x.id] === undefined || vals[x.id] === ''));
  return f ? `${f.label} is needed.` : '';
}
function customValueText(f, v) {
  if (v === undefined || v === null || v === '') return '';
  if (f.type === 'yesno') return v === true ? 'Yes' : v === false ? 'No' : String(v);
  if (f.type === 'multi') return (Array.isArray(v) ? v : [v]).join(', ');
  if (f.type === 'date') return fmtDate(v);
  if (f.type === 'number') return `${trimNum(v)}${f.unit ? ' ' + f.unit : ''}`;
  return String(v);
}
// [label, text] pairs of one section's values, for a record view or a printout.
function customPairs(target, values, section, role = S.me.role) {
  const vals = values || {};
  return fieldsFor(target, { retired: true, role }).filter(f => (f.section || '') === section && vals[f.id] !== undefined && vals[f.id] !== '').map(f => [f.label + (f.retired ? ' (retired field)' : ''), customValueText(f, vals[f.id])]);
}
function customKV(pairs) { return pairs.length ? `<dl class="kv">${pairs.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd class="pre">${esc(v)}</dd></div>`).join('')}</dl>` : ''; }
// Tag chips with the tag's colour.
function tagChip(name) { const c = tagColor(name); return `<span class="chip tiny tag" ${c ? `style="border-left-color:${esc(c)}"` : ''}>${esc(name)}</span>`; }
