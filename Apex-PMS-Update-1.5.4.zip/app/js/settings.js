// Settings: the branch, treatments, products and lots, forms, device settings sheets, tags,
// custom fields, backups, voice, the translator, presets, devices and the change log.

function renderSettings(tab, q = {}) {
  const owner = isOwner();
  const tabs = owner
    ? [['clinic', 'Branch'], ['services', 'Treatments'], ['products', 'Products'], ['forms', 'Forms'], ['sheets', 'Device settings'], ['tags', 'Tags'], ['fields', 'Custom fields'], ['backup', 'Backup'], ['line', 'LINE'], ['presets', 'Presets'], ['devices', 'Devices'], ['updates', 'Updates'], ['log', 'Change log']]
    : [['devices', 'Devices']];
  if (!tabs.some(t => t[0] === tab)) tab = tabs[0][0];
  const body = {
    clinic: clinicTab, services: servicesTab, products: productsTab, forms: formsTab, sheets: sheetsTab, tags: tagsTab, fields: fieldsTab,
    backup: backupTab, line: lineTab, presets: presetsTab, devices: devicesTab, updates: updatesTab, log: logTab,
  }[tab]();
  $app.innerHTML = shell('settings', `<div class="page-head"><h1>${owner ? 'Settings' : 'Devices'}</h1></div>${tabs.length > 1 ? tabsNav(tabs, tab, '#/settings/') : ''}<div id="set">${body}</div>
    <p class="meta center" style="margin-top:24px">Apex Patient Management System ${esc(S.version || APP_VERSION)}</p>`);
  wireShell();
  const wire = { clinic: wireClinic, services: wireServices, products: wireProducts, forms: wireForms, sheets: wireSheets, tags: wireTags, fields: wireFields, backup: wireBackup, line: wireLineTab, presets: wirePresetsTab, devices: wireDevices, updates: wireUpdatesTab, log: wireLog }[tab];
  if (wire) wire();
}

// ---------- branch ----------
function clinicTab() {
  const c = S.clinic;
  return `<form class="card" id="clinic"><h2 class="card-title">Branch</h2>
    <div class="grid3">${field('Hospital or clinic name', 'name', c.name)}${field('Branch', 'branchName', c.branchName, { ph: 'Siam Square One' })}${field('Branch code', 'branchCode', c.branchCode, { hint: 'Starts every new patient and visit number. Numbers already given keep their code.', attrs: 'maxlength="4" autocapitalize="characters"' })}</div>
    ${field('Address', 'address', c.address)}
    <div class="grid3">${field('Phone', 'phone', c.phone, { type: 'tel' })}${field('Email', 'email', c.email, { type: 'email' })}${field('Website', 'website', c.website, { ph: 'apexmedicalcenter.co.th' })}</div>
    <div class="grid3">${field('Dates show in', 'dateEra', c.dateEra || 'be', { type: 'select', options: [['be', 'Buddhist year, 2569'], ['ce', 'Christian year, 2026']], blank: false })}${field('Lock after', 'lockMinutes', c.lockMinutes ?? 10, { type: 'select', options: [[2, '2 minutes'], [5, '5 minutes'], [10, '10 minutes'], [30, '30 minutes'], [0, 'Never']], blank: false })}${field('Licence of the clinic', 'licenceNo', c.licenceNo, { ph: 'ใบอนุญาตประกอบกิจการ 10101012345', hint: 'Printed at the foot of every page.' })}</div>
    <div class="grid3">${field('Opens', 'opens', c.opens || '09:00', { type: 'time', hint: 'The bookings page shows these hours.' })}${field('Closes', 'closes', c.closes || '20:00', { type: 'time' })}</div>
    ${field('Footer on printouts', 'footer', c.footer, { ph: 'Apex Medical Center · 02 123 4567 · apexmedicalcenter.co.th' })}
    <div class="field"><span class="label">Logo</span><div class="row">${c.logo ? `<img src="${fileURL(c.logo)}" alt="" class="logo-prev">` : '<span class="meta">The Apex logo prints until another is added.</span>'}<label class="btn secondary small">Choose image<input type="file" class="file-hidden" accept="image/*" data-logo></label>${c.logo ? '<button type="button" class="btn quiet small" data-act="no-logo">Remove</button>' : ''}</div></div>
    <div class="row end"><button class="btn primary">Save</button></div></form>
    <div class="card" id="sample"><h2 class="card-title">Sample data</h2><div data-sample><p class="meta">Checking.</p></div></div>`;
}
// Sample patients, visits, charts, photos and results to try every screen, and four sample
// people to sign in as. All of it comes off with Remove sample data.
async function paintSample() {
  const box = document.querySelector('[data-sample]');
  if (!box) return;
  let st;
  try { st = await api('/api/sample'); } catch (e) { box.innerHTML = `<p class="bad-text">${esc(e.message)}</p>`; return; }
  const roleOf = r => (ROLES[r] || {}).label || r;
  box.innerHTML = st.loaded
    ? `<p class="muted">Loaded ${esc(fmtStamp(st.at))}. Sign in as one of these to see their screens. Everything marked as sample, its photos included, comes off with Remove sample data. Records you added yourself stay.</p>
      <table class="t"><thead><tr><th>Sign in as</th><th>Role</th><th>PIN</th></tr></thead><tbody>${(st.pins || []).map(p => `<tr><td>${esc(p.name)}</td><td>${esc(roleOf(p.role))}</td><td translate="no"><b>${esc(p.pin)}</b></td></tr>`).join('')}</tbody></table>
      <div class="row end"><button type="button" class="btn danger" data-sample-act="remove">Remove sample data</button></div>`
    : `<p class="muted">Nine sample patients with visits from the last few months: Botox, lip and under-eye filler, a skin booster course, HIFU with its settings, a thread lift, signed consent forms in Thai and English, charts, before and after photos, an open complication and follow-ups this week. Four sample people come with it: two doctors, an assistant and a staff login.</p>
      <div class="row end"><button type="button" class="btn primary" data-sample-act="load">Load sample data</button></div>`;
  const b = box.querySelector('[data-sample-act]');
  b.onclick = async () => {
    const act = b.dataset.sampleAct;
    if (act === 'remove' && !(await confirmDanger('Remove the sample data?', 'Every sample patient, visit, photo and person comes off. Records you added yourself stay.', 'Remove'))) return;
    b.disabled = true;
    try { const r = await api('/api/sample', { action: act }); await loadAll(); toast(act === 'load' ? `Sample loaded: ${r.added} records.` : `Sample removed: ${r.removed} records.`); render(); }
    catch (e) { fail(e); b.disabled = false; }
  };
}
function wireClinic() {
  paintSample();
  const f = document.getElementById('clinic');
  f.onsubmit = async e => {
    e.preventDefault();
    const c = { ...S.clinic };
    for (const k of ['name', 'branchName', 'address', 'phone', 'email', 'website', 'dateEra', 'licenceNo', 'footer', 'opens', 'closes']) c[k] = val(f, k);
    c.branchCode = val(f, 'branchCode').toUpperCase().replace(/[^A-Z0-9]/g, '');
    c.lockMinutes = nval(f, 'lockMinutes');
    if (!c.name) return toast('Enter the hospital or clinic name.');
    if (!/^[A-Z0-9]{2,4}$/.test(c.branchCode)) return toast('The branch code needs 2 to 4 letters or numbers.');
    try { await setMeta('clinic', c); delete f.dataset.dirty; toast('Branch details saved.'); render(); } catch (ex) { fail(ex); }
  };
  f.querySelector('[data-logo]').onchange = async e => {
    const file = e.target.files[0]; if (!file) return;
    try { const r = await resizeImage(file, 800, 0.92); const id = await uploadFile(r.blob); await setMeta('clinic', { ...S.clinic, logo: id }); render(); } catch (ex) { fail(ex); }
  };
  const nl = f.querySelector('[data-act="no-logo"]');
  if (nl) nl.onclick = async () => { await setMeta('clinic', { ...S.clinic, logo: '' }); render(); };
}

// ---------- treatments ----------
function servicesTab() {
  const list = [...S.services].sort((a, b) => (a.category || '').localeCompare(b.category || '') || a.name.localeCompare(b.name));
  const g = groupBy(list, s => s.category || 'Other');
  const have = new Set(S.services.map(x => x.name.trim().toLowerCase())), miss = APEX_SURGERY.filter(a => !have.has(a[1].toLowerCase())).length;
  return `<div class="row end gap-b">${miss ? `<button class="btn secondary" data-act="apex-svc">Add Apex's surgical treatments (${miss})</button>` : ''}<button class="btn primary" data-act="add-svc">${I.plus}Add treatment</button></div>
    ${list.length ? [...g.entries()].map(([cat, items]) => `<h3 class="section-title">${esc(cat)}</h3><div class="card flush"><table class="t fixed"><colgroup><col style="width:42%"><col style="width:18%"><col><col style="width:80px"></colgroup><tr><th>Treatment</th><th>Type</th><th>Forms</th><th></th></tr>
      ${items.map(s => `<tr class="${s.active === false ? 'dim' : ''}"><td><b>${esc(s.name)}</b>${s.nameTh ? ` <span class="meta" lang="th">${esc(s.nameTh)}</span>` : ''}${s.active === false ? ' ' + chip('Hidden') : ''}</td><td>${s.kind ? esc(KINDS[s.kind].label) : ''}</td><td class="meta">${(s.consents || []).filter(k => S.templates.consent[k]).map(k => esc(consentTitle(k))).join(', ')}</td><td class="n"><button class="btn quiet small" data-svc="${s.id}">Edit</button></td></tr>`).join('')}</table></div>`).join('')
      : empty('No treatments yet.', 'Add each treatment the branch does. Its consent forms, aftercare and device settings follow it onto the visit.')}`;
}
function wireServices() {
  document.querySelector('[data-act="add-svc"]').onclick = () => serviceSheet(null);
  const ap = document.querySelector('[data-act="apex-svc"]');
  if (ap) ap.onclick = async () => { ap.disabled = true; try { const r = await api('/api/services/apex', {}); await loadAll(); toast(`${plural(r.added, 'treatment')} added.`); render(); } catch (e) { ap.disabled = false; fail(e); } };
  document.querySelectorAll('[data-svc]').forEach(b => b.onclick = () => serviceSheet(service(b.dataset.svc)));
}
async function serviceSheet(s) {
  const cons = Object.keys(S.templates.consent);
  const f = await sheet({
    title: s ? s.name : 'Add treatment', wide: true,
    extra: s ? `<button type="button" class="btn quiet" data-hide>${s.active === false ? 'Show again' : 'Hide from lists'}</button>` : '',
    body: `<div class="grid3">${field('Name in English', 'name', s ? s.name : '', { ph: 'Botox, frown lines' })}${field('Name in Thai', 'nameTh', s ? s.nameTh : '', { ph: 'โบท็อกซ์ ร่องขมวดคิ้ว' })}${field('Category', 'category', s ? s.category : '', { attrs: 'list="cat-dl"' })}</div>${datalist('cat-dl', SERVICE_CATS)}
      <div class="grid3">${field('Treatment type', 'kind', s ? s.kind : '', { type: 'select', options: CHART_KINDS.map(k => [k, KINDS[k].label]), blank: 'None' })}${field('Aftercare', 'aftercare', s ? s.aftercare : '', { type: 'select', options: Object.keys(S.templates.aftercare).filter(k => aftercareText(k, 'en')).map(k => [k, KINDS[k] ? KINDS[k].label : k]), blank: 'None' })}${field('Settings to record', 'sheetId', s ? s.sheetId : '', { type: 'select', options: groupedSheetOptions(), blank: 'None', hint: 'The visit asks for these settings and fills them in from the last session.' })}</div>
      <div class="field"><span class="label">Consent forms</span><div class="checks tight">${cons.map(k => `<label class="check"><input type="checkbox" data-cons="${k}" ${(s && (s.consents || []).includes(k)) ? 'checked' : ''}><span>${esc(consentTitle(k))}</span></label>`).join('')}</div></div>
      ${customFieldsHTML('services', s ? s.custom : {}, 'service')}`,
    validate: form => (!val(form, 'name') ? 'Enter the treatment name in English.' : customMissing(form, 'services')),
    onOpen: form => {
      const h = form.querySelector('[data-hide]');
      if (h) h.onclick = async () => { form.close(null); await save('services', { ...s, active: s.active === false }, { action: s.active === false ? 'Treatment shown' : 'Treatment hidden' }); render(); };
    },
  });
  if (!f) return;
  const rec = { ...(s || { id: uid(), active: true }) };
  rec.custom = readCustomFields(f, 'services', s ? s.custom : {});
  for (const k of ['name', 'nameTh', 'category', 'kind', 'aftercare', 'sheetId']) rec[k] = val(f, k);
  rec.consents = [...f.querySelectorAll('[data-cons]')].filter(x => x.checked).map(x => x.dataset.cons);
  try { await save('services', rec, { action: s ? 'Treatment edited' : 'Treatment added' }); render(); } catch (e) { fail(e); }
}

// ---------- products and lots ----------
// The products charted on patients, with their lot numbers and expiry dates. Stock is
// counted in Apex's own system, so a lot here is a number to pick and nothing more.
// Products are grouped under Apex's headings, and a product added by hand under its type.
const productGroup = p => p.group || (KINDS[p.kind] || KINDS.other).label;
const apexMissing = () => { const have = new Set(S.products.map(p => p.name.trim().toLowerCase())); return APEX_PRODUCTS.filter(a => !have.has(a[1].toLowerCase())).length; };
function productsTab() {
  const order = g => { const i = APEX_PRODUCT_GROUPS.indexOf(g); return i < 0 ? 100 + KIND_KEYS.findIndex(k => KINDS[k].label === g) : i; };
  const list = [...S.products].sort((a, b) => order(productGroup(a)) - order(productGroup(b)) || a.name.localeCompare(b.name));
  const g = groupBy(list, productGroup);
  const miss = apexMissing();
  return `<div class="prod-bar gap-b"><input type="search" class="prod-q" data-prod-q placeholder="Find a product" aria-label="Find a product"><div class="row">${miss ? `<button class="btn secondary" data-act="apex-prod">Add Apex's product list (${miss})</button>` : ''}<button class="btn primary" data-act="add-prod">${I.plus}Add product</button></div></div>
    ${list.length ? [...g.entries()].map(([k, items]) => `<section data-prod-group><h3 class="section-title">${esc(k)}</h3><div class="card flush"><table class="t"><tr><th>Product</th><th>Unit</th><th>Lots in use</th><th></th></tr>
      ${items.map(p => { const lots = lotsOf(p.id); return `<tr class="${p.active === false ? 'dim' : ''}" data-prod-row="${esc(p.name.toLowerCase())}"><td><b translate="no">${esc(p.name)}</b>${p.active === false ? ' ' + chip('Hidden') : ''}${p.group && KINDS[p.kind] && KINDS[p.kind].chart ? ` <span class="meta">${esc(KINDS[p.kind].label)}</span>` : ''}</td><td>${esc(p.unit || '')}</td><td>${lots.length ? lots.map(l => `${esc(l.lot || 'No number')}${l.expiry ? ` <span class="meta ${l.expiry < todayISO() ? 'bad-text' : ''}">exp ${fmtDate(l.expiry)}</span>` : ''}`).join('<br>') : '<span class="meta">None</span>'}</td><td class="n"><button class="btn quiet small" data-prod="${p.id}">Edit</button></td></tr>`; }).join('')}</table></div></section>`).join('')
      : empty('No products yet.', 'Add the toxins, fillers, skin boosters, device cartridges and threads the doctors chart, with their lot numbers.')}`;
}
function wireProducts() {
  document.querySelector('[data-act="add-prod"]').onclick = () => productSheet(null);
  const ap = document.querySelector('[data-act="apex-prod"]');
  if (ap) ap.onclick = async () => {
    ap.disabled = true;
    try { const r = await api('/api/products/apex', {}); await loadAll(); toast(`${plural(r.added, 'product')} added.`); render(); }
    catch (e) { ap.disabled = false; fail(e); }
  };
  const q = document.querySelector('[data-prod-q]');
  if (q) q.oninput = () => {
    const t = q.value.trim().toLowerCase();
    document.querySelectorAll('[data-prod-row]').forEach(r => { r.hidden = !!t && !r.dataset.prodRow.includes(t); });
    document.querySelectorAll('[data-prod-group]').forEach(sec => { sec.hidden = ![...sec.querySelectorAll('[data-prod-row]')].some(r => !r.hidden); });
  };
  document.querySelectorAll('[data-prod]').forEach(b => b.onclick = () => productSheet(product(b.dataset.prod)));
}
async function productSheet(p) {
  const lots = p ? lotsOf(p.id, { all: true }) : [];
  const f = await sheet({
    title: p ? p.name : 'Add product', wide: true,
    extra: p ? `<button type="button" class="btn quiet" data-hide>${p.active === false ? 'Show again' : 'Hide from lists'}</button>` : '',
    body: `${field('Group', 'group', p ? p.group || '' : '', { ph: 'Injectables', attrs: 'list="group-dl"' })}${datalist('group-dl', APEX_PRODUCT_GROUPS)}<div class="grid3">${field('Name', 'name', p ? p.name : '', { ph: 'Botox 100 U', attrs: 'list="prod-dl"' })}${field('Type', 'kind', p ? p.kind : 'toxin', { type: 'select', options: KIND_KEYS.map(k => [k, KINDS[k].label]), blank: false })}${field('Unit', 'unit', p ? p.unit : 'U', { attrs: 'list="unit-dl"', hint: 'What the chart counts: U, ml, shots, pcs.' })}</div>
      ${datalist('prod-dl', Object.values(PRODUCT_HINTS).flat())}${datalist('unit-dl', UNITS)}
      <h3 class="sub-head">Lots</h3>
      ${rowsBlock('lots', [{ k: 'lot', label: 'Lot number', ph: 'C6012A1' }, { k: 'expiry', label: 'Expiry', type: 'date' }, { k: 'archived', label: 'Used up', type: 'select', options: [['', 'In use'], ['1', 'Used up']], w: '0.7fr' }], lots.map(l => ({ id: l.id, lot: l.lot, expiry: l.expiry, archived: l.archived ? '1' : '' })), 'Add lot')}
      <p class="meta">The chart picks the lot that expires first. A lot marked used up stays on the records that used it.</p>
      ${customFieldsHTML('products', p ? p.custom : {}, 'product')}`,
    onOpen: form => {
      wireRows(form);
      const kind = form.querySelector('[name=kind]'), unit = form.querySelector('[name=unit]');
      kind.onchange = () => { if (!p) unit.value = (KINDS[kind.value] || KINDS.other).unit; };
      const h = form.querySelector('[data-hide]');
      if (h) h.onclick = async () => { form.close(null); await save('products', { ...p, active: p.active === false }, { action: p.active === false ? 'Product shown' : 'Product hidden' }); render(); };
    },
    validate: form => (!val(form, 'name') ? 'Enter the product name.' : customMissing(form, 'products')),
  });
  if (!f) return;
  const rec = { ...(p || { id: uid(), active: true }), name: val(f, 'name'), group: val(f, 'group'), kind: val(f, 'kind'), unit: val(f, 'unit') || (KINDS[val(f, 'kind')] || KINDS.other).unit, custom: readCustomFields(f, 'products', p ? p.custom : {}) };
  try {
    await save('products', rec, { action: p ? 'Product edited' : 'Product added' });
    for (const r of readRows(f, 'lots')) {
      if (!r.lot && !r.expiry) continue;
      const cur = r.id ? lot(r.id) : null;
      await save('lots', { ...(cur || { id: uid(), productId: rec.id }), lot: r.lot, expiry: r.expiry, archived: r.archived === '1' }, { action: cur ? 'Lot edited' : 'Lot added' });
    }
    render();
  } catch (e) { fail(e); }
}

// ---------- forms ----------
// Each consent form and each aftercare text has a Thai, an English and a Chinese version.
// The patient picks the language on the tablet, and the signed copy keeps that text.
const FORM_LANGS = [['th', 'ไทย'], ['en', 'English'], ['zh', '中文']];
function formsTab() {
  const c = S.templates.consent;
  const starter = Object.values(c).filter(t => !t.apex).length;
  return `${starter ? `<div class="banner info">${plural(starter, 'form')} still ${starter === 1 ? 'has' : 'have'} the starter wording written for this system. When Apex sends its own consent forms, paste each one in and tick "This is Apex's own wording". Signed forms keep the wording the patient saw.</div>` : ''}<div class="card"><div class="card-head"><h2>Consent forms</h2><button class="btn secondary small" data-act="add-consent">${I.plus}Add form</button></div>
      <div class="list flat">${Object.entries(c).map(([k, t]) => `<div class="li"><div class="grow"><div class="t medium">${esc(consentTitle(k))}</div><div class="m">${FORM_LANGS.map(([l, n]) => `${consentHas(t, l) ? '✓' : '✗'} ${n}`).join(' · ')}${t.apex ? ' · Apex wording' : ''}</div></div><button class="btn secondary small" data-consent="${k}">Edit</button></div>`).join('')}</div>
      <p class="meta" style="margin-top:8px">"The doctor named on this form" is replaced with the visit's doctor when the patient signs.</p></div>
    <div class="card"><div class="card-head"><h2>Aftercare</h2></div><p class="meta">Each visit's aftercare starts from the parts that match its treatments, in the patient's language.</p>
      <div class="list flat">${CHART_KINDS.map(k => `<div class="li"><div class="grow"><div class="t medium">${esc(KINDS[k].label)}</div><div class="m">${FORM_LANGS.map(([l, n]) => `${aftercareText(k, l, false) ? '✓' : '✗'} ${n}`).join(' · ')}</div></div><button class="btn secondary small" data-after="${k}">Edit</button></div>`).join('')}</div></div>`;
}
function wireForms() {
  document.querySelectorAll('[data-consent]').forEach(b => b.onclick = () => consentEditSheet(b.dataset.consent));
  document.querySelector('[data-act="add-consent"]').onclick = () => consentEditSheet(null);
  document.querySelectorAll('[data-after]').forEach(b => b.onclick = () => aftercareEditSheet(b.dataset.after));
}
const langTabsHTML = cur => `<div class="seg" role="group" aria-label="Language">${FORM_LANGS.map(([l, n]) => `<button type="button" data-flang="${l}" class="${l === cur ? 'on' : ''}" translate="no">${n}</button>`).join('')}</div>`;
function wireLangTabs(form, onPick) {
  form.querySelectorAll('[data-flang]').forEach(b => b.onclick = () => { form.querySelectorAll('[data-flang]').forEach(x => x.classList.toggle('on', x === b)); onPick(b.dataset.flang); });
}
async function consentEditSheet(key) {
  const t0 = key ? S.templates.consent[key] : { title: {}, text: {} };
  const t = { title: langMap(t0.title), text: langMap(t0.text), apex: !!t0.apex };
  const builtIn = key && CONSENT_DEFAULTS[key];
  let lang = 'th';
  const f = await sheet({
    title: key ? 'Edit consent form' : 'Add consent form', wide: true,
    extra: key && !builtIn ? '<button type="button" class="btn danger" data-del>Delete</button>' : (builtIn ? '<button type="button" class="btn quiet" data-reset>Use the starter wording</button>' : ''),
    body: `${langTabsHTML(lang)}
      ${FORM_LANGS.map(([l]) => `<div data-fl="${l}" ${l === lang ? '' : 'hidden'}>${field('Title', 'title_' + l, t.title[l] || '', { ph: l === 'th' ? 'ยินยอมรับการฉีดโบท็อกซ์' : l === 'zh' ? '肉毒杆菌素注射同意书' : 'Botulinum toxin injections' })}${field('Text', 'text_' + l, t.text[l] || '', { type: 'textarea', attrs: 'style="min-height:320px"' })}</div>`).join('')}
      ${field('This is Apex\'s own wording', 'apex', t.apex, { type: 'check', hint: 'Tick once the text matches the form Apex uses.' })}`,
    onOpen: form => {
      wireLangTabs(form, l => { lang = l; form.querySelectorAll('[data-fl]').forEach(x => { x.hidden = x.dataset.fl !== l; }); });
      const del = form.querySelector('[data-del]');
      if (del) del.onclick = async () => { form.close(null); const tm = JSON.parse(JSON.stringify(S.templates)); delete tm.consent[key]; await setMeta('templates', tm); render(); };
      const reset = form.querySelector('[data-reset]');
      if (reset) reset.onclick = () => { for (const [l] of FORM_LANGS) { form.querySelector(`[name=title_${l}]`).value = CONSENT_DEFAULTS[key].title[l] || ''; form.querySelector(`[name=text_${l}]`).value = CONSENT_DEFAULTS[key].text[l] || ''; } };
    },
    validate: form => (!val(form, 'title_en') && !val(form, 'title_th') ? 'Enter the title in Thai or English.' : ''),
  });
  if (!f) return;
  const tm = JSON.parse(JSON.stringify(S.templates));
  const rec = { title: {}, text: {}, apex: val(f, 'apex') };
  for (const [l] of FORM_LANGS) { rec.title[l] = val(f, 'title_' + l); rec.text[l] = f.querySelector(`[name=text_${l}]`).value.trim(); }
  tm.consent[key || 'custom-' + uid().slice(0, 8)] = rec;
  try { await setMeta('templates', tm); toast('Form saved.'); render(); } catch (e) { fail(e); }
}
async function aftercareEditSheet(k) {
  const cur = langMap(S.templates.aftercare[k]);
  let lang = 'th';
  const f = await sheet({
    title: KINDS[k].label, wide: true,
    extra: AFTERCARE_DEFAULTS[k] ? '<button type="button" class="btn quiet" data-reset>Use the starter wording</button>' : '',
    body: `${langTabsHTML(lang)}${FORM_LANGS.map(([l]) => `<div data-fl="${l}" ${l === lang ? '' : 'hidden'}>${field('Aftercare', 'a_' + l, cur[l] || '', { type: 'textarea', attrs: 'style="min-height:260px"' })}</div>`).join('')}`,
    onOpen: form => {
      wireLangTabs(form, l => { lang = l; form.querySelectorAll('[data-fl]').forEach(x => { x.hidden = x.dataset.fl !== l; }); });
      const reset = form.querySelector('[data-reset]');
      if (reset) reset.onclick = () => { for (const [l] of FORM_LANGS) form.querySelector(`[name=a_${l}]`).value = langMap(AFTERCARE_DEFAULTS[k])[l] || ''; };
    },
  });
  if (!f) return;
  const tm = JSON.parse(JSON.stringify(S.templates));
  tm.aftercare[k] = Object.fromEntries(FORM_LANGS.map(([l]) => [l, f.querySelector(`[name=a_${l}]`).value.trim()]));
  try { await setMeta('templates', tm); toast('Aftercare saved.'); render(); } catch (e) { fail(e); }
}

// ---------- tags ----------
const TAG_COLORS = [['#C49A45', 'Gold'], ['#1F5E99', 'Blue'], ['#0E6B4F', 'Green'], ['#7A4FB5', 'Violet'], ['#B0306A', 'Rose'], ['#C27A0E', 'Amber'], ['#A33A2B', 'Red'], ['#5B6574', 'Grey']];
function tagCount(name) { return S.patients.filter(p => (p.tags || []).includes(name)).length; }
function tagsTab() {
  const list = tagList({ retired: true });
  const live = list.filter(t => !t.retired), retired = list.filter(t => t.retired);
  const row = t => `<tr class="${t.retired ? 'dim' : ''}"><td><span class="tag-dot" style="background:${esc(t.color || '#5B6574')}"></span><b>${esc(t.name)}</b>${t.mergedInto ? `<div class="meta">Merged into ${esc(t.mergedInto)}</div>` : ''}</td><td class="n">${plural(tagCount(t.name), 'patient')}</td><td class="n">${t.retired ? `<button class="btn quiet small" data-tag-restore="${t.id}">Use again</button>` : `<button class="btn quiet small" data-tag-edit="${t.id}">Rename</button><button class="btn quiet small" data-tag-merge="${t.id}">Merge into</button><button class="btn quiet small" data-tag-retire="${t.id}">Retire</button>`}</td></tr>`;
  return `<div class="row end gap-b"><button class="btn primary" data-act="add-tag">${I.plus}Add tag</button></div>
    <p class="meta">A tag is ticked on the patient record and filters the patient list, the day sheet, the reports and the marketing photo list. Renaming or merging changes every patient that carries it. A retired tag stays on the patients that have it and is offered to nobody new.</p>
    ${live.length ? `<div class="card flush"><table class="t"><tr><th>Tag</th><th class="n">On</th><th></th></tr>${live.map(row).join('')}</table></div>` : empty('No tags yet.')}
    ${retired.length ? `<h3 class="section-title">Retired</h3><div class="card flush"><table class="t">${retired.map(row).join('')}</table></div>` : ''}`;
}
function wireTags() {
  const on = (sel, fn) => document.querySelectorAll(sel).forEach(b => b.onclick = () => fn(tagDef(b.dataset.tagEdit || b.dataset.tagMerge || b.dataset.tagRetire || b.dataset.tagRestore)));
  document.querySelector('[data-act="add-tag"]').onclick = () => tagSheet(null);
  on('[data-tag-edit]', t => tagSheet(t));
  on('[data-tag-retire]', async t => { if (!(await ask({ title: `Retire ${t.name}?`, body: `${plural(tagCount(t.name), 'patient')} keep it. Nobody new gets it.`, buttons: [{ label: 'Cancel', value: null }, { label: 'Retire', value: true, kind: 'primary' }] }))) return; try { await save('tags', { ...t, retired: true }, { action: 'Tag retired' }); render(); } catch (e) { fail(e); } });
  on('[data-tag-restore]', async t => { try { const { mergedInto, ...rest } = t; await save('tags', { ...rest, retired: false, mergedInto: null }, { action: 'Tag back in use' }); render(); } catch (e) { fail(e); } });
  on('[data-tag-merge]', async t => {
    const others = tagList().filter(x => x.id !== t.id);
    if (!others.length) return toast('There is no other tag to merge into.');
    const f = await sheet({ title: `Merge ${t.name} into`, submit: 'Merge', body: `<p class="muted">Every patient tagged ${esc(t.name)} gets the tag you pick, and ${esc(t.name)} is retired.</p>${field('Tag', 'into', others[0].id, { type: 'select', options: others.map(x => [x.id, x.name]), blank: false })}` });
    if (!f) return;
    try { await save('tags', { ...t, mergeInto: val(f, 'into') }, { action: `Tag merged: ${t.name} into ${(tagDef(val(f, 'into')) || {}).name}` }); toast('Merged.'); render(); } catch (e) { fail(e); }
  });
}
async function tagSheet(t) {
  const f = await sheet({ title: t ? 'Rename tag' : 'Add tag', body: `<div class="grid2">${field('Name', 'name', t ? t.name : '', { ph: 'VIP' })}${field('Colour', 'color', t ? t.color || TAG_COLORS[0][0] : TAG_COLORS[Math.floor(Math.random() * TAG_COLORS.length)][0], { type: 'select', options: TAG_COLORS, blank: false })}</div>${t ? `<p class="meta">${plural(tagCount(t.name), 'patient')} carry this tag and are renamed with it.</p>` : ''}`, validate: x => (!val(x, 'name') ? 'Enter the name.' : '') });
  if (!f) return;
  try { await save('tags', { ...(t || { id: uid() }), name: val(f, 'name'), color: val(f, 'color') }, { action: t ? 'Tag renamed' : 'Tag added' }); render(); } catch (e) { fail(e); }
}

// ---------- custom fields ----------
function fieldsTab() {
  const list = S.fields.slice().sort((a, b) => FIELD_TARGETS.findIndex(x => x[0] === a.target) - FIELD_TARGETS.findIndex(x => x[0] === b.target) || (a.section || '').localeCompare(b.section || '') || num(a.order) - num(b.order));
  const g = groupBy(list, f => f.target);
  const typeLabel = t => (FIELD_TYPES.find(x => x[0] === t) || [t, t])[1];
  return `<div class="row end gap-b"><button class="btn primary" data-act="add-field">${I.plus}Add field</button></div>
    <p class="meta">A field goes on the patient record, the visit notes, a service, a stock product or a staff record, in the section you pick. Fields in Medical history, Lifestyle, Aesthetic profile and Notes are clinical and never show to the front desk or marketing. A retired field leaves the forms and keeps its old values readable.</p>
    ${FIELD_TARGETS.filter(([k]) => g.has(k)).map(([k, l]) => `<h3 class="section-title">${esc(l)}</h3><div class="card flush scroll-x"><table class="t"><tr><th>Field</th><th>Section</th><th>Type</th><th>Seen by</th><th></th></tr>
      ${g.get(k).map(f => `<tr class="${f.retired ? 'dim' : ''}"><td><b>${esc(f.label)}</b>${f.required ? ' <span class="meta">required</span>' : ''}${f.retired ? ' ' + chip('Retired') : ''}${f.hint ? `<div class="meta">${esc(f.hint)}</div>` : ''}</td><td>${esc(SECTION_LABEL(f.target, f.section))}</td><td class="meta">${esc(typeLabel(f.type))}${f.unit ? ', ' + esc(f.unit) : ''}${(f.options || []).length ? `<div class="meta">${esc(f.options.join(', '))}</div>` : ''}</td><td class="meta">${(f.roles || []).map(r => ROLES[r] ? ROLES[r].label : r).join(', ')}</td><td class="n"><button class="btn quiet small" data-field="${f.id}">Edit</button></td></tr>`).join('')}</table></div>`).join('')}
    ${!list.length ? empty('No custom fields yet.') : ''}`;
}
function wireFields() {
  document.querySelector('[data-act="add-field"]').onclick = () => fieldSheet(null);
  document.querySelectorAll('[data-field]').forEach(b => b.onclick = () => fieldSheet(fieldDef(b.dataset.field)));
}
async function fieldSheet(fd) {
  const f0 = fd || { target: 'patients', section: 'details', type: 'text', roles: ['owner', 'doctor', 'rn', 'nurse'], options: [], order: (Math.max(0, ...S.fields.map(x => num(x.order))) + 10) };
  const sectionsOf = target => [...(FIELD_SECTIONS[target] || []), ...[...new Set(S.fields.filter(x => x.target === target && !(FIELD_SECTIONS[target] || []).some(y => y[0] === x.section)).map(x => x.section))].map(k => [k, k]), ['__new', 'New section']];
  const f = await sheet({
    title: fd ? fd.label : 'Add field', wide: true,
    extra: fd ? `<button type="button" class="btn quiet" data-retire>${fd.retired ? 'Use again' : 'Retire'}</button>` : '',
    body: `<div class="grid3">${field('Goes on', 'target', f0.target, { type: 'select', options: FIELD_TARGETS, blank: false, attrs: fd ? 'disabled' : '' })}<label class="field"><span class="label">Section</span><select name="section">${sectionsOf(f0.target).map(([k, l]) => `<option value="${esc(k)}" ${k === f0.section ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>${field('New section name', 'newSection', '', { ph: 'Hair and scalp', attrs: 'data-newsec' })}</div>
      <div class="grid2">${field('Label', 'label', f0.label || '', { ph: 'Glogau photoaging type' })}${field('Hint under the box', 'hint', f0.hint || '', { ph: 'What to type, or an example.' })}</div>
      <div class="grid3">${field('Type', 'type', f0.type, { type: 'select', options: FIELD_TYPES, blank: false })}${field('Unit', 'unit', f0.unit || '', { ph: 'kg', attrs: 'data-unit' })}${field('Order', 'order', f0.order, { type: 'number', hint: 'Lower comes first.' })}</div>
      ${field('Choices, one per line', 'options', (f0.options || []).join('\n'), { type: 'textarea', attrs: 'data-opts style="min-height:90px"' })}
      <div class="grid2">${field('Required on the form', 'required', !!f0.required, { type: 'check' })}${field('Clinical', 'clinical', !!(f0.clinical || CLINICAL_SECTIONS.includes(f0.section)), { type: 'check', hint: 'Marks the field as part of the medical record.', attrs: 'data-clin' })}</div>
      <div class="field"><span class="label">Seen by</span><div class="checks tight">${ALL_ROLES.map(r => `<label class="check"><input type="checkbox" data-role="${r}" ${r === 'owner' || (f0.roles || []).includes(r) ? 'checked' : ''} ${r === 'owner' ? 'disabled' : ''}><span>${esc(ROLES[r].label)}</span></label>`).join('')}</div></div>`,
    onOpen: form => {
      const target = form.querySelector('[name=target]'), section = form.querySelector('[name=section]'), newSec = form.querySelector('[data-newsec]'), type = form.querySelector('[name=type]'), clin = form.querySelector('[data-clin]');
      const upd = () => {
        newSec.closest('.field').classList.toggle('hidden', section.value !== '__new'); if (section.value !== '__new') newSec.value = '';
        form.querySelector('[data-unit]').closest('.field').classList.toggle('hidden', type.value !== 'number');
        form.querySelector('[data-opts]').closest('.field').classList.toggle('hidden', !['choice', 'multi'].includes(type.value));
        const forced = CLINICAL_SECTIONS.includes(section.value);
        if (forced) clin.checked = true;
        clin.disabled = forced;
      };
      target.onchange = () => { section.innerHTML = sectionsOf(target.value).map(([k, l]) => `<option value="${esc(k)}">${esc(l)}</option>`).join(''); upd(); };
      section.onchange = upd; type.onchange = upd; clin.onchange = upd; upd();
      const rt = form.querySelector('[data-retire]');
      if (rt) rt.onclick = async () => { form.close(null); try { await save('fields', { ...fd, retired: !fd.retired }, { action: fd.retired ? 'Field back in use' : 'Field retired' }); render(); } catch (e) { fail(e); } };
    },
    validate: form => (!val(form, 'label') ? 'Enter the label.' : val(form, 'section') === '__new' && !val(form, 'newSection') ? 'Name the new section.' : ['choice', 'multi'].includes(val(form, 'type')) && !form.querySelector('[name=options]').value.trim() ? 'Enter the choices, one per line.' : ''),
  });
  if (!f) return;
  const rec = { ...f0, id: f0.id || uid(), target: fd ? fd.target : val(f, 'target'), section: val(f, 'section') === '__new' ? val(f, 'newSection') : val(f, 'section'), label: val(f, 'label'), hint: val(f, 'hint'), type: val(f, 'type'), unit: val(f, 'unit'), order: nval(f, 'order'), required: val(f, 'required'), clinical: val(f, 'clinical'),
    options: f.querySelector('[name=options]').value.split('\n').map(x => x.trim()).filter(Boolean), roles: [...f.querySelectorAll('[data-role]')].filter(x => x.checked).map(x => x.dataset.role) };
  try { await save('fields', rec, { action: fd ? 'Field edited' : 'Field added' }); render(); } catch (e) { fail(e); }
}

// ---------- backup ----------
function backupTab() {
  return `<div class="card"><h2 class="card-title">Download all the records</h2>
      <p class="meta">Every patient, visit, chart, booking and reminder in one file. Patients, Visits, Materials used and Bookings open in Excel; records.json and the raw folder have every record exactly as the program keeps it.</p>
      <div class="row"><a class="btn primary" href="/api/export/all" download>Download the records</a><a class="btn secondary" href="/api/export/all?files=1" download>With photos and signed forms</a></div></div>
    <div id="bk"><p class="meta">Loading.</p></div>`;
}
async function wireBackup() {
  let st;
  try { st = await api('/api/backup'); } catch (e) { return fail(e); }
  const el = document.getElementById('bk');
  if (!el) return;
  const last = st.last;
  el.innerHTML = `
    ${!st.hasKey ? `<div class="banner bad">No backups are being made yet. Set a backup passphrase below.</div>` : last && !last.ok ? `<div class="banner bad">The last backup failed: ${esc(last.error)}</div>` : ''}
    <div class="card"><h2 class="card-title">Automatic backups</h2>
      <p class="muted">The branch PC backs up the database and every photo each night, locked with your passphrase. Copies go to the backups folder next to the app, and to a second folder when one is set. Point the second folder at a Google Drive or OneDrive folder on this PC so a copy leaves the building.</p>
      <dl class="kv">
        <div><dt>Last backup</dt><dd>${last && last.ok ? `${fmtStamp(last.at)} · ${(last.size / 1048576).toFixed(1)} MB${last.copied && !last.copied.startsWith('failed') ? ' · copied' : ''}` : 'None yet'}</dd></div>
        <div><dt>Backups folder</dt><dd class="wrap">${esc(st.folder)}</dd></div>
        <div><dt>Second copy</dt><dd class="wrap">${st.folder2 ? esc(st.folder2) + (st.folder2Ok ? '' : ' (not found)') : 'Not set'}</dd></div>
      </dl>
      <form id="bkset" class="grid3" style="margin-top:12px">${field('Back up every night at', 'time', st.time, { type: 'time' })}${field('Second copy folder', 'folder2', st.folder2, { ph: 'G:\\My Drive\\Clinic backups', hint: 'A folder path on the branch PC.' })}${field('Keep the last', 'keep', st.keep, { type: 'select', options: [[14, '14 backups'], [30, '30 backups'], [60, '60 backups'], [90, '90 backups']], blank: false })}
        <div class="row end" style="grid-column:1/-1"><button class="btn secondary">Save</button><button type="button" class="btn primary" data-act="now" ${st.hasKey ? '' : 'disabled'}>Back up now</button></div></form></div>
    <div class="card"><h2 class="card-title">Passphrase</h2>
      <p class="muted">${st.hasKey ? `Set ${fmtStamp(st.keySet)}. Backups made after a change use the new passphrase while older files keep the old one.` : 'Backups cannot be opened without it, so write it down and keep it away from the branch PC.'}</p>
      <form id="bkkey" class="grid2">${field('Passphrase', 'p1', '', { type: 'password', hint: 'At least 8 characters.', attrs: 'autocomplete="new-password"' })}${field('Passphrase again', 'p2', '', { type: 'password', attrs: 'autocomplete="new-password"' })}<div class="row end" style="grid-column:1/-1"><button class="btn primary">${st.hasKey ? 'Change passphrase' : 'Set passphrase'}</button></div></form></div>
    <div id="cloud"><p class="meta">Loading.</p></div>
    <div class="card"><h2 class="card-title">Backups on this PC</h2>${st.list.length ? `<table class="t"><tr><th>File</th><th class="n">Size</th></tr>${st.list.map(b => `<tr><td>${esc(b.file)}</td><td class="n">${(b.size / 1048576).toFixed(1)} MB</td></tr>`).join('')}</table>` : '<p class="muted">None yet.</p>'}</div>
    <div class="card"><h2 class="card-title">Restore</h2>
      <p class="muted">Restoring replaces every record and photo with the contents of the backup file. The current data is kept in a "previous" folder inside the data folder, and everyone signs in again.</p>
      <div class="row end"><label class="btn danger">Choose backup file<input type="file" class="file-hidden" accept=".ccbak" data-restore></label></div></div>`;
  const set = document.getElementById('bkset');
  set.onsubmit = async e => { e.preventDefault(); try { await setMeta('backup', { ...(S.backup || {}), time: val(set, 'time'), folder2: val(set, 'folder2'), keep: nval(set, 'keep') }); toast('Backup settings saved.'); wireBackup(); } catch (ex) { fail(ex); } };
  set.querySelector('[data-act="now"]').onclick = async () => {
    toast('Making the backup.', 120000);
    try { const r = await api('/api/backup/now', {}); toast(r.ok ? `Backup saved, ${(r.size / 1048576).toFixed(1)} MB.` : 'The backup failed: ' + r.error, 6000); wireBackup(); } catch (ex) { fail(ex); }
  };
  const key = document.getElementById('bkkey');
  key.onsubmit = async e => {
    e.preventDefault();
    if (val(key, 'p1').length < 8) return toast('Use at least 8 characters.');
    if (val(key, 'p1') !== val(key, 'p2')) return toast('The two passphrases are different.');
    try { await api('/api/backup/key', { passphrase: val(key, 'p1') }); toast('Passphrase set.'); wireBackup(); } catch (ex) { fail(ex); }
  };
  wireCloud(st.hasKey);
  el.querySelector('[data-restore]').onchange = async ev => {
    const file = ev.target.files[0]; if (!file) return;
    const f = await sheet({ title: 'Restore backup', submit: 'Restore', body: `<p class="muted">${esc(file.name)} replaces everything on the branch PC.</p>${field('Passphrase', 'p', '', { type: 'password' })}${field('Type RESTORE to confirm', 'c', '', { ph: 'RESTORE' })}`, validate: x => (val(x, 'c') !== 'RESTORE' ? 'Type RESTORE in capitals.' : '') });
    if (!f) return;
    toast('Restoring. Keep this window open.', 600000);
    try { await api('/api/backup/restore', file, { raw: true, headers: { 'Content-Type': 'application/octet-stream', 'x-passphrase': encodeURIComponent(val(f, 'p')) } }); location.reload(); }
    catch (ex) { fail(ex); }
  };
}

// ---------- cloud storage ----------
// A bucket on Cloudflare R2, Amazon S3, DigitalOcean Spaces or Wasabi. Each photo goes up once
// and the database goes up after each nightly backup, both locked with the backup passphrase.
const mb = n => (n < 1048576 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1048576).toFixed(1)} MB`);
function cloudHTML(st, hasKey) {
  const c = st.settings, last = st.backupLast, dl = st.download;
  const on = c.photos || c.backups;
  return `${st.lastError && on ? `<div class="banner bad">The cloud copy stopped: ${esc(st.lastError)} It tries again every 5 minutes.</div>` : ''}
    <div class="card"><h2 class="card-title">Cloud storage</h2>
      <p class="muted">Copies every photo and the nightly database backup to cloud storage, locked with the backup passphrase before they leave this PC. The bucket and its keys come from the storage provider.</p>
      ${on ? `<dl class="kv">
        ${c.photos ? `<div><dt>Photos in the cloud</dt><dd>${st.photos.uploaded} of ${st.photos.local}${st.photos.waiting ? ` · ${st.photos.waiting} waiting` : ''}</dd></div>` : ''}
        ${c.backups ? `<div><dt>Last cloud backup</dt><dd>${last ? (last.ok ? `${fmtStamp(last.at)} · ${mb(last.size)}` : `Failed ${fmtStamp(last.at)}: ${esc(last.error)}`) : 'None yet'}</dd></div>` : ''}
        ${dl && (dl.running || dl.total) ? `<div><dt>Photos brought back</dt><dd>${dl.done} of ${dl.total}${dl.failed ? ` · ${dl.failed} failed` : ''}${dl.running ? ' · still running' : ''}</dd></div>` : ''}
      </dl>` : ''}
      <form id="cloudset" class="grid2" style="margin-top:12px" autocomplete="off">
        ${field('Storage address', 'endpoint', c.endpoint, { ph: 'https://<account id>.r2.cloudflarestorage.com', hint: 'The S3 address the provider gives for the bucket.' })}
        ${field('Region', 'region', c.region, { ph: 'auto', hint: 'auto for Cloudflare R2. The region code for the others, such as ap-southeast-1.' })}
        ${field('Bucket', 'bucket', c.bucket, { ph: 'apex-pms' })}
        ${field('Folder in the bucket', 'prefix', c.prefix, { ph: 'apex-pms/' + ((S.clinic && S.clinic.branchCode) || '') + '/' })}
        ${field('Access key', 'accessKeyId', c.accessKeyId, { attrs: 'spellcheck="false"' })}
        ${field('Secret key', 'secretAccessKey', '', { type: 'password', ph: c.hasSecret ? 'Saved. Type a new one to change it.' : '', attrs: 'autocomplete="new-password" spellcheck="false"' })}
        <div style="grid-column:1/-1" class="stack">
          ${field('Copy every photo to the cloud', 'photos', c.photos, { type: 'check' })}
          ${field('Back up the database to the cloud every night', 'backups', c.backups, { type: 'check', hint: 'After the backup on this PC. The photos are copied one by one, so the nightly file stays small.' })}
        </div>
        ${field('Keep the last', 'keep', c.keep, { type: 'select', options: [[14, '14 cloud backups'], [30, '30 cloud backups'], [60, '60 cloud backups'], [90, '90 cloud backups']], blank: false })}
        ${hasKey ? '' : '<p class="form-err" style="grid-column:1/-1">Set the backup passphrase above first.</p>'}
        <p class="form-err" data-err style="grid-column:1/-1"></p>
        <div class="row end" style="grid-column:1/-1"><button type="button" class="btn secondary" data-cloud="test">Test the connection</button>${c.backups && st.ready ? '<button type="button" class="btn secondary" data-cloud="now">Back up to the cloud now</button>' : ''}<button class="btn primary">Save</button></div>
      </form></div>
    ${st.ready ? `<div class="card"><h2 class="card-title">Restore from the cloud</h2>
      <p class="muted">Restoring replaces every record with the one in the cloud backup, and the photos come back from the cloud as they are opened. On a new PC, set it up, type the cloud settings above and save them with both boxes unticked, then restore. The current data is kept in a "previous" folder inside the data folder, and everyone signs in again.</p>
      <div id="cloudlist"><div class="row end"><button type="button" class="btn secondary" data-cloud="list">Show the cloud backups</button></div></div></div>` : ''}`;
}
async function wireCloud(hasKey) {
  const box = document.getElementById('cloud');
  if (!box) return;
  let st;
  try { st = await api('/api/cloud'); } catch (e) { box.innerHTML = ''; return; }
  box.innerHTML = cloudHTML(st, hasKey);
  const f = document.getElementById('cloudset');
  const err = m => { f.querySelector('[data-err]').textContent = m ? tr(m) : ''; };
  const form = () => ({ endpoint: val(f, 'endpoint'), region: val(f, 'region'), bucket: val(f, 'bucket'), prefix: val(f, 'prefix'), accessKeyId: val(f, 'accessKeyId'), secretAccessKey: val(f, 'secretAccessKey'), photos: val(f, 'photos'), backups: val(f, 'backups'), keep: nval(f, 'keep') });
  f.onsubmit = async e => {
    e.preventDefault(); err('');
    toast('Checking the connection.', 30000);
    try { await api('/api/cloud/settings', form()); toast('Cloud storage saved.'); wireCloud(hasKey); } catch (ex) { hideToast(); err(ex.message); }
  };
  f.querySelector('[data-cloud="test"]').onclick = async () => {
    err('');
    toast('Checking the connection.', 30000);
    try { await api('/api/cloud/test', form()); toast('The connection works.'); } catch (ex) { hideToast(); err(ex.message); }
  };
  const now = f.querySelector('[data-cloud="now"]');
  if (now) now.onclick = async () => {
    toast('Backing up to the cloud.', 120000);
    try { const r = await api('/api/cloud/backup', {}); toast(`Cloud backup saved, ${mb(r.size)}.`, 6000); wireCloud(hasKey); } catch (ex) { hideToast(); err(ex.message); }
  };
  const list = box.querySelector('[data-cloud="list"]');
  if (list) list.onclick = async () => {
    const out = document.getElementById('cloudlist');
    out.innerHTML = '<p class="meta">Loading.</p>';
    let rows;
    try { rows = await api('/api/cloud/backups'); } catch (ex) { out.innerHTML = `<p class="form-err">${esc(tr(ex.message))}</p>`; return; }
    out.innerHTML = rows.length ? `<div class="scroll-x"><table class="t"><tr><th>Backup</th><th class="n">Size</th><th></th></tr>${rows.map((b, i) => `<tr><td>${esc(b.name.replace(/^Apex PMS backup |\.ccbak$/g, ''))}</td><td class="n">${mb(b.size)}</td><td class="n"><button type="button" class="btn danger small" data-restore-cloud="${i}">Restore</button></td></tr>`).join('')}</table></div>` : '<p class="muted">No cloud backups yet.</p>';
    out.querySelectorAll('[data-restore-cloud]').forEach(b => b.onclick = async () => {
      const pick = rows[+b.dataset.restoreCloud];
      const sh = await sheet({ title: 'Restore from the cloud', submit: 'Restore', body: `<p class="muted">The backup of ${esc(pick.name.replace(/^Apex PMS backup |\.ccbak$/g, ''))} replaces every record on the branch PC.</p>${field('Backup passphrase', 'p', '', { type: 'password' })}${field('Type RESTORE to confirm', 'c', '', { ph: 'RESTORE' })}`, validate: x => (val(x, 'c') !== 'RESTORE' ? 'Type RESTORE in capitals.' : '') });
      if (!sh) return;
      toast('Restoring. Keep this window open.', 600000);
      try { await api('/api/cloud/restore', { name: pick.name, passphrase: val(sh, 'p') }); location.reload(); }
      catch (ex) { hideToast(); fail(ex); }
    });
  };
}

// ---------- devices ----------
// The cards live in devices.js.
const devicesTab = () => devicesTabHTML();
const wireDevices = () => wireDevicesTab();
// ---------- change log ----------
// Three logs for the admin: what changed, who signed in or was refused, and who opened which record.
const LOG_VIEWS = [['changes', 'Changes'], ['signins', 'Sign-ins'], ['opened', 'Records opened']];
let logView = 'changes';
function logTab() {
  return `<div class="row gap-b"><div class="seg" role="group" aria-label="Log">${LOG_VIEWS.map(([k, l]) => `<button type="button" data-logview="${k}" aria-pressed="${k === logView}">${l}</button>`).join('')}</div>
    <select id="logstore"${logView === 'changes' ? '' : ' hidden'}><option value="">Everything</option>${Object.entries(STORE_LABELS).map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select></div><div id="log"><p class="meta">Loading.</p></div>`;
}
const OPENED_WHAT = { record: 'Record', visit: 'Visit', chart: 'Chart', photos: 'Photos', print: 'Printed' };
function logRows(rows, line) {
  return rows.length ? `<div class="list">${rows.map(r => `<div class="li at-top"><div style="width:150px;flex:none" class="m">${fmtStamp(r.at)}</div><div class="grow">${line(r)}</div></div>`).join('')}</div>` : '<p class="muted">Nothing yet.</p>';
}
function wireLog() {
  const box = document.getElementById('log'), storeSel = document.getElementById('logstore');
  const load = async () => {
    box.innerHTML = '<p class="meta">Loading.</p>';
    try {
      if (logView === 'signins') {
        const rows = await api('/api/security');
        box.innerHTML = logRows(rows, r => `<div class="t medium${/Wrong|refused|locked/i.test(r.event) ? ' danger' : ''}">${esc(r.event)}</div><div class="m">${esc([r.name, r.device].filter(Boolean).join(' · '))}</div>`);
      } else if (logView === 'opened') {
        const rows = await api('/api/access');
        box.innerHTML = logRows(rows, r => { const p = patient(r.patientId); return `<div class="t medium">${esc(p ? p.name : 'A patient no longer on record')}${p && p.no ? ` <span class="meta">${esc(p.no)}</span>` : ''}</div><div class="m">${esc([r.byName, (ROLES[r.role] || {}).label, OPENED_WHAT[r.what] || r.what, r.device].filter(Boolean).join(' · '))}</div>`; });
      } else {
        const rows = await api('/api/history' + (storeSel.value ? '?store=' + storeSel.value : ''));
        const named = rows.map(r => ({ ...r, action: `${r.action}${r.patientId && patient(r.patientId) ? ' · ' + patient(r.patientId).name : ''}` }));
        box.innerHTML = named.length ? historyHTML(named) : '<p class="muted">Nothing yet.</p>';
      }
    } catch (e) { fail(e); }
  };
  document.querySelectorAll('[data-logview]').forEach(b => b.onclick = () => {
    logView = b.dataset.logview;
    document.querySelectorAll('[data-logview]').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    storeSel.hidden = logView !== 'changes';
    load();
  });
  storeSel.onchange = load;
  load();
}

// ---------- LINE ----------
// Apex's LINE Official Account sends the booking confirmations and reminders. The token and
// secret come from the LINE Developers console, Messaging API tab, and only the admin sees them.
const LINE_KINDS = [['confirm', 'Confirmation when booked'], ['remind', 'Reminder the day before'], ['soon', 'Reminder on the day'], ['followup', 'Follow-up due'], ['linked', 'Reply when a patient links LINE']];
function lineTab() {
  const L = S.line || {}, R = { confirm: true, dayBefore: true, dayBeforeHour: 18, soon: false, soonHours: 2, followUp: true, followUpDays: 3, ...(L.rules || {}) };
  const li = S.lineInfo || {};
  const hook = `https://<the address Apex's IT opens>/line/webhook`;
  return `<form class="card" id="lineset"><h2 class="card-title">LINE Official Account</h2>
    <label class="check"><input type="checkbox" name="enabled" ${L.enabled ? 'checked' : ''}> Send confirmations and reminders on LINE</label>
    <div class="grid2">${field('LINE ID', 'basicId', L.basicId || '', { ph: '@apexclinic', hint: 'The @ name patients add. It goes in the link QR.' })}${field('Channel secret', 'secret', L.secret || '', { attrs: 'autocomplete="off" spellcheck="false"', hint: 'LINE Developers, Basic settings.' })}</div>
    ${field('Channel access token', 'token', L.token || '', { type: 'textarea', attrs: 'rows="2" autocomplete="off" spellcheck="false"', hint: 'LINE Developers, Messaging API, Channel access token (long-lived).' })}
    <div class="field"><span class="label">Webhook URL</span><code class="pre" translate="no">${esc(hook)}</code><span class="hint">Patients link their LINE through this address, so LINE has to reach this PC from the internet. Apex's IT opens it, such as with a Cloudflare tunnel to this PC's port ${esc(String(S.port || 4810))}, then puts the address in LINE Developers, Messaging API, Webhook URL, and turns Use webhook on.</span><span class="hint">${li.seen ? `LINE last reached this PC ${fmtStamp(li.seen)}.` : 'LINE has not reached this PC yet.'}</span></div>
    <h3 style="margin-top:16px">When to send</h3>
    <label class="check"><input type="checkbox" name="r_confirm" ${R.confirm ? 'checked' : ''}> A confirmation as soon as a visit is booked</label>
    <div class="row"><label class="check"><input type="checkbox" name="r_dayBefore" ${R.dayBefore ? 'checked' : ''}> A reminder the day before, from</label><input type="time" name="r_dayBeforeHour" value="${String(R.dayBeforeHour).padStart(2, '0')}:00" step="3600" style="max-width:120px"></div>
    <div class="row"><label class="check"><input type="checkbox" name="r_soon" ${R.soon ? 'checked' : ''}> A reminder on the day, hours before</label><input type="number" name="r_soonHours" min="1" max="12" value="${R.soonHours}" style="max-width:90px"></div>
    <div class="row"><label class="check"><input type="checkbox" name="r_followUp" ${R.followUp ? 'checked' : ''}> A message when a follow-up is due and nothing is booked, days before</label><input type="number" name="r_followUpDays" min="0" max="30" value="${R.followUpDays}" style="max-width:90px"></div>
    <h3 style="margin-top:16px">Messages</h3><p class="meta">Each goes in the patient's language. {name}, {date}, {time}, {doctor}, {clinic}, {phone} and {reason} are filled in. Leave a box empty for the starting wording.</p>
    <div data-line-texts><p class="meta">Loading.</p></div>
    <div class="row end"><button class="btn primary">Save</button></div></form>
    <div class="card"><h2 class="card-title">Send a test</h2><div class="grid2"><label class="field"><span class="label">Patient with LINE linked</span><select name="testp">${S.patients.filter(p => p.lineUserId).map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('') || '<option value="">Nobody has linked LINE yet</option>'}</select></label>${field('Message', 'testtext', 'Test from ' + (S.clinic.name || 'the clinic'))}</div><div class="row end"><button type="button" class="btn secondary" data-line-test>Send</button></div></div>`;
}
async function wireLineTab() {
  const f = document.getElementById('lineset');
  let defaults = { texts: {} };
  try { defaults = await api('/api/line/defaults'); } catch (e) { /* the boxes stay empty */ }
  const L = S.line || {}, T = L.texts || {};
  f.querySelector('[data-line-texts]').innerHTML = LINE_KINDS.map(([k, label]) => `<details class="line-text"><summary>${esc(label)}</summary>${[['th', 'ไทย'], ['en', 'English'], ['zh', '中文']].map(([lang, ln]) => `<label class="field"><span class="label" translate="no">${ln}</span><textarea name="t_${k}_${lang}" rows="3" placeholder="${esc((defaults.texts[k] || {})[lang] || '')}" translate="no">${esc((T[k] || {})[lang] || '')}</textarea></label>`).join('')}</details>`).join('');
  f.onsubmit = async e => {
    e.preventDefault();
    const on = f.querySelector('[name=enabled]').checked;
    const texts = {};
    for (const [k] of LINE_KINDS) for (const lang of ['th', 'en', 'zh']) { const v = val(f, `t_${k}_${lang}`); if (v) (texts[k] = texts[k] || {})[lang] = v; }
    const rules = { confirm: f.r_confirm.checked, dayBefore: f.r_dayBefore.checked, dayBeforeHour: +String(f.r_dayBeforeHour.value || '18').split(':')[0], soon: f.r_soon.checked, soonHours: +f.r_soonHours.value || 2, followUp: f.r_followUp.checked, followUpDays: +f.r_followUpDays.value || 0 };
    const next = { ...L, enabled: on, basicId: val(f, 'basicId').trim(), secret: val(f, 'secret').trim(), token: val(f, 'token').trim(), rules, texts, enabledAt: on && !L.enabled ? Date.now() : L.enabledAt || (on ? Date.now() : 0) };
    if (on && (!next.token || !next.basicId)) return toast('Enter the LINE ID and the channel access token to turn LINE on.');
    try { await setMeta('line', next); await loadAll(); toast('LINE saved.'); render(); } catch (ex) { fail(ex); }
  };
  const t = document.querySelector('[data-line-test]');
  if (t) t.onclick = async () => {
    const card = t.closest('.card'), pid = card.querySelector('[name=testp]').value;
    if (!pid) return toast('A patient has to link LINE first, from their record.');
    try { await api('/api/line/test', { patientId: pid, text: card.querySelector('[name=testtext]').value }); toast('Sent.'); } catch (e) { fail(e); }
  };
}
