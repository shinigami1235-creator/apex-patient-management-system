// Small helpers shared by every screen. Classic scripts: everything here is global.

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function uid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const pad2 = n => String(n).padStart(2, '0');
function isoOf(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function todayISO() { return isoOf(new Date()); }
function nowTime() { const d = new Date(); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; }
function addDays(iso, n) { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return isoOf(d); }
function daysBetween(a, b) { return Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000); }

const TH_MONTHS = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
const TH_DAYS = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];
// The year as the branch shows it: Buddhist (2569) or Christian (2026).
const yearOf = y => (typeof S !== 'undefined' && S.clinic && S.clinic.dateEra === 'ce' ? y : y + 543);
const uiLang = () => (typeof curLang === 'function' ? curLang() : 'en');
// 2026-10-05 -> 5 ต.ค. 2569 in Thai, 05 Oct 2569 in English (or 2026 with Christian years)
function fmtDate(iso) {
  if (!iso) return '';
  const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return iso;
  return uiLang() === 'th' ? `${d} ${TH_MONTHS[m - 1]} ${yearOf(y)}` : `${pad2(d)} ${MONTHS[m - 1]} ${yearOf(y)}`;
}
// 5 ต.ค. or 05 Oct, for tight spaces.
function fmtDay(iso) { const s = fmtDate(iso); return s.split(' ').slice(0, 2).join(' '); }
// ต.ค. 2569 or Oct 2569, for an expiry date.
function fmtMonthYear(iso) { const s = fmtDate(iso); return s.split(' ').slice(1).join(' '); }
function fmtStamp(ms) {
  if (!ms) return '';
  const d = new Date(ms);
  return `${fmtDate(isoOf(d))} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}
function fmtTime(t) {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  if (uiLang() === 'th') return `${pad2(h)}:${pad2(m)} น.`;
  const ap = h >= 12 ? 'pm' : 'am';
  return `${((h + 11) % 12) + 1}:${pad2(m)}${ap}`;
}
function weekday(iso) { const k = new Date(iso + 'T00:00:00').getDay(); return uiLang() === 'th' ? TH_DAYS[k] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][k]; }

function ageOf(dob, on = todayISO()) {
  if (!dob) return '';
  const [y, m, d] = dob.split('-').map(Number);
  const [Y, M, D] = on.split('-').map(Number);
  let a = Y - y;
  if (M < m || (M === m && D < d)) a--;
  return a >= 0 ? a : '';
}

function num(v) { const n = parseFloat(v); return isFinite(n) ? n : 0; }
function trimNum(n, dp = 2) { return String(+(+n).toFixed(dp)); }
function money(n) {
  const c = (S.clinic && S.clinic.currency) || '฿';
  const v = +n || 0;
  return (v < 0 ? '-' : '') + c + Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function money0(n) {
  const c = (S.clinic && S.clinic.currency) || '฿';
  const v = Math.round(+n || 0);
  return (v < 0 ? '-' : '') + c + Math.abs(v).toLocaleString('en-US');
}
function round2(n) { return Math.round((+n || 0) * 100) / 100; }
function minutesOf(t) { if (!t) return null; const [h, m] = t.split(':').map(Number); return h * 60 + m; }
function timeOf(mins) { return `${pad2(Math.floor(mins / 60) % 24)}:${pad2(mins % 60)}`; }
function monthStart(iso) { return iso.slice(0, 8) + '01'; }
function monthEnd(iso) { const d = new Date(iso.slice(0, 7) + '-01T00:00:00'); d.setMonth(d.getMonth() + 1); d.setDate(0); return isoOf(d); }
function weekStart(iso) { const d = new Date(iso + 'T00:00:00'); const k = (d.getDay() + 6) % 7; d.setDate(d.getDate() - k); return isoOf(d); }
function monthName(iso) { const [y, m] = iso.split('-').map(Number); return uiLang() === 'th' ? ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'][m - 1] + ' ' + yearOf(y) : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][m - 1] + ' ' + yearOf(y); }
function daysInRange(from, to) { const out = []; for (let d = from; d <= to; d = addDays(d, 1)) out.push(d); return out; }
function plural(n, one, many) { return `${trimNum(n)} ${n === 1 ? one : (many || one + 's')}`; }
function sum(arr, f) { return arr.reduce((s, x) => s + (+f(x) || 0), 0); }
function groupBy(arr, f) { const m = new Map(); for (const x of arr) { const k = f(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; }
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

function safeName(s, max = 60) {
  return String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max).replace(/[. ]+$/, '') || 'Untitled';
}

// Decodes an image blob with its camera orientation applied.
async function decodeImage(blob) {
  if (window.createImageBitmap) {
    try { return await createImageBitmap(blob, { imageOrientation: 'from-image' }); } catch (e) { /* fall back */ }
  }
  const url = URL.createObjectURL(blob);
  try { const img = new Image(); img.src = url; await img.decode(); return img; }
  finally { URL.revokeObjectURL(url); }
}

// Returns {blob, width, height} scaled so the long edge is at most maxEdge.
async function resizeImage(blob, maxEdge, quality = 0.86) {
  const img = await decodeImage(blob);
  const k = Math.min(1, maxEdge / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * k)), h = Math.max(1, Math.round(img.height * k));
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  if (img.close) img.close();
  const out = await new Promise(r => c.toBlob(r, 'image/jpeg', quality));
  return { blob: out, width: w, height: h };
}

// Reads DateTimeOriginal from a JPEG's EXIF block. Returns YYYY-MM-DD or null.
async function exifDate(file) {
  try {
    if (!/jpe?g/i.test(file.type) && !/\.jpe?g$/i.test(file.name || '')) return null;
    const v = new DataView(await file.slice(0, 256 * 1024).arrayBuffer());
    if (v.getUint16(0) !== 0xFFD8) return null;
    let off = 2;
    while (off + 4 < v.byteLength) {
      const marker = v.getUint16(off), len = v.getUint16(off + 2);
      if (marker === 0xFFE1 && v.getUint32(off + 4) === 0x45786966) {
        const tiff = off + 10, le = v.getUint16(tiff) === 0x4949;
        const u16 = o => v.getUint16(o, le), u32 = o => v.getUint32(o, le);
        const ascii = (o, n) => { let s = ''; for (let i = 0; i < n; i++) { const c = v.getUint8(o + i); if (!c) break; s += String.fromCharCode(c); } return s; };
        const scan = (ifd, want) => { const out = {}; const n = u16(ifd); for (let i = 0; i < n; i++) { const e = ifd + 2 + i * 12, tag = u16(e); if (want.includes(tag)) out[tag] = tag === 0x8769 ? u32(e + 8) : ascii(tiff + u32(e + 8), u32(e + 4)); } return out; };
        const ifd0 = scan(tiff + u32(tiff + 4), [0x0132, 0x8769]);
        const raw = (ifd0[0x8769] && scan(tiff + ifd0[0x8769], [0x9003])[0x9003]) || ifd0[0x0132];
        const m = raw && raw.match(/^(\d{4}):(\d{2}):(\d{2})/);
        return m && m[1] !== '0000' ? `${m[1]}-${m[2]}-${m[3]}` : null;
      }
      if ((marker & 0xFF00) !== 0xFF00) return null;
      off += 2 + len;
    }
  } catch (e) { /* unreadable header */ }
  return null;
}

function blobToDataURL(blob) {
  return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(r.error); r.readAsDataURL(blob); });
}
async function dataURLToBlob(u) { return (await fetch(u)).blob(); }

// A QR code as an SVG string, drawn with the qrcode.js library under vendor.
function qrSVG(text, size = 180) {
  const qr = qrcode(0, 'M');
  qr.addData(text); qr.make();
  const n = qr.getModuleCount(), cell = size / (n + 8);
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${((c + 4) * cell).toFixed(2)},${((r + 4) * cell).toFixed(2)}h${cell.toFixed(2)}v${cell.toFixed(2)}h-${cell.toFixed(2)}z`;
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><rect width="${size}" height="${size}" fill="#fff"/><path d="${d}" fill="#101C2B"/></svg>`;
}

// Reads a code typed or scanned into a code field. A scanner types the whole address
// from a QR, so the part after #/ is what matters. Returns {kind, value}.
function parseCode(text) {
  const t = String(text || '').trim();
  if (!t) return null;
  const m = t.match(/#\/(p|v|l|pr|a)\/([^/?#\s]+)/i);
  if (m) return { kind: m[1].toLowerCase(), value: decodeURIComponent(m[2]) };
  if (/^P-?\d{3,}$/i.test(t)) return { kind: 'p', value: t.toUpperCase() };
  return { kind: 'text', value: t };
}

// Rows to a CSV file Excel opens straight away, with Filipino names and the peso sign intact.
function saveCSV(rows, filename) {
  const csv = rows.map(r => r.map(c => { const v = String(c ?? ''); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',')).join('\r\n');
  saveBlob(new Blob(['\ufeff' + csv], { type: 'text/csv' }), filename);
}
function saveBlob(blob, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
}


// Puts text on the clipboard. Returns false when this browser does not allow it.
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch (e) {
    const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch (x) { ok = false; }
    ta.remove(); return ok;
  }
}
