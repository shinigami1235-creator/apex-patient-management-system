// The patient card: a picture the patient keeps on their phone and shows at every visit, sent
// by LINE, Instagram or any app the phone or PC offers. Apex at the top, the patient's photo,
// name, HN and patient number, and the QR that opens the record when the staff scan it.
// The photo is one the patient sends, or one of the photos taken at the clinic.

const CARD_W = 1080, CARD_H = 1720;
const CARD_TEXT = {
  en: { hn: 'Hospital number (HN)', no: 'Patient number', show: 'Show this card at reception at every visit.' },
  th: { hn: 'เลขประจำตัวผู้ป่วย (HN)', no: 'เลขที่ผู้ป่วย', show: 'แสดงบัตรนี้ที่เคาน์เตอร์ทุกครั้งที่มารับบริการ' },
  zh: { hn: '病历号 (HN)', no: '患者编号', show: '每次就诊请在前台出示此卡。' },
};

function loadImg(src) {
  return new Promise((res, rej) => { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => res(im); im.onerror = () => rej(new Error('The picture could not be loaded.')); im.src = src; });
}
function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function fitText(g, text, max, size, weight = 700) {
  let s = size;
  do { g.font = `${weight} ${s}px "LINE Seed Sans TH", sans-serif`; s -= 2; } while (g.measureText(text).width > max && s > 20);
}

// Draws the card and returns it as a canvas.
async function drawPatientCard(p) {
  await Promise.all([document.fonts.load('700 60px "LINE Seed Sans TH"'), document.fonts.load('400 40px "LINE Seed Sans TH"')]).catch(() => {});
  const lang = ['th', 'en', 'zh'].includes(p.plang) ? p.plang : 'th';
  const T = CARD_TEXT[lang];
  const cv = document.createElement('canvas'); cv.width = CARD_W; cv.height = CARD_H;
  const g = cv.getContext('2d');
  // Background: Apex night to plum.
  const bg = g.createLinearGradient(0, 0, 0, CARD_H);
  bg.addColorStop(0, '#1F0A30'); bg.addColorStop(1, '#4A2266');
  g.fillStyle = bg; g.fillRect(0, 0, CARD_W, CARD_H);
  // The card itself.
  const cx = 60, cy = 60, cw = CARD_W - 120, ch = CARD_H - 120;
  g.save(); g.shadowColor = 'rgba(0,0,0,.35)'; g.shadowBlur = 40; g.shadowOffsetY = 12;
  roundRect(g, cx, cy, cw, ch, 48); g.fillStyle = '#FFFFFF'; g.fill(); g.restore();
  // Header band with the Apex logo in the centre.
  const band = 380;
  g.save(); roundRect(g, cx, cy, cw, band, 48); g.clip(); g.fillStyle = '#2A0F40'; g.fillRect(cx, cy, cw, band); g.restore();
  g.fillStyle = '#2A0F40'; g.fillRect(cx, cy + band - 50, cw, 50);
  try { const logo = await loadImg('assets/logo-white.png'); const lw = 380, lh = lw * logo.height / logo.width; g.drawImage(logo, (CARD_W - lw) / 2, cy + 52, lw, lh); }
  catch (e) { g.fillStyle = '#fff'; g.font = '800 96px "LINE Seed Sans TH", sans-serif'; g.textAlign = 'center'; g.fillText('APEX', CARD_W / 2, cy + 170); }
  const c = S.clinic || {};
  g.fillStyle = '#CDB9DD'; g.textAlign = 'center';
  fitText(g, [c.name, c.branchName].filter(Boolean).join(' · '), cw - 120, 34, 500);
  g.fillText([c.name, c.branchName].filter(Boolean).join(' · '), CARD_W / 2, cy + 196);
  // Photo, in a circle over the foot of the band.
  const r = 200, px = CARD_W / 2, py = cy + band + 64;
  g.save(); g.beginPath(); g.arc(px, py, r + 14, 0, Math.PI * 2); g.fillStyle = '#FFFFFF'; g.fill(); g.restore();
  g.save(); g.beginPath(); g.arc(px, py, r, 0, Math.PI * 2); g.clip();
  g.fillStyle = '#EDE6F3'; g.fillRect(px - r, py - r, r * 2, r * 2);
  let drew = false;
  if (p.cardPhoto) { try { const im = await loadImg(fileURL(p.cardPhoto)); const k = Math.max(2 * r / im.width, 2 * r / im.height); g.drawImage(im, px - im.width * k / 2, py - im.height * k / 2, im.width * k, im.height * k); drew = true; } catch (e) { /* initials below */ } }
  if (!drew) { g.fillStyle = '#6A388C'; g.font = '700 150px "LINE Seed Sans TH", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(cardInitials(p.name), px, py + 6); g.textBaseline = 'alphabetic'; }
  g.restore();
  // Name.
  let y = py + r + 100;
  g.fillStyle = '#1F0A30'; g.textAlign = 'center';
  fitText(g, p.name, cw - 100, 76, 700); g.fillText(p.name, CARD_W / 2, y);
  if (p.nameTh && p.nameTh !== p.name) { y += 64; g.fillStyle = '#5A4A66'; fitText(g, p.nameTh, cw - 100, 50, 500); g.fillText(p.nameTh, CARD_W / 2, y); }
  // HN and patient number.
  y += 70;
  const box = (label, value, x, w) => {
    roundRect(g, x, y, w, 150, 24); g.fillStyle = '#F5F0F9'; g.fill();
    g.fillStyle = '#6A5A76'; g.font = '500 30px "LINE Seed Sans TH", sans-serif'; g.textAlign = 'center'; g.fillText(label, x + w / 2, y + 52);
    g.fillStyle = '#1F0A30'; fitText(g, value, w - 40, 54, 700); g.fillText(value, x + w / 2, y + 116);
  };
  const half = (cw - 100 - 24) / 2;
  if (p.hn) { box(T.hn, p.hn, cx + 50, half); box(T.no, p.no || '', cx + 50 + half + 24, half); }
  else box(T.no, p.no || '', cx + 50, cw - 100);
  // QR, which opens the record when the staff scan it.
  y += 150 + 44;
  const qs = Math.min(400, cy + ch - y - 120);
  const svg = qrSVG(clinicURL('/p/' + (p.no || '')), qs);
  const qr = await loadImg('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg.replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" ')));
  g.drawImage(qr, (CARD_W - qs) / 2, y, qs, qs);
  g.fillStyle = '#5A4A66'; g.textAlign = 'center';
  fitText(g, T.show, cw - 100, 34, 500); g.fillText(T.show, CARD_W / 2, y + qs + 56);
  return cv;
}
const cardInitials = n => String(n || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('') || '?';
const cardBlob = cv => new Promise(res => cv.toBlob(res, 'image/png'));

// A square photo for the card, from a photo on file or one the patient sends, centred on the face when one is found.
async function cardPhotoFrom(src) {
  const im = await loadImg(src);
  let cx = im.width / 2, cy = im.height / 2, side = Math.min(im.width, im.height);
  try {
    const M = await import('/features/face/mesh.js');
    const k = Math.min(1, 1000 / Math.max(im.width, im.height));
    const c0 = document.createElement('canvas'); c0.width = Math.round(im.width * k); c0.height = Math.round(im.height * k);
    c0.getContext('2d').drawImage(im, 0, 0, c0.width, c0.height);
    const lm = await M.detect(new URL('vendor/face_mesh/', document.baseURI).href, c0);
    if (lm) {
      const xs = lm.map(q => q.x * im.width), ys = lm.map(q => q.y * im.height);
      const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      cx = (x0 + x1) / 2; cy = (y0 + y1) / 2 - (y1 - y0) * 0.05;
      side = Math.min(Math.max(x1 - x0, y1 - y0) * 1.9, im.width, im.height);
    }
  } catch (e) { /* centre crop */ }
  const sx = Math.max(0, Math.min(im.width - side, cx - side / 2)), sy = Math.max(0, Math.min(im.height - side, cy - side / 2));
  const out = document.createElement('canvas'); out.width = out.height = 600;
  out.getContext('2d').drawImage(im, sx, sy, side, side, 0, 0, 600, 600);
  return new Promise(res => out.toBlob(res, 'image/jpeg', 0.9));
}

async function patientCardSheet(p) {
  const photos = photosOf(p.id).slice(0, 12);
  const canEdit = canWritePatient();
  const scrim = document.createElement('div');
  scrim.className = 'scrim';
  scrim.innerHTML = `<div class="sheet wide pcard-sheet" role="dialog" aria-modal="true"><h2>Patient card</h2>
    <p class="meta">A picture for the patient's phone. They show it at reception, and the QR opens their record when it's scanned.</p>
    <div class="pcard-grid"><div class="pcard-prev"><span class="spin"></span></div>
      <div>${canEdit ? `<div class="field"><span class="label">Photo on the card</span>
        <div class="photo-grid pcard-photos">${photos.map(ph => `<button type="button" class="ph" data-card-photo="${ph.id}"><img src="${thumbURL(ph.id)}" alt="${esc(ph.view || '')}"></button>`).join('')}
          <label class="ph pcard-up" title="A photo the patient sends">${I.plus}<span>From a file</span><input type="file" accept="image/*" hidden data-card-file></label></div>
        ${p.cardPhoto ? '<button type="button" class="btn quiet small" data-card-none>No photo</button>' : ''}</div>` : ''}
      <div class="row end"><button type="button" class="btn secondary" data-x>Close</button><button type="button" class="btn secondary" data-card-save>Save picture</button><button type="button" class="btn primary" data-card-share>Share</button></div></div></div></div>`;
  document.body.appendChild(scrim);
  const close = () => scrim.remove();
  scrim.querySelector('[data-x]').onclick = close;
  scrim.addEventListener('click', e => { if (e.target === scrim) close(); });
  let blob = null;
  const paint = async () => {
    const box = scrim.querySelector('.pcard-prev');
    box.innerHTML = '<span class="spin"></span>';
    try { const cv = await drawPatientCard(patient(p.id) || p); blob = await cardBlob(cv); box.innerHTML = `<img src="${URL.createObjectURL(blob)}" alt="Patient card">`; }
    catch (e) { box.innerHTML = `<p class="bad-text">${esc(e.message)}</p>`; }
  };
  const setPhoto = async src => {
    try {
      toast('Fitting the photo to the card.');
      const sq = await cardPhotoFrom(src);
      const f = await uploadFile(sq);
      await save('patients', { ...patient(p.id), cardPhoto: f }, { action: 'Card photo changed' });
      paint();
    } catch (e) { fail(e); }
  };
  scrim.querySelectorAll('[data-card-photo]').forEach(b => b.onclick = () => setPhoto(fullURL(b.dataset.cardPhoto)));
  const fi = scrim.querySelector('[data-card-file]');
  if (fi) fi.onchange = () => { const f = fi.files[0]; if (f) setPhoto(URL.createObjectURL(f)); };
  const none = scrim.querySelector('[data-card-none]');
  if (none) none.onclick = async () => { try { await save('patients', { ...patient(p.id), cardPhoto: null }, { action: 'Card photo removed' }); none.remove(); paint(); } catch (e) { fail(e); } };
  const name = () => `Apex card ${(patient(p.id) || p).name}.png`.replace(/[\\/:*?"<>|]/g, '');
  const download = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name(); document.body.appendChild(a); a.click(); a.remove(); };
  scrim.querySelector('[data-card-save]').onclick = () => { if (blob) { download(); markSeen(p.id, 'card'); } };
  scrim.querySelector('[data-card-share]').onclick = async () => {
    if (!blob) return;
    const file = new File([blob], name(), { type: 'image/png' });
    markSeen(p.id, 'card');
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], title: 'Apex patient card' }); } catch (e) { if (e.name !== 'AbortError') fail(e); }
    } else { download(); toast('This browser can\'t share pictures, so the card was saved as a picture. Send it by LINE or any app.', 7000); }
  };
  paint();
}
// Whoever can change the patient's contact details can change the card photo.
function canWritePatient() { return !!(S.me && /[wl]/.test(accessOf('patients'))); }
