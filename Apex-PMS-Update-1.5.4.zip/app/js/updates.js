// Updates and closing for the day. The branch PC downloads a new version by itself; the admin and
// the staff see it's ready, and it goes in when the program is closed from the PC with Close.
// The admin can also put it in straight away under Settings, Updates.

const canClose = () => onClinicPC() && S.me && (S.me.role === 'owner' || S.me.role === 'staff');
const updateReady = () => (S.update && S.update.ready && S.update.launcher ? S.update.ready : null);
const notesOf = r => (r && r.notes ? (curLang() === 'th' && r.notes.th) || r.notes.en || '' : '');

// The line on Today when a version is waiting.
function updateBannerHTML() {
  const r = S.me && (S.me.role === 'owner' || S.me.role === 'staff') ? updateReady() : null;
  if (!r) return '';
  return `<div class="banner info update-banner"><b>Version ${esc(r.version)} is ready.</b> <span>It installs when the program is closed for the day with Close at the top of the screen on the branch PC.</span>${notesOf(r) ? `<div class="meta" translate="no">${esc(notesOf(r))}</div>` : ''}</div>`;
}

async function closeProgram() {
  const r = updateReady();
  const choice = await ask(r ? {
    title: 'Close for the day',
    body: `<p>Version ${esc(r.version)} is ready. Keep the program open about a minute while it installs, and the black window closes by itself when it's done.</p>${notesOf(r) ? `<p class="meta" translate="no">${esc(notesOf(r))}</p>` : ''}`,
    buttons: [{ label: 'Cancel', value: null }, { label: 'Close without updating', value: 'close' }, { label: 'Update and close', value: 'update', kind: 'primary' }],
  } : {
    title: 'Close the program?',
    body: '<p>Tablets can\'t open records until it\'s started again from the Apex PMS icon.</p>',
    buttons: [{ label: 'Cancel', value: null }, { label: 'Close', value: 'close', kind: 'primary' }],
  });
  if (!choice) return;
  let out;
  try { out = await api('/api/close', { update: choice === 'update' }); } catch (e) { return fail(e); }
  closedScreen(out.install ? `Installing version ${r.version}. The black window closes by itself when it's done.` : 'The program is closed. You can close this browser window.');
}
function closedScreen(text) {
  stopEvents();
  $app.innerHTML = `<div class="setup-hero"><img class="logo" src="assets/logo.png" alt="Apex"><h1>Patient Management System</h1></div>
    <div class="setup-body"><div class="card"><h2>${esc(text)}</h2><p class="muted">Start it again from the Apex PMS icon on the desktop.</p></div></div>`;
}
// Another device closed the program or started an update.
function onClosing(m) {
  toast(m.restart ? 'The branch PC is installing an update. The program is back in about a minute.' : 'The branch PC closed the program for the day.', 8000);
}

// Settings, Updates (the admin).
function updatesTab() {
  const u = S.update || {};
  const r = u.ready;
  return `<div class="card"><h2 class="card-title">Updates</h2>
    <div class="list flat">
      <div class="li"><div class="grow"><div class="t medium">Installed version</div><div class="m">${esc(u.version || S.version || '')}</div></div></div>
      <div class="li"><div class="grow"><div class="t medium">Newest version</div><div class="m">${u.checking ? 'Checking.' : u.latest ? esc(u.latest) : 'Not checked yet.'}${u.checked ? ` · checked ${esc(fmtStamp(u.checked))}` : ''}</div>${u.error ? `<div class="m bad-text">${esc(u.error)}</div>` : ''}</div><button class="btn secondary small" data-act="upd-check" ${u.checking ? 'disabled' : ''}>Check now</button></div>
      ${r ? `<div class="li"><div class="grow"><div class="t medium">Version ${esc(r.version)} is ready</div>${notesOf(r) ? `<div class="m" translate="no">${esc(notesOf(r))}</div>` : ''}<div class="m">It installs when the program is closed for the day with Close on the branch PC. Update now installs it straight away and starts the program again; tablets reconnect by themselves in about a minute.</div></div>${u.launcher ? '<button class="btn primary small" data-act="upd-now">Update now</button>' : ''}</div>` : ''}
    </div>
    ${u.launcher === false ? '<p class="meta">This copy was started without the Apex PMS icon, so updates install only with update.bat in the program folder.</p>' : ''}
    <p class="meta">The branch PC looks for a new version when it starts and every six hours. update.bat in the program folder does the same by hand while the program is closed.</p></div>`;
}
function wireUpdatesTab() {
  const c = document.querySelector('[data-act="upd-check"]');
  if (c) c.onclick = async () => { c.disabled = true; try { applyMeta({ update: await api('/api/update/check', {}) }); } catch (e) { fail(e); } render(); };
  const n = document.querySelector('[data-act="upd-now"]');
  if (n) n.onclick = async () => {
    const r = updateReady();
    if (!(await ask({ title: `Install version ${r.version} now?`, body: '<p>The program closes for about a minute while it installs, then starts again. Tablets reconnect by themselves. Saves made on a tablet in that minute wait on the tablet and go through after.</p>', buttons: [{ label: 'Cancel', value: null }, { label: 'Update now', value: true, kind: 'primary' }] }))) return;
    try { await api('/api/close', { restart: true }); } catch (e) { return fail(e); }
    toast('Installing. The program is back in about a minute.', 60000);
  };
}
