// Patient check-in: the tablet handed to the patient in the waiting area. They check their
// details, fill in their health questions and sign the forms the visit still needs. The
// screen covers the app, and only a staff PIN closes it, so the rest of the clinic's
// records stay out of reach. A reload or the auto-lock brings it back after sign-in.

const CHECKIN_KEY = 'cc_checkin';
const CHECKIN_STEPS = [['details', 'Your details'], ['health', 'Your health'], ['forms', 'Forms to sign'], ['done', 'Done']];
const checkinFlag = () => { try { return JSON.parse(sessionStorage.getItem(CHECKIN_KEY) || 'null'); } catch (e) { return null; } };
const setCheckinFlag = x => { try { if (x) sessionStorage.setItem(CHECKIN_KEY, JSON.stringify(x)); else sessionStorage.removeItem(CHECKIN_KEY); } catch (e) { /* this browser keeps nothing */ } };

// Called after sign-in: a check-in left open on this tablet comes back where it was.
function resumeCheckin() {
  const f = checkinFlag();
  if (!f || document.querySelector('.checkin')) return;
  const v = visit(f.visitId);
  if (!v || !can('clinical')) return setCheckinFlag(null);
  openCheckin(v, f.step);
}

function checkinFormsLeft(v) {
  const p = patient(v.patientId);
  const cur = visit(v.id) || v;
  return [...consentsWanted(cur, p)].filter(k => S.templates.consent[k] && !(cur.consents || []).some(c => c.key === k));
}

function openCheckin(v, step = 'details') {
  document.querySelectorAll('.checkin').forEach(x => x.remove());
  const el = document.createElement('div');
  el.className = 'checkin';
  el.dataset.uiLang = (patient(v.patientId) || {}).plang || 'th';
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Patient check-in');
  document.body.appendChild(el);
  const show = s => {
    step = s;
    setCheckinFlag({ visitId: v.id, step });
    const p = patient(v.patientId);
    const idx = CHECKIN_STEPS.findIndex(x => x[0] === step);
    el.innerHTML = `<div class="ck-top"><button class="btn small ck-back" data-ck-staff data-ui-lang="${curLang()}">${I.back}Back</button><b>${esc(S.clinic.name || '')}</b>${plangSwitchHTML(el.dataset.uiLang)}</div>
      <div class="ck-body">
        <div class="ck-steps">${CHECKIN_STEPS.map(([k, label], i) => `<span class="${i < idx ? 'done' : i === idx ? 'on' : ''}"><b>${i + 1}.</b> ${esc(label)}</span>`).join('')}</div>
        <h1>${step === 'done' ? `Thank you, ${esc(p.goesBy || p.name.split(' ')[0])}` : `Hi ${esc(p.goesBy || p.name.split(' ')[0])}`}</h1>
        <form class="ck-form" novalidate>${checkinStepHTML(step, v, p)}<p class="form-err" data-err></p>
          <div class="row end">${idx > 0 && step !== 'done' ? '<button type="button" class="btn secondary" data-ck-back>Back</button>' : ''}${step === 'done' ? '' : `<button class="btn primary">${step === 'forms' ? (checkinFormsLeft(v).length ? 'Sign later' : 'Finish') : 'Next'}</button>`}</div>
        </form>
      </div>`;
    const form = el.querySelector('form');
    wireRows(form);
    el.scrollTop = 0;
    wirePlangSwitch(el);
    el.querySelector('[data-ck-staff]').onclick = () => checkinExit(el, v);
    const bk = el.querySelector('[data-ck-back]'); if (bk) bk.onclick = () => show(CHECKIN_STEPS[idx - 1][0]);
    el.querySelectorAll('[data-ck-sign]').forEach(b => b.onclick = async () => {
      const ok = await signSheet(visit(v.id) || v, patient(v.patientId), b.dataset.ckSign);
      if (ok) toast('Signed. Thank you.');
      show('forms');
    });
    form.oninput = () => { form.querySelector('[data-err]').textContent = ''; };
    form.onsubmit = async e => {
      e.preventDefault();
      const err = m => { form.querySelector('[data-err]').textContent = m; };
      try {
        if (step === 'details' || step === 'health') {
          const rec = checkinRead(step, form, patient(v.patientId));
          if (typeof rec === 'string') return err(rec);
          await save('patients', rec, { action: 'Updated by the patient at check-in' });
        }
        show(CHECKIN_STEPS[idx + 1][0]);
      } catch (ex) { err(ex.message); }
    };
  };
  show(step);
}

function checkinStepHTML(step, v, p) {
  if (step === 'details') return `<p class="lead">Please check your details and fix anything that has changed.</p>
    <div class="card"><div class="ck-name">${esc(p.name)}</div>
      <div class="grid2">${field('What we call you', 'goesBy', p.goesBy, { ph: 'Kwan' })}${field('Date of birth', 'dob', p.dob, { type: 'date' })}</div>
      <div class="grid2">${field('Mobile', 'phone', p.phone, { type: 'tel', ph: '081 234 5678' })}${field('Email', 'email', p.email, { type: 'email', ph: 'kwan.c@gmail.com' })}</div>
      ${field('Address', 'address', p.address, { ph: '99/12 Sukhumvit 31, Khlong Toei, Bangkok 10110' })}
      <div class="grid2">${field('Sex', 'sex', p.sex, { type: 'select', options: ['Female', 'Male'] })}${field('Work', 'occupation', p.occupation, { ph: 'Teacher' })}</div></div>
    <div class="card"><h2 class="card-title">Who we call in an emergency</h2>
      ${rowsBlock('contacts', [{ k: 'name', label: 'Name', ph: 'Somchai Chaiyaporn' }, { k: 'relation', label: 'Relation', ph: 'Husband', w: '0.7fr' }, { k: 'phone', label: 'Phone', ph: '089 765 4321', type: 'tel' }], p.contacts, 'Add someone')}</div>`;
  if (step === 'health') { const sc = p.screen || {}; return `<p class="lead">These keep your treatment safe. Tell us everything, even if it seems small.</p>
    <div class="card"><h2 class="card-title">Allergies</h2>
      ${rowsBlock('allergies', [{ k: 'what', label: 'Allergic to', ph: 'Lidocaine, latex, a food' }, { k: 'reaction', label: 'What happens', ph: 'Hives and lip swelling' }], p.allergies, 'Add allergy')}
      ${field('I have no allergies that I know of', 'nka', p.nka, { type: 'check' })}</div>
    <div class="card"><h2 class="card-title">Medicines, vitamins and supplements</h2>
      ${rowsBlock('meds', [{ k: 'name', label: 'Name', ph: 'Losartan' }, { k: 'dose', label: 'Dose', ph: '50 mg', w: '0.6fr' }, { k: 'freq', label: 'How often', ph: 'Once a day' }], p.meds, 'Add medicine')}</div>
    <div class="card"><h2 class="card-title">Illnesses, operations and past treatments</h2>
      ${rowsBlock('conditions', [{ k: 'name', label: 'Illness', ph: 'Thyroid problem' }, { k: 'year', label: 'Since', ph: '2019', w: '0.4fr' }], p.conditions, 'Add illness')}
      <div style="height:12px"></div>
      ${rowsBlock('surgeries', [{ k: 'what', label: 'Operation or aesthetic treatment', ph: 'Nose implant' }, { k: 'year', label: 'Year', ph: '2021', w: '0.4fr' }], p.surgeries, 'Add one')}</div>
    <div class="card"><h2 class="card-title">Tick everything that is true for you</h2>
      <div class="checks">${SCREEN.map(s => `<label class="check"><input type="checkbox" name="sc_${s.k}" ${sc[s.k] ? 'checked' : ''}><span>${esc(s.label)}</span></label>`).join('')}</div>
      <div class="grid2" style="margin-top:8px">${field('Smoking', 'smoking', p.smoking, { ph: 'No, or how much' })}${field('Alcohol', 'alcohol', p.alcohol, { ph: 'No, or how often' })}</div></div>`; }
  if (step === 'forms') {
    const left = checkinFormsLeft(v), signed = (visit(v.id) || v).consents || [];
    return `<p class="lead">${left.length ? 'Please read each form and sign it on the screen. Ask us about anything that is not clear.' : 'Everything is signed.'}</p>
      <div class="card"><div class="list flat">${left.map(k => `<div class="li"><div class="grow"><div class="t medium">${esc(S.templates.consent[k].title)}</div></div><button type="button" class="btn primary small" data-ck-sign="${esc(k)}">Read and sign</button></div>`).join('')}
        ${signed.map(c => `<div class="li"><div class="grow"><div class="t">${esc(c.title)}</div></div><span class="chip ok">Signed</span></div>`).join('')}
        ${!left.length && !signed.length ? '<p class="muted">No forms are needed today.</p>' : ''}</div></div>`;
  }
  return `<p class="lead">You are all set. Please hand the tablet back to the front desk.</p>`;
}

// The patient's answers merged into the latest record; a string is an error to show.
function checkinRead(step, form, cur) {
  const rec = { ...cur, checkinAt: Date.now() };
  if (step === 'details') {
    for (const k of ['goesBy', 'dob', 'sex', 'phone', 'email', 'address', 'occupation']) rec[k] = val(form, k);
    if (!rec.phone) return 'Enter your mobile number so we can reach you.';
    rec.contacts = readRows(form, 'contacts');
  } else {
    rec.allergies = readRows(form, 'allergies');
    if (!rec.allergies.length && !val(form, 'nka')) return 'Add your allergies, or tick that you have none that you know of.';
    rec.nka = !rec.allergies.length;
    // Rows the patient left alone keep what the staff entered (severity, reasons, notes).
    const keep = (list, old, key) => list.map(x => ({ ...((old || []).find(o => o[key] && o[key] === x[key]) || {}), ...x }));
    rec.allergies = keep(rec.allergies, cur.allergies, 'what');
    rec.meds = keep(readRows(form, 'meds'), cur.meds, 'name');
    rec.conditions = keep(readRows(form, 'conditions'), cur.conditions, 'name');
    rec.surgeries = keep(readRows(form, 'surgeries'), cur.surgeries, 'what');
    rec.screen = Object.fromEntries(SCREEN.map(s => [s.k, val(form, 'sc_' + s.k)]).filter(x => x[1]));
    rec.smoking = val(form, 'smoking'); rec.alcohol = val(form, 'alcohol');
  }
  return rec;
}

// Only a staff PIN closes check-in. Someone else signing in ends it too.
function checkinExit(ck, v) {
  const el = document.createElement('div');
  el.className = 'lock';
  document.body.appendChild(el);
  const close = () => el.remove();
  pinPad(el, S.me, {
    title: 'Staff PIN to close check-in',
    onPin: async pin => {
      await api('/api/login', { userId: S.me.id, pin });
      stopEvents(); startEvents(); lastActive = Date.now();
      setCheckinFlag(null);
      el.remove(); ck.remove();
      toast('Check-in closed.');
      if (S.pendingGoto) { const g = S.pendingGoto; S.pendingGoto = null; go(g); }
      else if (location.hash === '#/visit/' + v.id) renderVisit(v.id); else go('#/visit/' + v.id);
    },
    back: () => { close(); setCheckinFlag(null); ck.remove(); lockNow(); },
    extra: '<button class="ghost" data-kiosk>Back to the patient</button>',
    onExtra: close,
  });
}
