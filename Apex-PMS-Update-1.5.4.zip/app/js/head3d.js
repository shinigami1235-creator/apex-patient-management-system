// The patient's 3D head: built on press from the standard photos, and the treatment
// chart drawn on it. The fit and bake live in js/head as modules and load only when
// someone builds a head or opens a 3D chart.

// ---------- head records ----------
const headsOf = pid => S.heads.filter(h => h.patientId === pid).sort((a, b) => (b.version || 0) - (a.version || 0));
const latestHead = pid => headsOf(pid)[0] || null;
const headThumbURL = (h, view) => (h && h.thumbs && h.thumbs[view] ? fileURL(h.thumbs[view]) : '');
const headLabel = h => h ? `Head ${h.version}` : 'No head';
function headPhotoViews(h) { return HEAD_VIEWS.filter(v => h.photos && h.photos[v.key]); }
function headPhotoText(h) {
  const n = headPhotoViews(h).length;
  const missing = HEAD_VIEWS.filter(v => !(h.photos && h.photos[v.key])).map(v => v.label.toLowerCase());
  return `${plural(n, 'photo')}${missing.length ? `, no ${missing.join(', ')}` : ''}`;
}

let headModules = null;
async function headView() {
  if (!headModules) headModules = import('/js/head/head-view.mjs');
  return headModules;
}

// A mark's 2D form for one standard view, for cards, prints and the treatment lines.
// Marks the view cannot see are left out.
function marksForView(marks, view) {
  const out = [];
  for (const m of marks) {
    if (m.anchors) {
      const pts = (m.projPts && m.projPts[view]) || [];
      const seen = pts.filter(q => q[2]);
      if (seen.length < Math.max(2, pts.length / 2)) continue;
      out.push({ ...m, pts: pts.map(q => [q[0], q[1]]) });
    } else if (m.anchor) {
      const q = m.proj && m.proj[view];
      if (!q || !q.visible) continue;
      out.push({ ...m, x: q.x, y: q.y });
    } else out.push(m);
  }
  return out;
}

// ---------- the build job ----------
// One build at a time on this device. It carries on while the user works on the rest of
// the visit, and the card it was started from shows how far it is.
let HEAD_JOB = null; // { patientId, visitId, text, error, head }
const headJobFor = visitId => (HEAD_JOB && HEAD_JOB.visitId === visitId ? HEAD_JOB : null);
const headBuilding = () => !!(HEAD_JOB && !HEAD_JOB.error && !HEAD_JOB.head);

// This visit's photo of each standard view: Before or Baseline first, then the earliest.
function visitHeadPhotos(v) {
  const rank = ph => (ph.stage === 'Before' || ph.stage === 'Baseline' ? 0 : 1);
  const out = {};
  for (const hv of HEAD_VIEWS) {
    const mine = S.photos.filter(ph => ph.visitId === v.id && ph.view === hv.photo).sort((a, b) => rank(a) - rank(b) || (a.created || 0) - (b.created || 0));
    out[hv.key] = mine.length ? mine[0].id : '';
  }
  return out;
}
// Why a head cannot be built from these photos, or '' when it can.
function headPhotoProblem(ids) {
  if (!HEAD_VIEWS.some(v => ids[v.key])) return 'No front, 45 or side photos yet. Add them under Photos.';
  if (!ids.front) return 'A front photo is needed.';
  if (!HEAD_VIEWS.some(v => v.key !== 'front' && ids[v.key])) return 'A front photo and at least one 45 or side photo are needed.';
  return '';
}
const missingViewText = (ids, views = HEAD_VIEWS) => { const m = views.filter(v => !ids[v.key]).map(v => v.label.toLowerCase()); return m.length ? `No ${m.length > 1 ? m.slice(0, -1).join(', ') + ' or ' + m[m.length - 1] : m[0]} photo. The head is built without ${m.length > 1 ? 'them' : 'it'}.` : ''; };
// Whether a head was built from any photo of this visit.
const headFromVisit = (h, v) => !!h && HEAD_VIEWS.some(hv => { const ph = h.photos && h.photos[hv.key] ? photoMeta(h.photos[hv.key]) : null; return ph && ph.visitId === v.id; });
function headPhotoDate(h) {
  const dates = HEAD_VIEWS.map(hv => (h.photos && h.photos[hv.key] ? photoMeta(h.photos[hv.key]) : null)).filter(Boolean).map(ph => ph.date).filter(Boolean).sort();
  return dates.length ? fmtDate(dates[dates.length - 1]) : '';
}

// Starts a build from this visit's photos. The chart on this visit moves to the new head
// only while it has no marks.
async function buildHeadFromVisit(v, p) {
  if (!can('clinical')) return;
  if (headBuilding()) { toast('A head is being built. Wait for it to finish.'); return; }
  const ids = visitHeadPhotos(v);
  const why = headPhotoProblem(ids);
  if (why) { toast(why); return; }
  HEAD_JOB = { patientId: p.id, visitId: v.id, text: 'Starting', error: '', head: null };
  const paint = () => { const el = document.querySelector(`[data-head-job="${v.id}"]`); if (el) el.textContent = HEAD_JOB.text; };
  try {
    const h = await buildHeadRecord(p, ids, t => { HEAD_JOB.text = t; paint(); });
    HEAD_JOB.head = h;
    const c = S.charts.find(x => x.visitId === v.id && x.view === HEAD_CHART.key);
    if (c && !(c.marks || []).length && !visit(v.id).signedAt) await save('charts', { ...c, base: { type: 'head', headId: h.id } }, { action: 'Chart moved to ' + headLabel(h) });
    toast(`${headLabel(h)} built.`);
  } catch (e) {
    console.error(e);
    HEAD_JOB.error = e.message || 'The head could not be built.';
  }
  repaintHeadCard(v.id);
}
// Redraws only the head card when its visit is on screen, so typing elsewhere on the
// page is left alone.
function repaintHeadCard(visitId) {
  const { parts } = route();
  const old = document.querySelector('.chart-card:has([data-chart="head"])');
  if (!old || parts[0] !== 'visit' || parts[1] !== visitId) return;
  const v = visit(visitId), p = patient(v.patientId);
  old.insertAdjacentHTML('afterend', headChartCard(v, p));
  old.remove();
  document.querySelector('[data-chart="head"]').onclick = e => { e.preventDefault(); openChart(v.id, HEAD_CHART.key).catch(fail); };
  wireHeadChartCard(v, p);
}

// ---------- the chart card on the visit page ----------
function headChartCard(v, p) {
  const c = S.charts.find(x => x.visitId === v.id && x.view === HEAD_CHART.key);
  const head = c ? byId('heads', c.base.headId) : latestHead(p.id);
  const locked = !!v.signedAt;
  const job = headJobFor(v.id);
  const ids = visitHeadPhotos(v);
  const why = headPhotoProblem(ids);
  const canBuild = !locked && !why && can('clinical') && p.photoConsent !== 'no';
  const fromVisit = headFromVisit(head, v);
  const lines = c ? linesFromMarks(c.marks || []) : [];
  const marked = !!(c && (c.marks || []).length);
  // the picture and its caption, which open the chart
  const pic = c ? chartSVG(c, chartThumbURL(c), 'preserveAspectRatio="xMidYMid meet"') : `<div class="ph-blank">${locked ? 'No chart' : 'Start chart'}</div>`;
  let sub = '';
  if (c) sub = lines.length ? lines.map(l => `${l.product || KINDS[l.kind].short} ${trimNum(l.amount)} ${l.unit}`).join(', ') : 'No treatment marks';
  else if (head) sub = headLabel(head);
  else sub = locked ? 'No head built' : why ? why : 'No head yet';
  // the foot: the build, what the head was built from, and the view the card shows
  let foot = '';
  if (job && !job.head && !job.error) foot = `<div class="progress-line"><span class="spin"></span><span data-head-job="${v.id}">${esc(job.text)}</span></div>`;
  else if (job && job.error) foot = `<p class="form-err">${esc(job.error)}</p><button class="btn secondary small" data-act="build-head-visit">Try again</button>`;
  else if (!head && canBuild) foot = `${ids.front && HEAD_VIEWS.slice(0, 3).every(x => ids[x.key]) ? '' : `<p class="meta">${esc(missingViewText(ids, HEAD_VIEWS.slice(0, 3)))}</p>`}<button class="btn primary small" data-act="build-head-visit">Build head</button>`;
  else if (head && !fromVisit && !marked && canBuild) foot = `<p class="meta">${esc(headLabel(head))} is from the photos of ${esc(headPhotoDate(head) || 'an earlier visit')}.</p><button class="btn secondary small" data-act="build-head-visit">Rebuild from this visit</button>`;
  else if (head && !fromVisit && marked && !locked) foot = `<p class="meta">Drawn on ${esc(headLabel(head))}, built from the photos of ${esc(headPhotoDate(head) || 'an earlier visit')}.</p>`;
  if (c && !locked) foot += `<label class="hd-shot"><span class="meta">Card shows</span><select data-act="head-shot" aria-label="View on the card">${HEAD_VIEWS.map(x => `<option value="${x.key}" ${(c.shot || 'front') === x.key ? 'selected' : ''}>${x.label}</option>`).join('')}</select></label>`;
  return `<div class="chart-card ${c ? '' : 'blank'}"><button class="chart-open" data-chart="${HEAD_CHART.key}">${pic}<div class="cap"><b>${HEAD_CHART.label}${c && head ? ` <span class="meta">${esc(headLabel(head))}</span>` : ''}</b><span class="meta">${esc(sub)}</span></div></button>${foot ? `<div class="chart-foot">${foot}</div>` : ''}</div>`;
}
function wireHeadChartCard(v, p) {
  const b = document.querySelector('[data-act="build-head-visit"]');
  if (b) b.onclick = () => { buildHeadFromVisit(visit(v.id), patient(p.id)); repaintHeadCard(v.id); };
  const s = document.querySelector('[data-act="head-shot"]');
  if (s) s.onchange = async () => {
    const c = S.charts.find(x => x.visitId === v.id && x.view === HEAD_CHART.key);
    if (!c) return;
    try { await save('charts', { ...c, shot: s.value }, { action: 'Chart card view set' }); renderVisit(v.id); } catch (e) { fail(e); }
  };
}

// ---------- building ----------
// The patient's photos of one standard view, newest first. A visit's own photos come first.
function headPhotoChoices(p, viewKey, visitId) {
  const want = HEAD_VIEWS.find(v => v.key === viewKey).photo;
  const list = photosOf(p.id).filter(ph => ph.view === want);
  if (visitId) list.sort((a, b) => (b.visitId === visitId) - (a.visitId === visitId));
  return list;
}
function photoChoiceLabel(ph) { return [fmtDate(ph.date), ph.stage, ph.area].filter(Boolean).join(' · '); }

function headSlotHTML(p, v, visitId, chosen) {
  const list = headPhotoChoices(p, v.key, visitId);
  const cur = chosen ? byId('photos', chosen) : null;
  return `<div class="hd-slot" data-slot="${v.key}">
    <div class="hd-slot-pic">${cur ? `<img src="${thumbURL(cur.id)}" alt="${esc(v.label)}">` : `<span>No ${esc(v.label.toLowerCase())} photo</span>`}</div>
    <label class="field"><span class="label">${esc(v.label)}</span><select name="ph_${v.key}" ${list.length ? '' : 'disabled'}>${list.length ? '' : '<option value="">None</option>'}${list.map(ph => `<option value="${ph.id}" ${ph.id === chosen ? 'selected' : ''}>${esc(photoChoiceLabel(ph))}</option>`).join('')}${list.length ? '<option value="">Leave out</option>' : ''}</select></label>
  </div>`;
}

// Opens the build sheet. Resolves with the new head record, or null.
// The photos picked on the build sheet. Front and 45s leaves the side photos out.
function headIdsFrom(form) {
  const ids = {};
  for (const v of HEAD_VIEWS) ids[v.key] = val(form, 'ph_' + v.key);
  if (val(form, 'use') !== 'all') { ids.right = ''; ids.left = ''; }
  return ids;
}
async function buildHeadSheet(p, { visitId = '' } = {}) {
  if (!can('clinical')) return null;
  if (p.photoConsent === 'no') { toast('The patient declined photos.'); return null; }
  if (headBuilding()) { toast('A head is being built. Wait for it to finish.'); return null; }
  const chosen = {};
  for (const v of HEAD_VIEWS) { const list = headPhotoChoices(p, v.key, visitId); chosen[v.key] = list.length ? list[0].id : ''; }
  const have = HEAD_VIEWS.filter(v => chosen[v.key]);
  if (!have.length) { toast('No front, 45 or side photos yet. Add them under Photos on a visit.'); return null; }
  const prev = latestHead(p.id);
  let result = null;
  await sheet({
    title: prev ? 'Rebuild head' : 'Build head', submit: prev ? 'Rebuild head' : 'Build head', wide: true,
    body: `<p class="muted">The latest photo of each view is picked. Change any of them, then press ${prev ? 'Rebuild' : 'Build'} head. A build takes a minute or two on the branch PC and longer on a tablet.</p>
      ${field('Photos to use', 'use', 'f45', { type: 'select', blank: false, options: [['f45', 'Front and both 45s'], ['all', 'All five, the sides too']], hint: 'The side photos often catch the ear and the wall behind. The head stops just in front of the ear either way.' })}
      <div class="hd-slots">${HEAD_VIEWS.map(v => headSlotHTML(p, v, visitId, chosen[v.key])).join('')}</div>
      <p class="meta" data-missing></p>
      <div class="progress-line hidden" data-progress><span class="spin"></span><span data-progress-text></span></div>`,
    onOpen: form => {
      const upd = () => {
        const ids = headIdsFrom(form);
        const sides = val(form, 'use') === 'all';
        form.querySelectorAll('[data-slot="right"], [data-slot="left"]').forEach(x => { x.hidden = !sides; });
        form.querySelector('[data-missing]').textContent = missingViewText(ids, sides ? HEAD_VIEWS : HEAD_VIEWS.slice(0, 3));
        for (const v of HEAD_VIEWS) {
          const id = val(form, 'ph_' + v.key), pic = form.querySelector(`[data-slot="${v.key}"] .hd-slot-pic`);
          pic.innerHTML = id ? `<img src="${thumbURL(id)}" alt="${esc(v.label)}">` : `<span>No ${esc(v.label.toLowerCase())} photo</span>`;
        }
      };
      form.querySelectorAll('select').forEach(s => s.onchange = upd);
      upd();
    },
    validate: async form => {
      const ids = headIdsFrom(form);
      const why = headPhotoProblem(ids);
      if (why) return why;
      const box = form.querySelector('[data-progress]'), txt = form.querySelector('[data-progress-text]');
      box.classList.remove('hidden');
      form.querySelectorAll('select').forEach(s => s.disabled = true);
      HEAD_JOB = { patientId: p.id, visitId: '', text: 'Starting', error: '', head: null };
      try {
        result = await buildHeadRecord(p, ids, t => { HEAD_JOB.text = t; txt.textContent = t; });
        HEAD_JOB.head = result;
        return '';
      } catch (e) {
        console.error(e);
        HEAD_JOB.error = e.message || 'The head could not be built.';
        box.classList.add('hidden');
        form.querySelectorAll('select').forEach(s => s.disabled = false);
        return HEAD_JOB.error;
      }
    },
  });
  if (result) toast(`${headLabel(result)} built.`);
  return result;
}

// Asked during a build when a side photo faces the other way from the slot it is in.
async function askSidesSwapped(wrong) {
  const label = k => (HEAD_VIEWS.find(v => v.key === k) || {}).label || k;
  const pair = wrong.length === 2 && wrong[0].looksLike === wrong[1].key;
  const side = k => (/^right/.test(k) ? 'right' : 'left');
  const body = pair ? `The ${label(wrong[0].key)} photo shows the ${side(wrong[1].key)} side of the face and the ${label(wrong[1].key)} photo shows the ${side(wrong[0].key)} side. They look filed in each other's place.`
    : wrong.map(w => `The ${label(w.key)} photo shows the ${side(w.looksLike)} side of the face.`).join(' ');
  const r = await ask({ title: pair ? 'These two look swapped' : 'This photo looks misfiled', body: `<p>${esc(body)}</p><p class="meta">Switching also changes the view on the photo records, so the 2D charts use them right.</p>`,
    buttons: [{ label: 'Build as filed', value: 'keep' }, { label: pair ? 'Switch them' : `Move it to ${label(wrong[0].looksLike)}`, value: 'swap', kind: 'primary' }] });
  return r === 'swap' ? 'swap' : 'keep';
}

// Runs the build, stores the files and saves the head record.
async function buildHeadRecord(p, photoIds, progress) {
  progress('Loading the 3D tools');
  let HB, HV;
  try { [HB, HV] = await Promise.all([import('/js/head/head-build.mjs'), headView()]); }
  catch (e) { console.error(e); throw new Error('The 3D tools could not be loaded on this device. ' + (e.message || '')); }
  HB.configure({ atlasW: headAtlasMax(), photoMax: smallDevice() ? 1600 : 2048 });
  const photos = {};
  for (const [k, id] of Object.entries(photoIds)) if (id) photos[k] = fullURL(id);
  const r = await HB.buildHead(photos, { progress, onSides: wrong => askSidesSwapped(wrong) });
  // Photos filed the wrong way round move to the slot they face, here and on their records.
  if (r.moved && Object.keys(r.moved).length) {
    const was = { ...photoIds };
    for (const [to, from] of Object.entries(r.moved)) photoIds[to] = was[from];
    for (const from of Object.values(r.moved)) if (!r.moved[from]) photoIds[from] = '';
    for (const [to, from] of Object.entries(r.moved)) {
      const ph = byId('photos', was[from]), hv = HEAD_VIEWS.find(v => v.key === to);
      if (ph && hv && ph.view !== hv.photo) await save('photos', { ...ph, view: hv.photo }, { action: `Photo filed as ${hv.photo}, since it faces that way` });
    }
  }
  progress('Saving the head');
  const files = { mesh: await uploadFile(HB.meshBlob(r.mesh, r.lm3)) };
  const atlas = await HB.atlasBlobs(HB.atlasCanvas(r.mesh));
  files.atlas = await uploadFile(atlas.atlas);
  files.alpha = await uploadFile(atlas.alpha);
  const shots = await HV.standardShots(r.mesh);
  const thumbs = {};
  for (const [k, blob] of Object.entries(shots)) thumbs[k] = await uploadFile(blob);
  const rec = { id: uid(), patientId: p.id, built: Date.now(), builtBy: S.me.id, photos: photoIds, files, thumbs, stats: r.stats, missing: r.missing, noFace: r.noFace };
  return save('heads', rec, { action: 'Head built' });
}

// ---------- the patient's 3D head tab ----------
function patientHeadTab(p) {
  const heads = headsOf(p.id);
  const btn = `<button class="btn primary" data-act="build-head">${heads.length ? 'Rebuild head' : 'Build head'}</button>`;
  if (!heads.length) return empty('No 3D head yet.', 'It is built from the front, 45 and side photos on the visits.', btn);
  const row = h => `<div class="hd-thumbs">${HEAD_VIEWS.map(v => h.thumbs && h.thumbs[v.key] ? `<img src="${headThumbURL(h, v.key)}" alt="${esc(v.label)}" title="${esc(v.label)}">` : '').join('')}</div>`;
  const meta = h => `${headLabel(h)} · built ${fmtStamp(h.built)} by ${esc(userName(h.builtBy))} · ${esc(headPhotoText(h))}${(h.noFace || []).length ? ` · no face found in the ${h.noFace.map(k => (HEAD_VIEWS.find(v => v.key === k) || {}).label || k).join(', ').toLowerCase()} photo, its outline was used` : ''}`;
  const used = h => S.charts.filter(c => c.base && c.base.headId === h.id).length;
  const [latest, ...older] = heads;
  return `<div class="card"><div class="card-head"><h2>${esc(headLabel(latest))}</h2>${btn}</div>
      <p class="meta">${meta(latest)}${used(latest) ? ` · ${plural(used(latest), 'chart')}` : ''}</p>${row(latest)}</div>
    ${older.length ? `<details class="card"><summary class="link-summary"><b>Older heads</b> <span class="meta">${older.length}</span></summary>
      ${older.map(h => `<div class="hd-old"><p class="meta">${meta(h)}${used(h) ? ` · ${plural(used(h), 'chart')}` : ''}</p>${row(h)}</div>`).join('')}
      <p class="meta">A chart keeps the head it was drawn on.</p></details>` : ''}`;
}
function wirePatientHeadTab(p) {
  const b = document.querySelector('[data-act="build-head"]');
  if (b) b.onclick = async () => { const h = await buildHeadSheet(p); if (h) renderPatient(p.id, 'head'); };
}

// ---------- the 3D chart editor ----------
async function openHeadChart(visitId) {
  const v = visit(visitId), p = patient(v.patientId);
  const existing = S.charts.find(c => c.visitId === visitId && c.view === HEAD_CHART.key);
  let head = existing ? byId('heads', existing.base.headId) : latestHead(p.id);
  if (existing && !head) { toast('The head this chart was drawn on is missing.'); return; }
  if (!head) {
    if (v.signedAt) { toast('No head built for this patient.'); return; }
    const r = await ask({ title: 'No 3D head yet', body: 'Build one from the front, 45 and side photos.', buttons: [{ label: 'Cancel', value: null }, { label: 'Build head', value: true, kind: 'primary' }] });
    if (!r) return;
    head = await buildHeadSheet(p, { visitId });
    if (!head) return;
  }
  const chart = existing ? JSON.parse(JSON.stringify(existing)) : { id: uid(), patientId: p.id, visitId, view: HEAD_CHART.key, base: { type: 'head', headId: head.id }, shot: 'front', marks: [], dilution: { units: 100, ml: 2.5 } };
  if (!chart.dilution) chart.dilution = { units: 100, ml: 2.5 };
  chart.w = 600; chart.h = 800;
  const wait = document.createElement('div');
  wait.className = 'editor'; wait.id = 'editor';
  wait.innerHTML = `<div class="ed-top"><div class="ttl">${esc(HEAD_CHART.label)} chart · ${esc(p.name)}</div></div><div class="hd-loading"><span class="spin"></span>Loading the head</div>`;
  document.body.appendChild(wait);
  let HV, loaded;
  try {
    HV = await headView();
    loaded = await HV.loadHeadFiles({ meshUrl: fileURL(head.files.mesh), atlasUrl: fileURL(head.files.atlas), alphaUrl: fileURL(head.files.alpha), maxAtlas: headAtlasMax() });
  } catch (e) { wait.remove(); fail(e); return; }
  const saved = (S.editorSettings && S.editorSettings.tools) || null;
  const mesh = HV.headMesh(loaded);
  E = {
    kind: 'head', v, p, chart, head, HV, mesh, viewer: null, isNew: !existing, tool: 'toxin', sel: -1, undo: [], redo: [], dirty: false, zoom: 1, penSeen: false,
    tools: saved || defaultToolSettings(), readOnly: !!v.signedAt || !can('edit'), az: 0, el: 0,
    render: hdRender, redraw: hdDrawMarks, sideRefresh: hdSideRefresh, dispose: () => { if (E.viewer) E.viewer.dispose(); if (E.ro) E.ro.disconnect(); },
  };
  wait.innerHTML = '';
  wait.setAttribute('role', 'dialog'); wait.setAttribute('aria-label', 'Treatment chart');
  document.addEventListener('keydown', edKeys);
  hdRender();
}

// The stage and its viewer are built once. After that a render refreshes the tools, the
// side panel and the marks, since a new canvas would mean a new WebGL context each time.
function hdRender() {
  const root = document.getElementById('editor');
  if (!root) return;
  if (root.querySelector('#hdcanvas') && E.viewer) {
    root.querySelectorAll('[data-tool]').forEach(b => b.setAttribute('aria-pressed', E.tool === b.dataset.tool));
    root.querySelectorAll('[data-tech]').forEach(b => b.setAttribute('aria-pressed', E.tool === 'filler' && fillerTech(E.tools.filler) === b.dataset.tech));
    const u = root.querySelector('[data-ed="undo"]'), r = root.querySelector('[data-ed="redo"]');
    if (u) u.disabled = !E.undo.length;
    if (r) r.disabled = !E.redo.length;
    hdSideRefresh(); hdDrawMarks();
    return;
  }
  const { v, p, chart, head } = E;
  const ro = E.readOnly;
  const toolBtn = (k, label, icon) => `<button class="tool" data-tool="${k}" aria-pressed="${E.tool === k}" title="${label}">${icon}<span>${label}</span></button>`;
  const az = E.viewer ? E.viewer.V.az : 0, el = E.viewer ? E.viewer.V.el : 0;
  root.innerHTML = `
    <div class="ed-top">
      <button class="btn secondary small" data-ed="close">Back</button>
      <div class="ttl">${esc(HEAD_CHART.label)} chart · ${esc(p.name)}<small>${fmtDate(v.date)} · ${esc(headLabel(head))}${ro ? ' · signed, view only' : ''}</small></div>
      <span class="spacer"></span>
      <div class="seg" role="group" aria-label="Chart view">${CHART_VIEWS.map(x => `<button data-ed="view" data-view="${x.key}" aria-pressed="false">${x.label}</button>`).join('')}<button data-ed="view" data-view="${HEAD_CHART.key}" aria-pressed="true">${HEAD_CHART.label}</button></div>
      <button class="btn secondary small" data-ed="print">Print</button>
      <button class="btn secondary small ed-side-toggle" data-ed="side">Settings</button>
      ${ro ? '' : `<button class="btn primary small" data-ed="save">Save</button>`}
    </div>
    <div class="ed-body">
      <div class="ed-tools" role="toolbar" aria-label="Tools">
        ${toolBtn('select', 'Select', TOOL_ICONS.select)}
        ${toolBtn('hand', 'Turn', TOOL_ICONS.hand)}
        ${ro ? edReopenTool() : `<hr>
        ${drawToolsHTML(toolBtn)}
        <hr>
        ${toolBtn('pen', 'Pen', TOOL_ICONS.pen)}
        ${toolBtn('text', 'Text', TOOL_ICONS.text)}
        ${toolBtn('erase', 'Erase', TOOL_ICONS.erase)}
        <hr>
        <button class="tool" data-ed="undo" ${E.undo.length ? '' : 'disabled'}>${TOOL_ICONS.undo}<span>Undo</span></button>
        <button class="tool" data-ed="redo" ${E.redo.length ? '' : 'disabled'}>${TOOL_ICONS.redo}<span>Redo</span></button>`}
      </div>
      <div class="ed-stage hd-stage">
        <canvas id="hdcanvas"></canvas>
        <svg class="board hd-board" id="board" xmlns="http://www.w3.org/2000/svg"><g id="marks"></g><polyline id="live" fill="none" stroke="#1F5E99" stroke-width="2" stroke-dasharray="6 4" points=""/></svg>
        <div class="seg hd-views" role="group" aria-label="Standard view">${HEAD_VIEWS.map(x => `<button data-ed="angle" data-view="${x.key}" aria-pressed="${hdViewKey(az, el) === x.key}">${x.label}</button>`).join('')}</div>
        <div class="ed-zoom"><button data-ed="zoom-out" aria-label="Zoom out">−</button><button data-ed="fit" aria-label="Fit to screen">⤢</button><button data-ed="zoom-in" aria-label="Zoom in">+</button></div>
      </div>
      <aside class="ed-side" id="edside">${hdSide()}</aside>
    </div>`;
  hdMount(root);
  hdWire(root);
  besideRefresh();
}

// Tablets and phones get the head's texture at half size for viewing, since the full
// 4096 atlas and its copies take more memory than a tablet browser allows a page.
function smallDevice() {
  try { return matchMedia('(pointer: coarse)').matches || (navigator.deviceMemory && navigator.deviceMemory <= 4); } catch (e) { return false; }
}
const headAtlasMax = () => (smallDevice() ? 2048 : 4096);

// Which standard view the camera is on, or '' between them.
function hdViewKey(az, el) {
  if (Math.abs(el) > 1) return '';
  const v = HEAD_VIEWS.find(x => Math.abs(((az - E.HV.STD_VIEWS.find(s => s.key === x.key).az + 540) % 360) - 180) < 1);
  return v ? v.key : '';
}

// The viewer on the stage canvas, sized to the stage.
function hdMount(root) {
  const canvas = root.querySelector('#hdcanvas'), stage = root.querySelector('.hd-stage');
  const keep = E.viewer ? { az: E.viewer.V.az, el: E.viewer.V.el, zoom: E.viewer.V.zoom } : { az: 0, el: 0, zoom: E.zoom };
  if (E.viewer) E.viewer.dispose();
  if (E.ro) E.ro.disconnect();
  E.viewer = E.HV.makeViewer(canvas, E.mesh, { bg: 0xffffff });
  E.viewer.setAngles(keep.az, keep.el); E.viewer.setZoom(keep.zoom);
  const fit = () => {
    const w = stage.clientWidth, h = stage.clientHeight;
    if (!w || !h) return;
    E.viewer.size(w, h);
    const board = root.querySelector('#board');
    board.setAttribute('viewBox', `0 0 ${w} ${h}`);
    board.style.width = w + 'px'; board.style.height = h + 'px';
    hdDraw();
  };
  E.ro = new ResizeObserver(fit);
  E.ro.observe(stage);
  fit();
}

function hdDraw() {
  if (!E || !E.viewer) return;
  E.viewer.render();
  hdDrawMarks();
}

// Marks in the picture as the camera stands now.
function hdMarks2D(marks = E.chart.marks, vw = E.viewer) {
  return marks.map(m => {
    if (m.anchors) {
      const pts = m.anchors.map(a => vw.project(a.p, a.n));
      if (pts.filter(q => q.visible).length < Math.max(2, pts.length / 2)) return { t: 'hidden' };
      return { ...m, pts: pts.map(q => [q.x, q.y]) };
    }
    if (m.anchor) {
      const q = vw.project(m.anchor.p, m.anchor.n);
      return q.visible ? { ...m, x: q.x, y: q.y } : { t: 'hidden' };
    }
    return m;
  });
}
function hdDrawMarks() {
  const g = document.getElementById('marks');
  if (!g || !E.viewer) return;
  const { w, h } = E.viewer.V;
  g.innerHTML = marksSVG(hdMarks2D(), w, h, { selected: E.sel });
}

// Projections of a mark into each standard picture, stored with it.
function hdProjectMark(m, vw = E.viewer) {
  if (m.anchors) {
    m.projPts = {};
    for (const sv of HEAD_VIEWS) m.projPts[sv.key] = m.anchors.map(a => { const q = vw.projectInView(sv.key, a.p, a.n); return [q.x, q.y, q.visible ? 1 : 0]; });
  } else if (m.anchor) {
    m.proj = {};
    for (const sv of HEAD_VIEWS) m.proj[sv.key] = vw.projectInView(sv.key, m.anchor.p, m.anchor.n);
  }
  return m;
}

function hdSide() {
  let h = `<button class="btn secondary small ed-side-close" data-ed="side">Close</button>` + edToolPanel() + templatesPanelHTML() + besideFieldHTML();
  h += `<h3 style="margin-top:16px">Head</h3><p class="meta">${esc(headLabel(E.head))}, built ${fmtStamp(E.head.built)} from ${esc(headPhotoText(E.head))}.</p>`;
  const latest = latestHead(E.p.id);
  if (latest && latest.id !== E.head.id) h += `<p class="meta">This chart was drawn on ${esc(headLabel(E.head))}, and ${esc(headLabel(latest))} is the latest.</p>`;
  if (!E.readOnly) h += `<div class="row"><button class="btn secondary small" data-ed="rebuild">Rebuild head</button></div>`;
  if (!E.readOnly) h += `<label class="field" style="margin-top:12px"><span class="label">Card shows</span><select data-shot>${HEAD_VIEWS.map(x => `<option value="${x.key}" ${(E.chart.shot || 'front') === x.key ? 'selected' : ''}>${x.label}</option>`).join('')}</select><span class="hint">The view on the visit page.</span></label>`;
  return h;
}

function hdWire(root) {
  root.querySelectorAll('[data-tool]').forEach(b => b.onclick = () => { E.tool = b.dataset.tool; E.sel = -1; hdRender(); });
  root.querySelectorAll('[data-tech]').forEach(b => b.onclick = () => setFillerTech(b.dataset.tech));
  root.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => hdAction(b.dataset.ed, b));
  const side = root.querySelector('#edside');
  side.addEventListener('change', e => { if (e.target.matches('[data-shot]')) { E.chart.shot = e.target.value; E.dirty = true; return; } edSideChange(e); });
  side.addEventListener('input', e => { if (e.target.matches('input[data-set], [data-dil]')) edSideChange(e); });
  side.addEventListener('focusin', e => { if (e.target.closest('[data-scope="mark"]') && e.target.matches('[data-set]')) edPush(); });
  hdWireColors(side);
  const stage = root.querySelector('.hd-stage');
  stage.addEventListener('wheel', e => { e.preventDefault(); E.viewer.setZoom(E.viewer.V.zoom * (e.deltaY < 0 ? 1.12 : 0.89)); hdDraw(); }, { passive: false });
  // Safari's own pinch would zoom the page under the head.
  for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) stage.addEventListener(ev, e => e.preventDefault(), { passive: false });
  const board = root.querySelector('#board');
  hdWirePointers(board);
  board.addEventListener('pointerdown', hdDown);
  // A touch on the head closes the settings drawer on a narrow screen.
  board.addEventListener('pointerdown', () => side.classList.remove('open'), true);
}
function hdWireColors(side) {
  side.querySelectorAll('[data-color]').forEach(b => b.onclick = () => {
    const scope = b.closest('[data-scope]').dataset.scope;
    if (scope === 'mark') { edPush(); E.chart.marks[E.sel].color = b.dataset.color; } else E.tools[E.tool].color = b.dataset.color;
    hdRender();
  });
}
function hdSideRefresh() {
  const side = document.getElementById('edside');
  side.innerHTML = hdSide();
  side.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => hdAction(b.dataset.ed, b));
  hdWireColors(side);
}

async function hdAction(a, b) {
  const c = E.chart;
  if (a === 'reopen') return edReopen();
  if (a === 'tpl') return applyTemplate(b.dataset.id);
  if (a === 'tpl-save') return saveTemplateSpots();
  if (a === 'tpl-reset') return resetTemplateSpots();
  if (a === 'close') {
    if (E.dirty && !E.readOnly) {
      const r = await ask({ title: 'Save the chart?', body: 'The changes on this chart are not saved yet.', buttons: [{ label: 'Discard', value: 'discard', kind: 'danger' }, { label: 'Cancel', value: null }, { label: 'Save', value: 'save', kind: 'primary' }] });
      if (!r) return;
      if (r === 'save') await hdSave();
    }
    edClose(); render();
  } else if (a === 'save') { await hdSave(); toast('Chart saved.'); hdRender(); }
  else if (a === 'view') {
    const view = b.dataset.view;
    if (view === HEAD_CHART.key) return;
    const blocked = chartViewBlocked(E.v.id, view);
    if (blocked) { toast(blocked); return; }
    if (E.dirty && !E.readOnly) await hdSave();
    const vid = E.v.id;
    edClose(); await openChart(vid, view);
  }
  else if (a === 'angle') { E.viewer.setView(b.dataset.view); hdDraw(); document.querySelectorAll('.hd-views button').forEach(x => x.setAttribute('aria-pressed', x === b)); E.besideView = b.dataset.view; if (E.beside === 'photo') besideRefresh(); }
  else if (a === 'undo') edUndo();
  else if (a === 'redo') edRedo();
  else if (a === 'del') edDelete(E.sel);
  else if (a === 'desel') { E.sel = -1; hdRender(); }
  else if (a === 'zoom-in') { E.viewer.setZoom(E.viewer.V.zoom * 1.25); hdDraw(); }
  else if (a === 'zoom-out') { E.viewer.setZoom(E.viewer.V.zoom / 1.25); hdDraw(); }
  else if (a === 'fit') { E.viewer.setZoom(1); hdDraw(); }
  else if (a === 'side') document.getElementById('edside').classList.toggle('open');
  else if (a === 'print') printHeadChart(E.chart, E.v, E.p);
  else if (a === 'rebuild') {
    const h = await buildHeadSheet(E.p, { visitId: E.v.id });
    if (!h) return;
    if (c.marks.length) { toast(`${headLabel(h)} built. This chart stays on ${headLabel(E.head)}.`); hdSideRefresh(); return; }
    if (E.dirty) await hdSave();
    const vid = E.v.id;
    edClose(); await openHeadChart(vid);
  }
}

async function hdSave() {
  const c = E.chart;
  if (E.isNew && !c.marks.length) { E.dirty = false; return; }
  await save('charts', { ...c }, { action: E.isNew ? 'Chart started' : 'Chart edited' });
  E.isNew = false; E.dirty = false;
  await syncChartLines(E.v.id);
  E.v = visit(E.v.id);
}

// ---------- pointer input ----------
// One finger or the mouse: a tap places a mark, a drag draws, and in Turn mode a drag
// turns the head. Two fingers: pinch to zoom and drag to turn, whatever the tool.
function hdPointerGone(e) {
  if (!E || !E.ptrs) return;
  E.ptrs.delete(e.pointerId);
  if (!E.ptrs.size) E.multi = false;
}
// Every lifted or cancelled pointer leaves the set, whichever gesture it was part of.
function hdWirePointers(board) {
  board.addEventListener('pointerup', hdPointerGone);
  board.addEventListener('pointercancel', hdPointerGone);
}
function hdTwoFinger(board) {
  const vw = E.viewer;
  const ids = [...E.ptrs.keys()];
  const at = () => ids.map(i => E.ptrs.get(i));
  const [a0, b0] = at();
  const d0 = Math.max(10, Math.hypot(b0[0] - a0[0], b0[1] - a0[1]));
  const m0 = [(a0[0] + b0[0]) / 2, (a0[1] + b0[1]) / 2];
  const az0 = vw.V.az, el0 = vw.V.el, z0 = vw.V.zoom;
  E.multi = true; E.multiSeq = (E.multiSeq || 0) + 1;
  document.getElementById('live').setAttribute('points', '');
  const move = ev => {
    if (!E.ptrs.has(ev.pointerId)) return;
    E.ptrs.set(ev.pointerId, [ev.clientX, ev.clientY]);
    if (ids.some(i => !E.ptrs.has(i))) return;
    const [a, b] = at();
    const d = Math.hypot(b[0] - a[0], b[1] - a[1]), m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    vw.setZoom(z0 * d / d0);
    vw.setAngles(az0 - (m[0] - m0[0]) * 0.4, Math.max(-60, Math.min(60, el0 + (m[1] - m0[1]) * 0.3)));
    hdDraw();
    hdPressView();
  };
  const up = ev => {
    if (!ids.includes(ev.pointerId)) return;
    board.removeEventListener('pointermove', move);
    board.removeEventListener('pointerup', up);
    board.removeEventListener('pointercancel', up);
  };
  board.addEventListener('pointermove', move);
  board.addEventListener('pointerup', up);
  board.addEventListener('pointercancel', up);
}
function hdPressView() {
  const vw = E.viewer, k = hdViewKey(vw.V.az, vw.V.el);
  document.querySelectorAll('.hd-views button').forEach(x => x.setAttribute('aria-pressed', x.dataset.view === k));
}

function hdDown(e) {
  if (!E || !E.viewer) return;
  const board = e.currentTarget, vw = E.viewer;
  e.preventDefault();
  board.setPointerCapture(e.pointerId);
  if (!E.ptrs) E.ptrs = new Map();
  E.ptrs.set(e.pointerId, [e.clientX, e.clientY]);
  if (E.ptrs.size === 2) { hdTwoFinger(board); return; }
  if (E.ptrs.size > 2 || E.multi) return;
  if (e.pointerType === 'pen') E.penSeen = true;
  const hit = e.target.closest('[data-i]');
  const hitI = hit ? +hit.dataset.i : -1;
  const turn = E.tool === 'hand' || (E.penSeen && e.pointerType === 'touch') || e.button === 1 || (E.readOnly && E.tool !== 'select');
  const slack = e.pointerType === 'touch' ? 8 : 4;
  const seq0 = E.multiSeq || 0;
  const start = toNorm(e);
  const sx = e.clientX, sy = e.clientY, az0 = vw.V.az, el0 = vw.V.el;
  const anchors = [];
  const first = vw.pick(start[0], start[1]);
  if (first) anchors.push(first);
  let moved = false;
  const live = document.getElementById('live');
  const sel0 = E.sel;
  let dragOrig = null;
  const drawing = ['filler', 'booster', 'device', 'thread', 'pen'].includes(E.tool);

  if (!turn && E.tool === 'select' && hitI >= 0) {
    E.sel = hitI;
    dragOrig = JSON.parse(JSON.stringify(E.chart.marks[hitI]));
    if (sel0 !== hitI) { hdDrawMarks(); hdSideRefresh(); }
  }

  const move = ev => {
    if (ev.pointerId !== e.pointerId || E.multi) return;
    if (Math.hypot(ev.clientX - sx, ev.clientY - sy) > slack) moved = true;
    if (turn) {
      vw.setAngles(az0 - (ev.clientX - sx) * 0.4, Math.max(-60, Math.min(60, el0 + (ev.clientY - sy) * 0.3)));
      hdDraw();
      hdPressView();
      return;
    }
    const q = toNorm(ev);
    if (E.tool === 'select' && dragOrig && !E.readOnly) {
      const m = E.chart.marks[E.sel];
      if (!m.anchor) return;
      const a = vw.pick(q[0], q[1]);
      if (a) { m.anchor = a; hdDrawMarks(); }
      return;
    }
    if (drawing) {
      const ce = ev.getCoalescedEvents ? ev.getCoalescedEvents() : [ev];
      for (const c of ce) {
        const f = toNorm(c), a = vw.pick(f[0], f[1]);
        if (!a) continue;
        const last = anchors[anchors.length - 1];
        if (last && Math.hypot(a.p[0] - last.p[0], a.p[1] - last.p[1], a.p[2] - last.p[2]) < 0.012) continue;
        anchors.push(a);
      }
      const { w, h } = vw.V;
      const shown = E.tool === 'filler' && fillerTech(E.tools.filler) === 'fan' && anchors.length > 1 ? [anchors[0], anchors[anchors.length - 1]] : anchors;
      live.setAttribute('points', shown.map(a => { const p2 = vw.screen(a.p); return `${(p2.x * w).toFixed(1)},${(p2.y * h).toFixed(1)}`; }).join(' '));
    }
  };
  const up = ev => {
    if (ev.pointerId !== e.pointerId) return;
    board.removeEventListener('pointermove', move);
    board.removeEventListener('pointerup', up);
    board.removeEventListener('pointercancel', up);
    live.setAttribute('points', '');
    if (turn || E.multi || (E.multiSeq || 0) !== seq0) return;
    const s = E.tools[E.tool];
    const base = () => { const l = s.lotId ? lot(s.lotId) : null, p = l ? product(l.productId) : null; return { t: E.tool, lotId: s.lotId || '', productId: p ? p.id : '', product: p ? p.name : (s.product || ''), unit: p ? p.unit : KINDS[E.tool].unit, amount: s.amount, area: s.area || '' }; };
    const add = m => { edPush(); E.chart.marks.push(hdProjectMark(m)); hdRender(); };
    if (E.tool === 'select') {
      if (dragOrig && moved && !E.readOnly) {
        const m = E.chart.marks[E.sel];
        if (m.anchor) { const after = JSON.stringify(hdProjectMark(m)); E.chart.marks[E.sel] = dragOrig; edPush(); E.chart.marks[E.sel] = JSON.parse(after); }
      }
      if (hitI < 0) E.sel = -1;
      hdRender();
      return;
    }
    if (E.tool === 'erase') { if (hitI >= 0) edDelete(hitI); return; }
    if (!first) { if (!moved) toast('Tap on the head.'); return; }
    if (E.tool === 'toxin') {
      if (moved && anchors.length > 3) return;
      add({ ...base(), anchor: first }); return;
    }
    const tech = E.tool === 'filler' ? fillerTech(s) : 'point';
    if (tech === 'arrow' || tech === 'fan') {
      const last = anchors[anchors.length - 1];
      if (!moved || anchors.length < 2 || Math.hypot(last.p[0] - first.p[0], last.p[1] - first.p[1], last.p[2] - first.p[2]) < 0.02) { toast('Drag from the entry point to where the needle ends.'); return; }
      const j = tech === 'fan' ? fanAt(hdMarks2D(), start, vw.V.w, vw.V.h) : -1;
      if (j >= 0 && E.chart.marks[j].anchors) { edPush(); E.chart.marks[j].anchors.push(last); hdProjectMark(E.chart.marks[j]); hdRender(); return; }
      add({ ...base(), depth: s.depth || '', technique: tech, anchors: tech === 'fan' ? [first, last] : anchors });
      return;
    }
    if (E.tool === 'filler' && moved && anchors.length >= 3 && openStroke(anchors.map(a => a.p), 0.008)) { add({ ...base(), depth: s.depth || '', technique: 'arrow', anchors }); return; }
    if (E.tool === 'filler' || E.tool === 'booster') {
      if (!moved || anchors.length < 4) add({ ...base(), depth: s.depth || '', anchor: first });
      else add({ ...base(), depth: s.depth || '', anchors });
      return;
    }
    if (E.tool === 'device' || E.tool === 'thread') {
      if (!moved || anchors.length < 4) { toast(E.tool === 'device' ? 'Drag around the area to shade it.' : 'Drag along the thread path.'); return; }
      add({ ...base(), settings: E.tool === 'device' ? s.settings || '' : undefined, anchors }); return;
    }
    if (E.tool === 'pen') {
      if (anchors.length < 2) return;
      add({ t: 'pen', color: s.color, anchors }); return;
    }
    if (E.tool === 'text') {
      textPrompt('').then(txt => { if (!txt) return; add({ t: 'text', color: s.color, text: txt, anchor: first }); });
    }
  };
  board.addEventListener('pointermove', move);
  board.addEventListener('pointerup', up);
  board.addEventListener('pointercancel', up);
}
