// Consent forms and aftercare in Thai, English and Chinese. Starter wording only: Apex's
// own forms replace these under Settings, Forms, and Apex's team checks the Thai and
// Chinese before the forms are used with patients.

// "The doctor named on this form" in each language. When a patient signs, it is replaced
// with the visit's doctor.
const DOCTOR_PHRASE = { en: 'the doctor named on this form', th: 'แพทย์ที่ระบุชื่อในแบบฟอร์มนี้', zh: '本表所列医生' };

const CONSENT_DEFAULTS = {
  toxin: {
    title: { en: 'Botulinum toxin injections', th: 'การฉีดโบทูลินัมท็อกซิน (โบท็อกซ์)', zh: '肉毒杆菌素注射' },
    text: {
      en: `I agree to botulinum toxin injections by the doctor named on this form.

The injections relax the treated muscles to soften lines. The effect starts in 3 to 5 days, is complete at 2 weeks and lasts about 3 to 4 months.

Bruising, swelling, redness, tenderness and headache can follow the injections. A heavy or drooping eyelid or brow, an uneven result or a crooked smile can happen when the toxin reaches a nearby muscle, and these settle within weeks. An allergic reaction, or trouble swallowing, speaking or breathing, is rare and needs a doctor at once.

I am not pregnant or breastfeeding. I have told the doctor about my medicines, allergies and conditions, including any nerve or muscle disease.

Results vary from person to person, a touch-up may be needed, and the doctor cannot promise a particular result.

I was able to ask questions and all of them were answered.`,
      th: `ข้าพเจ้ายินยอมรับการฉีดโบทูลินัมท็อกซินโดยแพทย์ที่ระบุชื่อในแบบฟอร์มนี้

ยาจะทำให้กล้ามเนื้อบริเวณที่ฉีดคลายตัวเพื่อลดริ้วรอย ผลเริ่มเห็นใน 3 ถึง 5 วัน เห็นผลเต็มที่ใน 2 สัปดาห์ และอยู่ได้ประมาณ 3 ถึง 4 เดือน

หลังฉีดอาจมีรอยช้ำ บวม แดง เจ็บ และปวดศีรษะได้ หนังตาหรือคิ้วอาจหนักหรือตก ผลอาจไม่เท่ากันสองข้าง หรือยิ้มเบี้ยว หากยาไปถึงกล้ามเนื้อข้างเคียง อาการเหล่านี้จะดีขึ้นภายในไม่กี่สัปดาห์ อาการแพ้ หรือกลืน พูด หรือหายใจลำบาก พบได้น้อยมาก และต้องพบแพทย์ทันที

ข้าพเจ้าไม่ได้ตั้งครรภ์หรือให้นมบุตร ข้าพเจ้าได้แจ้งแพทย์เรื่องยาที่ใช้ ประวัติแพ้ และโรคประจำตัว รวมถึงโรคของเส้นประสาทหรือกล้ามเนื้อแล้ว

ผลการรักษาแตกต่างกันในแต่ละบุคคล อาจต้องฉีดเติม และแพทย์ไม่สามารถรับรองผลที่แน่นอนได้

ข้าพเจ้าได้ซักถามข้อสงสัยและได้รับคำตอบครบถ้วนแล้ว`,
      zh: `本人同意由本表所列医生为本人注射肉毒杆菌素。

注射会使治疗部位的肌肉放松，从而淡化皱纹。效果在3至5天开始显现，2周达到完全效果，可维持约3至4个月。

注射后可能出现淤青、肿胀、发红、触痛和头痛。如药物扩散到邻近肌肉，可能出现眼睑或眉毛沉重下垂、两侧效果不对称或笑容歪斜，这些情况会在数周内消退。过敏反应，或吞咽、说话、呼吸困难极为少见，一旦出现须立即就医。

本人没有怀孕或哺乳。本人已告知医生所用药物、过敏史及疾病，包括任何神经或肌肉疾病。

治疗效果因人而异，可能需要补打，医生无法保证特定效果。

本人已提出所有问题，并已全部得到解答。`,
    },
  },
  filler: {
    title: { en: 'Hyaluronic acid filler injections', th: 'การฉีดฟิลเลอร์ไฮยาลูรอนิก แอซิด', zh: '玻尿酸填充注射' },
    text: {
      en: `I agree to hyaluronic acid filler injections by the doctor named on this form.

Filler adds volume to the treated area. The result shows at once and settles over 2 weeks as the swelling goes down. It lasts 6 to 18 months depending on the product and the area.

Bruising, swelling, redness, tenderness, lumps and an uneven result can follow the injections. Infection, a late swelling or nodule and an allergic reaction can happen. The rarest and most serious risk is filler entering a blood vessel, which can cause skin loss and scarring and, very rarely, blindness or stroke. I will call Apex at once for pale, mottled or dusky skin, severe pain or any change in my vision.

Hyaluronic acid filler can be dissolved with hyaluronidase when needed.

I am not pregnant or breastfeeding. I have told the doctor about my medicines, allergies, cold sores and any filler or implant I had before.

Results vary from person to person, a touch-up may be needed, and the doctor cannot promise a particular result.

I was able to ask questions and all of them were answered.`,
      th: `ข้าพเจ้ายินยอมรับการฉีดฟิลเลอร์ไฮยาลูรอนิก แอซิด โดยแพทย์ที่ระบุชื่อในแบบฟอร์มนี้

ฟิลเลอร์เพิ่มปริมาตรให้บริเวณที่ฉีด เห็นผลทันที และผลจะเข้าที่ภายใน 2 สัปดาห์เมื่ออาการบวมยุบ อยู่ได้ 6 ถึง 18 เดือน ขึ้นกับชนิดของฟิลเลอร์และบริเวณที่ฉีด

หลังฉีดอาจมีรอยช้ำ บวม แดง เจ็บ เป็นก้อน และผลไม่เท่ากันได้ อาจเกิดการติดเชื้อ อาการบวมหรือก้อนที่เกิดภายหลัง และอาการแพ้ได้ ความเสี่ยงที่พบน้อยที่สุดแต่ร้ายแรงที่สุดคือฟิลเลอร์เข้าไปในหลอดเลือด ซึ่งอาจทำให้ผิวหนังตายและเกิดแผลเป็น และพบได้น้อยมากที่ทำให้ตาบอดหรือเกิดโรคหลอดเลือดสมอง หากผิวซีด เป็นลาย หรือคล้ำ ปวดมาก หรือการมองเห็นเปลี่ยนไป ข้าพเจ้าจะโทรแจ้ง Apex ทันที

ฟิลเลอร์ไฮยาลูรอนิก แอซิด สามารถสลายได้ด้วยยาไฮยาลูโรนิเดสเมื่อจำเป็น

ข้าพเจ้าไม่ได้ตั้งครรภ์หรือให้นมบุตร ข้าพเจ้าได้แจ้งแพทย์เรื่องยาที่ใช้ ประวัติแพ้ เริมที่ปาก และฟิลเลอร์หรือวัสดุเสริมที่เคยทำมาก่อนแล้ว

ผลการรักษาแตกต่างกันในแต่ละบุคคล อาจต้องฉีดเติม และแพทย์ไม่สามารถรับรองผลที่แน่นอนได้

ข้าพเจ้าได้ซักถามข้อสงสัยและได้รับคำตอบครบถ้วนแล้ว`,
      zh: `本人同意由本表所列医生为本人注射玻尿酸填充剂。

填充剂为治疗部位增加容量。效果立即可见，随着肿胀消退在2周内稳定，可维持6至18个月，视产品和部位而定。

注射后可能出现淤青、肿胀、发红、触痛、硬块及两侧不对称。也可能发生感染、迟发性肿胀或结节以及过敏反应。最罕见但最严重的风险是填充剂进入血管，可能导致皮肤坏死和疤痕，极少数情况下导致失明或中风。如出现皮肤苍白、花斑或发暗、剧烈疼痛或视力变化，本人将立即致电Apex。

需要时，玻尿酸填充剂可用透明质酸酶溶解。

本人没有怀孕或哺乳。本人已告知医生所用药物、过敏史、唇疱疹以及以往做过的填充或植入物。

治疗效果因人而异，可能需要补打，医生无法保证特定效果。

本人已提出所有问题，并已全部得到解答。`,
    },
  },
  booster: {
    title: { en: 'Skin booster injections', th: 'การฉีดสกินบูสเตอร์', zh: '水光针注射' },
    text: {
      en: `I agree to skin booster injections by the doctor named on this form.

Small bumps, redness, swelling and bruising at the injection points are expected and settle in 1 to 3 days. Infection, lumps and an allergic reaction can happen. Results build over weeks and a course of 2 to 3 sessions is usual.

I am not pregnant or breastfeeding. I have told the doctor about my medicines, allergies and cold sores.

Results vary from person to person and the doctor cannot promise a particular result.

I was able to ask questions and all of them were answered.`,
      th: `ข้าพเจ้ายินยอมรับการฉีดสกินบูสเตอร์โดยแพทย์ที่ระบุชื่อในแบบฟอร์มนี้

ตุ่มเล็ก ๆ รอยแดง บวม และรอยช้ำที่จุดฉีดเป็นอาการที่พบได้ และจะหายใน 1 ถึง 3 วัน อาจเกิดการติดเชื้อ ก้อน และอาการแพ้ได้ ผลจะค่อย ๆ เห็นในหลายสัปดาห์ และโดยทั่วไปต้องทำ 2 ถึง 3 ครั้ง

ข้าพเจ้าไม่ได้ตั้งครรภ์หรือให้นมบุตร ข้าพเจ้าได้แจ้งแพทย์เรื่องยาที่ใช้ ประวัติแพ้ และเริมที่ปากแล้ว

ผลการรักษาแตกต่างกันในแต่ละบุคคล และแพทย์ไม่สามารถรับรองผลที่แน่นอนได้

ข้าพเจ้าได้ซักถามข้อสงสัยและได้รับคำตอบครบถ้วนแล้ว`,
      zh: `本人同意由本表所列医生为本人注射水光针。

注射点出现小鼓包、发红、肿胀和淤青属正常现象，会在1至3天内消退。也可能发生感染、硬块和过敏反应。效果在数周内逐渐显现，通常需要2至3次疗程。

本人没有怀孕或哺乳。本人已告知医生所用药物、过敏史及唇疱疹。

治疗效果因人而异，医生无法保证特定效果。

本人已提出所有问题，并已全部得到解答。`,
    },
  },
  device: {
    title: { en: 'Energy-based device treatment', th: 'การรักษาด้วยเครื่องมือพลังงาน', zh: '能量仪器治疗' },
    text: {
      en: `I agree to treatment with the device written on this form, such as HIFU, radiofrequency or laser, by the team under the doctor named on this form.

Redness, swelling, tenderness, numbness and tingling can follow the treatment and usually settle within days. Blisters, burns, bruising, darker or lighter patches of skin and scarring can happen. Results build over weeks to months and more than one session may be needed.

I have told the team about my medicines, recent sun exposure, any pacemaker or metal implant, pregnancy, and isotretinoin taken in the last 6 months.

Results vary from person to person and Apex cannot promise a particular result.

I was able to ask questions and all of them were answered.`,
      th: `ข้าพเจ้ายินยอมรับการรักษาด้วยเครื่องมือที่ระบุในแบบฟอร์มนี้ เช่น HIFU คลื่นวิทยุ หรือเลเซอร์ โดยทีมภายใต้การดูแลของแพทย์ที่ระบุชื่อในแบบฟอร์มนี้

หลังทำอาจมีอาการแดง บวม เจ็บ ชา และเสียวซ่า ซึ่งมักหายภายในไม่กี่วัน อาจเกิดตุ่มพอง แผลไหม้ รอยช้ำ ผิวคล้ำขึ้นหรือขาวลงเป็นหย่อม และแผลเป็นได้ ผลจะค่อย ๆ เห็นในหลายสัปดาห์ถึงหลายเดือน และอาจต้องทำมากกว่าหนึ่งครั้ง

ข้าพเจ้าได้แจ้งทีมเรื่องยาที่ใช้ การโดนแดดเมื่อเร็ว ๆ นี้ เครื่องกระตุ้นหัวใจหรือโลหะในร่างกาย การตั้งครรภ์ และการใช้ยาไอโซเตรติโนอินใน 6 เดือนที่ผ่านมาแล้ว

ผลการรักษาแตกต่างกันในแต่ละบุคคล และ Apex ไม่สามารถรับรองผลที่แน่นอนได้

ข้าพเจ้าได้ซักถามข้อสงสัยและได้รับคำตอบครบถ้วนแล้ว`,
      zh: `本人同意在本表所列医生指导下，由治疗团队使用本表所写的仪器（如超声刀、射频或激光）为本人治疗。

治疗后可能出现发红、肿胀、触痛、麻木和刺痛，通常数天内消退。也可能出现水泡、烫伤、淤青、皮肤局部变深或变浅以及疤痕。效果在数周至数月内逐渐显现，可能需要多次治疗。

本人已告知治疗团队所用药物、近期日晒、心脏起搏器或体内金属植入物、怀孕情况，以及过去6个月内是否服用异维A酸。

治疗效果因人而异，Apex无法保证特定效果。

本人已提出所有问题，并已全部得到解答。`,
    },
  },
  thread: {
    title: { en: 'Thread lift', th: 'การร้อยไหม', zh: '埋线提升' },
    text: {
      en: `I agree to a thread lift by the doctor named on this form.

Swelling, bruising, tenderness, dimpling and tightness are expected and settle in 1 to 2 weeks. A thread can be felt or seen under the skin, can move, or can poke out and need removal. Infection and an uneven result can happen. The lift lasts about 6 to 12 months.

I am not pregnant or breastfeeding. I have told the doctor about my medicines, allergies and any filler or implant I had before.

Results vary from person to person and the doctor cannot promise a particular result.

I was able to ask questions and all of them were answered.`,
      th: `ข้าพเจ้ายินยอมรับการร้อยไหมโดยแพทย์ที่ระบุชื่อในแบบฟอร์มนี้

อาการบวม ช้ำ เจ็บ ผิวเป็นรอยบุ๋ม และรู้สึกตึง เป็นอาการที่พบได้ และจะหายใน 1 ถึง 2 สัปดาห์ อาจคลำหรือมองเห็นไหมใต้ผิวหนัง ไหมอาจเคลื่อน หรือโผล่ออกมาและต้องนำออก อาจเกิดการติดเชื้อและผลไม่เท่ากันได้ ผลการยกกระชับอยู่ได้ประมาณ 6 ถึง 12 เดือน

ข้าพเจ้าไม่ได้ตั้งครรภ์หรือให้นมบุตร ข้าพเจ้าได้แจ้งแพทย์เรื่องยาที่ใช้ ประวัติแพ้ และฟิลเลอร์หรือวัสดุเสริมที่เคยทำมาก่อนแล้ว

ผลการรักษาแตกต่างกันในแต่ละบุคคล และแพทย์ไม่สามารถรับรองผลที่แน่นอนได้

ข้าพเจ้าได้ซักถามข้อสงสัยและได้รับคำตอบครบถ้วนแล้ว`,
      zh: `本人同意由本表所列医生为本人进行埋线提升。

肿胀、淤青、触痛、皮肤凹陷和紧绷感属正常现象，会在1至2周内消退。线可能在皮下被摸到或看到，可能移位，或穿出皮肤需要取出。也可能发生感染和两侧不对称。提升效果可维持约6至12个月。

本人没有怀孕或哺乳。本人已告知医生所用药物、过敏史以及以往做过的填充或植入物。

治疗效果因人而异，医生无法保证特定效果。

本人已提出所有问题，并已全部得到解答。`,
    },
  },
  privacy: {
    title: { en: 'Personal data notice (PDPA)', th: 'หนังสือแจ้งการเก็บข้อมูลส่วนบุคคล (PDPA)', zh: '个人信息告知书（PDPA）' },
    text: {
      en: `Apex keeps my personal and health information under the Personal Data Protection Act B.E. 2562 (2019).

What is kept: my name, contact details, date of birth, ID or passport number, medical history, allergies and medicines, the treatments I receive with the products and lot numbers used, my clinical photographs and the consents I sign.

Why: to treat me safely, to keep my medical record and to meet what the law asks of a medical clinic. My health information is sensitive data, and I give my explicit consent for Apex to collect and use it for my care.

Who sees it: the doctors and assistants who care for me. It is shared outside Apex only with my permission, with a doctor I am referred to, or when the law requires it.

How it is kept: on Apex's own computer at this branch, with locked backups. Apex keeps a log of who opens my record, and keeps the record for as long as the law on medical records requires.

My rights: I can ask to see or get a copy of my record, have a mistake corrected, object to or limit how my information is used, and withdraw this consent for the future. I can raise a concern with Apex or with the Office of the Personal Data Protection Committee.`,
      th: `Apex เก็บข้อมูลส่วนบุคคลและข้อมูลสุขภาพของข้าพเจ้าตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562

ข้อมูลที่เก็บ ได้แก่ ชื่อ ข้อมูลติดต่อ วันเกิด เลขบัตรประชาชนหรือหนังสือเดินทาง ประวัติการรักษา ประวัติแพ้และยาที่ใช้ การรักษาที่ได้รับพร้อมผลิตภัณฑ์และเลขล็อตที่ใช้ ภาพถ่ายทางการแพทย์ และหนังสือยินยอมที่ข้าพเจ้าลงนาม

วัตถุประสงค์ เพื่อให้การรักษาที่ปลอดภัย เพื่อเก็บเวชระเบียน และเพื่อปฏิบัติตามที่กฎหมายกำหนดสำหรับสถานพยาบาล ข้อมูลสุขภาพเป็นข้อมูลอ่อนไหว และข้าพเจ้าให้ความยินยอมโดยชัดแจ้งให้ Apex เก็บและใช้ข้อมูลนี้เพื่อการดูแลรักษาข้าพเจ้า

ผู้ที่เห็นข้อมูล คือแพทย์และผู้ช่วยที่ดูแลข้าพเจ้า ข้อมูลจะเปิดเผยนอก Apex เฉพาะเมื่อข้าพเจ้าอนุญาต เมื่อส่งต่อให้แพทย์ท่านอื่น หรือเมื่อกฎหมายกำหนด

วิธีเก็บ เก็บในคอมพิวเตอร์ของ Apex ที่สาขานี้ พร้อมสำรองข้อมูลแบบเข้ารหัส Apex บันทึกว่าใครเปิดดูเวชระเบียนของข้าพเจ้า และเก็บเวชระเบียนไว้ตามระยะเวลาที่กฎหมายว่าด้วยเวชระเบียนกำหนด

สิทธิของข้าพเจ้า ข้าพเจ้าขอดูหรือขอสำเนาเวชระเบียน ขอแก้ไขข้อมูลที่ผิด คัดค้านหรือขอจำกัดการใช้ข้อมูล และถอนความยินยอมนี้สำหรับอนาคตได้ ข้าพเจ้าร้องเรียนได้ที่ Apex หรือสำนักงานคณะกรรมการคุ้มครองข้อมูลส่วนบุคคล`,
      zh: `Apex根据泰国《个人信息保护法》（佛历2562年，即2019年）保存本人的个人信息和健康信息。

保存的信息：本人的姓名、联系方式、出生日期、身份证或护照号码、病史、过敏史和用药、所接受的治疗及所用产品和批号、临床照片以及本人签署的同意书。

目的：为本人提供安全的治疗、保存病历，以及履行法律对医疗机构的要求。健康信息属于敏感信息，本人明确同意Apex为本人的诊疗收集和使用这些信息。

查看人员：为本人诊疗的医生和助理。仅在本人同意、转诊给其他医生或法律要求时，信息才会提供给Apex以外的人。

保存方式：保存在本分院Apex自己的电脑上，并有加密备份。Apex记录谁打开过本人的病历，并按病历相关法律规定的期限保存。

本人的权利：本人可以要求查看或复制病历、更正错误、反对或限制信息的使用，以及撤回今后的同意。本人可以向Apex或个人信息保护委员会办公室提出投诉。`,
    },
  },
  photos: {
    title: { en: 'Clinical photographs', th: 'การถ่ายภาพทางการแพทย์', zh: '临床照片' },
    text: {
      en: `I agree to clinical photographs of the treated area for my medical record.

They are used to plan and compare my treatments. They will be shown outside Apex only with my separate written permission.`,
      th: `ข้าพเจ้ายินยอมให้ถ่ายภาพบริเวณที่รักษาเพื่อเก็บไว้ในเวชระเบียน

ภาพใช้เพื่อวางแผนและเปรียบเทียบผลการรักษา และจะไม่นำไปแสดงนอก Apex เว้นแต่ข้าพเจ้าให้ความยินยอมเป็นลายลักษณ์อักษรแยกต่างหาก`,
      zh: `本人同意为病历拍摄治疗部位的临床照片。

照片用于规划和对比本人的治疗。未经本人另行书面许可，照片不会在Apex以外展示。`,
    },
  },
  marketing: {
    title: { en: 'Photos in Apex marketing', th: 'การใช้ภาพในการประชาสัมพันธ์ของ Apex', zh: 'Apex宣传使用照片' },
    text: {
      en: `I agree to Apex using my before and after photographs on its social media pages, website and printed materials.

My name will not be shown. Apex may crop the photos or cover my eyes.

I can withdraw this permission at any time by telling Apex. Posts already published stay up until Apex removes them, which it will do within 7 days of my request.`,
      th: `ข้าพเจ้ายินยอมให้ Apex ใช้ภาพก่อนและหลังการรักษาของข้าพเจ้าในสื่อสังคมออนไลน์ เว็บไซต์ และสื่อสิ่งพิมพ์ของ Apex

จะไม่แสดงชื่อของข้าพเจ้า Apex อาจครอปภาพหรือปิดบริเวณดวงตา

ข้าพเจ้าถอนความยินยอมนี้ได้ทุกเมื่อโดยแจ้ง Apex โพสต์ที่เผยแพร่แล้วจะถูกลบภายใน 7 วันนับจากที่ข้าพเจ้าแจ้ง`,
      zh: `本人同意Apex在其社交媒体、网站和印刷品上使用本人治疗前后的照片。

不会显示本人姓名。Apex可以裁剪照片或遮挡本人眼睛。

本人可随时通知Apex撤回此许可。已发布的内容将在本人提出要求后7天内删除。`,
    },
  },
};

const AFTERCARE_DEFAULTS = {
  toxin: {
    en: `Botulinum toxin
- Stay upright for 4 hours and do not rub, massage or press the treated areas.
- Skip exercise, sauna, facials and alcohol for the rest of the day.
- Use a cold pack wrapped in cloth for swelling or bruising.
- The effect starts in 3 to 5 days and is complete at 2 weeks.
- Come back at 2 weeks if one side looks different from the other.
- Call Apex for trouble swallowing, speaking or breathing, or a drooping eyelid.`,
    th: `โบทูลินัมท็อกซิน
- อยู่ในท่าตั้งตรง 4 ชั่วโมง และห้ามถู นวด หรือกดบริเวณที่ฉีด
- งดออกกำลังกาย ซาวน่า ทำหน้า และแอลกอฮอล์ในวันนี้
- ประคบเย็นโดยห่อผ้าไว้ หากบวมหรือช้ำ
- ผลเริ่มเห็นใน 3 ถึง 5 วัน และเห็นผลเต็มที่ใน 2 สัปดาห์
- กลับมาพบแพทย์ที่ 2 สัปดาห์ หากสองข้างดูไม่เท่ากัน
- โทรแจ้ง Apex หากกลืน พูด หรือหายใจลำบาก หรือหนังตาตก`,
    zh: `肉毒杆菌素
- 保持直立4小时，不要揉搓、按摩或按压注射部位。
- 当天不要运动、蒸桑拿、做面部护理或饮酒。
- 如有肿胀或淤青，用布包着冰袋冷敷。
- 效果在3至5天开始显现，2周达到完全效果。
- 如2周时两侧看起来不一样，请回诊。
- 如出现吞咽、说话或呼吸困难，或眼睑下垂，请致电Apex。`,
  },
  filler: {
    en: `Filler
- Do not press, massage or put make-up on the treated areas for 12 hours.
- Skip exercise, sauna, hot yoga, alcohol and facials for 48 hours.
- Sleep on your back with your head raised for 2 nights.
- Use a cold pack wrapped in cloth for swelling. Swelling and bruising settle in 1 to 2 weeks.
- Put off dental work for 2 weeks.
- Call Apex at once for pale, mottled or dusky skin, severe or worsening pain, or any change in your vision.`,
    th: `ฟิลเลอร์
- ห้ามกด นวด หรือแต่งหน้าบริเวณที่ฉีด 12 ชั่วโมง
- งดออกกำลังกาย ซาวน่า ฮอตโยคะ แอลกอฮอล์ และทำหน้า 48 ชั่วโมง
- นอนหงายหนุนศีรษะสูง 2 คืน
- ประคบเย็นโดยห่อผ้าไว้หากบวม อาการบวมและช้ำจะหายใน 1 ถึง 2 สัปดาห์
- เลื่อนการทำฟันออกไป 2 สัปดาห์
- โทรแจ้ง Apex ทันที หากผิวซีด เป็นลาย หรือคล้ำ ปวดมากหรือปวดมากขึ้น หรือการมองเห็นเปลี่ยนไป`,
    zh: `填充剂
- 12小时内不要按压、按摩注射部位或在该处化妆。
- 48小时内不要运动、蒸桑拿、做热瑜伽、饮酒或做面部护理。
- 头部垫高仰睡2晚。
- 肿胀时用布包着冰袋冷敷。肿胀和淤青会在1至2周内消退。
- 2周内不要看牙。
- 如皮肤苍白、花斑或发暗，疼痛剧烈或加重，或视力有任何变化，请立即致电Apex。`,
  },
  booster: {
    en: `Skin booster
- The small bumps flatten within 24 hours. Do not press or massage them.
- Skip make-up for 12 hours, and sauna, alcohol and exercise for 24 hours.
- Apply SPF 50 sunscreen every morning.
- Call Apex for redness, swelling or pain that keeps getting worse after day 3.`,
    th: `สกินบูสเตอร์
- ตุ่มเล็ก ๆ จะยุบภายใน 24 ชั่วโมง ห้ามกดหรือนวด
- งดแต่งหน้า 12 ชั่วโมง และงดซาวน่า แอลกอฮอล์ และออกกำลังกาย 24 ชั่วโมง
- ทาครีมกันแดด SPF 50 ทุกเช้า
- โทรแจ้ง Apex หากแดง บวม หรือปวดมากขึ้นเรื่อย ๆ หลังวันที่ 3`,
    zh: `水光针
- 小鼓包会在24小时内变平，不要按压或按摩。
- 12小时内不要化妆，24小时内不要蒸桑拿、饮酒或运动。
- 每天早上涂SPF 50防晒霜。
- 如第3天后发红、肿胀或疼痛持续加重，请致电Apex。`,
  },
  device: {
    en: `Device treatment
- Redness and swelling settle in 1 to 3 days.
- Use a gentle cleanser and moisturiser and skip scrubs, retinoids and acids for 5 days.
- Apply SPF 50 sunscreen every morning and again at midday.
- Do not pick blisters or crusts.
- Call Apex for blisters, burns or pain that keeps getting worse.`,
    th: `การรักษาด้วยเครื่องมือ
- อาการแดงและบวมจะหายใน 1 ถึง 3 วัน
- ใช้คลีนเซอร์และมอยส์เจอไรเซอร์ที่อ่อนโยน และงดสครับ เรตินอยด์ และกรดผลัดผิว 5 วัน
- ทาครีมกันแดด SPF 50 ทุกเช้า และทาซ้ำตอนกลางวัน
- ห้ามแกะตุ่มพองหรือสะเก็ด
- โทรแจ้ง Apex หากมีตุ่มพอง แผลไหม้ หรือปวดมากขึ้นเรื่อย ๆ`,
    zh: `仪器治疗
- 发红和肿胀会在1至3天内消退。
- 使用温和的洁面和保湿产品，5天内不要使用磨砂、维A类和酸类产品。
- 每天早上涂SPF 50防晒霜，中午补涂。
- 不要抠水泡或结痂。
- 如出现水泡、烫伤或疼痛持续加重，请致电Apex。`,
  },
  thread: {
    en: `Thread lift
- Sleep on your back with your head raised for 1 week.
- Avoid wide mouth opening, chewing gum, facial massage and dental work for 2 weeks.
- Skip exercise, sauna and alcohol for 1 week.
- Take the antibiotics and pain relief exactly as prescribed.
- Call Apex for fever, increasing redness, pus, or a thread poking through the skin.`,
    th: `ร้อยไหม
- นอนหงายหนุนศีรษะสูง 1 สัปดาห์
- หลีกเลี่ยงการอ้าปากกว้าง เคี้ยวหมากฝรั่ง นวดหน้า และทำฟัน 2 สัปดาห์
- งดออกกำลังกาย ซาวน่า และแอลกอฮอล์ 1 สัปดาห์
- ทานยาฆ่าเชื้อและยาแก้ปวดตามที่แพทย์สั่ง
- โทรแจ้ง Apex หากมีไข้ แดงมากขึ้น มีหนอง หรือไหมโผล่ออกมาจากผิว`,
    zh: `埋线提升
- 头部垫高仰睡1周。
- 2周内避免张大嘴、嚼口香糖、面部按摩和看牙。
- 1周内不要运动、蒸桑拿或饮酒。
- 严格按医嘱服用抗生素和止痛药。
- 如发烧、发红加重、有脓液或线头穿出皮肤，请致电Apex。`,
  },
};

// A template field held as text in one language (from before the forms had three) or as
// { th, en, zh }.
function langMap(v) { return typeof v === 'string' ? { en: v } : { ...(v || {}) }; }
// The field in the asked language, else English, else Thai.
function consentText(t, field, lang) { const m = langMap(t && t[field]); return m[lang] || m.en || m.th || m.zh || ''; }
function consentHas(t, lang) { const m = langMap(t && t.text); return !!(m[lang] && langMap(t.title)[lang]); }
// The aftercare of one treatment type in a language. Falls back to English unless asked not to.
function aftercareText(k, lang, fallback = true) {
  const m = langMap(S.templates && S.templates.aftercare ? S.templates.aftercare[k] : AFTERCARE_DEFAULTS[k]);
  return m[lang] || (fallback ? m.en || m.th || '' : '');
}

if (typeof module !== 'undefined') module.exports = { CONSENT_DEFAULTS, AFTERCARE_DEFAULTS, DOCTOR_PHRASE };
