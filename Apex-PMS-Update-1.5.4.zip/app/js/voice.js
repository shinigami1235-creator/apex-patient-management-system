// Voice: press the mic in the top bar (or F2), speak, and the branch PC turns it into text
// with whisper.cpp. In a text box the words go in where the cursor is. Anywhere else they
// are a command: open a page or a patient, add treatment lines or treatments, write a note.
// Anything that saves shows on screen first. Dictation is English only, since Thai speech
// recognition is too weak for clinical notes.

const VOICE = { state: 'idle', stream: null, ctx: null, proc: null, src: null, chunks: [], rate: 48000, target: null, lastInsert: null, timer: null };
const voiceOn = () => !!(S.voice && S.voice.enabled);

// ---------- recording ----------
async function voiceToggle() {
  if (VOICE.state === 'listening') return voiceStop(true);
  if (VOICE.state !== 'idle') return;
  if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    await ask({ title: 'Voice needs the secure address', body: secureNote('Voice') || '<p>This browser has no microphone access.</p>', buttons: [{ label: 'Close', value: null }] });
    return;
  }
  const a = document.activeElement;
  VOICE.target = a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|email|tel|)$/.test(a.type))) && !a.readOnly && !a.disabled ? a : null;
  try {
    VOICE.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  } catch (e) { voiceBar(`The microphone could not start: ${e.message}`, 'bad', 5000); return; }
  const Ctx = window.AudioContext || window.webkitAudioContext;
  VOICE.ctx = new Ctx();
  VOICE.rate = VOICE.ctx.sampleRate;
  VOICE.src = VOICE.ctx.createMediaStreamSource(VOICE.stream);
  VOICE.proc = VOICE.ctx.createScriptProcessor(4096, 1, 1);
  VOICE.chunks = [];
  let heard = false, quietSince = 0;
  const started = Date.now();
  VOICE.proc.onaudioprocess = e => {
    const d = e.inputBuffer.getChannelData(0);
    VOICE.chunks.push(new Float32Array(d));
    let s = 0; for (let i = 0; i < d.length; i++) s += d[i] * d[i];
    const rms = Math.sqrt(s / d.length), now = Date.now();
    if (rms > 0.02) { heard = true; quietSince = 0; } else if (heard && !quietSince) quietSince = now;
    // Stops by itself after a pause, at 20 seconds, or when nothing was said in 7.
    if ((heard && quietSince && now - quietSince > 1400) || now - started > 20000 || (!heard && now - started > 7000)) voiceStop(heard);
  };
  VOICE.src.connect(VOICE.proc);
  VOICE.proc.connect(VOICE.ctx.destination);
  VOICE.state = 'listening';
  paintMic();
  voiceBar(VOICE.target ? 'Listening. The words go into the box.' : 'Listening.', 'on');
}

async function voiceStop(use) {
  if (VOICE.state !== 'listening') return;
  VOICE.state = 'reading';
  try { VOICE.proc.disconnect(); VOICE.src.disconnect(); } catch (e) { /* already off */ }
  VOICE.stream.getTracks().forEach(t => t.stop());
  VOICE.ctx.close().catch(() => {});
  paintMic();
  if (!use || !VOICE.chunks.length) { VOICE.state = 'idle'; paintMic(); return voiceBar('Nothing heard.', '', 2500); }
  voiceBar('Reading what you said.', 'busy');
  try {
    const wav = wavOf(VOICE.chunks, VOICE.rate);
    const r = await api('/api/voice', { wav: b64Of(wav), prompt: voicePrompt() });
    VOICE.state = 'idle'; paintMic();
    await voiceAct(r.text || '');
  } catch (e) { VOICE.state = 'idle'; paintMic(); voiceBar(e.message, 'bad', 6000); }
}

// 16 kHz mono 16-bit WAV, the format whisper reads.
function wavOf(chunks, rate) {
  const n = chunks.reduce((a, c) => a + c.length, 0), all = new Float32Array(n);
  let o = 0; for (const c of chunks) { all.set(c, o); o += c.length; }
  const ratio = rate / 16000, len = Math.floor(n / ratio), pcm = new Int16Array(len);
  for (let i = 0; i < len; i++) {
    const a = Math.floor(i * ratio), b = Math.min(n, Math.floor((i + 1) * ratio));
    let s = 0; for (let j = a; j < b; j++) s += all[j];
    const v = Math.max(-1, Math.min(1, s / Math.max(1, b - a)));
    pcm[i] = v < 0 ? v * 0x8000 : v * 0x7FFF;
  }
  const buf = new ArrayBuffer(44 + pcm.length * 2), dv = new DataView(buf);
  const str = (off, t) => { for (let i = 0; i < t.length; i++) dv.setUint8(off + i, t.charCodeAt(i)); };
  str(0, 'RIFF'); dv.setUint32(4, 36 + pcm.length * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
  dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true); dv.setUint32(24, 16000, true);
  dv.setUint32(28, 32000, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); str(36, 'data'); dv.setUint32(40, pcm.length * 2, true);
  new Int16Array(buf, 44).set(pcm);
  return new Uint8Array(buf);
}
function b64Of(bytes) { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); }

// Names whisper should spell the clinic's way: today's patients first, then services and products.
function voicePrompt() {
  const today = todayISO();
  const pts = [...new Set([...S.visits.filter(v => v.date === today).map(v => v.patientId), ...[...S.visits].sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 40).map(v => v.patientId)])].map(id => patient(id)).filter(Boolean).map(p => p.name);
  const words = [...pts.slice(0, 25), ...S.services.filter(s => s.active !== false).map(s => s.name), ...S.products.filter(p => p.active !== false).map(p => p.name).slice(0, 30)];
  return ('Open, add, plan, findings, assessment, units, ml, glabella, nasolabial, tear trough. ' + words.join(', ')).slice(0, 700);
}

// ---------- the bar and the mic ----------
function micButtonHTML() {
  if (!voiceOn()) return '';
  return `<button class="mic ${VOICE.state}" data-act="voice" aria-label="Voice" title="Voice (F2)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg><span>Voice</span></button>`;
}
// The Dictate button on the notes: the words go into the notes box last tapped, or the first one.
let lastNoteBox = null;
document.addEventListener('focusin', e => { if (e.target.matches && e.target.matches('textarea:not([disabled]):not([readonly])')) lastNoteBox = e.target; });
function dictateButtonHTML() {
  if (voiceOn()) return `<button type="button" class="btn secondary small${DICT.on ? ' on' : ''}" data-dictate aria-pressed="${DICT.on}" title="Tap a box, then dictate. It keeps listening until you press Stop.">${dictateLabel()}</button>`;
  if (isOwner()) return '<a class="btn quiet small" href="#/settings/voice">Turn on dictation</a>';
  return '';
}
['pointerdown', 'mousedown'].forEach(ev => document.addEventListener(ev, e => { if (e.target.closest && e.target.closest('[data-dictate]')) e.preventDefault(); }, true));
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-dictate]');
  if (!b) return;
  e.preventDefault();
  if (DICT.on) return dictStop();
  const form = b.closest('form');
  const box = lastNoteBox && document.contains(lastNoteBox) && form && form.contains(lastNoteBox) ? lastNoteBox : form && form.querySelector('textarea:not([disabled]):not([readonly])');
  if (box) box.focus();
  dictStart(form);
});

// ---------- keep listening ----------
// Dictate keeps the microphone on until it is pressed again. Each phrase goes to the PC as
// soon as the doctor pauses, and its words land in the note box tapped last, so moving on to
// the next box while talking works. Phrases are written in the order they were said.
const DICT = { on: false, stream: null, ctx: null, proc: null, src: null, chunks: [], pre: [], rate: 48000, heard: false, quiet: 0, segStart: 0, lastSpeech: 0, queue: Promise.resolve(), waiting: 0, formId: '' };
const STOP_ICON = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>';
function dictateLabel() { return DICT.on ? `${STOP_ICON}Stop` : `${I.mic || ''}Dictate`; }
function paintDictate() {
  document.querySelectorAll('[data-dictate]').forEach(b => { b.classList.toggle('on', DICT.on); b.setAttribute('aria-pressed', DICT.on); b.innerHTML = dictateLabel(); });
}
async function dictStart(form) {
  if (DICT.on) return;
  if (VOICE.state !== 'idle') return voiceBar('Wait for the voice command to finish.', '', 2500);
  if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    await ask({ title: 'Voice needs the secure address', body: secureNote('Voice') || '<p>This browser has no microphone access.</p>', buttons: [{ label: 'Close', value: null }] });
    return;
  }
  try { DICT.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
  catch (e) { voiceBar(`The microphone could not start: ${e.message}`, 'bad', 5000); return; }
  const Ctx = window.AudioContext || window.webkitAudioContext;
  DICT.ctx = new Ctx(); DICT.rate = DICT.ctx.sampleRate;
  DICT.src = DICT.ctx.createMediaStreamSource(DICT.stream);
  DICT.proc = DICT.ctx.createScriptProcessor(4096, 1, 1);
  Object.assign(DICT, { on: true, chunks: [], pre: [], heard: false, quiet: 0, lastSpeech: Date.now(), formId: (form && form.id) || '' });
  DICT.proc.onaudioprocess = e => {
    if (!DICT.on) return;
    // The note page closed or the screen locked: dictation ends with it.
    if (document.querySelector('.lock') || (DICT.formId && !document.getElementById(DICT.formId))) return dictStop();
    const d = new Float32Array(e.inputBuffer.getChannelData(0));
    let sum = 0; for (let i = 0; i < d.length; i++) sum += d[i] * d[i];
    const loud = Math.sqrt(sum / d.length) > 0.02, now = Date.now();
    if (!DICT.heard) {
      // A moment before the first word is kept, so its start is not clipped.
      DICT.pre.push(d); if (DICT.pre.length > 4) DICT.pre.shift();
      if (loud) { DICT.heard = true; DICT.chunks = DICT.pre; DICT.pre = []; DICT.segStart = now; DICT.quiet = 0; DICT.lastSpeech = now; }
      else if (now - DICT.lastSpeech > 120000) dictStop();
      return;
    }
    DICT.chunks.push(d);
    if (loud) { DICT.quiet = 0; DICT.lastSpeech = now; } else if (!DICT.quiet) DICT.quiet = now;
    if ((DICT.quiet && now - DICT.quiet > 900) || now - DICT.segStart > 25000) dictCut();
  };
  DICT.src.connect(DICT.proc); DICT.proc.connect(DICT.ctx.destination);
  paintDictate();
  voiceBar('Listening until you press Stop.', 'on');
}
function dictBox() {
  const f = DICT.formId ? document.getElementById(DICT.formId) : null;
  const ok = el => el && document.contains(el) && !el.disabled && !el.readOnly && (!f || f.contains(el));
  if (ok(lastNoteBox)) return lastNoteBox;
  return f ? f.querySelector('textarea:not([disabled]):not([readonly])') : null;
}
function dictCut() {
  const seg = DICT.chunks;
  DICT.chunks = []; DICT.heard = false; DICT.quiet = 0; DICT.lastSpeech = Date.now();
  if (seg.length < 4) return;
  const wav = wavOf(seg, DICT.rate);
  DICT.waiting++;
  DICT.queue = DICT.queue.then(async () => {
    try {
      const r = await api('/api/voice', { wav: b64Of(wav), prompt: voicePrompt() });
      // whisper writes [BLANK_AUDIO] or (coughing) for sounds that are not words.
      const text = String(r.text || '').replace(/[[(][^\])]*[\])]/g, '').trim();
      const box = text && dictBox();
      if (box) voiceDictate(box, text);
    } catch (e) { voiceBar(e.message, 'bad', 6000); }
    finally {
      DICT.waiting--;
      if (DICT.on) voiceBar('Listening until you press Stop.', 'on');
      else if (!DICT.waiting) voiceBar('Dictation stopped.', '', 2000);
    }
  });
}
async function dictStop() {
  if (!DICT.on) return;
  if (DICT.heard) dictCut();
  DICT.on = false;
  try { DICT.proc.disconnect(); DICT.src.disconnect(); } catch (e) { /* already off */ }
  DICT.stream.getTracks().forEach(t => t.stop());
  DICT.ctx.close().catch(() => {});
  paintDictate();
  voiceBar(DICT.waiting ? 'Writing the last words.' : 'Dictation stopped.', DICT.waiting ? 'busy' : '', DICT.waiting ? 0 : 2000);
  await DICT.queue;
}
function paintMic() { document.querySelectorAll('[data-act="voice"]').forEach(b => { b.className = 'mic ' + VOICE.state; }); }
function voiceBar(text, cls = '', ms = 0) {
  let el = document.getElementById('voicebar');
  if (!el) { el = document.createElement('div'); el.id = 'voicebar'; el.setAttribute('role', 'status'); el.setAttribute('aria-live', 'polite'); document.body.appendChild(el); }
  el.className = 'voicebar ' + cls; el.textContent = text; el.hidden = false;
  clearTimeout(VOICE.timer);
  if (ms) VOICE.timer = setTimeout(() => { el.hidden = true; }, ms);
}
// The mic keeps focus where it was, so dictation lands in the box being typed in.
['pointerdown', 'mousedown'].forEach(ev => document.addEventListener(ev, e => { if (e.target.closest && e.target.closest('[data-act="voice"]')) e.preventDefault(); }, true));
document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-act="voice"]'); if (b) { e.preventDefault(); voiceToggle(); } });
document.addEventListener('keydown', e => { if (e.key === 'F2' && S.me && voiceOn() && !document.querySelector('.lock, .checkin')) { e.preventDefault(); voiceToggle(); } });

// ---------- understanding ----------
const NUM_WORDS = { zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90, half: 0.5 };
// Lower case words with numbers joined: "five thousand" and "5,000" both become "5000".
function voiceWords(text) {
  let t = String(text).toLowerCase().replace(/(\d),(\d{3})/g, '$1$2').replace(/(\d)\.(\d)/g, '$1§$2').replace(/(\d{1,2}):(\d{2})/g, '$1¦$2')
    .replace(/\bp\.\s?m\.?/g, 'pm').replace(/\ba\.\s?m\.?/g, 'am').replace(/'s\b/g, '').replace(/[₱$]/g, ' ').replace(/[^\p{L}\p{N}§¦\s'-]/gu, ' ').replace(/§/g, '.').replace(/¦/g, ':');
  const out = [];
  let acc = null, cur = 0;
  const flush = () => { if (acc !== null) { out.push(String(acc + cur)); acc = null; cur = 0; } };
  for (const w of t.split(/\s+/).filter(Boolean)) {
    if (w in NUM_WORDS) { if (acc === null) acc = 0; cur += NUM_WORDS[w]; continue; }
    if ((w === 'hundred' || w === 'thousand') && acc !== null) { if (w === 'hundred') cur = (cur || 1) * 100; else { acc = (acc + (cur || 1)) * 1000; cur = 0; } continue; }
    if (w === 'thousand' && out.length && /^\d+(\.\d+)?$/.test(out[out.length - 1])) { out[out.length - 1] = String(num(out[out.length - 1]) * 1000); continue; }
    if (w === 'and' && acc !== null) continue;
    flush();
    out.push(w.replace(/^'+|'+$/g, ''));
  }
  flush();
  return out.filter(Boolean);
}

function editDistance(a, b) {
  if (a === b) return 0;
  const m = a.length, n = b.length; if (!m || !n) return m || n;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const row = [i]; for (let j = 1; j <= n; j++) row[j] = Math.min(prev[j] + 1, row[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = row; }
  return prev[n];
}
const wordLike = (a, b) => a === b || (a.length > 3 && b.length > 3 && (b.startsWith(a) || 1 - editDistance(a, b) / Math.max(a.length, b.length) >= 0.75));
const nameWords = s => voiceWords(String(s).replace(/^(dr|dra)\.?\s+/i, '')).filter(w => !['the', 'of', 'and', 'with', 'ml', 'u'].includes(w));

// The best match for a run of spoken words among items. Returns { item, score, from, to }.
function voiceFind(words, items, nameOf, { min = 0.6, maxLen = 5 } = {}) {
  let best = null;
  const cands = items.map(it => ({ it, names: [].concat(nameOf(it)).filter(Boolean).map(nameWords) }));
  for (let i = 0; i < words.length; i++) for (let j = i + 1; j <= Math.min(words.length, i + maxLen); j++) {
    const span = words.slice(i, j);
    if (span.some(w => /^\d/.test(w))) continue;
    for (const c of cands) for (const nw of c.names) {
      if (!nw.length) continue;
      const hit = span.filter(w => nw.some(x => wordLike(w, x))).length;
      if (hit < span.length) continue;
      const used = nw.filter(x => span.some(w => wordLike(w, x))).length;
      const score = (0.6 + 0.4 * used / nw.length) * (span.length === 1 && nw.length > 1 && span[0].length < 4 ? 0.7 : 1) + span.length * 0.01;
      if (score >= min && (!best || score > best.score)) best = { item: c.it, score, from: i, to: j, all: [] };
    }
  }
  return best;
}
// Every item that matches about as well as the best, so a common first name asks which one.
function voiceFindAll(words, items, nameOf) {
  const b = voiceFind(words, items, nameOf);
  if (!b) return [];
  const span = words.slice(b.from, b.to);
  return items.filter(it => { const m = voiceFind(span, [it], nameOf); return m && m.score >= b.score - 0.08; });
}

const VOICE_PAGES = [
  [['today', 'home', 'dashboard'], '#/today'], [['patients', 'patient list'], '#/patients'], [['complications'], '#/complications'],
  [['team', 'people', 'doctors'], '#/team'], [['me', 'my page'], '#/me'], [['settings', 'devices'], '#/settings'],
];
const PATIENT_TABS = { record: 'record', visits: 'visits', visit: 'visits', photos: 'photos', pictures: 'photos', history: 'visits' };
const WEEKDAY_WORDS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const MONTH_WORDS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

// A date in the words: today, tomorrow, Friday, next Monday, October 20, the 20th.
function voiceDate(words) {
  const today = todayISO();
  const at = (i, n = 1) => ({ from: i, to: i + n });
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (w === 'today') return { date: today, ...at(i) };
    if (w === 'tomorrow') return { date: addDays(today, 1), ...at(i) };
    if (w === 'yesterday') return { date: addDays(today, -1), ...at(i) };
    const wd = WEEKDAY_WORDS.indexOf(w);
    if (wd >= 0) {
      const dow = new Date(today + 'T00:00').getDay();
      let d = (wd - dow + 7) % 7 || 7;
      const next = words[i - 1] === 'next';
      if (next && d < 7 && wd > dow) d += 7;
      return { date: addDays(today, d), from: next ? i - 1 : i, to: i + 1 };
    }
    const mo = MONTH_WORDS.findIndex(m => m === w || (w.length >= 3 && m.startsWith(w)));
    if (mo >= 0 && w !== 'may' || w === 'may' && /^\d/.test(words[i + 1] || words[i - 1] || '')) {
      const after = parseInt(words[i + 1], 10), before = parseInt(words[i - 1], 10);
      const day = after >= 1 && after <= 31 ? after : before >= 1 && before <= 31 ? before : 0;
      if (!day) continue;
      let y = +today.slice(0, 4);
      let iso = `${y}-${String(mo + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      if (iso < addDays(today, -60)) iso = `${y + 1}${iso.slice(4)}`;
      return { date: iso, from: after === day ? i : i - 1, to: after === day ? i + 2 : i + 1 };
    }
    const th = /^(\d{1,2})(st|nd|rd|th)$/.exec(w);
    if (th) { const day = +th[1]; let iso = today.slice(0, 8) + String(day).padStart(2, '0'); if (iso < today) iso = addDays(iso.slice(0, 8) + '01', 32).slice(0, 8) + String(day).padStart(2, '0'); return { date: iso, from: words[i - 1] === 'the' ? i - 1 : i, to: i + 1 }; }
  }
  return null;
}
// A time: 3pm, 3:30 pm, 15:30, at 3 (clinic hours, so 1 to 7 means afternoon).
function voiceTime(words) {
  for (let i = 0; i < words.length; i++) {
    let m = /^(\d{1,2})(?::(\d{2}))?(am|pm)?$/.exec(words[i]);
    if (!m) continue;
    let ap = m[3] || (/^(am|pm)$/.test(words[i + 1] || '') ? words[i + 1] : '');
    const prev = words[i - 1];
    let min = m[2] ? +m[2] : 0, to = i + 1 + (!m[3] && ap ? 1 : 0);
    if (!m[2] && !ap && prev !== 'at') { if (/^\d{2}$/.test(words[i + 1] || '') && /^(am|pm)$/.test(words[i + 2] || '')) { min = +words[i + 1]; ap = words[i + 2]; to = i + 3; } else continue; }
    if (!m[2] && /^(30|15|45)$/.test(words[i + 1] || '') && !ap) { min = +words[i + 1]; to = i + 2; }
    let h = +m[1];
    if (h > 23 || min > 59) continue;
    if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0;
    if (!ap && h >= 1 && h <= 7) h += 12;
    return { time: `${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`, from: prev === 'at' ? i - 1 : i, to };
  }
  return null;
}
const without = (words, ...spans) => words.filter((_, i) => !spans.some(s => s && i >= s.from && i < s.to));

const activePatients = () => S.patients.filter(p => !p.archived && !p.mergedInto);
async function pickOne(title, list, label) {
  if (list.length <= 1) return list[0] || null;
  return ask({ title, body: 'More than one fits what was said.', buttons: [...list.slice(0, 6).map(x => ({ label: label(x), value: x })), { label: 'Cancel', value: null }] });
}
async function voicePatient(words) {
  const list = voiceFindAll(words, activePatients(), p => [p.name, p.goesBy ? `${p.goesBy} ${p.name.split(' ').slice(-1)[0]}` : '']);
  return pickOne('Which patient?', list, p => `${p.name}${p.no ? ' · ' + p.no : ''}`);
}

// ---------- acting ----------
async function voiceAct(text) {
  const raw = String(text || '').trim();
  if (!raw) return voiceBar('Nothing heard.', '', 2500);
  const t = VOICE.target;
  const w = voiceWords(raw);
  const forced = w[0] === 'command';
  if (t && document.body.contains(t) && !forced) return voiceDictate(t, raw);
  const words = forced ? w.slice(1) : w;
  voiceBar(`“${raw}”`, '', 4000);
  try {
    const done = await voiceCommand(words, raw);
    if (!done) voiceBar(`“${raw}” is not a command I know. Open the guide, Voice, for the list.`, 'bad', 6000);
  } catch (e) { fail(e); }
}

function voiceDictate(t, raw) {
  const lw = raw.toLowerCase().replace(/[.!?,\s]+$/, '');
  if (/^(scratch|delete|undo) that$/.test(lw)) {
    const li = VOICE.lastInsert;
    if (li && li.el === t && t.value.slice(li.at, li.at + li.text.length) === li.text) { t.value = t.value.slice(0, li.at) + t.value.slice(li.at + li.text.length); t.setSelectionRange(li.at, li.at); t.dispatchEvent(new Event('input', { bubbles: true })); VOICE.lastInsert = null; voiceBar('Taken out.', '', 2000); }
    return;
  }
  let ins = raw.replace(/\s*\b(new|next) paragraph\b[.,]?\s*/gi, '\n\n').replace(/\s*\b(new|next) line\b[.,]?\s*/gi, '\n');
  const at = t.selectionStart ?? t.value.length, end = t.selectionEnd ?? at;
  const before = t.value.slice(0, at);
  if (t.tagName === 'INPUT') ins = ins.replace(/\n+/g, ' ').replace(/[.]$/, '');
  if (before && !/\s$/.test(before) && !/^[\s,.;:]/.test(ins)) ins = ' ' + ins;
  if (before.trim() && !/[.!?\n]\s*$/.test(before) && t.tagName === 'TEXTAREA') ins = ins.replace(/^(\s*)(\p{Lu})(?=\p{Ll})/u, (m, s, c) => s + c.toLowerCase());
  t.value = before + ins + t.value.slice(end);
  const pos = at + ins.length;
  t.setSelectionRange(pos, pos);
  t.focus();
  t.dispatchEvent(new Event('input', { bubbles: true }));
  VOICE.lastInsert = { el: t, at, text: ins };
  voiceBar('Added. Say “scratch that” to take it out.', '', 2500);
}

// Each handler returns true when the words were its command.
async function voiceCommand(words, raw) {
  const { parts } = route();
  const first = words[0], rest = words.slice(1), phrase = words.join(' ');
  if (!words.length) return false;
  if (/^(lock|lock the screen|lock screen)$/.test(phrase)) { lockNow(); return true; }
  if (/^(cancel|never ?mind|stop)$/.test(phrase)) { voiceBar('Cancelled.', '', 1500); return true; }
  if (/^new patient$/.test(phrase)) { go('#/patient/new'); return true; }

  // On a visit: services, treatment lines, notes, the camera.
  if ((parts[0] === 'visit' || parts[0] === 'chart') && can('clinical')) { const r = await voiceOnVisit(visit(parts[1]), words); if (r) return true; }
  if ((phrase.startsWith('new visit') || phrase.startsWith('start a visit') || phrase.startsWith('start visit')) && can('clinical')) {
    const p = await voicePatient(words.slice(2)); if (!p) return voiceBar('Say the patient after “new visit for”.', 'bad', 4000), true;
    go('#/patient/' + p.id + '/visits'); newVisit(p.id); return true;
  }
  // A page, or a patient.
  const verb = /^(open|go|show|find|search|look)$/.test(first);
  const body = verb ? words.slice(words[1] === 'to' || words[1] === 'up' || words[1] === 'for' ? 2 : 1).filter(x => x !== 'the' && x !== 'page' && x !== 'screen') : words;
  const bodyText = body.join(' ');
  const page = VOICE_PAGES.find(([names]) => names.includes(bodyText));
  if (page) { go(typeof page[1] === 'function' ? page[1]() : page[1]); return true; }
  if (verb && can('clinical')) {
    const tab = body.length > 1 ? PATIENT_TABS[body[body.length - 1]] : '';
    const p = await voicePatient(tab ? body.slice(0, -1).filter(x => !/^'?s$/.test(x)) : body);
    if (p) { go(`#/patient/${p.id}${tab ? '/' + tab : ''}`); return true; }
    voiceBar(`No patient matches “${raw}”.`, 'bad', 5000); return true;
  }
  // Just a name opens that patient.
  if (can('clinical')) {
    const m = voiceFind(words, activePatients(), p => p.name, { min: 0.8 });
    if (m && m.from === 0 && m.to === words.length) { const p = await voicePatient(words); if (p) { go('#/patient/' + p.id); return true; } }
  }
  return false;
}


const NOTE_FIELDS = { complaint: 'complaint', complaints: 'complaint', reason: 'complaint', findings: 'findings', finding: 'findings', exam: 'findings', assessment: 'assessment', diagnosis: 'assessment', plan: 'plan' };
async function voiceOnVisit(v, words) {
  if (!v) return false;
  const locked = !!v.signedAt;
  const head = words[0], phrase = words.join(' ');
  if (/^(camera|take photos|photos|open the camera)$/.test(phrase)) { (typeof openOverlayCamera === 'function' ? openOverlayCamera(v) : openGuidedCamera(v)).catch(fail); return true; }
  if (/^(hand to patient|check in|check-in|patient check in)$/.test(phrase)) { openCheckin(v); return true; }
  if ((head === 'preset' || (head === 'use' && words[1] === 'preset')) && !locked) {
    const m = voiceFind(words.slice(head === 'use' ? 2 : 1), S.presets, x => x.name, { min: 0.6 });
    if (!m) return voiceBar('No preset matches that.', 'bad', 4000), true;
    if (await ask({ title: `Use ${m.item.name}?`, body: esc(presetSummary(m.item)), buttons: [{ label: 'Cancel', value: null }, { label: 'Use it', value: true, kind: 'primary' }] })) await applyPreset(visit(v.id), m.item);
    return true;
  }
  if (NOTE_FIELDS[head] && words.length > 1) {
    if (locked) return voiceBar('This visit is signed.', 'bad', 3000), true;
    const form = document.getElementById('notes'), box = form && form.querySelector(`[name=${NOTE_FIELDS[head]}]`);
    if (!box) return false;
    const text = words.slice(words[1] === 'is' ? 2 : 1).join(' ');
    const sentence = text.charAt(0).toUpperCase() + text.slice(1) + (/[.!?]$/.test(text) ? '' : '.');
    box.value = (box.value.trim() ? box.value.trim() + ' ' : '') + sentence;
    form.requestSubmit();
    return true;
  }
  if (head === 'add' && (words[1] === 'service' || words[1] === 'treatment' && !/\d/.test(phrase)) || head === 'service') {
    if (locked) return voiceBar('This visit is signed.', 'bad', 3000), true;
    const m = voiceFind(words.slice(head === 'add' ? 2 : 1), S.services.filter(s => s.active !== false), s => s.name);
    if (!m) return voiceBar('No treatment matches that.', 'bad', 4000), true;
    const sv = m.item;
    if (!(await ask({ title: 'Add this treatment?', body: esc(sv.name), buttons: [{ label: 'Cancel', value: null }, { label: 'Add it', value: true, kind: 'primary' }] }))) return true;
    await pushTo('visits', v.id, 'services', [{ id: uid(), serviceId: sv.id, name: sv.name }], 'Treatment added by voice');
    render(); return true;
  }
  // A treatment line: "Botox 20 units glabella", "add treatment filler 1 ml lips".
  const tw = head === 'add' || head === 'treatment' ? words.slice(words[1] === 'treatment' || words[1] === 'line' ? 2 : 1) : words;
  const prods = S.products.filter(p => p.active !== false);
  const pm = voiceFind(tw, prods, p => [p.name, (KINDS[p.kind] || {}).short, p.brand]);
  const amt = tw.findIndex(x => /^\d+(\.\d+)?$/.test(x));
  if (!pm || amt < 0) return false;
  if (locked) return voiceBar('This visit is signed.', 'bad', 3000), true;
  const pr = pm.item, l = pickLot(pr.id);
  const unitWord = tw[amt + 1] || '';
  const unit = /^(units?|u|you)$/.test(unitWord) ? 'U' : /^(ml|mls|cc|millilit(er|re)s?)$/.test(unitWord) ? 'ml' : /^(shots?)$/.test(unitWord) ? 'shots' : /^(threads?|pieces?|pcs)$/.test(unitWord) ? 'pcs' : '';
  const used = { from: amt, to: amt + 1 + (unit ? 1 : 0) };
  const areaWords = without(tw, pm, used).filter(x => !['on', 'in', 'to', 'at', 'for', 'the', 'of', 'into', 'and'].includes(x));
  const area = areaWords.join(' ').replace(/^./, c => c.toUpperCase());
  const line = { id: uid(), source: 'manual', kind: pr.kind, lotId: l ? l.id : '', productId: pr.id, product: pr.name, lot: l ? l.lot : '', amount: num(tw[amt]), unit: unit || pr.unit || KINDS[pr.kind].unit, area, notes: '' };
  const ok = await ask({ title: 'Add this treatment line?', body: `<b>${esc(line.product)}</b> ${trimNum(line.amount)} ${esc(line.unit)}${area ? ' · ' + esc(area) : ''}<br><span class="meta">${l ? 'Lot ' + esc(l.lot || '') : 'No lot recorded'}</span>`, buttons: [{ label: 'Cancel', value: null }, { label: 'Add it', value: true, kind: 'primary' }] });
  if (!ok) return true;
  await pushTo('visits', v.id, 'treatments', [line], 'Treatment line added by voice');
  render();
  return true;
}

// ---------- settings ----------
function voiceTab() {
  const v = S.voice || {};
  return `<form class="card" id="voiceset"><h2 class="card-title">Dictation</h2>
    <p class="muted">Doctors dictate notes and give commands from this PC or a tablet on the secure address. Whisper runs on this PC, so nothing said leaves the branch. Dictation and commands are in English, since Thai speech recognition is too weak for clinical notes. Patient and product names come through best when said the way they are spelled in the records.</p>
    <div class="grid2">${field('Dictation', 'enabled', v.enabled ? 'yes' : '', { type: 'select', options: [['yes', 'On for everyone'], ['', 'Off']], blank: false })}${field('Speech model', 'model', v.model || 'base', { type: 'select', blank: false, options: [['base', 'Fast (148 MB)'], ['small', 'Better (488 MB)'], ['turbo', 'Best, slower (574 MB)']] })}</div>
    <div data-vstatus><p class="meta">Checking.</p></div>
    <div class="row end"><button class="btn primary">Save</button></div></form>`;
}
function wireVoiceTab() {
  const f = document.getElementById('voiceset');
  f.onsubmit = async e => {
    e.preventDefault();
    try { await setMeta('voice', { enabled: !!val(f, 'enabled'), model: val(f, 'model'), lang: 'en' }); delete f.dataset.dirty; toast('Dictation saved.'); render(); } catch (ex) { fail(ex); }
  };
  const box = f.querySelector('[data-vstatus]');
  let tick = null;
  const paint = async () => {
    if (!document.body.contains(box)) return clearInterval(tick);
    let st;
    try { st = await api('/api/voice/status'); } catch (e) { box.innerHTML = `<p class="bad-text">${esc(e.message)}</p>`; return; }
    const j = st.job;
    const busy = j && !j.done && !j.error;
    const want = val(f, 'model') || st.model;
    const mb = n => Math.round(n / 1048576);
    box.innerHTML = `<div class="list flat">
      <div class="li"><div class="grow"><div class="t medium">The program (whisper.cpp)</div><div class="m">${st.bin ? 'Installed.' : st.platform === 'win32' ? 'Not installed yet. About 4 MB.' : 'Not installed. On this computer, build whisper.cpp and point CLINIC_WHISPER_BIN at whisper-cli.'}</div></div>${!st.bin && st.platform === 'win32' ? `<button type="button" class="btn secondary small" data-vdl="bin" ${busy ? 'disabled' : ''}>Download</button>` : chip(st.bin ? 'Ready' : 'Missing', st.bin ? 'ok' : 'warn')}</div>
      ${Object.entries(st.models).map(([k, m]) => `<div class="li"><div class="grow"><div class="t medium">Speech model: ${esc(m.label)}</div><div class="m">${m.size} MB${k === want ? ' · the one in use' : ''}</div></div>${m.have ? chip('Downloaded', 'ok') : `<button type="button" class="btn ${k === want ? 'primary' : 'secondary'} small" data-vdl="${k}" ${busy ? 'disabled' : ''}>Download</button>`}</div>`).join('')}</div>
      ${j ? `<p class="${j.error ? 'bad-text' : 'meta'}">${j.error ? esc(j.error) : j.done ? 'Download finished.' : `Downloading: ${mb(j.got)}${j.total ? ' of ' + mb(j.total) : ''} MB.`}</p>` : ''}
      <p class="meta">${st.ready ? 'Voice is ready. Press the mic in the top bar or F2, speak, and pause.' : 'Voice works once the program and the chosen model are both downloaded.'}</p>`;
    box.querySelectorAll('[data-vdl]').forEach(b => b.onclick = async () => { try { await api('/api/voice/download', { what: b.dataset.vdl }); paint(); } catch (e) { fail(e); } });
    if (!busy) { clearInterval(tick); tick = null; } else if (!tick) tick = setInterval(paint, 1500);
  };
  paint();
}
