// Encrypted backups of the database and every stored file.
// File layout: one line of JSON (salt, iv, settings), then AES-256-GCM ciphertext of a
// gzip stream, then the 16-byte GCM tag. Inside the gzip is a simple archive:
// [u32 name length][name][u64 size][bytes] repeated, ended by a zero name length.
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const { pipeline } = require('stream/promises');
const { Readable, Writable } = require('stream');

let C = null, timer = null, running = false;
const ITER = 250000;

function init(ctx) { C = ctx; reschedule(); setTimeout(catchUp, 20000); }

function settings() { return { time: '21:00', keep: 30, folder2: '', ...(C.getMeta('backup', {}) || {}) }; }
function backupDir() { const d = path.join(C.rootDir, 'backups'); fs.mkdirSync(d, { recursive: true }); return d; }

function setPassphrase(pass) {
  const salt = crypto.randomBytes(16);
  const key = crypto.pbkdf2Sync(pass, salt, ITER, 32, 'sha256');
  C.setMeta('backupKey', { salt: salt.toString('base64'), key: key.toString('base64'), iterations: ITER, set: Date.now() });
}

function status() {
  const s = settings(), k = C.getMeta('backupKey');
  let list = [];
  try { list = fs.readdirSync(backupDir()).filter(f => f.endsWith('.ccbak')).map(f => { const st = fs.statSync(path.join(backupDir(), f)); return { file: f, size: st.size, at: st.mtimeMs }; }).sort((a, b) => b.at - a.at).slice(0, 40); } catch (e) { /* none yet */ }
  return { hasKey: !!k, keySet: k ? k.set : 0, last: C.getMeta('backupLast'), folder: backupDir(), folder2: s.folder2, folder2Ok: s.folder2 ? fs.existsSync(s.folder2) : null, time: s.time, keep: s.keep, list, running };
}

function* walk(dir, base = '') {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const rel = base ? base + '/' + e.name : e.name;
    if (e.isDirectory()) yield* walk(path.join(dir, e.name), rel);
    else yield rel;
  }
}

// Writes one encrypted backup to `out`. Without files it holds the database alone, for the
// nightly copy to cloud storage, where the photos are kept one by one.
async function write(out, k, reason, withFiles) {
  const stamp = new Date();
  const snap = path.join(C.dataDir, `backup-snapshot-${process.pid}-${Date.now()}.db`);
  try {
    fs.rmSync(snap, { force: true });
    const { backup } = require('node:sqlite');
    await backup(C.db(), snap);
    const iv = crypto.randomBytes(12);
    const head = JSON.stringify({ app: 'apex-pms', format: 1, cipher: 'aes-256-gcm', kdf: 'pbkdf2-sha256', iterations: k.iterations, salt: k.salt, iv: iv.toString('base64'), made: stamp.toISOString(), reason, ...(withFiles ? {} : { files: false }) }) + '\n';
    const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(k.key, 'base64'), iv);
    const files = withFiles ? [...walk(C.filesDir)] : [];
    async function* archive() {
      const entry = function* (nm, size) { const nb = Buffer.from(nm, 'utf8'); const h = Buffer.alloc(4 + nb.length + 8); h.writeUInt32BE(nb.length, 0); nb.copy(h, 4); h.writeBigUInt64BE(BigInt(size), 4 + nb.length); yield h; };
      const st = fs.statSync(snap);
      yield* entry('clinic.db', st.size);
      for await (const ch of fs.createReadStream(snap)) yield ch;
      for (const f of files) {
        const full = path.join(C.filesDir, f);
        let size; try { size = fs.statSync(full).size; } catch (e) { continue; }
        yield* entry('files/' + f, size);
        if (size > 0) for await (const ch of fs.createReadStream(full, { end: size - 1 })) yield ch;
      }
      yield Buffer.alloc(4);
    }
    const ws = fs.createWriteStream(out + '.part');
    ws.write(head);
    await pipeline(Readable.from(archive()), zlib.createGzip({ level: 6 }), cipher, ws, { end: false });
    await new Promise((resolve, reject) => ws.end(cipher.getAuthTag(), err => (err ? reject(err) : resolve())));
    fs.renameSync(out + '.part', out);
    return { size: fs.statSync(out).size, files: files.length };
  } catch (e) {
    fs.rmSync(out + '.part', { force: true });
    throw e;
  } finally {
    fs.rmSync(snap, { force: true });
  }
}

function backupName(stamp = new Date()) {
  const p2 = n => String(n).padStart(2, '0');
  return `Apex PMS backup ${stamp.getFullYear()}-${p2(stamp.getMonth() + 1)}-${p2(stamp.getDate())} ${p2(stamp.getHours())}${p2(stamp.getMinutes())}${p2(stamp.getSeconds())}.ccbak`;
}

async function run(reason = 'Scheduled') {
  if (running) return { ok: false, error: 'A backup is already running.' };
  const k = C.getMeta('backupKey');
  if (!k) return { ok: false, error: 'Set a backup passphrase first.' };
  running = true;
  const name = backupName();
  const out = path.join(backupDir(), name);
  try {
    const { size, files } = await write(out, k, reason, true);
    let copied = '';
    const s = settings();
    if (s.folder2) {
      try { fs.copyFileSync(out, path.join(s.folder2, name)); copied = s.folder2; prune(s.folder2, s.keep); }
      catch (e) { copied = 'failed: ' + e.message; }
    }
    prune(backupDir(), s.keep);
    const last = { at: Date.now(), file: name, size, ok: true, reason, copied, files };
    C.setMeta('backupLast', last);
    C.audit(`Backup made (${reason.toLowerCase()})`);
    if (C.afterBackup) C.afterBackup(reason);
    return last;
  } catch (e) {
    const last = { at: Date.now(), ok: false, error: e.message, reason };
    C.setMeta('backupLast', last);
    return last;
  } finally {
    running = false;
  }
}

// The database alone, encrypted with the backup passphrase, in a temporary file for the
// cloud copy. The caller removes the file.
async function databaseOnly(reason) {
  const k = C.getMeta('backupKey');
  if (!k) throw httpErr(409, 'Set a backup passphrase first.');
  const dir = path.join(C.dataDir, 'cloud-outbox');
  fs.mkdirSync(dir, { recursive: true });
  const name = backupName();
  const out = path.join(dir, name);
  await write(out, k, reason, false);
  return { name, file: out };
}

function prune(dir, keep) {
  const list = fs.readdirSync(dir).filter(f => /^Apex PMS backup .*\.ccbak$/.test(f)).map(f => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs })).sort((a, b) => b.t - a.t);
  for (const x of list.slice(Math.max(1, keep || 30))) fs.rmSync(path.join(dir, x.f), { force: true });
}

function reschedule() {
  if (timer) clearTimeout(timer);
  const [h, m] = String(settings().time || '21:00').split(':').map(Number);
  const now = new Date(), at = new Date(now);
  at.setHours(h || 0, m || 0, 0, 0);
  if (at <= now) at.setDate(at.getDate() + 1);
  timer = setTimeout(async () => { await run('Scheduled'); reschedule(); }, at - now);
}

// Runs a backup at start-up when the last good one is more than a day old.
async function catchUp() {
  const last = C.getMeta('backupLast');
  if (!C.getMeta('backupKey')) return;
  if (!last || !last.ok || Date.now() - last.at > 26 * 3600000) await run('Catch-up');
}

// Restores a backup file over the live data. The current data is kept in a
// "previous-..." folder next to it.
async function restore(file, pass, { close, reopen }) {
  const fd = fs.openSync(file, 'r');
  const size = fs.fstatSync(fd).size;
  const headBuf = Buffer.alloc(Math.min(4096, size));
  fs.readSync(fd, headBuf, 0, headBuf.length, 0);
  const nl = headBuf.indexOf(10);
  let head;
  try { head = JSON.parse(headBuf.subarray(0, nl).toString('utf8')); } catch (e) { fs.closeSync(fd); throw httpErr(400, 'The file you picked is not a Apex PMS backup.'); }
  if (head.app !== 'apex-pms') { fs.closeSync(fd); throw httpErr(400, 'The file you picked is not a Apex PMS backup.'); }
  const tag = Buffer.alloc(16);
  fs.readSync(fd, tag, 0, 16, size - 16);
  fs.closeSync(fd);
  const key = crypto.pbkdf2Sync(pass, Buffer.from(head.salt, 'base64'), head.iterations, 32, 'sha256');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(head.iv, 'base64'));
  decipher.setAuthTag(tag);
  const stage = path.join(C.dataDir, 'restore-stage');
  fs.rmSync(stage, { recursive: true, force: true });
  fs.mkdirSync(path.join(stage, 'files'), { recursive: true });

  let buf = Buffer.alloc(0), state = 'name', nameLen = 0, name = '', remaining = 0n, out = null, done = false;
  const sink = new Writable({
    write(chunk, enc, cb) {
      buf = Buffer.concat([buf, chunk]);
      try {
        for (;;) {
          if (done) break;
          if (state === 'name') {
            if (buf.length < 4) break;
            nameLen = buf.readUInt32BE(0);
            if (nameLen === 0) { done = true; buf = Buffer.alloc(0); break; }
            if (buf.length < 4 + nameLen + 8) break;
            name = buf.subarray(4, 4 + nameLen).toString('utf8');
            remaining = buf.readBigUInt64BE(4 + nameLen);
            buf = buf.subarray(4 + nameLen + 8);
            const safe = path.normalize(name).replace(/^(\.\.[/\\])+/, '');
            const dest = path.join(stage, safe);
            if (!dest.startsWith(stage + path.sep)) throw new Error('Bad entry in backup.');
            fs.mkdirSync(path.dirname(dest), { recursive: true });
            out = fs.openSync(dest, 'w');
            state = 'data';
          }
          if (state === 'data') {
            if (remaining === 0n) { fs.closeSync(out); state = 'name'; continue; }
            if (!buf.length) break;
            const take = Number(remaining < BigInt(buf.length) ? remaining : BigInt(buf.length));
            fs.writeSync(out, buf, 0, take);
            buf = buf.subarray(take);
            remaining -= BigInt(take);
            if (remaining === 0n) { fs.closeSync(out); state = 'name'; }
          }
        }
        cb();
      } catch (e) { cb(e); }
    },
  });
  try {
    await pipeline(fs.createReadStream(file, { start: nl + 1, end: size - 17 }), decipher, zlib.createGunzip(), sink);
  } catch (e) {
    fs.rmSync(stage, { recursive: true, force: true });
    if (/auth|decrypt|unsupported state/i.test(e.message)) throw httpErr(401, 'Wrong passphrase.');
    throw httpErr(400, 'The backup file is damaged: ' + e.message);
  }
  if (!done || !fs.existsSync(path.join(stage, 'clinic.db'))) { fs.rmSync(stage, { recursive: true, force: true }); throw httpErr(400, 'The backup file is incomplete.'); }

  const p2 = n => String(n).padStart(2, '0');
  const d = new Date();
  const prev = path.join(C.dataDir, `previous-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}`);
  fs.mkdirSync(prev, { recursive: true });
  close();
  // Every move is recorded so a failure halfway (Windows holds a file open, say)
  // puts the old data back and reopens it instead of leaving an empty clinic.
  const moved = [];
  const move = (from, to) => { renameRetry(from, to); moved.push([from, to]); };
  try {
    for (const f of ['clinic.db', 'clinic.db-wal', 'clinic.db-shm']) if (fs.existsSync(path.join(C.dataDir, f))) move(path.join(C.dataDir, f), path.join(prev, f));
    // A database-only backup from the cloud leaves the photos here in place. Missing ones
    // come back from the cloud as they are opened.
    if (head.files !== false && fs.existsSync(C.filesDir)) move(C.filesDir, path.join(prev, 'files'));
    move(path.join(stage, 'clinic.db'), path.join(C.dataDir, 'clinic.db'));
    if (head.files !== false) move(path.join(stage, 'files'), C.filesDir);
  } catch (e) {
    for (const [from, to] of moved.reverse()) { try { renameRetry(to, from); } catch (e2) { console.error('Restore roll-back:', e2.message); } }
    try { reopen(); } catch (e3) { console.error('Reopen after failed restore:', e3.message); }
    fs.rmSync(stage, { recursive: true, force: true });
    throw httpErr(409, 'The restore could not finish and the clinic data was put back as it was. Close other windows using the clinic files and try again. (' + e.message + ')');
  }
  fs.rmSync(stage, { recursive: true, force: true });
  reopen();
  C.db().exec('DELETE FROM sessions');
}

// Windows can refuse a rename for a moment while antivirus or a viewer holds the file.
function renameRetry(from, to) {
  for (let i = 0; ; i++) {
    try { return fs.renameSync(from, to); }
    catch (e) { if (i >= 8 || !/EPERM|EBUSY|EACCES/.test(e.code || '')) throw e; const until = Date.now() + 250; while (Date.now() < until) { /* short wait */ } }
  }
}

function httpErr(code, msg) { const e = new Error(msg); e.code = code; e.expose = true; return e; }

module.exports = { init, run, status, setPassphrase, reschedule, restore, databaseOnly, isRunning: () => running };
