// Updates from Gid's download page on GitHub. The program checks the feed (update.json) when it
// starts and every six hours, downloads a newer version in the background and unpacks it into
// update\ready. Nothing is replaced while the program runs: the launcher (launch.js) puts the
// new files in place when the program closes for the day, or when update.bat runs.
//
// Each update is signed with Gid's key. The program refuses a feed or a file that isn't signed
// by that key or doesn't match its checksum, so a changed download can't run on the branch PC.
// Only the app and server folders are replaced. The data folder, the backups and node.exe are
// never touched, and the old version is kept in update\previous to go back to.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { readZip } = require('./zip.js');

const ROOT = process.env.CLINIC_INSTALL_ROOT || path.resolve(__dirname, '..');
const DATA = process.env.CLINIC_DATA || path.join(ROOT, 'data');
const UPD = path.join(ROOT, 'update');
const READY = path.join(UPD, 'ready');
const PREV = path.join(UPD, 'previous');
const FEED = process.env.CLINIC_UPDATE_FEED || 'https://raw.githubusercontent.com/shinigami1235-creator/apex-patient-management-system/main/update.json';
const PUBLIC_KEY = process.env.CLINIC_UPDATE_KEY || `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAUUf5yxESBRosXxqzr+6KhvF34v2IEehFXN/KjibjMng=
-----END PUBLIC KEY-----`;
// The folders an update replaces. node.exe stays, since the launcher runs on it; a new Node comes with the installer.
const PARTS = ['app', 'server'];

const versionOf = dir => { try { return JSON.parse(fs.readFileSync(path.join(dir, 'server', 'version.json'), 'utf8')).version; } catch (e) { return ''; } };
const current = () => versionOf(ROOT);
function newer(a, b) {
  const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}

// The signed part of the feed, in a fixed order so the same feed always gives the same bytes.
const SIGNED = ['version', 'date', 'file', 'size', 'sha256', 'notes'];
const signedBytes = m => Buffer.from(JSON.stringify(SIGNED.map(k => [k, m[k] === undefined ? null : m[k]])));
function verified(m) {
  if (!m || typeof m !== 'object' || !m.signature || !/^\d+(\.\d+)*$/.test(String(m.version)) || !/^[\w.-]+\.zip$/.test(String(m.file)) || !/^[0-9a-f]{64}$/.test(String(m.sha256))) return false;
  try { return crypto.verify(null, signedBytes(m), PUBLIC_KEY, Buffer.from(m.signature, 'base64')); } catch (e) { return false; }
}

async function fetchFeed() {
  const r = await fetch(FEED + (FEED.includes('?') ? '&' : '?') + 't=' + Date.now(), { signal: AbortSignal.timeout(20000), headers: { 'Cache-Control': 'no-cache' } });
  if (!r.ok) throw new Error(`The update page answered ${r.status}.`);
  const m = await r.json();
  if (!verified(m)) throw new Error('The update page is not signed with the Apex key, so it was ignored.');
  return m;
}

// The version waiting in update\ready, when it is newer than the one running and still intact.
function ready() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(READY, 'MANIFEST.json'), 'utf8'));
    if (!verified(m) || versionOf(READY) !== m.version || !newer(m.version, current())) return null;
    for (const p of PARTS) if (!fs.existsSync(path.join(READY, p))) return null;
    return m;
  } catch (e) { return null; }
}

// Downloads and unpacks the version in the feed, when it is newer. Returns the ready manifest or null.
async function fetchUpdate(log = () => {}) {
  const m = await fetchFeed();
  if (!newer(m.version, current())) return null;
  const have = ready();
  if (have && have.version === m.version) return have;
  fs.mkdirSync(UPD, { recursive: true });
  const url = new URL(m.file, FEED).href;
  log(`Downloading version ${m.version}.`);
  const r = await fetch(url, { signal: AbortSignal.timeout(10 * 60000) });
  if (!r.ok) throw new Error(`The update file answered ${r.status}.`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (crypto.createHash('sha256').update(buf).digest('hex') !== m.sha256 || (m.size && buf.length !== m.size)) throw new Error('The update file did not match its checksum, so it was not used.');
  const tmp = READY + '.tmp';
  fs.rmSync(tmp, { recursive: true, force: true });
  for (const e of readZip(buf)) {
    const rel = e.name.replace(/\\/g, '/');
    if (rel.endsWith('/')) continue;
    if (!PARTS.includes(rel.split('/')[0]) || rel.split('/').some(s => s === '..' || s === '') || path.isAbsolute(rel)) throw new Error(`The update file has an unexpected entry: ${rel}`);
    const out = path.join(tmp, rel);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, e.data);
  }
  if (versionOf(tmp) !== m.version) throw new Error('The update file holds a different version from the update page.');
  fs.writeFileSync(path.join(tmp, 'MANIFEST.json'), JSON.stringify(m, null, 1));
  fs.rmSync(READY, { recursive: true, force: true });
  fs.renameSync(tmp, READY);
  log(`Version ${m.version} is downloaded and ready.`);
  return ready();
}

// Windows sometimes holds a folder for a moment (antivirus, the search index), so a move is tried a few times.
function move(from, to) {
  for (let i = 0; ; i++) {
    try { fs.renameSync(from, to); return; }
    catch (e) { if (i >= 20 || !['EPERM', 'EBUSY', 'EACCES'].includes(e.code)) throw e; Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 500); }
  }
}

// Puts the ready version in place. Run only while the program is closed.
function apply(log = () => {}) {
  const m = ready();
  if (!m) return null;
  const from = current();
  fs.rmSync(PREV, { recursive: true, force: true });
  fs.mkdirSync(path.join(PREV, 'data'), { recursive: true });
  // A copy of the database first, in case the new version changes how records are kept.
  for (const f of ['clinic.db', 'clinic.db-wal', 'clinic.db-shm']) if (fs.existsSync(path.join(DATA, f))) fs.copyFileSync(path.join(DATA, f), path.join(PREV, 'data', f));
  const done = [];
  try {
    for (const p of PARTS) { move(path.join(ROOT, p), path.join(PREV, p)); done.push(p); move(path.join(READY, p), path.join(ROOT, p)); done.push(p + '+'); }
  } catch (e) {
    // Back to how it was.
    for (const d of done.reverse()) {
      const p = d.replace('+', '');
      try { if (d.endsWith('+')) move(path.join(ROOT, p), path.join(READY, p)); else move(path.join(PREV, p), path.join(ROOT, p)); } catch (err) { /* reported below */ }
    }
    throw new Error(`The update could not be put in place (${e.message}). Version ${from} is still installed.`);
  }
  fs.writeFileSync(path.join(PREV, 'VERSION.json'), JSON.stringify({ version: from, replacedBy: m.version, at: new Date().toISOString() }));
  fs.rmSync(READY, { recursive: true, force: true });
  log(`Updated from version ${from} to ${m.version}.`);
  return { from, to: m.version };
}

// Back to the version before the last update, when the new one would not start.
function rollback(log = () => {}) {
  let v;
  try { v = JSON.parse(fs.readFileSync(path.join(PREV, 'VERSION.json'), 'utf8')); } catch (e) { return null; }
  for (const p of PARTS) if (!fs.existsSync(path.join(PREV, p))) return null;
  const failed = path.join(UPD, 'failed');
  fs.rmSync(failed, { recursive: true, force: true });
  fs.mkdirSync(failed, { recursive: true });
  for (const p of PARTS) { if (fs.existsSync(path.join(ROOT, p))) move(path.join(ROOT, p), path.join(failed, p)); move(path.join(PREV, p), path.join(ROOT, p)); }
  for (const f of ['clinic.db', 'clinic.db-wal', 'clinic.db-shm']) { const b = path.join(PREV, 'data', f); if (fs.existsSync(b)) fs.copyFileSync(b, path.join(DATA, f)); else fs.rmSync(path.join(DATA, f), { force: true }); }
  fs.rmSync(PREV, { recursive: true, force: true });
  log(`Went back to version ${v.version}. The version that would not start is in update\\failed.`);
  return v;
}

module.exports = { ROOT, UPD, FEED, current, newer, verified, signedBytes, fetchFeed, fetchUpdate, ready, apply, rollback };
