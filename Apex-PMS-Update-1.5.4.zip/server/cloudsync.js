// Copies the branch's photos and a nightly database backup to cloud storage, encrypted on the
// branch PC before they leave it.
//
// Photos: every file goes up once, sealed with the branch's data key (AES-256-GCM), under
// files/<id>. A photo missing on the PC, after a restore or on a new PC, comes back from the
// cloud the first time it is opened. The data key sits in the database and, wrapped with the
// backup passphrase, in keys.json in the bucket, so the passphrase alone opens the photos again.
//
// Backups: after each nightly backup on the PC, the database alone goes up under backups/, in
// the same encrypted format as the PC's own backups. The last 30 are kept.
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cloud = require('./cloud.js');

let C = null;
const MAGIC = Buffer.from('APXC1');
const S = { queue: [], queued: new Set(), busy: false, lastError: '', lastErrorAt: 0, retry: null, download: null, backupBusy: false };

function tables() { C.db().exec('CREATE TABLE IF NOT EXISTS cloudfiles (id TEXT PRIMARY KEY, at INTEGER); CREATE TABLE IF NOT EXISTS cloudtrash (id TEXT PRIMARY KEY, at INTEGER);'); }
function init(ctx) {
  C = ctx;
  tables();
  setTimeout(scan, 30000);
  setInterval(scan, 10 * 60000);
}
// After a restore swaps the database, the tables are made again if the backup predates them.
function reopened() { tables(); S.queue = []; S.queued.clear(); }

function settings() { return { photos: false, backups: false, keep: 30, ...(C.getMeta('cloud') || {}) }; }
function on(kind) { const s = settings(); return cloud.ready(s) && !!s[kind]; }

// ---------- keys ----------
function dataKey() {
  let k = C.getMeta('cloudKey');
  if (!k) { k = { key: crypto.randomBytes(32).toString('base64'), id: crypto.randomUUID(), made: Date.now() }; C.setMeta('cloudKey', k); }
  return { key: Buffer.from(k.key, 'base64'), id: k.id };
}
function seal(buf) {
  const { key } = dataKey(), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const body = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([MAGIC, iv, body, c.getAuthTag()]);
}
function unseal(buf, key = dataKey().key) {
  if (!buf || buf.length < MAGIC.length + 28 || !buf.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error('Not an Apex PMS file.');
  const iv = buf.subarray(5, 17), tag = buf.subarray(buf.length - 16), body = buf.subarray(17, buf.length - 16);
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(body), d.final()]);
}
// keys.json: the data key locked with the key made from the backup passphrase.
async function publishKey() {
  const s = settings(), bk = C.getMeta('backupKey');
  if (!cloud.ready(s) || !bk) return;
  // A folder already used by another set-up keeps its key: this PC restores from it first, or
  // the admin picks a different folder.
  const had = await cloud.get(s, 'keys.json');
  if (had) {
    let doc = null; try { doc = JSON.parse(had.toString('utf8')); } catch (e) { /* unreadable, so it is replaced */ }
    const mine = C.getMeta('cloudKey');
    if (doc && doc.keyId && (!mine || mine.id !== doc.keyId)) throw Object.assign(new Error('This cloud folder already holds Apex PMS data from another set-up. To bring it onto this PC, leave photos and backups off and restore a cloud backup first. To start a new copy, use a different folder.'), { code: 409, expose: true });
  }
  const { key, id } = dataKey(), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', Buffer.from(bk.key, 'base64'), iv);
  const wrapped = Buffer.concat([c.update(key), c.final()]);
  const doc = { app: 'apex-pms', keyId: id, kdf: 'pbkdf2-sha256', iterations: bk.iterations, salt: bk.salt, iv: iv.toString('base64'), wrapped: wrapped.toString('base64'), tag: c.getAuthTag().toString('base64'), written: new Date().toISOString() };
  await cloud.put(s, 'keys.json', Buffer.from(JSON.stringify(doc, null, 1)), 'application/json');
}
// Opens keys.json with the passphrase, for a PC that has the photos in the cloud and no database.
function keyFromPassphrase(doc, pass) {
  const kek = crypto.pbkdf2Sync(pass, Buffer.from(doc.salt, 'base64'), doc.iterations, 32, 'sha256');
  const d = crypto.createDecipheriv('aes-256-gcm', kek, Buffer.from(doc.iv, 'base64'));
  d.setAuthTag(Buffer.from(doc.tag, 'base64'));
  return Buffer.concat([d.update(Buffer.from(doc.wrapped, 'base64')), d.final()]);
}

// ---------- photos ----------
function localFiles() { try { return fs.readdirSync(C.filesDir).filter(f => C.fileRe.test(f)); } catch (e) { return []; } }
function isUp(id) { return !!C.db().prepare('SELECT 1 FROM cloudfiles WHERE id = ?').get(id); }
function enqueue(id) {
  if (!on('photos') || S.queued.has(id) || isUp(id)) return;
  S.queued.add(id); S.queue.push(id);
  pump();
}
function scan() {
  if (!C || !on('photos')) return;
  const up = new Set(C.db().prepare('SELECT id FROM cloudfiles').all().map(r => r.id));
  for (const f of localFiles()) if (!up.has(f) && !S.queued.has(f)) { S.queued.add(f); S.queue.push(f); }
  pump();
}
async function pump() {
  if (S.busy) return;
  S.busy = true;
  try {
    const s = settings();
    for (const t of C.db().prepare('SELECT id FROM cloudtrash').all()) {
      if (!cloud.ready(s)) break;
      await cloud.del(s, 'files/' + t.id);
      C.db().prepare('DELETE FROM cloudtrash WHERE id = ?').run(t.id);
    }
    while (S.queue.length && on('photos')) {
      const id = S.queue[0];
      let buf;
      try { buf = fs.readFileSync(path.join(C.filesDir, id)); } catch (e) { buf = null; }
      if (buf) {
        await cloud.put(settings(), 'files/' + id, seal(buf));
        C.db().prepare('INSERT OR REPLACE INTO cloudfiles (id, at) VALUES (?, ?)').run(id, Date.now());
      }
      S.queue.shift(); S.queued.delete(id);
    }
    S.lastError = '';
  } catch (e) {
    // The internet dropped or the keys stopped working. The queue waits and tries again.
    S.lastError = e.message; S.lastErrorAt = Date.now();
    clearTimeout(S.retry); S.retry = setTimeout(pump, 5 * 60000);
  } finally { S.busy = false; }
}
// A deleted photo is deleted from the cloud too, now or when the cloud can next be reached.
function forget(id) {
  if (!C) return;
  const was = isUp(id);
  C.db().prepare('DELETE FROM cloudfiles WHERE id = ?').run(id);
  if (was) { C.db().prepare('INSERT OR REPLACE INTO cloudtrash (id, at) VALUES (?, ?)').run(id, Date.now()); pump(); }
}
// Brings one missing photo back from the cloud. Returns true when it is on the PC again.
const fetching = new Map();
function fetchMissing(id) {
  const s = settings();
  if (!cloud.ready(s) || !C.fileRe.test(id)) return Promise.resolve(false);
  if (fetching.has(id)) return fetching.get(id);
  const p = (async () => {
    try {
      const buf = await cloud.get(s, 'files/' + id);
      if (!buf) return false;
      const plain = unseal(buf);
      const file = path.join(C.filesDir, id);
      fs.writeFileSync(file + '.part', plain); fs.renameSync(file + '.part', file);
      C.db().prepare('INSERT OR REPLACE INTO cloudfiles (id, at) VALUES (?, ?)').run(id, Date.now());
      return true;
    } catch (e) { S.lastError = e.message; S.lastErrorAt = Date.now(); return false; }
    finally { fetching.delete(id); }
  })();
  fetching.set(id, p);
  return p;
}
// After a restore from the cloud: every photo the PC lacks, in the background.
async function downloadAll() {
  if (S.download && S.download.running) return;
  const s = settings();
  if (!cloud.ready(s)) return;
  S.download = { running: true, done: 0, total: 0, failed: 0, started: Date.now() };
  try {
    const have = new Set(localFiles());
    const want = (await cloud.list(s, 'files/')).map(o => o.key.slice('files/'.length)).filter(id => C.fileRe.test(id) && !have.has(id));
    S.download.total = want.length;
    for (const id of want) { if (await fetchMissing(id)) S.download.done++; else S.download.failed++; }
  } catch (e) { S.lastError = e.message; S.lastErrorAt = Date.now(); }
  finally { S.download.running = false; S.download.ended = Date.now(); }
}

// ---------- backups ----------
async function backupNow(reason = 'Nightly') {
  if (!on('backups')) return { ok: false, error: 'Cloud backups are off.' };
  if (S.backupBusy) return { ok: false, error: 'A cloud backup is already running.' };
  S.backupBusy = true;
  let made = null;
  try {
    made = await C.backup.databaseOnly(reason);
    const s = settings();
    const body = fs.readFileSync(made.file);
    await cloud.put(s, 'backups/' + made.name, body);
    const keep = Math.max(1, +s.keep || 30);
    const list = (await cloud.list(s, 'backups/')).filter(o => o.key.endsWith('.ccbak')).sort((a, b) => b.key.localeCompare(a.key));
    for (const o of list.slice(keep)) await cloud.del(s, o.key);
    const last = { ok: true, at: Date.now(), file: made.name, size: body.length, reason };
    C.setMeta('cloudBackupLast', last);
    C.audit(`Cloud backup made (${reason.toLowerCase()})`);
    return last;
  } catch (e) {
    const last = { ok: false, at: Date.now(), error: e.message, reason };
    C.setMeta('cloudBackupLast', last);
    return last;
  } finally {
    if (made) fs.rmSync(made.file, { force: true });
    S.backupBusy = false;
  }
}
async function listBackups() {
  const s = settings();
  return (await cloud.list(s, 'backups/')).filter(o => o.key.endsWith('.ccbak')).map(o => ({ name: o.key.slice('backups/'.length), size: o.size, at: o.at })).sort((a, b) => b.name.localeCompare(a.name));
}
// Downloads one cloud backup to a file for backup.restore.
async function download(name, to) {
  if (!/^Apex PMS backup [\d-]+ \d{6}\.ccbak$/.test(name)) throw Object.assign(new Error('Pick a backup from the list.'), { code: 400, expose: true });
  const buf = await cloud.get(settings(), 'backups/' + name);
  if (!buf) throw Object.assign(new Error('That backup is no longer in the cloud.'), { code: 404, expose: true });
  fs.writeFileSync(to, buf);
}

function status() {
  const s = settings();
  const local = localFiles();
  const up = C.db().prepare('SELECT COUNT(*) n FROM cloudfiles').get().n;
  return {
    settings: { ...cloud.publicSettings(s), photos: !!s.photos, backups: !!s.backups, keep: +s.keep || 30 },
    ready: cloud.ready(s),
    photos: { local: local.length, uploaded: Math.min(up, local.length), waiting: S.queue.length, busy: S.busy },
    lastError: S.lastError, lastErrorAt: S.lastErrorAt,
    backupLast: C.getMeta('cloudBackupLast'), backupBusy: S.backupBusy,
    download: S.download,
  };
}

module.exports = { init, reopened, settings, on, enqueue, scan, pump, forget, fetchMissing, downloadAll, backupNow, listBackups, download, publishKey, keyFromPassphrase, seal, unseal, status };
