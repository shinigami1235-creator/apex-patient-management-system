# Apex Patient Management System: the laptop's Mobile hotspot, through the Windows tethering API.
# Run by server\hotspot.js as: powershell -File hotspot.ps1 status|on|off
# Prints one line of JSON. Needs Windows PowerShell 5.1, which every Windows 10 and 11 PC has.
param([string]$Action = 'status')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$out = [ordered]@{ ok = $true; supported = $true }
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $ext = [System.WindowsRuntimeSystemExtensions].GetMethods()
  $asTaskOp = ($ext | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  $asTaskAct = ($ext | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
  function Await($op, [Type]$type) { $t = $asTaskOp.MakeGenericMethod($type).Invoke($null, @($op)); $t.Wait(-1) | Out-Null; $t.Result }
  function AwaitAction($act) { $t = $asTaskAct.Invoke($null, @($act)); $t.Wait(-1) | Out-Null }
  $null = [Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]
  $null = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]
  $null = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]
  $TM = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]
  $resultType = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult]

  # The hotspot hangs off a connection. With internet it shares it; without, any other
  # connection the laptop has (a router with no internet, a cable) is enough to start it.
  $conn = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
  $out.sharing = 'internet'
  if (-not $conn) {
    $out.sharing = 'none'
    foreach ($p in [Windows.Networking.Connectivity.NetworkInformation]::GetConnectionProfiles()) {
      if ($p.NetworkAdapter -ne $null) {
        try { if ($TM::GetTetheringCapabilityFromConnectionProfile($p).ToString() -eq 'Enabled') { $conn = $p; break } } catch { }
      }
    }
  }
  if (-not $conn) { throw 'NOPROFILE' }
  $cap = $TM::GetTetheringCapabilityFromConnectionProfile($conn).ToString()
  if ($cap -ne 'Enabled') { throw ('CAPABILITY:' + $cap) }
  $out.network = $conn.ProfileName
  $tm = $TM::CreateFromConnectionProfile($conn)

  if ($Action -eq 'on' -and $tm.TetheringOperationalState.ToString() -ne 'On') {
    # Windows turns an idle hotspot off after 5 minutes. A clinic hotspot stays on.
    try { $TM::DisableNoConnectionsTimeout() } catch { try { $tm.DisableNoConnectionsTimeout() } catch { } }
    $r = Await ($tm.StartTetheringAsync()) $resultType
    if ($r.Status.ToString() -ne 'Success') { throw ('START:' + $r.Status.ToString() + ':' + $r.AdditionalErrorMessage) }
  }
  if ($Action -eq 'off' -and $tm.TetheringOperationalState.ToString() -ne 'Off') {
    $r = Await ($tm.StopTetheringAsync()) $resultType
    if ($r.Status.ToString() -ne 'Success') { throw ('STOP:' + $r.Status.ToString() + ':' + $r.AdditionalErrorMessage) }
  }
  if ($Action -eq 'settings') { Start-Process 'ms-settings:network-mobilehotspot' }

  $cfg = $tm.GetCurrentAccessPointConfiguration()
  $out.state = $tm.TetheringOperationalState.ToString()
  $out.ssid = $cfg.Ssid
  $out.passphrase = $cfg.Passphrase
  try { $out.band = $cfg.Band.ToString() } catch { $out.band = '' }
  $out.clients = [int]$tm.ClientCount
  $out.max = [int]$tm.MaxClientCount
  $list = @()
  try { foreach ($c in $tm.GetTetheringClients()) { $list += [ordered]@{ mac = $c.MacAddress; names = @($c.HostNames | ForEach-Object { $_.DisplayName }) } } } catch { }
  $out.devices = $list
  try { $out.idleOff = [bool]$TM::IsNoConnectionsTimeoutEnabled() } catch { try { $out.idleOff = [bool]$tm.IsNoConnectionsTimeoutEnabled() } catch { $out.idleOff = $null } }
} catch {
  $out.ok = $false
  $out.error = [string]$_.Exception.Message
  if ($_.Exception.InnerException) { $out.error = [string]$_.Exception.InnerException.Message }
  if ([string]$_ -match '^(NOPROFILE|CAPABILITY:|START:|STOP:)') { $out.error = [string]$_ }
}
$out | ConvertTo-Json -Compress -Depth 4
