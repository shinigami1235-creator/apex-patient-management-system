// LINE on the branch PC: booking confirmations, reminders the day before and follow-ups that
// are due, sent to each patient from Apex's LINE Official Account in the patient's language.
//
// The PC sends through LINE's Messaging API, which needs only its internet. Linking a patient
// needs LINE to reach the PC: the patient scans a QR on the tablet, LINE opens a chat with the
// clinic and a link code typed in, and when they send it LINE calls /line/webhook here. That
// address has to be open to the internet, such as through a Cloudflare tunnel Apex's IT sets up.
// A patient who is not linked gets their reminder on the "send by hand" list instead.
'use strict';
const crypto = require('crypto');

const API = () => (process.env.CLINIC_LINE_API || 'https://api.line.me').replace(/\/$/, '');

// Messages in each language. {name} {date} {time} {doctor} {clinic} {phone} {reason} are filled in.
const DEFAULT_TEXTS = {
  confirm: {
    th: 'สวัสดีค่ะ คุณ{name} {clinic} ยืนยันนัดของคุณ{date} เวลา {time} น. กับ{doctor} หากต้องการเลื่อนนัด ตอบกลับข้อความนี้หรือโทร {phone} ค่ะ',
    en: 'Hello {name}, {clinic} confirms your appointment on {date} at {time} with {doctor}. To change it, reply here or call {phone}.',
    zh: '{name}您好，{clinic}确认您的预约：{date} {time}，医生：{doctor}。如需更改，请回复此消息或致电 {phone}。',
  },
  remind: {
    th: 'แจ้งเตือนนัดพรุ่งนี้ คุณ{name} มีนัดที่ {clinic} {date} เวลา {time} น. กับ{doctor} หากมาไม่ได้ ตอบกลับข้อความนี้หรือโทร {phone} ค่ะ',
    en: 'A reminder for tomorrow, {name}: your appointment at {clinic} is on {date} at {time} with {doctor}. If you cannot come, reply here or call {phone}.',
    zh: '{name}您好，提醒您明天在{clinic}的预约：{date} {time}，医生：{doctor}。如无法前来，请回复此消息或致电 {phone}。',
  },
  soon: {
    th: 'คุณ{name} อีกไม่นานถึงเวลานัดที่ {clinic} เวลา {time} น. ค่ะ',
    en: '{name}, your appointment at {clinic} is today at {time}.',
    zh: '{name}您好，您今天 {time} 在{clinic}有预约。',
  },
  followup: {
    th: 'สวัสดีค่ะ คุณ{name} ถึงเวลานัดติดตามผลที่ {clinic} แล้วค่ะ ({reason}) ตอบกลับข้อความนี้เพื่อนัดวันเวลาที่สะดวก หรือโทร {phone} ค่ะ',
    en: 'Hello {name}, it is time for your follow-up at {clinic} ({reason}). Reply here to choose a day, or call {phone}.',
    zh: '{name}您好，您在{clinic}的复诊时间到了（{reason}）。请回复此消息预约时间，或致电 {phone}。',
  },
  linked: {
    th: 'เชื่อม LINE กับ {clinic} แล้วค่ะ การยืนยันนัดและการแจ้งเตือนจะส่งมาที่นี่',
    en: 'Your LINE is now linked with {clinic}. Appointment confirmations and reminders will come here.',
    zh: '您的LINE已与{clinic}连接。预约确认和提醒将发送到这里。',
  },
};
const DEFAULT_RULES = { confirm: true, dayBefore: true, dayBeforeHour: 18, soon: false, soonHours: 2, followUp: true, followUpDays: 3 };

function settings(getMeta) {
  const m = getMeta('line') || {};
  return { ...m, rules: { ...DEFAULT_RULES, ...(m.rules || {}) }, texts: m.texts || {} };
}
function textFor(set, kind, lang) {
  const own = set.texts[kind] && set.texts[kind][lang];
  return own || DEFAULT_TEXTS[kind][lang] || DEFAULT_TEXTS[kind].th;
}
const LOCALE = { th: 'th-TH', en: 'en-GB', zh: 'zh-CN' };
function dateWords(iso, lang) {
  const d = new Date(iso + 'T12:00:00');
  const opts = lang === 'th' ? { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' } : { weekday: 'long', day: 'numeric', month: 'long' };
  return new Intl.DateTimeFormat(LOCALE[lang] || 'th-TH', opts).format(d);
}
function fill(text, v) { return text.replace(/\{(\w+)\}/g, (m, k) => (v[k] !== undefined && v[k] !== null ? String(v[k]) : '')); }

// Signature on a webhook call: base64 HMAC-SHA256 of the body with the channel secret.
function signed(secret, body, sig) {
  if (!secret || !sig) return false;
  const want = crypto.createHmac('sha256', secret).update(body).digest('base64');
  const a = Buffer.from(want), b = Buffer.from(String(sig));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function call(token, path, body) {
  const r = await fetch(API() + path, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) });
  if (!r.ok) { let msg = ''; try { msg = (await r.json()).message || ''; } catch (e) { /* not json */ } throw new Error(`LINE answered ${r.status}${msg ? ': ' + msg : ''}`); }
}
const push = (token, to, text) => call(token, '/v2/bot/message/push', { to, messages: [{ type: 'text', text: text.slice(0, 4900) }] });
const reply = (token, replyToken, text) => call(token, '/v2/bot/message/reply', { replyToken, messages: [{ type: 'text', text: text.slice(0, 4900) }] });

// A link code is "APEX" and six letters and digits, such as APEX-4F7K2Q.
const CODE_RE = /APEX[\s-]?([A-Z0-9]{6})/i;

module.exports = { DEFAULT_TEXTS, DEFAULT_RULES, settings, textFor, dateWords, fill, signed, push, reply, CODE_RE };
