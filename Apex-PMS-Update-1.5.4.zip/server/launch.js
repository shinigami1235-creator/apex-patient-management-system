// Starts the Apex Patient Management System and puts updates in place around it.
// Start Apex PMS.bat runs this; update.bat runs it with "update".
//
// - On start: a downloaded update that wasn't installed yet (the window was closed with the X)
//   installs first, unless someone presses N within 15 seconds.
// - The program runs as its own process. When it's closed for the day from the app, it says
//   whether to install the waiting update first, and this puts it in place.
// - If a new version stops within a minute of its first start, the old one comes back by itself.
'use strict';
const path = require('path');
const { spawn } = require('child_process');
const U = require('./update.js');

const PORT = +process.env.CLINIC_PORT || 4810;
// Exit codes the program uses to say how it was closed (server.js, POST /api/close).
const CLOSE = 40, CLOSE_UPDATE = 42, RESTART_UPDATE = 43;
const say = s => console.log(s);
const sleep = ms => new Promise(r => setTimeout(r, ms));

// Waits for Enter (yes) or N (no), or the time to run out (yes).
function askYes(question, seconds) {
  return new Promise(resolve => {
    const stdin = process.stdin;
    if (!stdin.isTTY) return resolve(true);
    let left = seconds, done = false;
    const finish = v => { if (done) return; done = true; clearInterval(t); stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', on); process.stdout.write('\n'); resolve(v); };
    const on = d => { const k = String(d).toLowerCase(); if (k === 'n') finish(false); else if (k === '\r' || k === '\n' || k === 'y') finish(true); else if (k === '\u0003') process.exit(1); };
    stdin.setRawMode(true); stdin.resume(); stdin.on('data', on);
    process.stdout.write(`${question} `);
    const t = setInterval(() => { left--; if (left <= 0) finish(true); }, 1000);
  });
}

async function running() {
  try { const r = await fetch(`http://127.0.0.1:${PORT}/api/hello`, { signal: AbortSignal.timeout(2000) }); return r.ok; } catch (e) { return false; }
}

function install(why) {
  const m = U.ready();
  if (!m) return null;
  say('');
  say(`Installing version ${m.version}${why ? ' ' + why : ''}. This takes about a minute. Don't close this window.`);
  try { return U.apply(say); } catch (e) { say(e.message); return null; }
}

function runServer() {
  return new Promise(resolve => {
    const child = spawn(process.execPath, ['--no-warnings', path.join(U.ROOT, 'server', 'server.js')], { stdio: 'inherit', env: { ...process.env, APEX_LAUNCHER: '1' } });
    child.on('exit', (code, signal) => resolve(code === null ? (signal ? 1 : 0) : code));
  });
}

// Ctrl+C reaches both; the program closes itself and this follows.
process.on('SIGINT', () => {});

async function run() {
  const waiting = U.ready();
  if (waiting && !(await running())) {
    say(`Version ${waiting.version} of the Apex Patient Management System is downloaded and ready.`);
    if (waiting.notes && waiting.notes.en) say(`What's new: ${waiting.notes.en}`);
    if (await askYes('Install it now? Press Enter to install, or N to start without it. It installs by itself in 15 seconds.', 15)) install();
  }
  let justUpdated = !!(waiting && !U.ready());
  for (;;) {
    const started = Date.now();
    const code = await runServer();
    if (code === CLOSE) { say('The Apex Patient Management System is closed.'); return 0; }
    if (code === CLOSE_UPDATE) {
      const r = install('before closing');
      say(r ? `Version ${r.to} is installed. It opens the next time the Apex PMS icon is pressed.` : 'Nothing was installed. The program is closed.');
      await sleep(4000);
      return 0;
    }
    if (code === RESTART_UPDATE) { const r = install(); justUpdated = !!r; say('Starting again.'); continue; }
    if (justUpdated && Date.now() - started < 60000 && code !== 0) {
      say('');
      say('The new version stopped as soon as it started.');
      if (U.rollback(say)) { justUpdated = false; say('Starting the previous version.'); continue; }
    }
    return code === 0 ? 0 : 1;
  }
}

async function manual() {
  say('Apex Patient Management System update');
  say(`Installed version: ${U.current() || 'unknown'}`);
  if (await running()) {
    say('');
    say('The program is open. Close it first: Close in the program on this PC, or close its black window. Then run update.bat again.');
    return 1;
  }
  let m = null;
  try { say('Checking for a newer version.'); m = await U.fetchUpdate(say); }
  catch (e) { say(e.message); m = U.ready(); if (m) say(`Installing version ${m.version}, which was downloaded earlier.`); }
  if (!m) { say(`This is the newest version.`); return 0; }
  if (m.notes && m.notes.en) say(`What's new: ${m.notes.en}`);
  const r = install();
  if (!r) return 1;
  say(`Done. Start it from the Apex PMS icon.`);
  return 0;
}

(process.argv[2] === 'update' ? manual() : run()).then(code => process.exit(code), e => { console.error(e); process.exit(1); });
