// Cloud storage for photos and backups, on any service that speaks the S3 protocol: Cloudflare R2,
// Amazon S3, DigitalOcean Spaces, Wasabi or Backblaze B2. Requests are signed with AWS
// Signature Version 4, written out here so the program needs nothing installed.
'use strict';

const crypto = require('crypto');

const sha256 = b => crypto.createHash('sha256').update(b).digest('hex');
const hmac = (k, s) => crypto.createHmac('sha256', k).update(s).digest();
// S3 wants every character escaped except A-Z a-z 0-9 - _ . ~, and the slashes of a key kept.
const enc = s => encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const encKey = k => k.split('/').map(enc).join('/');
const unx = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');

// The settings as the admin typed them, tidied: no trailing slash on the address, the prefix
// ending in one slash.
function clean(cfg) {
  const c = cfg || {};
  const endpoint = String(c.endpoint || '').trim().replace(/\/+$/, '');
  const prefix = String(c.prefix || '').trim().replace(/^\/+/, '').replace(/\/*$/, '/').replace(/^\/$/, '');
  return { endpoint, region: String(c.region || '').trim() || 'auto', bucket: String(c.bucket || '').trim(), accessKeyId: String(c.accessKeyId || '').trim(), secretAccessKey: String(c.secretAccessKey || '').trim(), prefix };
}
function ready(cfg) { const c = clean(cfg); return !!(c.endpoint && c.bucket && c.accessKeyId && c.secretAccessKey && /^https?:\/\//.test(c.endpoint)); }

// Path-style addresses (endpoint/bucket/key) work on every one of these services.
function urlFor(c, key, query = {}) {
  const u = new URL(c.endpoint);
  const basePath = u.pathname.replace(/\/+$/, '');
  const path = `${basePath}/${enc(c.bucket)}${key !== undefined ? '/' + encKey(key) : ''}`;
  const qs = Object.keys(query).sort().map(k => `${enc(k)}=${enc(String(query[k]))}`).join('&');
  return { host: u.host, path, qs, href: `${u.protocol}//${u.host}${path}${qs ? '?' + qs : ''}` };
}

// The headers that sign one request. `now` is passed in by the tests.
function sign(c, method, key, query, body, extraHeaders = {}, now = new Date()) {
  const { host, path, qs, href } = urlFor(c, key, query);
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '');
  const day = amzDate.slice(0, 8);
  const payloadHash = sha256(body || Buffer.alloc(0));
  const headers = { host, 'x-amz-content-sha256': payloadHash, 'x-amz-date': amzDate };
  for (const [k, v] of Object.entries(extraHeaders)) headers[k.toLowerCase()] = String(v).trim();
  const names = Object.keys(headers).sort();
  const canonical = [method, path, qs, names.map(n => `${n}:${headers[n]}`).join('\n') + '\n', names.join(';'), payloadHash].join('\n');
  const scope = `${day}/${c.region}/s3/aws4_request`;
  const toSign = ['AWS4-HMAC-SHA256', amzDate, scope, sha256(canonical)].join('\n');
  let k = hmac('AWS4' + c.secretAccessKey, day);
  for (const part of [c.region, 's3', 'aws4_request']) k = hmac(k, part);
  const signature = crypto.createHmac('sha256', k).update(toSign).digest('hex');
  headers.authorization = `AWS4-HMAC-SHA256 Credential=${c.accessKeyId}/${scope}, SignedHeaders=${names.join(';')}, Signature=${signature}`;
  delete headers.host;
  return { href, headers };
}

class CloudError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
// What the service said, in words the admin can act on.
function explain(status, text) {
  const code = (/<Code>([^<]+)<\/Code>/.exec(text || '') || [])[1] || '';
  if (code === 'NoSuchBucket') return 'The bucket does not exist. Check its name.';
  if (['InvalidAccessKeyId', 'SignatureDoesNotMatch', 'AuthorizationHeaderMalformed', 'InvalidArgument'].includes(code) || status === 401) return 'The cloud storage refused the keys. Check the access key, the secret key and the region.';
  if (code === 'AccessDenied' || status === 403) return 'The keys have no permission for this bucket. Give them read and write access to it.';
  return `The cloud storage answered ${status}${code ? ' ' + code : ''}.`;
}

async function request(cfg, method, key, { query = {}, body, headers = {}, timeout = 60000 } = {}) {
  const c = clean(cfg);
  if (!ready(c)) throw new CloudError(0, 'Cloud storage is not set up.');
  const { href, headers: h } = sign(c, method, key, query, body, headers);
  let res;
  try { res = await fetch(href, { method, headers: h, body: body && body.length ? body : undefined, signal: AbortSignal.timeout(timeout) }); }
  catch (e) { throw new CloudError(0, 'The cloud storage could not be reached. Check the internet connection and the address.'); }
  return res;
}

async function put(cfg, key, body, contentType = 'application/octet-stream') {
  const res = await request(cfg, 'PUT', clean(cfg).prefix + key, { body, headers: { 'content-type': contentType } });
  if (!res.ok) throw new CloudError(res.status, explain(res.status, await res.text()));
}
async function get(cfg, key) {
  const res = await request(cfg, 'GET', clean(cfg).prefix + key);
  if (res.status === 404) { const t = await res.text(); if (/NoSuchBucket/.test(t)) throw new CloudError(404, explain(404, t)); return null; }
  if (!res.ok) throw new CloudError(res.status, explain(res.status, await res.text()));
  return Buffer.from(await res.arrayBuffer());
}
async function del(cfg, key) {
  const res = await request(cfg, 'DELETE', clean(cfg).prefix + key);
  if (!res.ok && res.status !== 404) throw new CloudError(res.status, explain(res.status, await res.text()));
}
// Every key under a prefix, with its size and date, page by page.
async function list(cfg, sub = '') {
  const c = clean(cfg), out = [];
  let token = '';
  do {
    const query = { 'list-type': 2, prefix: c.prefix + sub, ...(token ? { 'continuation-token': token } : {}) };
    const res = await request(cfg, 'GET', undefined, { query });
    const text = await res.text();
    if (!res.ok) throw new CloudError(res.status, explain(res.status, text));
    for (const m of text.matchAll(/<Contents>([\s\S]*?)<\/Contents>/g)) {
      const pick = t => ((new RegExp(`<${t}>([^<]*)</${t}>`).exec(m[1]) || [])[1] || '');
      out.push({ key: unx(pick('Key')).slice(c.prefix.length), size: +pick('Size'), at: Date.parse(pick('LastModified')) || 0 });
    }
    token = /<IsTruncated>true<\/IsTruncated>/.test(text) ? unx((/<NextContinuationToken>([^<]*)<\/NextContinuationToken>/.exec(text) || [])[1] || '') : '';
  } while (token);
  return out;
}

// Writes, reads back and removes a small file, so the admin knows the settings work.
async function test(cfg) {
  const key = `connection-test/${crypto.randomUUID()}.txt`, body = Buffer.from('Apex PMS connection test ' + new Date().toISOString());
  await put(cfg, key, body, 'text/plain');
  const back = await get(cfg, key);
  await del(cfg, key);
  if (!back || !back.equals(body)) throw new CloudError(0, 'The test file came back different. Check the address and the bucket.');
  return true;
}

// The secret key never leaves the branch PC: screens get the settings without it.
function publicSettings(cfg) { const c = clean(cfg); return { ...c, secretAccessKey: '', hasSecret: !!c.secretAccessKey }; }

module.exports = { clean, ready, sign, put, get, del, list, test, publicSettings, CloudError };
