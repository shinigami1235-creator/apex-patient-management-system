// Voice on the branch PC: whisper.cpp turns a short recording into text, offline. The
// program and the speech models live in data/whisper. The owner downloads them from
// Settings, Voice. Nothing leaves the PC except those two downloads.
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const MODELS = {
  base: { file: 'ggml-base.bin', label: 'Fast', size: 148 },
  small: { file: 'ggml-small.bin', label: 'Better', size: 488 },
  turbo: { file: 'ggml-large-v3-turbo-q5_0.bin', label: 'Best, slower', size: 574 },
};
const MODEL_URL = f => `https://huggingface.co/ggerganov/whisper.cpp/resolve/main/${f}`;
const RELEASES = 'https://api.github.com/repos/ggml-org/whisper.cpp/releases?per_page=20';
const BIN_FALLBACK = 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.7.6/whisper-bin-x64.zip';

let dir = '';
let job = null; // { what, got, total, error }

function init(dataDir) { dir = path.join(dataDir, 'whisper'); }

// The program: CLINIC_WHISPER_BIN, or whisper-cli found anywhere under data/whisper/bin.
function findBin() {
  if (process.env.CLINIC_WHISPER_BIN) return fs.existsSync(process.env.CLINIC_WHISPER_BIN) ? process.env.CLINIC_WHISPER_BIN : '';
  const root = path.join(dir, 'bin');
  const names = process.platform === 'win32' ? ['whisper-cli.exe', 'main.exe'] : ['whisper-cli', 'main'];
  const walk = (d, depth) => {
    let list = [];
    try { list = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return ''; }
    for (const n of names) if (list.some(x => x.isFile() && x.name === n)) return path.join(d, n);
    if (depth > 3) return '';
    for (const x of list) if (x.isDirectory()) { const f = walk(path.join(d, x.name), depth + 1); if (f) return f; }
    return '';
  };
  return walk(root, 0);
}
function modelPath(name) {
  if (process.env.CLINIC_WHISPER_MODEL) return process.env.CLINIC_WHISPER_MODEL;
  const m = MODELS[name] || MODELS.base;
  return path.join(dir, 'models', m.file);
}
function haveModel(name) { try { return fs.statSync(modelPath(name)).size > 1e6 || !!process.env.CLINIC_WHISPER_MODEL; } catch (e) { return false; } }

function status(settings = {}) {
  const model = MODELS[settings.model] ? settings.model : 'base';
  return {
    platform: process.platform, bin: !!findBin(), model, ready: !!findBin() && haveModel(model),
    models: Object.fromEntries(Object.entries(MODELS).map(([k, m]) => [k, { label: m.label, size: m.size, have: haveModel(k) }])),
    job: job ? { ...job } : null,
  };
}

// Streams a download to a .part file and moves it in place when complete.
async function fetchTo(url, file, what) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const r = await fetch(url, { headers: { 'User-Agent': 'ApexPMS' }, redirect: 'follow' });
  if (!r.ok) throw new Error(`${what} could not download (${r.status}).`);
  job.total = +r.headers.get('content-length') || 0;
  const part = file + '.part';
  const out = fs.createWriteStream(part);
  try {
    for await (const chunk of r.body) { job.got += chunk.length; if (!out.write(chunk)) await new Promise(res => out.once('drain', res)); }
    await new Promise((res, rej) => out.end(e => (e ? rej(e) : res())));
  } catch (e) { out.destroy(); fs.rmSync(part, { force: true }); throw e; }
  fs.renameSync(part, file);
}

async function binURL() {
  try {
    const r = await fetch(RELEASES, { headers: { 'User-Agent': 'ApexPMS', Accept: 'application/vnd.github+json' } });
    if (r.ok) for (const rel of await r.json()) { const a = (rel.assets || []).find(x => x.name === 'whisper-bin-x64.zip'); if (a) return a.browser_download_url; }
  } catch (e) { /* the fixed release below */ }
  return BIN_FALLBACK;
}

// Starts a download in the background. what: 'bin' or a model name.
function download(what) {
  if (job && !job.done && !job.error) throw new Error('A download is already running.');
  if (what !== 'bin' && !MODELS[what]) throw new Error('Unknown model.');
  if (what === 'bin' && process.platform !== 'win32') throw new Error('The program downloads only on Windows. On this PC, build whisper.cpp and set CLINIC_WHISPER_BIN to whisper-cli.');
  job = { what, got: 0, total: 0, done: false, error: '' };
  (async () => {
    if (what === 'bin') {
      const zip = path.join(dir, 'whisper-bin-x64.zip');
      await fetchTo(await binURL(), zip, 'The voice program');
      const dest = path.join(dir, 'bin');
      fs.rmSync(dest, { recursive: true, force: true });
      await new Promise((res, rej) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -Force -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${dest.replace(/'/g, "''")}'`], { windowsHide: true, timeout: 120000 }, e => (e ? rej(new Error('The voice program could not unzip: ' + e.message)) : res())));
      fs.rmSync(zip, { force: true });
      if (!findBin()) throw new Error('The download has no whisper-cli.exe in it.');
    } else {
      await fetchTo(MODEL_URL(MODELS[what].file), path.join(dir, 'models', MODELS[what].file), 'The speech model');
    }
    job.done = true;
  })().catch(e => { job.error = e.message; });
  return { ...job };
}

// A recording in, the words out. prompt carries names so whisper spells them right.
function transcribe(wav, { model = 'base', lang = 'en', prompt = '' } = {}) {
  const bin = findBin();
  if (!bin) return Promise.reject(new Error('Voice is not set up. The owner downloads it in Settings, Voice.'));
  if (!haveModel(model)) return Promise.reject(new Error('The speech model is not downloaded yet.'));
  if (!(wav && wav.length > 44 && wav.slice(0, 4).toString() === 'RIFF')) return Promise.reject(new Error('The recording is empty.'));
  const tmp = path.join(os.tmpdir(), `cc-voice-${crypto.randomBytes(6).toString('hex')}.wav`);
  fs.writeFileSync(tmp, wav);
  const args = ['-m', modelPath(model), '-f', tmp, '-l', ['en', 'tl', 'auto'].includes(lang) ? lang : 'en', '-nt', '-np', '-t', String(Math.max(2, Math.min(8, os.cpus().length - 1)))];
  if (prompt) args.push('--prompt', prompt.slice(0, 700));
  const script = /\.(m?js)$/.test(bin);
  return new Promise((resolve, reject) => {
    execFile(script ? process.execPath : bin, script ? [bin, ...args] : args, { windowsHide: true, timeout: 90000, maxBuffer: 1 << 20, cwd: path.dirname(bin) }, (err, stdout, stderr) => {
      fs.rmSync(tmp, { force: true });
      if (err) return reject(new Error('Voice could not read the recording: ' + String(stderr || err.message).trim().split('\n').slice(-1)[0]));
      resolve(clean(stdout));
    });
  });
}
// Whisper marks silence and noise in brackets. Those, and timestamps, come off.
function clean(s) {
  return String(s || '').split(/\r?\n/).map(l => l.replace(/^\[[^\]]*-->[^\]]*\]\s*/, '')).join(' ')
    .replace(/\[[^\]]*\]|\([^)]*(music|silence|noise|blank|inaudible)[^)]*\)/gi, ' ').replace(/\s+/g, ' ').trim();
}

module.exports = { init, status, download, transcribe, clean, MODELS };
