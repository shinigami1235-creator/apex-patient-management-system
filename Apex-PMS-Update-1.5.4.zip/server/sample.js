// Sample data, so the branch can try every screen before the real patients go in.
// Everything it adds carries sample: true and comes off in one go with Remove sample data,
// along with its pictures. Dates are counted back from today, so the sample always looks
// current: visits today, follow-ups this week, a complication still open.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { CONSENT_DEFAULTS, AFTERCARE_DEFAULTS, DOCTOR_PHRASE } = require('../app/js/forms.js');

const DIR = path.join(__dirname, 'sample');
const uid = () => crypto.randomUUID();
const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const day = n => { const d = new Date(); d.setDate(d.getDate() + n); return iso(d); };
const at = (n, hm) => { const [h, m] = hm.split(':').map(Number); const d = new Date(); d.setDate(d.getDate() + n); d.setHours(h, m, 0, 0); return d.getTime(); };
const lang = (m, l) => (typeof m === 'string' ? m : m[l] || m.en || '');

// The people who sign in. Their PINs show on the Settings card while the sample is loaded.
const PEOPLE = [
  { key: 'pim', name: 'Dr. Pimchanok Wongsawat', nameTh: 'พญ. พิมพ์ชนก วงศ์สวัสดิ์', role: 'doctor', title: 'Dermatologist', licence: 'ว. 34567', pin: '1111', lang: 'th' },
  { key: 'tk', name: 'Dr. Thanakorn Rattanapong', nameTh: 'นพ. ธนกร รัตนพงษ์', role: 'doctor', title: 'Plastic surgeon', licence: 'ว. 28911', pin: '2222', lang: 'en' },
  { key: 'nok', name: 'Nok Saelim', nameTh: 'นก แซ่ลิ้ม', role: 'nurse', title: 'Nurse assistant', pin: '3333', lang: 'th' },
  { key: 'fah', name: 'Fah Boonmee', nameTh: 'ฟ้า บุญมี', role: 'staff', title: 'EMR staff', pin: '4444', lang: 'th' },
];

const PRODUCTS = [
  { key: 'botox', name: 'Botox 100 U', kind: 'toxin', unit: 'U', lot: 'C7012C3', exp: 300 },
  { key: 'nabota', name: 'Nabota 100 U', kind: 'toxin', unit: 'U', lot: 'NBA24071', exp: 210 },
  { key: 'volbella', name: 'Juvederm Volbella 1 ml', kind: 'filler', unit: 'ml', lot: 'VB30A11', exp: 400 },
  { key: 'voluma', name: 'Juvederm Voluma 1 ml', kind: 'filler', unit: 'ml', lot: 'VM31B07', exp: 380 },
  { key: 'tear', name: 'Restylane Eyelight 0.5 ml', kind: 'filler', unit: 'ml', lot: 'RE2290', exp: 260 },
  { key: 'profhilo', name: 'Profhilo 2 ml', kind: 'booster', unit: 'ml', lot: 'PH24-118', exp: 330 },
  { key: 'ulthera', name: 'Ulthera DS 4.0 cartridge', kind: 'device', unit: 'shots', lot: 'UL4-5521', exp: 700 },
  { key: 'pdo', name: 'PDO cog thread 19G', kind: 'thread', unit: 'pcs', lot: 'PD9903', exp: 500 },
  { key: 'hyal', name: 'Hyaluronidase 1500 IU', kind: 'medicine', unit: 'amp', lot: 'HY1145', exp: 240 },
];

function load(ctx) {
  const { getDoc, allDocs, putDoc, hashPin, FILES, branchCode, me } = ctx;
  const now = Date.now();
  const out = [];
  const put = (store, doc) => { doc = { ...doc, sample: true, created: doc.created || now, updated: now, updatedBy: me.id, createdBy: doc.createdBy || me.id }; putDoc(store, doc); out.push({ store, doc }); return doc; };
  const file = name => { const id = uid() + path.extname(name); fs.copyFileSync(path.join(DIR, name), path.join(FILES, id)); return id; };

  // people
  const U = {};
  for (const p of PEOPLE) {
    const salt = crypto.randomBytes(16).toString('base64');
    const { key, pin, ...rest } = p;
    U[key] = put('users', { id: uid(), ...rest, clinicalRole: p.role === 'doctor' ? 'doctor' : 'none', salt, pinHash: hashPin(pin, salt), pinLen: pin.length });
  }

  // treatments the sample uses: the branch's own when it has them, sample ones when not
  const services = allDocs('services');
  const SV = {};
  const svc = (name, rest) => { SV[name] = services.find(s => s.name === name) || put('services', { id: uid(), name, active: true, ...rest }); return SV[name]; };
  svc('Consultation', { category: 'Consultation', kind: '' });
  svc('Review', { category: 'Consultation', kind: '' });
  svc('Botox, forehead and frown lines', { category: 'Botulinum toxin', kind: 'toxin', consents: ['toxin'], aftercare: 'toxin' });
  svc('Botox, jaw slimming', { category: 'Botulinum toxin', kind: 'toxin', consents: ['toxin'], aftercare: 'toxin' });
  svc('Lip filler', { category: 'Filler', kind: 'filler', consents: ['filler'], aftercare: 'filler' });
  svc('Under-eye filler', { category: 'Filler', kind: 'filler', consents: ['filler'], aftercare: 'filler' });
  svc('Skin booster', { category: 'Skin booster', kind: 'booster', consents: ['booster'], aftercare: 'booster' });
  svc('HIFU full face', { category: 'Energy device', kind: 'device', consents: ['device'], aftercare: 'device', sheetId: 'hifu' });
  svc('Thread lift', { category: 'Thread lift', kind: 'thread', consents: ['thread'], aftercare: 'thread' });
  const line = name => ({ id: uid(), serviceId: SV[name].id, name });

  // products and lots
  const P = {}, L = {};
  for (const p of PRODUCTS) {
    P[p.key] = put('products', { id: uid(), name: p.name, kind: p.kind, unit: p.unit, active: true, custom: {} });
    L[p.key] = put('lots', { id: uid(), productId: P[p.key].id, lot: p.lot, expiry: day(p.exp), archived: false });
  }

  // numbers in their own range, so the branch's own patients keep 00001 onwards
  let pn = 90000, vn = 900000;
  const patient = rec => put('patients', { id: uid(), no: `${branchCode}-${++pn}`, screen: {}, allergies: [], meds: [], conditions: [], surgeries: [], contacts: [], tags: [], custom: {}, nationality: 'Thai', idType: 'Thai ID card', plang: 'th', photoConsent: 'yes', ...rec });
  const photo = (p, v, name, view, stage, area = '') => put('photos', { id: uid(), patientId: p.id, visitId: v.id, view, stage, area, date: v.date, w: name.includes('daniel') ? 700 : name.includes('sarah') ? 460 : 420, h: name.includes('daniel') ? 700 : name.includes('sarah') ? 560 : 540, name, fileId: file(name), thumbId: file(name) });
  const sigFor = () => file('signature.png');
  const consent = (key, l, doctor, signer, when) => {
    const t = CONSENT_DEFAULTS[key];
    const name = l === 'th' && doctor.nameTh ? doctor.nameTh : doctor.name;
    return { id: uid(), key, lang: l, title: lang(t.title, l), titleEn: lang(t.title, 'en'), text: lang(t.text, l).split(DOCTOR_PHRASE[l] || DOCTOR_PHRASE.en).join(name), apexWording: false, signer, signatureId: sigFor(), signedAt: when, witness: U.nok.name, witnessId: U.nok.id };
  };
  const aftercare = (keys, l) => keys.map(k => lang(AFTERCARE_DEFAULTS[k], l)).filter(Boolean).join('\n\n');
  const mark = (t, prod, amount, area, x, y, extra = {}) => ({ t, lotId: L[prod].id, productId: P[prod].id, product: P[prod].name, unit: P[prod].unit, amount, area, x, y, ...extra });
  // A filler arrow (technique 'arrow', the needle path) or fan ('fan', entry point first, then each arrow's tip).
  const markPts = (t, prod, amount, area, technique, pts, extra = {}) => ({ t, lotId: L[prod].id, productId: P[prod].id, product: P[prod].name, unit: P[prod].unit, amount, area, technique, pts, ...extra });
  const TECH_NOTE = { arrow: 'Linear threading', fan: 'Fanning' };
  // the treatment record a chart gives, as the app works it out from the marks
  const linesFrom = marks => {
    const g = new Map();
    for (const m of marks) {
      const k = [m.t, m.lotId, m.product.toLowerCase(), m.unit].join('|');
      if (!g.has(k)) g.set(k, { kind: m.t, lotId: m.lotId, productId: m.productId, product: m.product, lot: (Object.values(L).find(l => l.id === m.lotId) || {}).lot || '', unit: m.unit, amount: 0, areas: new Set(), points: 0, notes: new Set() });
      const x = g.get(k); x.amount += m.amount; x.points++; if (m.area) x.areas.add(m.area); if (m.depth) x.notes.add(m.depth); if (TECH_NOTE[m.technique]) x.notes.add(TECH_NOTE[m.technique]); if (m.settings) x.notes.add(m.settings);
    }
    return [...g.entries()].map(([k, x]) => ({ id: 'c-' + k, source: 'chart', kind: x.kind, lotId: x.lotId, productId: x.productId, product: x.product, lot: x.lot, unit: x.unit, amount: +x.amount.toFixed(3), area: [...x.areas].join(', '), notes: [...x.notes].join('; '), points: x.points }));
  };
  const visit = (p, n, time, doctor, rec, marks) => {
    const v = put('visits', { id: uid(), no: `${branchCode}-V${++vn}`, patientId: p.id, date: day(n), time, type: 'Treatment', doctorId: doctor.id, complaint: '', findings: '', assessment: '', plan: '', services: [], treatments: marks ? linesFrom(marks) : [], consents: [], rx: [], meds: [], settings: [], aftercare: null, followUp: '', followReason: '', created: at(n, time), createdBy: doctor.id, ...rec });
    if (marks) put('charts', { id: uid(), patientId: p.id, visitId: v.id, view: 'front', base: { type: 'drawing' }, w: 600, h: 800, marks, dilution: { units: 100, ml: 2.5 } });
    return v;
  };
  const signed = (n, time, doctor) => ({ signedAt: at(n, time), signedBy: doctor.id });

  // 1. Kanokwan: Botox four months ago, a review, lip filler two weeks ago
  const kan = patient({ name: 'Kanokwan Chaiyaporn', nameTh: 'กนกวรรณ ชัยพร', goesBy: 'Kwan', hn: '6512001', dob: '1990-02-11', sex: 'Female', skin: 'III', phone: '081 234 5678', line: 'kwan.cp', email: 'kwan.c@gmail.com', occupation: 'Flight attendant', source: 'Instagram', privacyConsentAt: at(-120, '10:05'), marketingConsent: 'yes',
    allergies: [{ what: 'Penicillin', reaction: 'Rash', severity: 'Mild' }], contacts: [{ name: 'Somchai Chaiyaporn', relation: 'Father', phone: '089 765 4321' }], created: at(-120, '10:00') });
  const kTox = [
    mark('toxin', 'botox', 4, 'Forehead', 0.38, 0.26), mark('toxin', 'botox', 4, 'Forehead', 0.46, 0.25), mark('toxin', 'botox', 4, 'Forehead', 0.54, 0.25), mark('toxin', 'botox', 4, 'Forehead', 0.62, 0.26),
    mark('toxin', 'botox', 5, 'Glabella', 0.5, 0.375), mark('toxin', 'botox', 4, 'Glabella', 0.44, 0.36), mark('toxin', 'botox', 4, 'Glabella', 0.56, 0.36)];
  const k1 = visit(kan, -120, '10:20', U.pim, { ...signed(-120, '11:05', U.pim), services: [line('Botox, forehead and frown lines')], complaint: 'Frown lines and forehead lines, wants a softer look before a wedding in December.', findings: 'Dynamic glabellar lines grade 3, forehead lines grade 2. No ptosis.', assessment: 'Dynamic glabellar and forehead lines.', plan: 'Botulinum toxin to glabella and forehead. Review in 2 weeks.',
    consents: [consent('toxin', 'th', U.pim, 'Kanokwan Chaiyaporn', at(-120, '10:30')), consent('privacy', 'th', U.pim, 'Kanokwan Chaiyaporn', at(-120, '10:05')), consent('photos', 'th', U.pim, 'Kanokwan Chaiyaporn', at(-120, '10:06'))],
    aftercare: aftercare(['toxin'], 'th'), followUp: day(-106), followReason: 'Review the result' }, kTox);
  const kb = photo(kan, k1, 'kanokwan.jpg', 'Front', 'Before');
  const k2 = visit(kan, -106, '15:00', U.pim, { ...signed(-106, '15:20', U.pim), type: 'Review', services: [line('Review')], findings: 'Even result. Full frown no longer creases the glabella. No brow drop.', plan: 'Repeat in 4 months.' });
  put('visits', { ...k1, outcome: { gais: 2, rating: 9, note: 'Happy with the result.', by: U.pim.id, at: at(-106, '15:15'), onVisitId: k2.id } });
  photo(kan, k2, 'kanokwan-after.jpg', 'Front', 'After');
  const kLip = [markPts('filler', 'volbella', 0.3, 'Upper lip', 'arrow', [[0.435, 0.628], [0.462, 0.623], [0.49, 0.621]], { depth: 'Submucosal' }), markPts('filler', 'volbella', 0.3, 'Upper lip', 'arrow', [[0.565, 0.628], [0.538, 0.623], [0.51, 0.621]], { depth: 'Submucosal' }), mark('filler', 'volbella', 0.2, 'Lower lip', 0.5, 0.655, { depth: 'Submucosal' }), mark('filler', 'volbella', 0.2, 'Cupid\'s bow', 0.5, 0.612)];
  const k3 = visit(kan, -14, '13:30', U.pim, { ...signed(-14, '14:25', U.pim), services: [line('Lip filler')], complaint: 'Thin upper lip.', findings: 'Upper to lower lip ratio 1 to 1.7. No asymmetry.', assessment: 'Lip volume loss, upper more than lower.', plan: 'Volbella 1 ml to lips. Review in 2 weeks for a touch-up.',
    consents: [consent('filler', 'th', U.pim, 'Kanokwan Chaiyaporn', at(-14, '13:40'))], aftercare: aftercare(['filler'], 'th'), followUp: day(2), followReason: 'Lip filler review and touch-up',
    rx: [{ drug: 'Mupirocin 2% ointment', qty: '1 tube', sig: 'Apply to the injection points 3 times a day for 3 days' }] }, kLip);
  photo(kan, k3, 'kanokwan.jpg', 'Front', 'Before', 'Lips');
  photo(kan, k3, 'kanokwan-after.jpg', 'Front', 'After', 'Lips');
  const lv = (a, b, c, d, e, f, g) => ({ lines: { level: a, area: 'forehead' }, texture: { level: b, area: 'cheeks' }, spots: { level: c, area: 'cheeks' }, redness: { level: d, area: 'cheeks' }, under: { level: e, area: 'under' }, sag: { level: f, area: 'folds' }, shine: { level: g, area: 'tzone' } });

  // 2. Li Na: first visit today, through the translator, allergic to lidocaine
  const li = patient({ name: 'Li Na', nameTh: '', goesBy: 'Lina', hn: '6512002', dob: '1993-07-30', sex: 'Female', nationality: 'Chinese', idType: 'Passport', idNo: 'EB4417285', plang: 'zh', phone: '+86 138 0013 8000', custom: { 'f-contact': 'WeChat' }, source: 'Friend', photoConsent: '',
    allergies: [{ what: 'Lidocaine', reaction: 'Face swelling', severity: 'Moderate' }], surgeries: [{ what: 'Lip filler', year: '2024', where: 'Shanghai' }], tags: [], created: at(0, '09:40') });
  const l1 = visit(li, 0, '10:00', U.tk, { type: 'Consultation', services: [line('Consultation')], complaint: 'Wants a higher nose bridge and fuller lips. Had lip filler in Shanghai in 2024.', findings: 'Low dorsum, wide alar base. Small residual filler lump in the left upper lip.', plan: 'Discuss nose thread lift against filler. Avoid lidocaine.' });
  put('transcripts', { id: uid(), patientId: li.id, visitId: l1.id, date: l1.date, title: 'Consult with Li Na', lines: 4, by: U.tk.id, text: `Consult with Li Na\n${day(0)} · English from Chinese\n\n[00:00:04] I had filler in my lips two years ago in Shanghai.\n           (Chinese) 两年前我在上海打过嘴唇填充。\n[00:00:11] I am allergic to lidocaine. It made my face swell.\n           (Chinese) 我对利多卡因过敏，脸会肿。\n[00:00:20] I want my nose higher, but nothing too big.\n           (Chinese) 我想让鼻子高一点，但不要太夸张。\n[00:00:31] Can I do it before I fly home on Sunday?\n           (Chinese) 我周日回国之前可以做吗？\n` });

  // 3. Daniel: jaw Botox, then HIFU with its settings, here today for a review
  const dan = patient({ name: 'Daniel Weber', nka: true, hn: '6512003', dob: '1981-05-02', sex: 'Male', nationality: 'German', idType: 'Passport', idNo: 'C01X00T47', plang: 'en', skin: 'II', phone: '082 555 0147', custom: { 'f-contact': 'WhatsApp' }, email: 'd.weber@posteo.de', occupation: 'Engineer', source: 'Google', privacyConsentAt: at(-200, '16:00'),
    meds: [{ name: 'Losartan', dose: '50 mg', freq: 'Once a day', reason: 'High blood pressure' }], conditions: [{ name: 'Hypertension', year: '2019', notes: 'Controlled' }], created: at(-200, '15:50') });
  const dJaw = [mark('toxin', 'nabota', 15, 'Left masseter', 0.27, 0.62), mark('toxin', 'nabota', 10, 'Left masseter', 0.29, 0.66), mark('toxin', 'nabota', 15, 'Right masseter', 0.73, 0.62), mark('toxin', 'nabota', 10, 'Right masseter', 0.71, 0.66)];
  const d1 = visit(dan, -200, '16:10', U.tk, { ...signed(-200, '16:50', U.tk), services: [line('Botox, jaw slimming')], complaint: 'Square jaw, grinds teeth at night.', findings: 'Masseter hypertrophy both sides, strong on clenching.', assessment: 'Bilateral masseter hypertrophy with bruxism.', plan: 'Nabota 50 U to masseters. Review in 3 months.',
    consents: [consent('toxin', 'en', U.tk, 'Daniel Weber', at(-200, '16:15')), consent('privacy', 'en', U.tk, 'Daniel Weber', at(-200, '16:00')), consent('photos', 'en', U.tk, 'Daniel Weber', at(-200, '16:01'))], aftercare: aftercare(['toxin'], 'en') }, dJaw);
  photo(dan, d1, 'daniel.jpg', 'Front', 'Before');
  const hifu = (n, energy) => ({ id: uid(), by: U.tk.id, at: at(n, '14:40'), sheetId: 'hifu', name: 'HIFU', group: 'Energy device', area: 'Full face and submental', values: [{ label: 'Cartridge', unit: 'mm', type: 'number', value: '4.5' }, { label: 'Energy', unit: 'J', type: 'number', value: energy }, { label: 'Spacing', unit: 'mm', type: 'number', value: '1.5' }, { label: 'Lines', unit: '', type: 'number', value: '400' }, { label: 'Passes', unit: '', type: 'number', value: '2' }], response: 'Good', responseNote: 'Mild redness only', reaction: '', next: 'Same', nextNote: '' });
  const dHifu = [mark('device', 'ulthera', 200, 'Left cheek and jawline', 0.3, 0.58, { pts: [[0.25, 0.52], [0.3, 0.6], [0.37, 0.67], [0.45, 0.72]], settings: '4.5 mm, 0.9 J' }), mark('device', 'ulthera', 200, 'Right cheek and jawline', 0.7, 0.58, { pts: [[0.75, 0.52], [0.7, 0.6], [0.63, 0.67], [0.55, 0.72]], settings: '4.5 mm, 0.9 J' })];
  const d2 = visit(dan, -60, '14:30', U.tk, { ...signed(-60, '15:45', U.tk), services: [line('HIFU full face')], complaint: 'Sagging jawline.', findings: 'Mild jowling, loss of jawline definition.', plan: 'HIFU full face. Review in 2 months.', consents: [consent('device', 'en', U.tk, 'Daniel Weber', at(-60, '14:35'))], settings: [hifu(-60, '0.9')], aftercare: aftercare(['device'], 'en') }, dHifu);
  photo(dan, d2, 'daniel.jpg', 'Front', 'Before', 'Jawline');
  const d3 = visit(dan, 0, '11:30', U.tk, { type: 'Review', services: [line('Review')], complaint: 'Two-month review after HIFU.', findings: 'Jawline sharper, jowl softer.' });
  photo(dan, d3, 'daniel-after.jpg', 'Front', 'After', 'Jawline');

  // 4. Siriporn: under-eye filler a month ago, a lump still being watched
  const sir = patient({ name: 'Siriporn Kaewmanee', nka: true, nameTh: 'ศิริพร แก้วมณี', hn: '6512004', dob: '1985-11-19', sex: 'Female', phone: '086 321 9988', line: 'siri.kmn', source: 'Walk-in', privacyConsentAt: at(-30, '11:00'), created: at(-30, '10:55'), screen: { thinner: 'yes' } });
  const sTear = [markPts('filler', 'tear', 0.25, 'Left tear trough', 'fan', [[0.335, 0.5], [0.355, 0.452], [0.38, 0.452], [0.405, 0.462]], { depth: 'Supraperiosteal, cannula' }), markPts('filler', 'tear', 0.25, 'Right tear trough', 'fan', [[0.665, 0.5], [0.645, 0.452], [0.62, 0.452], [0.595, 0.462]], { depth: 'Supraperiosteal, cannula' })];
  const s1 = visit(sir, -30, '11:10', U.pim, { ...signed(-30, '12:00', U.pim), services: [line('Under-eye filler')], complaint: 'Tired look under the eyes.', findings: 'Tear trough hollowing grade 2 both sides.', plan: 'Eyelight 0.5 ml to tear troughs. Stop fish oil 7 days before next time.',
    consents: [consent('filler', 'th', U.pim, 'Siriporn Kaewmanee', at(-30, '11:15')), consent('privacy', 'th', U.pim, 'Siriporn Kaewmanee', at(-30, '11:00')), consent('photos', 'th', U.pim, 'Siriporn Kaewmanee', at(-30, '11:01'))], aftercare: aftercare(['filler'], 'th'), followUp: day(4), followReason: 'Check the left under-eye lump' }, sTear);
  put('incidents', { id: uid(), patientId: sir.id, visitId: s1.id, by: U.pim.id, date: day(-27), type: 'Lump or nodule', severity: 'Mild', area: 'Left tear trough', what: 'Small soft lump under the left eye, no redness or pain.', given: 'Massage taught. Hyaluronidase if still there at 4 weeks.', followUp: day(4), outcome: 'Improving', outcomeNote: 'Smaller at the 2-week call.' });

  // 5. Emily: skin booster course, declined photos
  const emi = patient({ name: 'Emily Carter', nka: true, hn: '6512005', dob: '1988-03-08', sex: 'Female', nationality: 'British', idType: 'Passport', idNo: '533928817', plang: 'en', phone: '095 410 2266', email: 'emily.carter@outlook.com', photoConsent: 'no', privacyConsentAt: at(-45, '17:00'), created: at(-45, '16:55') });
  const boost = (n, sid) => [mark('booster', 'profhilo', 0.2, 'Left cheek', 0.32, 0.5), mark('booster', 'profhilo', 0.2, 'Left cheek', 0.33, 0.58), mark('booster', 'profhilo', 0.2, 'Right cheek', 0.68, 0.5), mark('booster', 'profhilo', 0.2, 'Right cheek', 0.67, 0.58), mark('booster', 'profhilo', 0.2, 'Chin', 0.5, 0.71)];
  visit(emi, -45, '17:10', U.pim, { ...signed(-45, '17:45', U.pim), services: [line('Skin booster')], complaint: 'Dull, dry skin after a year in Bangkok.', plan: 'Profhilo 2 sessions, 4 weeks apart.', consents: [consent('booster', 'en', U.pim, 'Emily Carter', at(-45, '17:12')), consent('privacy', 'en', U.pim, 'Emily Carter', at(-45, '17:00'))], aftercare: aftercare(['booster'], 'en') }, boost(-45));
  visit(emi, -15, '17:30', U.pim, { ...signed(-15, '18:00', U.pim), services: [line('Skin booster')], complaint: 'Second session.', findings: 'Skin more hydrated.', consents: [consent('booster', 'en', U.pim, 'Emily Carter', at(-15, '17:32'))], aftercare: aftercare(['booster'], 'en') }, boost(-15));

  // 6. Natthawut: a consultation three days ago that nobody signed
  const nat = patient({ name: 'Natthawut Srisawat', nameTh: 'ณัฐวุฒิ ศรีสวัสดิ์', hn: '6512006', dob: '1995-09-14', sex: 'Male', phone: '091 778 2030', line: 'natt.s', source: 'TikTok', created: at(-3, '18:20') });
  visit(nat, -3, '18:30', U.tk, { type: 'Consultation', services: [line('Consultation')], complaint: 'Acne scars on both cheeks.', findings: 'Rolling and boxcar scars, cheeks.', plan: 'Fractional laser course. Quote sent through reception.' });

  // 7. Arisa: thread lift with a bruise that has gone
  const ari = patient({ name: 'Arisa Thongdee', nka: true, nameTh: 'อริสา ทองดี', hn: '6512007', dob: '2000-01-25', sex: 'Female', phone: '084 902 1177', line: 'arisa.td', source: 'Instagram', privacyConsentAt: at(-9, '13:00'), created: at(-9, '12:50') });
  const aThread = [mark('thread', 'pdo', 4, 'Left midface', 0.32, 0.55, { pts: [[0.24, 0.47], [0.3, 0.55], [0.36, 0.63]] }), mark('thread', 'pdo', 4, 'Right midface', 0.68, 0.55, { pts: [[0.76, 0.47], [0.7, 0.55], [0.64, 0.63]] })];
  const a1 = visit(ari, -9, '13:10', U.tk, { ...signed(-9, '14:30', U.tk), services: [line('Thread lift')], complaint: 'Wants a lifted midface without surgery.', plan: 'PDO cog threads 4 each side. Review in 2 weeks.', consents: [consent('thread', 'th', U.tk, 'Arisa Thongdee', at(-9, '13:15')), consent('privacy', 'th', U.tk, 'Arisa Thongdee', at(-9, '13:00'))],
    rx: [{ drug: 'Amoxicillin 500 mg', qty: '15 capsules', sig: '1 capsule 3 times a day for 5 days' }, { drug: 'Paracetamol 500 mg', qty: '10 tablets', sig: '1 to 2 tablets every 6 hours when needed for pain' }], aftercare: aftercare(['thread'], 'th'), followUp: day(5), followReason: 'Thread lift review' }, aThread);
  put('incidents', { id: uid(), patientId: ari.id, visitId: a1.id, by: U.tk.id, date: day(-8), type: 'Bruising', severity: 'Mild', area: 'Right cheek', what: 'Bruise at the right entry point.', given: 'Cold compress, arnica gel.', followUp: day(-2), outcome: 'Resolved', outcomeNote: 'Gone by day 6.', resolvedOn: day(-3) });

  // 8. Malee: Botox this morning, signed
  const mal = patient({ name: 'Malee Suksawat', nka: true, nameTh: 'มาลี สุขสวัสดิ์', hn: '6512008', dob: '1968-06-03', sex: 'Female', phone: '081 990 4512', occupation: 'Teacher', source: 'Friend', privacyConsentAt: at(-380, '09:00'), created: at(-380, '09:00'), screen: { thinner: 'yes' } });
  visit(mal, 0, '09:15', U.tk, { ...signed(0, '09:55', U.tk), services: [line('Botox, forehead and frown lines')], complaint: 'Forehead and frown lines, a yearly top-up.', findings: 'Static forehead lines grade 2.', plan: 'Botox 30 U. Review in 2 weeks.', consents: [consent('toxin', 'th', U.tk, 'Malee Suksawat', at(0, '09:20'))], aftercare: aftercare(['toxin'], 'th'),
    meds: [{ id: uid(), at: at(0, '09:25'), drug: 'Lidocaine cream 5%', dose: 1, unit: 'tube', route: 'Topical', site: 'Forehead', time: '09:25', givenBy: U.nok.name, lotId: '', productId: '', lot: 'LC2210', reaction: '', allergyOk: false }] },
  [mark('toxin', 'botox', 4, 'Forehead', 0.38, 0.26), mark('toxin', 'botox', 4, 'Forehead', 0.5, 0.25), mark('toxin', 'botox', 4, 'Forehead', 0.62, 0.26), mark('toxin', 'botox', 6, 'Glabella', 0.5, 0.375), mark('toxin', 'botox', 6, 'Glabella', 0.44, 0.36), mark('toxin', 'botox', 6, 'Glabella', 0.56, 0.36)]);

  // 9. Sarah: a consultation last week
  const sar = patient({ name: 'Sarah Mitchell', nka: true, hn: '6512009', dob: '1991-12-12', sex: 'Female', nationality: 'Australian', idType: 'Passport', idNo: 'PA7781234', plang: 'en', phone: '097 330 6612', email: 'sarah.m@gmail.com', source: 'Google', privacyConsentAt: at(-6, '15:00'), created: at(-6, '14:55') });
  const sr1 = visit(sar, -6, '15:10', U.tk, { ...signed(-6, '15:50', U.tk), type: 'Consultation', services: [line('Consultation')], complaint: 'Wants a softer nose tip and a stronger chin.', findings: 'Bulbous tip, mild chin retrusion.', plan: 'Chin filler first. Nose thread lift to discuss after.', consents: [consent('privacy', 'en', U.tk, 'Sarah Mitchell', at(-6, '15:00')), consent('photos', 'en', U.tk, 'Sarah Mitchell', at(-6, '15:01'))] });
  photo(sar, sr1, 'sarah.jpg', 'Front', 'Before');

  // Bookings: today, tomorrow and the next two weeks, one of them made from a follow-up.
  const book = (p, n, time, doctor, service, rest = {}) => put('bookings', { id: uid(), patientId: p.id, date: day(n), time, mins: 30, doctorId: doctor.id, serviceId: service ? SV[service].id : '', what: '', status: 'booked', remind: true, source: 'staff', ...rest });
  book(dan, 0, '11:30', U.tk, 'Review', { status: 'confirmed', what: 'Two-month review after HIFU' });
  book(li, 0, '14:00', U.tk, 'Consultation', { what: 'Second opinion on the nose' });
  book(kan, 1, '10:00', U.pim, 'Lip filler', { what: 'Lip filler review and touch-up', source: 'followup' });
  book(sar, 1, '15:30', U.tk, 'Consultation', { mins: 45, what: 'Chin filler planning' });
  book(ari, 3, '13:00', U.pim, 'Review', { status: 'confirmed' });
  book(emi, 9, '17:00', U.pim, 'Skin booster', { what: 'Profhilo, second session', mins: 45 });
  book(mal, 12, '09:30', U.pim, 'Botox, forehead and frown lines', { status: 'cancelled', what: 'Moved to next month' });

  return { docs: out, pins: PEOPLE.map(p => ({ name: p.name, role: p.role, pin: p.pin })) };
}

// Everything marked as sample, and the pictures only sample records use.
function remove(ctx) {
  const { allDocs, delDoc, FILES, STORES } = ctx;
  const out = [];
  const files = new Set();
  const scan = v => { if (typeof v === 'string') { if (/^[0-9a-f-]{36}\.(jpg|png)$/.test(v)) files.add(v); } else if (v && typeof v === 'object') for (const x of Object.values(v)) scan(x); };
  for (const store of STORES) for (const d of allDocs(store)) if (d.sample) { scan(d); delDoc(store, d.id); out.push({ store, doc: d }); }
  // a picture a real record also points to stays
  for (const store of STORES) for (const d of allDocs(store)) { const keep = new Set(); const s2 = v => { if (typeof v === 'string') { if (files.has(v)) keep.add(v); } else if (v && typeof v === 'object') for (const x of Object.values(v)) s2(x); }; s2(d); for (const k of keep) files.delete(k); }
  for (const f of files) fs.rmSync(path.join(FILES, f), { force: true });
  return out;
}

module.exports = { load, remove, PEOPLE };
