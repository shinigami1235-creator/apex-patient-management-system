// A plain .zip written straight to the download, with no compression, since photos are
// already compressed and every computer opens a stored zip. Each entry's checksum is worked
// out before it is written, so the zip needs nothing unusual to open. Up to 4 GB in all.
'use strict';
const fs = require('fs');
const zlib = require('zlib');

const LIMIT = 0xFFFFFFFF;

function dosTime(d = new Date()) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

// out: a writable stream. Returns { addBuffer, addFile, end }.
function zipWriter(out) {
  let offset = 0, closed = false, waiting = null;
  const central = [];
  const { time, date } = dosTime();
  // A download the browser stops closes the stream; the writer then stops too.
  out.on('close', () => { closed = true; if (waiting) { const w = waiting; waiting = null; w(); } });
  const write = buf => new Promise((res, rej) => {
    if (closed) return rej(new Error('The download was stopped.'));
    offset += buf.length;
    if (out.write(buf)) return res();
    waiting = res;
    out.once('drain', () => { if (waiting === res) { waiting = null; res(); } });
  });
  async function entry(name, size, crc, body) {
    if (offset + size + 200 > LIMIT) throw new Error('The download would pass 4 GB. Download the records without the photos, and keep the photos through Backup.');
    const nameBuf = Buffer.from(name, 'utf8');
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(0, 8);
    h.writeUInt16LE(time, 10); h.writeUInt16LE(date, 12); h.writeUInt32LE(crc >>> 0, 14); h.writeUInt32LE(size, 18); h.writeUInt32LE(size, 22);
    h.writeUInt16LE(nameBuf.length, 26); h.writeUInt16LE(0, 28);
    const at = offset;
    await write(Buffer.concat([h, nameBuf]));
    await body();
    central.push({ nameBuf, crc, size, at });
  }
  return {
    async addBuffer(name, buf) { await entry(name, buf.length, zlib.crc32(buf), () => write(buf)); },
    async addFile(name, file) {
      let crc = 0, size = 0;
      for await (const chunk of fs.createReadStream(file)) { crc = zlib.crc32(chunk, crc); size += chunk.length; }
      await entry(name, size, crc, async () => { for await (const chunk of fs.createReadStream(file)) await write(chunk); });
    },
    async end() {
      const start = offset;
      for (const e of central) {
        const c = Buffer.alloc(46);
        c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(0, 10);
        c.writeUInt16LE(time, 12); c.writeUInt16LE(date, 14); c.writeUInt32LE(e.crc >>> 0, 16); c.writeUInt32LE(e.size, 20); c.writeUInt32LE(e.size, 24);
        c.writeUInt16LE(e.nameBuf.length, 28); c.writeUInt32LE(e.at, 42);
        await write(Buffer.concat([c, e.nameBuf]));
      }
      const end = Buffer.alloc(22);
      end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(central.length, 8); end.writeUInt16LE(central.length, 10);
      end.writeUInt32LE(offset - start, 12); end.writeUInt32LE(start, 16);
      await write(end);
      await new Promise(res => out.end(res));
    },
  };
}

// Rows for a spreadsheet: one column per field, lists and sub-records written as JSON.
function csvOf(rows) {
  const cols = [];
  for (const r of rows) for (const k of Object.keys(r)) if (!cols.includes(k)) cols.push(k);
  const cell = v => {
    if (v === null || v === undefined) return '';
    const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  // The byte-order mark makes Excel read the Thai correctly.
  return '﻿' + [cols.join(','), ...rows.map(r => cols.map(c => cell(r[c])).join(','))].join('\r\n') + '\r\n';
}

// Reads a whole .zip held in memory: stored and deflated entries, as any zip tool writes them.
function readZip(buf) {
  let end = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { end = i; break; }
  if (end < 0) throw new Error('The file is not a zip.');
  const count = buf.readUInt16LE(end + 10);
  let at = buf.readUInt32LE(end + 16);
  const out = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(at) !== 0x02014b50) throw new Error('The zip is damaged.');
    const method = buf.readUInt16LE(at + 10), crc = buf.readUInt32LE(at + 16) >>> 0, csize = buf.readUInt32LE(at + 20), size = buf.readUInt32LE(at + 24);
    const nl = buf.readUInt16LE(at + 28), xl = buf.readUInt16LE(at + 30), cl = buf.readUInt16LE(at + 32), off = buf.readUInt32LE(at + 42);
    const name = buf.slice(at + 46, at + 46 + nl).toString('utf8');
    at += 46 + nl + xl + cl;
    if (name.endsWith('/')) { out.push({ name, data: Buffer.alloc(0) }); continue; }
    const lnl = buf.readUInt16LE(off + 26), lxl = buf.readUInt16LE(off + 28);
    const raw = buf.slice(off + 30 + lnl + lxl, off + 30 + lnl + lxl + csize);
    const data = method === 0 ? raw : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data) throw new Error(`The zip uses a packing this program can't read (${name}).`);
    if (data.length !== size || (zlib.crc32(data) >>> 0) !== crc) throw new Error(`The zip is damaged at ${name}.`);
    out.push({ name, data });
  }
  return out;
}

module.exports = { zipWriter, csvOf, readZip };
