// The laptop as the clinic's own wifi. Windows' Mobile hotspot is switched on and off
// through hotspot.ps1, so tablets and phones join the laptop directly, with no router.
// The laptop's address on its own hotspot is always 192.168.137.1.
'use strict';
const { execFile } = require('child_process');
const path = require('path');

const HOTSPOT_IP = '192.168.137.1';
const SCRIPT = path.join(__dirname, 'hotspot.ps1');
let last = null, lastAt = 0, busy = null;

// Tests run on Linux with a pretend hotspot: CLINIC_HOTSPOT_STUB=1.
const stub = { state: 'Off', ssid: 'Apex PMS', passphrase: 'apex-2614-clinic', clients: 0 };
function runStub(action) {
  if (action === 'on') stub.state = 'On';
  if (action === 'off') { stub.state = 'Off'; stub.clients = 0; }
  if (action === 'join') stub.clients += 1;
  return { ok: true, supported: true, sharing: 'internet', network: 'Clinic router', state: stub.state, ssid: stub.ssid, passphrase: stub.passphrase, band: 'TwoPointFourGigahertz', clients: stub.clients, max: 8, devices: [], idleOff: false };
}

function run(action) {
  if (process.env.CLINIC_HOTSPOT_STUB) return Promise.resolve(runStub(action));
  if (process.platform !== 'win32') return Promise.resolve({ ok: false, supported: false, error: 'The hotspot works on a Windows branch PC.' });
  return new Promise(resolve => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', SCRIPT, action], { windowsHide: true, timeout: 45000 }, (err, stdout) => {
      const line = String(stdout || '').trim().split(/\r?\n/).pop();
      try { resolve(JSON.parse(line)); } catch (e) { resolve({ ok: false, supported: true, error: err ? err.message : 'No answer from Windows.' }); }
    });
  });
}

// One call at a time, since two PowerShells switching the hotspot would fight.
async function call(action) {
  while (busy) await busy.catch(() => {});
  busy = run(action);
  try { const r = await busy; last = { ...r, at: Date.now() }; lastAt = Date.now(); return last; } finally { busy = null; }
}
async function status(maxAge = 3000) { return last && Date.now() - lastAt < maxAge ? last : call('status'); }
const turn = on => call(on ? 'on' : 'off');
const openSettings = () => call('settings');

// Plain words for what went wrong.
function explain(r) {
  if (!r || r.ok) return '';
  const e = String(r.error || '');
  if (!r.supported) return e;
  if (e === 'NOPROFILE') return 'The hotspot needs the laptop joined to some network first, a router, a phone hotspot or a cable, even one with no internet.';
  if (e.startsWith('CAPABILITY:')) {
    const why = e.slice(11);
    return {
      DisabledByGroupPolicy: 'A Windows policy on this laptop blocks the hotspot.',
      DisabledByHardwareLimitation: 'This laptop\'s wifi card cannot run a hotspot.',
      DisabledByOperator: 'The network provider blocks sharing this connection.',
      DisabledBySku: 'This edition of Windows has no Mobile hotspot.',
      DisabledByRequiredAppNotInstalled: 'Windows needs an app it is missing to share this connection.',
      DisabledDueToUnknownCause: 'Windows will not start the hotspot on this connection.',
      DisabledBySystemCapability: 'Windows will not let programs control the hotspot here.',
    }[why] || `Windows will not start the hotspot (${why}).`;
  }
  if (e.startsWith('START:') || e.startsWith('STOP:')) {
    const why = e.split(':')[1];
    return {
      WiFiDeviceOff: 'Wifi is switched off on the laptop. Switch it on, then try again.',
      OperationInProgress: 'Windows is still switching the hotspot. Try again in a few seconds.',
      NetworkLimitedConnectivity: 'Windows will not share a connection that has limited connectivity. Join a network with internet, or use a cable.',
      BluetoothDeviceOff: 'Bluetooth is off, and Windows was set to share over Bluetooth. Change Share over to Wi-Fi in the hotspot settings.',
      RadioRestriction: 'Airplane mode or a radio switch is blocking wifi.',
      BadConfiguration: 'The hotspot name or password is not valid. Change them in the hotspot settings.',
    }[why] || `Windows could not ${e.startsWith('START') ? 'start' : 'stop'} the hotspot (${why}).`;
  }
  return 'Windows did not answer about the hotspot: ' + e;
}

// The wifi QR every phone camera reads: WIFI:T:WPA;S:name;P:password;;
function wifiQR(ssid, pass) {
  const q = s => String(s || '').replace(/([\\;,:"])/g, '\\$1');
  return `WIFI:T:WPA;S:${q(ssid)};P:${q(pass)};;`;
}

// Lets tablets reach the clinic's two ports through Windows Firewall on every kind of
// network, the hotspot included. Windows asks the person at the laptop to allow it.
function allowFirewall(ports) {
  if (process.env.CLINIC_HOTSPOT_STUB) return Promise.resolve({ ok: true });
  if (process.platform !== 'win32') return Promise.resolve({ ok: false, error: 'This is for a Windows branch PC.' });
  const list = ports.filter(Boolean).join(',');
  const name = `Apex PMS ${ports[0]}`;
  const cmd = `/c netsh advfirewall firewall delete rule name="${name}" >nul & netsh advfirewall firewall add rule name="${name}" dir=in action=allow protocol=TCP localport=${list} profile=any`;
  const ps = `try { Start-Process -FilePath cmd.exe -ArgumentList '${cmd.replace(/'/g, "''")}' -Verb RunAs -WindowStyle Hidden -Wait; 'OK' } catch { 'NO:' + $_.Exception.Message }`;
  return new Promise(resolve => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(ps, 'utf16le').toString('base64')], { windowsHide: true, timeout: 120000 }, (err, stdout) => {
      const out = String(stdout || '').trim();
      resolve(out.endsWith('OK') ? { ok: true } : { ok: false, error: /cancel/i.test(out) ? 'Windows was not allowed to change the firewall.' : (out.replace(/^NO:/, '') || (err && err.message) || 'No answer from Windows.') });
    });
  });
}

module.exports = { HOTSPOT_IP, status, turn, openSettings, explain, wifiQR, call, allowFirewall };
