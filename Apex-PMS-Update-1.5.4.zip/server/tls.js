// The secure address on the branch wifi. Browsers let a page use the camera and the
// microphone only over https (or on localhost), so the branch PC also serves the app over
// https.
//
// The PC makes its own small certificate authority once, the "Apex PMS local certificate".
// Each iPad and Android tablet installs it once from the tablet set-up page, and from then on
// the tablet trusts the PC's address with no warning: the camera, the microphone and Add to
// Home Screen all work. The PC signs a new address certificate with it whenever its addresses
// change, so the tablets never need the certificate again.
//
// Everything is built here from Node's own crypto, so nothing is installed.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ---------- DER, the encoding certificates use ----------
function len(n) {
  if (n < 0x80) return Buffer.from([n]);
  const b = []; while (n) { b.unshift(n & 0xff); n >>= 8; }
  return Buffer.from([0x80 | b.length, ...b]);
}
const tlv = (tag, body) => Buffer.concat([Buffer.from([tag]), len(body.length), body]);
const seq = (...items) => tlv(0x30, Buffer.concat(items));
const set = (...items) => tlv(0x31, Buffer.concat(items));
function oid(s) {
  const p = s.split('.').map(Number), out = [40 * p[0] + p[1]];
  for (const n of p.slice(2)) { const b = []; let v = n; b.unshift(v & 0x7f); v >>= 7; while (v) { b.unshift(0x80 | (v & 0x7f)); v >>= 7; } out.push(...b); }
  return tlv(0x06, Buffer.from(out));
}
function int(buf) { if (buf[0] & 0x80) buf = Buffer.concat([Buffer.from([0]), buf]); return tlv(0x02, buf); }
const utf8 = s => tlv(0x0c, Buffer.from(s, 'utf8'));
const nul = () => Buffer.from([0x05, 0x00]);
const bool = v => tlv(0x01, Buffer.from([v ? 0xff : 0x00]));
const octet = b => tlv(0x04, b);
function bits(bytes, unused = 0) { return tlv(0x03, Buffer.concat([Buffer.from([unused]), Buffer.from(bytes)])); }
function time(d) {
  const p = n => String(n).padStart(2, '0');
  const s = `${p(d.getUTCFullYear() % 100)}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}Z`;
  return d.getUTCFullYear() < 2050 ? tlv(0x17, Buffer.from(s)) : tlv(0x18, Buffer.from(String(d.getUTCFullYear()) + s.slice(2)));
}
const name = (cn, org = 'Apex Patient Management System') => seq(set(seq(oid('2.5.4.3'), utf8(cn))), set(seq(oid('2.5.4.10'), utf8(org))));
function ipBytes(ip) {
  if (ip.includes(':')) { const parts = ip.split('::'); const a = parts[0] ? parts[0].split(':') : [], b = parts[1] ? parts[1].split(':') : []; const all = [...a, ...Array(8 - a.length - b.length).fill('0'), ...b]; return Buffer.from(all.flatMap(h => { const v = parseInt(h || '0', 16); return [v >> 8, v & 0xff]; })); }
  return Buffer.from(ip.split('.').map(Number));
}
const ext = (id, critical, body) => (critical ? seq(oid(id), bool(true), octet(body)) : seq(oid(id), octet(body)));
const keyId = spki => crypto.createHash('sha1').update(spki).digest();
const sha256rsa = () => seq(oid('1.2.840.113549.1.1.11'), nul());
const pem = (label, der) => `-----BEGIN ${label}-----\n${der.toString('base64').match(/.{1,64}/g).join('\n')}\n-----END ${label}-----\n`;
const derOf = p => Buffer.from(String(p).replace(/-----[^-]+-----/g, '').replace(/\s+/g, ''), 'base64');
function signCert(tbs, key) { const sig = crypto.sign('sha256', tbs, key); return seq(tbs, sha256rsa(), tlv(0x03, Buffer.concat([Buffer.from([0]), sig]))); }

// The local certificate authority: valid 10 years, allowed to sign address certificates only.
function makeAuthority(label) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const spki = publicKey.export({ type: 'spki', format: 'der' });
  const now = new Date(Date.now() - 86400000), until = new Date(Date.now() + 3650 * 86400000);
  const subject = name(label);
  const exts = tlv(0xa3, seq(
    ext('2.5.29.19', true, seq(bool(true), int(Buffer.from([0])))), // a CA, no CA below it
    ext('2.5.29.15', true, bits([0x06], 1)), // keyCertSign, cRLSign
    ext('2.5.29.14', false, octet(keyId(spki))),
  ));
  const tbs = seq(tlv(0xa0, int(Buffer.from([2]))), int(crypto.randomBytes(16)), sha256rsa(), subject, seq(time(now), time(until)), subject, spki, exts);
  const der = signCert(tbs, privateKey);
  return { key: privateKey.export({ type: 'pkcs8', format: 'pem' }), cert: pem('CERTIFICATE', der), der };
}

// The address certificate, signed by the authority, for these host names and addresses.
// Valid 397 days, the longest iPads and browsers accept.
function makeCertificate(hosts, ips, ca) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const spki = publicKey.export({ type: 'spki', format: 'der' });
  const now = new Date(Date.now() - 86400000), until = new Date(Date.now() + 397 * 86400000);
  const caKey = crypto.createPrivateKey(ca.key);
  const caSpki = crypto.createPublicKey(caKey).export({ type: 'spki', format: 'der' });
  const san = seq(...hosts.map(h => tlv(0x82, Buffer.from(h))), ...ips.map(ip => tlv(0x87, ipBytes(ip))));
  const exts = tlv(0xa3, seq(
    ext('2.5.29.17', false, san),
    ext('2.5.29.19', true, seq()), // not a CA
    ext('2.5.29.15', true, bits([0xa0], 5)), // digitalSignature, keyEncipherment
    ext('2.5.29.37', false, seq(oid('1.3.6.1.5.5.7.3.1'))), // server auth
    ext('2.5.29.14', false, octet(keyId(spki))),
    ext('2.5.29.35', false, seq(tlv(0x80, keyId(caSpki)))),
  ));
  const tbs = seq(tlv(0xa0, int(Buffer.from([2]))), int(crypto.randomBytes(16)), sha256rsa(), ca.subject, seq(time(now), time(until)), name('Apex Patient Management System'), spki, exts);
  const der = signCert(tbs, caKey);
  return { key: privateKey.export({ type: 'pkcs8', format: 'pem' }), cert: pem('CERTIFICATE', der) };
}

// The authority in dataDir/tls, made once and kept. Its name carries the branch code so a
// tablet that visits two branches can tell the certificates apart.
function authorityFor(dataDir, branchCode = '') {
  const dir = path.join(dataDir, 'tls'), keyFile = path.join(dir, 'ca-key.pem'), certFile = path.join(dir, 'ca.pem');
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(keyFile) || !fs.existsSync(certFile)) {
    const label = `Apex PMS local certificate${branchCode ? ' ' + branchCode : ''}`;
    const a = makeAuthority(label);
    fs.writeFileSync(keyFile, a.key, { mode: 0o600 }); fs.writeFileSync(certFile, a.cert);
    for (const f of ['key.pem', 'cert.pem', 'names.json']) fs.rmSync(path.join(dir, f), { force: true });
  }
  const cert = fs.readFileSync(certFile, 'utf8');
  const der = derOf(cert);
  // The subject is read back from the certificate so the address certificate names the same issuer.
  const x = new crypto.X509Certificate(der);
  const cn = (x.subject.match(/CN=([^\n]+)/) || [])[1] || 'Apex PMS local certificate';
  return { key: fs.readFileSync(keyFile, 'utf8'), cert, der, subject: name(cn), label: cn, fingerprint: x.fingerprint256 };
}

// The key and certificate chain in dataDir/tls, made again when the PC's addresses are not
// all on it or it is close to running out.
function certificateFor(dataDir, ips, branchCode, hosts = []) {
  const ca = authorityFor(dataDir, branchCode);
  const names = [...new Set(['localhost', ...hosts])].sort();
  const dir = path.join(dataDir, 'tls'), keyFile = path.join(dir, 'key.pem'), certFile = path.join(dir, 'cert.pem'), infoFile = path.join(dir, 'names.json');
  const want = [...new Set(['127.0.0.1', ...ips])].sort();
  try {
    const had = JSON.parse(fs.readFileSync(infoFile, 'utf8'));
    if (want.every(ip => had.ips.includes(ip)) && names.every(n => (had.hosts || ['localhost']).includes(n)) && Date.now() - had.at < 360 * 86400000 && had.ca === ca.fingerprint) return { key: fs.readFileSync(keyFile), cert: fs.readFileSync(certFile, 'utf8') + ca.cert, made: false };
  } catch (e) { /* none yet */ }
  const c = makeCertificate(names, want, ca);
  fs.writeFileSync(keyFile, c.key, { mode: 0o600 }); fs.writeFileSync(certFile, c.cert); fs.writeFileSync(infoFile, JSON.stringify({ ips: want, hosts: names, at: Date.now(), ca: ca.fingerprint }));
  return { key: c.key, cert: c.cert + ca.cert, made: true };
}

// The configuration profile an iPad installs: the authority as a trusted root.
function mobileconfig(ca, branchName = '') {
  const uuid = () => crypto.randomUUID().toUpperCase();
  const id = 'th.co.apexmedicalcenter.pms.' + crypto.createHash('sha1').update(ca.der).digest('hex').slice(0, 12);
  const x = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadContent</key>
  <array>
    <dict>
      <key>PayloadCertificateFileName</key><string>apex-pms.cer</string>
      <key>PayloadContent</key><data>${ca.der.toString('base64')}</data>
      <key>PayloadDescription</key><string>Lets this iPad open the Apex Patient Management System securely on the branch wifi.</string>
      <key>PayloadDisplayName</key><string>${x(ca.label)}</string>
      <key>PayloadIdentifier</key><string>${id}.cert</string>
      <key>PayloadType</key><string>com.apple.security.root</string>
      <key>PayloadUUID</key><string>${uuid()}</string>
      <key>PayloadVersion</key><integer>1</integer>
    </dict>
  </array>
  <key>PayloadDescription</key><string>Installs the certificate of the Apex Patient Management System${branchName ? ' at ' + x(branchName) : ''}, so the camera and microphone work on this iPad.</string>
  <key>PayloadDisplayName</key><string>Apex Patient Management System</string>
  <key>PayloadIdentifier</key><string>${id}</string>
  <key>PayloadOrganization</key><string>Apex Medical Center</string>
  <key>PayloadRemovalDisallowed</key><false/>
  <key>PayloadType</key><string>Configuration</string>
  <key>PayloadUUID</key><string>${uuid()}</string>
  <key>PayloadVersion</key><integer>1</integer>
</dict>
</plist>
`;
}

module.exports = { makeAuthority, makeCertificate, authorityFor, certificateFor, mobileconfig };
