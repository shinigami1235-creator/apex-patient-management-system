// The large model files for the before and after picture tool: MediaPipe Pose for body points, and
// ONNX Runtime with ALIKED and LightGlue for the closer match, 53 MB in all. They stay out of the
// installer and the updates so those stay small. The first time a screen asks for one, the branch PC
// downloads it from the download page, checks its SHA-256 against the list below, keeps it in
// data/models and serves it from there. A file not on the list is never fetched.
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const BASE = process.env.CLINIC_MODELS_URL || 'https://raw.githubusercontent.com/shinigami1235-creator/apex-patient-management-system/main/models/';
// path: [size in bytes, SHA-256]
const FILES = {
  'mediapipe-pose/pose.js': [47089, 'fcb703afcce65d0a1c540f6a70c3bb45fc84521498c21a9d4160265dde648ab4'],
  'mediapipe-pose/pose_landmark_lite.tflite': [2819824, 'f17bfbecadb61c3be1baa8b8d851cc6619c870a87167b32848ad20db306b9d61'],
  'mediapipe-pose/pose_solution_packed_assets.data': [2962288, 'a63c614bef30d35947f13be361820b1e4e3bec9cfeebf4d11216a18373108e85'],
  'mediapipe-pose/pose_solution_packed_assets_loader.js': [8002, 'd7aa29b7d8e11b5c97a58d719e982dd15c2de72995d95112d60492b854840a36'],
  'mediapipe-pose/pose_solution_simd_wasm_bin.js': [276478, '3983d1dca31d945d81abb70b18dd61f28ef4736e112463d7cfb1cbadef588127'],
  'mediapipe-pose/pose_solution_simd_wasm_bin.wasm': [6104372, '195a929430e2ce130b3efb82e64ba27c8e68cb0f6bad870b715688060ea6f7e2'],
  'mediapipe-pose/pose_web.binarypb': [1007, 'dc8efd1c2d62007b34278467407fda5f70847f41310e0e39f0f59fc17b1d01f7'],
  'onnxruntime/ort-wasm-simd-threaded.mjs': [20856, '30dd851d9c00622940500f71ddd2ff8820c5cb65270816080175b958705385a8'],
  'onnxruntime/ort-wasm-simd-threaded.wasm': [11210254, '71aef04959c5c1b6de461b6538e2058e306610034a85aad2742d0c7fd4533fe4'],
  'onnxruntime/ort.wasm.min.js': [48327, '65e09376df69107e881b5c34d2d37aed333a366b6d941073ec518168e269b87d'],
  'aliked/aliked-extractor.onnx': [12522238, '7dfff8f0f7591f1cac38b27d39f9dd27c319491cb2300f570f54988efa321440'],
  'aliked/lightglue-matcher.onnx': [17143576, 'd1c1e826caab8796ea23ece17a2ce46a16368d67aac5e860f6e2bcc10c83f275']
};
const TYPES = { '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.wasm': 'application/wasm' };

let dir = null;
const fetching = new Map();
function init(dataDir) { dir = path.join(dataDir, 'models'); }

function good(file, want) {
  try {
    const st = fs.statSync(file);
    if (st.size !== want[0]) return false;
    return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') === want[1];
  } catch (e) { return false; }
}

// Downloads one file once, however many screens ask for it at the same time.
function fetchOnce(rel) {
  if (fetching.has(rel)) return fetching.get(rel);
  const want = FILES[rel], dest = path.join(dir, rel);
  const p = (async () => {
    let res;
    try { res = await fetch(BASE + rel, { signal: AbortSignal.timeout(10 * 60000) }); }
    catch (e) { throw new Error('The branch PC could not download ' + rel + '. Check its internet connection.'); }
    if (!res.ok) throw new Error('The download page answered ' + res.status + ' for ' + rel + '.');
    const body = Buffer.from(await res.arrayBuffer());
    if (body.length !== want[0] || crypto.createHash('sha256').update(body).digest('hex') !== want[1]) throw new Error(rel + ' came down different from the expected file, so it was not kept.');
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest + '.part', body);
    fs.renameSync(dest + '.part', dest);
  })();
  fetching.set(rel, p);
  p.finally(() => fetching.delete(rel)).catch(() => {});
  return p;
}

// GET /models/<folder>/<file>
async function serve(req, res, rel) {
  const want = FILES[rel];
  if (!want || !dir) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
  const file = path.join(dir, rel);
  if (!fs.existsSync(file) || fs.statSync(file).size !== want[0]) {
    try { await fetchOnce(rel); }
    catch (e) { res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end(e.message); }
  }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(rel)] || 'application/octet-stream', 'Content-Length': want[0], 'Cache-Control': 'public, max-age=604800' });
  fs.createReadStream(file).pipe(res);
}

// Which files the PC already holds, for a check that they came down whole.
function status() { return Object.keys(FILES).map(rel => ({ file: rel, size: FILES[rel][0], held: !!dir && good(path.join(dir, rel), FILES[rel]) })); }

module.exports = { init, serve, status, FILES };
